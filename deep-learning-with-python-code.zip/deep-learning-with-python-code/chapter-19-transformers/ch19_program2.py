# ch19_program2.py
# Positional encoding. Chapter 18 showed attention has no inherent
# sense of order. Part A builds the sinusoidal positional encoding and
# hand-checks the first few rows. Part B proves the point concretely:
# pool two tokens with a fixed query, once with plain content and once
# with positional encoding added, and see whether swapping which
# position holds which token changes the result.

import numpy as np


def positional_encoding(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe


d_model = 4
print("Part A: sinusoidal positional encoding, d_model=4")
PE = positional_encoding(6, d_model)
for pos in range(3):
    print(f"  PE(pos={pos}) = {PE[pos]}")
print(f"  ... (Program 2 computes up to pos=5; only the first 3 rows are shown here)")


def softmax(scores):
    w = np.exp(scores - scores.max())
    return w / w.sum()


def pool(keys, query, d_k):
    scores = keys @ query / np.sqrt(d_k)
    weights = softmax(scores)
    return weights @ keys, weights            # value_proj = identity, so values = keys


# ---------------------------------------------------------------
# Part B: does swapping which position holds which token change the
# pooled output? Without positional encoding, it provably cannot --
# the pooling sum does not care what order it is added in. With
# positional encoding added to each position, it does.
# ---------------------------------------------------------------
emb_X = np.array([1.0, 0.0, 1.0, 0.0])
emb_Y = np.array([0.0, 1.0, 0.0, 1.0])
query = np.array([3.0, 1.0, 0.0, 1.0])

seq_A_content = np.stack([emb_X, emb_Y])   # X at position 0, Y at position 1
seq_B_content = np.stack([emb_Y, emb_X])   # Y at position 0, X at position 1

print("\nPart B: swap X and Y's positions -- does the pooled output change?")

context_A, weights_A = pool(seq_A_content, query, d_model)
context_B, weights_B = pool(seq_B_content, query, d_model)
print("  WITHOUT positional encoding:")
print(f"    seq A = [X, Y]: weights={weights_A}, context={context_A}")
print(f"    seq B = [Y, X]: weights={weights_B}, context={context_B}")
print(f"    contexts identical? {np.allclose(context_A, context_B)}")

seq_A_with_pe = seq_A_content + PE[:2]
seq_B_with_pe = seq_B_content + PE[:2]
context_A_pe, weights_A_pe = pool(seq_A_with_pe, query, d_model)
context_B_pe, weights_B_pe = pool(seq_B_with_pe, query, d_model)
print("  WITH positional encoding added to each position:")
print(f"    seq A = [X, Y]: weights={weights_A_pe}, context={context_A_pe}")
print(f"    seq B = [Y, X]: weights={weights_B_pe}, context={context_B_pe}")
print(f"    contexts identical? {np.allclose(context_A_pe, context_B_pe)}")
