# ch19_program1.py
# Multi-head attention: split Q, K, V into several smaller heads, run
# scaled dot-product attention independently in each, then concatenate
# the results back together. For hand-tractability, Q, K, V below are
# given directly (as if already projected from some input) rather than
# derived through separate W_Q/W_K/W_V matrices, and the final output
# projection is left as identity -- Chapter 18 already covered
# projecting an input into Q/K/V, so this program isolates the one
# genuinely new idea: splitting into heads and concatenating back.

import numpy as np
import torch
import torch.nn.functional as F

d_model, num_heads = 4, 2
d_k = d_model // num_heads

Q = np.array([[1.0, 0.0, 1.0, 0.0],
              [0.0, 1.0, 0.0, 1.0]])
K = np.array([[1.0, 1.0, 0.0, 1.0],
              [1.0, 0.0, 1.0, 0.0]])
V = np.array([[1.0, 2.0, 3.0, 4.0],
              [5.0, 6.0, 7.0, 8.0]])

print("NumPy, one head at a time:")
head_outputs = []
for h in range(num_heads):
    Qh = Q[:, h * d_k:(h + 1) * d_k]
    Kh = K[:, h * d_k:(h + 1) * d_k]
    Vh = V[:, h * d_k:(h + 1) * d_k]

    scores = (Qh @ Kh.T) / np.sqrt(d_k)
    weights = np.exp(scores - scores.max(axis=1, keepdims=True))
    weights = weights / weights.sum(axis=1, keepdims=True)
    out_h = weights @ Vh

    print(f"  head {h}: scores=\n{scores}")
    print(f"  head {h}: weights=\n{weights}")
    print(f"  head {h}: output=\n{out_h}")
    head_outputs.append(out_h)

concatenated = np.concatenate(head_outputs, axis=1)
print(f"concatenated heads (output projection = identity for this example) =\n{concatenated}")

# ---------------------------------------------------------------
# Same computation with raw PyTorch tensor ops, all heads at once via
# a reshape instead of a Python loop -- the way a real implementation
# vectorizes it.
# ---------------------------------------------------------------
Q_t = torch.tensor(Q, dtype=torch.float32)
K_t = torch.tensor(K, dtype=torch.float32)
V_t = torch.tensor(V, dtype=torch.float32)

T = Q_t.shape[0]
Qh_t = Q_t.view(T, num_heads, d_k).transpose(0, 1)   # (num_heads, T, d_k)
Kh_t = K_t.view(T, num_heads, d_k).transpose(0, 1)
Vh_t = V_t.view(T, num_heads, d_k).transpose(0, 1)

scores_t = (Qh_t @ Kh_t.transpose(1, 2)) / np.sqrt(d_k)
weights_t = F.softmax(scores_t, dim=-1)
out_t = weights_t @ Vh_t                              # (num_heads, T, d_k)
concatenated_t = out_t.transpose(0, 1).reshape(T, d_model)

print("\nPyTorch, vectorized over heads:")
print(f"  concatenated heads =\n{concatenated_t.numpy()}")
