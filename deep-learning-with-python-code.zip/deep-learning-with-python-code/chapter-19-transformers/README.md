# Chapter 19 · Transformers

Code for Chapter 19 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 18](../chapter-18-attention-mechanisms/README.md) · [Chapter 20 →](../chapter-20-deep-learning-for-nlp/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 19.1.1 Program 1: Multi-Head Attention, by Hand and by Framework | Multi-head attention, by hand and by framework | [`ch19_program1.py`](ch19_program1.py) | [ch19_program1.txt](expected_output/ch19_program1.txt) | 2 s |
| 2 | 19.2.1 Program 2: Positional Encoding, and Proving It Matters | Positional encoding, and an exact proof that it is what gives attention a sense of order | [`ch19_program2.py`](ch19_program2.py) | [ch19_program2.txt](expected_output/ch19_program2.txt) | < 1 s |
| 3 | 19.3.1 Program 3: The Encoder Block, Verified Against the Framework | Assembling a Transformer encoder block and verifying it against `nn.TransformerEncoderLayer` | [`ch19_program3.py`](ch19_program3.py) | [ch19_program3.txt](expected_output/ch19_program3.txt) | 2 s |
| 4 | 19.5.1 Program 4: Does A Come Before B? A Trained Comparison | Does A come before B? A trained comparison, with and without positional encoding | [`ch19_program4.py`](ch19_program4.py) | [ch19_program4.txt](expected_output/ch19_program4.txt) | 33 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-19-transformers
python ch19_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch19_notebook.ipynb`](ch19_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, PyTorch.
