# ch19_program4.py
# The payoff: a "which came first" task that genuinely NEEDS order, not
# just content. Every sequence carries one A-marker and one B-marker at
# two random positions; the label is whether A occurs before B. Part A
# trains an attention-pooling model with and without positional encoding
# across sequence lengths. Part B looks directly at what the model can
# and cannot tell apart: take one sequence, build its "order-swapped
# twin" by swapping which position holds A and which holds B, and ask
# whether the two trained models can tell the twins apart at all.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


def positional_encoding(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe.astype(np.float32)


def make_batch(seq_len, n, rng):
    """Each sequence: one-hot [is_A, is_B, is_other] per position, with
    A and B placed at two distinct random positions. Target: 1 if A's
    position precedes B's, else 0."""
    X = np.zeros((n, seq_len, 3), dtype=np.float32)
    targets = np.zeros(n, dtype=np.float32)
    for idx in range(n):
        pos_a, pos_b = rng.choice(seq_len, size=2, replace=False)
        X[idx, :, 2] = 1.0
        X[idx, pos_a] = [1, 0, 0]
        X[idx, pos_b] = [0, 1, 0]
        targets[idx] = 1.0 if pos_a < pos_b else 0.0
    return torch.tensor(X), torch.tensor(targets)


class OrderModel(nn.Module):
    """Linear embedding, optional added positional encoding, then a
    single learned query attending over the sequence -- the same
    attention-pooling shape as Chapter 18's retriever, extended with an
    optional positional-encoding buffer."""

    def __init__(self, d_model=32, use_pe=False, max_len=200):
        super().__init__()
        self.embed = nn.Linear(3, d_model)
        self.use_pe = use_pe
        if use_pe:
            self.register_buffer("pe", torch.tensor(positional_encoding(max_len, d_model)))
        self.key_proj = nn.Linear(d_model, d_model)
        self.val_proj = nn.Linear(d_model, d_model)
        self.query = nn.Parameter(torch.randn(d_model))
        self.head = nn.Linear(d_model, 1)
        self.d_model = d_model

    def forward(self, x):
        T = x.shape[1]
        e = self.embed(x)
        if self.use_pe:
            e = e + self.pe[:T]
        K = self.key_proj(e)
        V = self.val_proj(e)
        scores = (K @ self.query) / self.d_model ** 0.5
        weights = torch.softmax(scores, dim=1)
        context = (weights.unsqueeze(-1) * V).sum(dim=1)
        return self.head(context).squeeze(-1)


def train_model(seq_len, use_pe, epochs=300):
    torch.manual_seed(0)
    model = OrderModel(use_pe=use_pe)
    opt = optim.Adam(model.parameters(), lr=0.02)
    rng = np.random.default_rng(seq_len)
    X_train, y_train = make_batch(seq_len, 1000, rng)
    loss_fn = nn.BCEWithLogitsLoss()
    for _ in range(epochs):
        opt.zero_grad()
        pred = model(X_train)
        loss = loss_fn(pred, y_train)
        loss.backward()
        opt.step()
    return model


def test_accuracy(model, seq_len, test_rng):
    X_test, y_test = make_batch(seq_len, 200, test_rng)
    with torch.no_grad():
        pred = torch.sigmoid(model(X_test))
        acc = ((pred > 0.5).float() == y_test).float().mean().item()
    return acc


# ---------------------------------------------------------------
# Part A: test accuracy vs sequence length, with and without
# positional encoding.
# ---------------------------------------------------------------
print("Part A: test accuracy on 'does A come before B?', by sequence length")
print(f"{'seq_len':>8}{'without_pe':>13}{'with_pe':>10}")
trained = {}
for seq_len in [10, 30, 50]:
    accs = {}
    for use_pe in [False, True]:
        model = train_model(seq_len, use_pe)
        test_rng = np.random.default_rng(seq_len + 1000)
        accs[use_pe] = test_accuracy(model, seq_len, test_rng)
        trained[(seq_len, use_pe)] = model
    print(f"{seq_len:8d}{accs[False]:13.4f}{accs[True]:10.4f}")

# ---------------------------------------------------------------
# Part B: order-swapped twins. Take one sequence, then build a twin
# that swaps which of the two marked positions holds A and which
# holds B -- same positions, same content elsewhere, opposite label.
# A model with no way to sense order must give the SAME prediction to
# both twins; the exact-identity argument from Program 2 predicts this
# should hold exactly, not just approximately.
# ---------------------------------------------------------------
seq_len = 30
pos_a, pos_b = 8, 19
twin1 = np.zeros((1, seq_len, 3), dtype=np.float32)
twin1[0, :, 2] = 1.0
twin1[0, pos_a] = [1, 0, 0]
twin1[0, pos_b] = [0, 1, 0]
twin2 = np.zeros((1, seq_len, 3), dtype=np.float32)
twin2[0, :, 2] = 1.0
twin2[0, pos_a] = [0, 1, 0]
twin2[0, pos_b] = [1, 0, 0]
twin1_t, twin2_t = torch.tensor(twin1), torch.tensor(twin2)

print(f"\nPart B: order-swapped twins, seq_len={seq_len}, markers at positions {pos_a} and {pos_b}")
print(f"  twin 1: A at {pos_a}, B at {pos_b}   (A before B is True)")
print(f"  twin 2: B at {pos_a}, A at {pos_b}   (A before B is False)")
for use_pe in [False, True]:
    model = trained[(seq_len, use_pe)]
    with torch.no_grad():
        p1 = torch.sigmoid(model(twin1_t)).item()
        p2 = torch.sigmoid(model(twin2_t)).item()
    print(f"  use_pe={use_pe!s:5s}: P(A before B | twin1)={p1:.4f}  "
          f"P(A before B | twin2)={p2:.4f}  difference={abs(p1 - p2):.6f}")
