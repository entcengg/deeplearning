# ch19_program3.py
# Assembling the full Transformer encoder block: multi-head self-attention
# (Program 1) wrapped in a residual connection and layer normalization,
# followed by a position-wise feed-forward network wrapped in its own
# residual connection and layer normalization. Built from scratch here,
# then verified -- by copying its weights across -- against PyTorch's own
# nn.TransformerEncoderLayer, so the two must compute exactly the same
# function if the by-hand version is correct.

import numpy as np
import torch
import torch.nn as nn

torch.manual_seed(0)


class TransformerEncoderBlock(nn.Module):
    """One encoder block: multi-head self-attention, then a feed-forward
    network, each wrapped in a residual connection and layer norm."""

    def __init__(self, d_model, num_heads, d_ff):
        super().__init__()
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        self.d_model = d_model
        self.W_Q = nn.Linear(d_model, d_model)
        self.W_K = nn.Linear(d_model, d_model)
        self.W_V = nn.Linear(d_model, d_model)
        self.W_O = nn.Linear(d_model, d_model)          # output projection, Fig. 19.1
        self.norm1 = nn.LayerNorm(d_model)
        self.ff1 = nn.Linear(d_model, d_ff)
        self.ff2 = nn.Linear(d_ff, d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x):
        T = x.shape[0]
        Q = self.W_Q(x).view(T, self.num_heads, self.d_k).transpose(0, 1)
        K = self.W_K(x).view(T, self.num_heads, self.d_k).transpose(0, 1)
        V = self.W_V(x).view(T, self.num_heads, self.d_k).transpose(0, 1)
        scores = (Q @ K.transpose(1, 2)) / self.d_k ** 0.5
        weights = torch.softmax(scores, dim=-1)
        heads = (weights @ V).transpose(0, 1).reshape(T, self.d_model)
        attn_out = self.W_O(heads)

        x = self.norm1(x + attn_out)                    # residual + layer norm
        ff_out = self.ff2(torch.relu(self.ff1(x)))
        x = self.norm2(x + ff_out)                       # residual + layer norm
        return x


d_model, num_heads, d_ff, T = 8, 2, 16, 4
mine = TransformerEncoderBlock(d_model, num_heads, d_ff)
reference = nn.TransformerEncoderLayer(d_model=d_model, nhead=num_heads,
                                        dim_feedforward=d_ff, dropout=0.0,
                                        activation="relu", batch_first=True,
                                        norm_first=False)

# Copy the from-scratch block's weights into PyTorch's own layer so both
# compute literally the same function. nn.MultiheadAttention packs
# W_Q, W_K, W_V into one in_proj_weight/in_proj_bias.
with torch.no_grad():
    reference.self_attn.in_proj_weight.copy_(
        torch.cat([mine.W_Q.weight, mine.W_K.weight, mine.W_V.weight], dim=0))
    reference.self_attn.in_proj_bias.copy_(
        torch.cat([mine.W_Q.bias, mine.W_K.bias, mine.W_V.bias], dim=0))
    reference.self_attn.out_proj.weight.copy_(mine.W_O.weight)
    reference.self_attn.out_proj.bias.copy_(mine.W_O.bias)
    reference.linear1.weight.copy_(mine.ff1.weight)
    reference.linear1.bias.copy_(mine.ff1.bias)
    reference.linear2.weight.copy_(mine.ff2.weight)
    reference.linear2.bias.copy_(mine.ff2.bias)
    reference.norm1.weight.copy_(mine.norm1.weight)
    reference.norm1.bias.copy_(mine.norm1.bias)
    reference.norm2.weight.copy_(mine.norm2.weight)
    reference.norm2.bias.copy_(mine.norm2.bias)

x = torch.randn(T, d_model)
out_mine = mine(x)
out_reference = reference(x.unsqueeze(0)).squeeze(0)     # batch_first needs a batch dim

print(f"Input shape:  {tuple(x.shape)}  (T={T} tokens, d_model={d_model})")
print(f"Output shape: {tuple(out_mine.shape)}  (unchanged -- a Transformer block preserves shape)")
print(f"\nFrom-scratch block, output =\n{out_mine.detach().numpy()}")
print(f"\nnn.TransformerEncoderLayer, output =\n{out_reference.detach().numpy()}")

max_diff = (out_mine - out_reference).abs().max().item()
print(f"\nmax abs difference = {max_diff:.2e}")
print(f"allclose (atol=1e-5)? {torch.allclose(out_mine, out_reference, atol=1e-5)}")
