# ch17_program3.py
# Do LSTM and GRU actually preserve gradients across time better than
# a plain RNN? A single backward pass through T=50 steps, measuring
# the gradient norm reaching each timestep's hidden state (cell state
# for the LSTM) -- the same experimental design as Chapter 16 Program
# 3 Part A, now repeated for all three cell types, first at default
# initialization and then with a standard practical initialization
# trick applied.

import torch
import torch.nn as nn

T, HIDDEN = 50, 20
CHECKPOINTS = [1, 10, 20, 30, 40, 50]


def gradient_norms(cell_type, gate_bias=0.0):
    # The SAME seed (0) is used both right before building the cell
    # (so every architecture starts from the "same" random draw of
    # its own weights) and again right before drawing the input
    # sequence (so all three architectures see the identical inputs).
    # This isolates the effect of the gating mechanism itself: any
    # difference in gradient decay below comes from architecture and
    # initialization, not from different random weights or inputs.
    torch.manual_seed(0)
    if cell_type == "RNN":
        cell = nn.RNNCell(1, HIDDEN)
    elif cell_type == "GRU":
        cell = nn.GRUCell(1, HIDDEN)
        with torch.no_grad():
            cell.bias_ih[HIDDEN:2 * HIDDEN] += gate_bias   # update gate z
    else:
        cell = nn.LSTMCell(1, HIDDEN)
        with torch.no_grad():
            cell.bias_ih[HIDDEN:2 * HIDDEN] += gate_bias   # forget gate f

    torch.manual_seed(0)
    xs = [torch.randn(1, 1) for _ in range(T)]

    h = torch.zeros(1, HIDDEN)
    c = torch.zeros(1, HIDDEN) if cell_type == "LSTM" else None
    states = []
    for x in xs:
        if cell_type == "LSTM":
            h, c = cell(x, (h, c))
            c.retain_grad()
            states.append(c)
        else:
            h = cell(x, h)
            h.retain_grad()
            states.append(h)

    target = torch.randn(1, HIDDEN)
    loss = ((states[-1] - target) ** 2).mean()
    loss.backward()
    return [states[t - 1].grad.norm().item() for t in CHECKPOINTS]


def print_table(title, biases):
    print(title)
    header = f"{'cell':>6}" + "".join(f"{t:>12d}" for t in CHECKPOINTS)
    print(header)
    for cell_type, bias in biases:
        norms = gradient_norms(cell_type, gate_bias=bias)
        row = f"{cell_type:>6}" + "".join(f"{n:12.2e}" for n in norms)
        print(row)
    print()


print(f"Gradient norm reaching each checkpoint timestep (T={T}, hidden={HIDDEN}).")
print("Columns are timesteps counted from the start of the sequence;")
print("a larger number at an early timestep means more gradient survived.\n")

print_table(
    "Default initialization (forget/update gate bias = 0, PyTorch's default):",
    [("RNN", 0.0), ("LSTM", 0.0), ("GRU", 0.0)],
)

print_table(
    "With forget/update gate bias = +2.0 (the standard initialization trick):",
    [("RNN", 0.0), ("LSTM", 2.0), ("GRU", 2.0)],
)
