# Chapter 17 · LSTM and GRU

Code for Chapter 17 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 16](../chapter-16-recurrent-neural-networks/README.md) · [Chapter 18 →](../chapter-18-attention-mechanisms/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 17.2.1 Program 1: An LSTM Cell's Forward Pass, by Hand and by Framework | An LSTM cell's forward pass, gate by gate, by hand and by framework | [`ch17_program1.py`](ch17_program1.py) | [ch17_program1.txt](expected_output/ch17_program1.txt) | 2 s |
| 2 | 17.3.1 Program 2: A GRU Cell's Forward Pass, by Hand and by Framework | A GRU cell's forward pass, gate by gate, by hand and by framework | [`ch17_program2.py`](ch17_program2.py) | [ch17_program2.txt](expected_output/ch17_program2.txt) | 2 s |
| 3 | 17.4.1 Program 3: Gradient Preservation, With and Without a Good Initialization | Gradient norm vs. timestep for RNN, LSTM, and GRU, at default initialization and with the forget/update-gate-bias trick | [`ch17_program3.py`](ch17_program3.py) | [ch17_program3.txt](expected_output/ch17_program3.txt) | 2 s |
| 4 | 17.5.1 Program 4: Counting and Timing the Three Cells | Parameter counts, multiply-adds and measured forward-plus-backward time for RNN, GRU and LSTM layers | [`ch17_program4.py`](ch17_program4.py) | [ch17_program4.txt](expected_output/ch17_program4.txt) | 6 s |
| 5 | 17.6.1 Program 5: One Task, Three Cells, Two Training Recipes | RNN, GRU and LSTM trained on the same long-range recall task, at default initialization and with the gate bias, under two training recipes | [`ch17_program5.py`](ch17_program5.py) | [ch17_program5.txt](expected_output/ch17_program5.txt) | 5 min |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-17-lstm-and-gru
python ch17_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch17_notebook.ipynb`](ch17_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, PyTorch.

## Notes

- Program 4's parameter and multiply-add counts match the book exactly; its timings are measured on your computer and will differ.
