# ch17_program1.py
# An LSTM cell's forward pass, computed gate by gate with NumPy (all
# scalars, for hand-tractability) and checked against PyTorch's
# nn.LSTMCell.

import numpy as np
import torch
import torch.nn as nn


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


# Scalar LSTM (input_size=1, hidden_size=1) so every gate is one number.
w_xf, w_hf, b_f = 0.5, 0.3, 0.1     # forget gate
w_xi, w_hi, b_i = 0.6, -0.2, 0.0    # input gate
w_xc, w_hc, b_c = 0.4, 0.25, -0.1   # candidate (uses tanh)
w_xo, w_ho, b_o = 0.3, 0.4, 0.2     # output gate

h, c = 0.0, 0.0   # h_0, c_0
xs = [1.0, -0.5]

print("NumPy, gate by gate:")
for t, x in enumerate(xs, start=1):
    f = sigmoid(w_xf * x + w_hf * h + b_f)
    i = sigmoid(w_xi * x + w_hi * h + b_i)
    g = np.tanh(w_xc * x + w_hc * h + b_c)
    o = sigmoid(w_xo * x + w_ho * h + b_o)
    c = f * c + i * g
    h = o * np.tanh(c)
    print(f"  t={t}: f={f:.4f} i={i:.4f} g={g:.4f} o={o:.4f}  ->  c={c:.4f} h={h:.4f}")

# ---------------------------------------------------------------
# Same computation with PyTorch's nn.LSTMCell. PyTorch stacks the 4
# gates, in the fixed order [input, forget, cell, output], along the
# first dimension of weight_ih (shape 4*hidden x input) and
# weight_hh (shape 4*hidden x hidden).
# ---------------------------------------------------------------
cell = nn.LSTMCell(input_size=1, hidden_size=1)
with torch.no_grad():
    cell.weight_ih.copy_(torch.tensor([[w_xi], [w_xf], [w_xc], [w_xo]]))
    cell.weight_hh.copy_(torch.tensor([[w_hi], [w_hf], [w_hc], [w_ho]]))
    cell.bias_ih.copy_(torch.tensor([b_i, b_f, b_c, b_o]))
    cell.bias_hh.zero_()

h_t = torch.zeros(1, 1)
c_t = torch.zeros(1, 1)
print("\nPyTorch nn.LSTMCell, step by step:")
for t, x in enumerate(xs, start=1):
    x_t = torch.tensor([[x]], dtype=torch.float32)
    h_t, c_t = cell(x_t, (h_t, c_t))
    print(f"  t={t}: c={c_t.item():.4f} h={h_t.item():.4f}")
