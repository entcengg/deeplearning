# ch17_program4.py
# What does gating cost? Part A: the closed-form parameter count for a
# plain RNN, a GRU and an LSTM layer, checked against layers actually
# instantiated in PyTorch. Part B: multiply-adds per timestep. Part C:
# measured wall-clock time of one forward+backward pass on the SAME input,
# reported as a ratio to the plain RNN (best of many trials; absolute
# times vary from machine to machine and run to run, ratios far less).

import time
import torch
import torch.nn as nn

torch.set_num_threads(1)     # one thread: steadier timings on a shared machine

BLOCKS = {"RNN": 1, "GRU": 3, "LSTM": 4}          # gate blocks stacked per layer
LAYER = {"RNN": nn.RNN, "GRU": nn.GRU, "LSTM": nn.LSTM}


def formula(kind, d, h):
    # k blocks, each: input weights (h x d), recurrent weights (h x h), and
    # PyTorch's TWO bias vectors (b_ih and b_hh), each of length h.
    return BLOCKS[kind] * (h * d + h * h + 2 * h)


def counted(kind, d, h):
    layer = LAYER[kind](input_size=d, hidden_size=h, batch_first=True)
    return sum(p.numel() for p in layer.parameters()), tuple(layer.weight_ih_l0.shape)


print("Part A: parameters of one recurrent layer (d = input size, h = hidden size)")
print(f"{'d':>4}{'h':>5}  {'cell':<5}{'formula':>9}{'counted':>9}   weight_ih shape")
for d, h in [(4, 8), (1, 16), (64, 256)]:
    for kind in ["RNN", "GRU", "LSTM"]:
        n_formula = formula(kind, d, h)
        n_counted, shape = counted(kind, d, h)
        assert n_formula == n_counted
        print(f"{d:4d}{h:5d}  {kind:<5}{n_formula:9d}{n_counted:9d}   {shape}")

d, h = 64, 256
print(f"\nSame d={d}, h={h}: LSTM/GRU = {formula('LSTM', d, h) / formula('GRU', d, h):.4f}"
      f" (= 4/3),  GRU/RNN = {formula('GRU', d, h) / formula('RNN', d, h):.1f},"
      f"  LSTM/RNN = {formula('LSTM', d, h) / formula('RNN', d, h):.1f}")

print("\nPart B: multiply-adds per timestep in the matrix products, k*h*(d+h)")
for kind in ["RNN", "GRU", "LSTM"]:
    print(f"  {kind:<5} d=4, h=8: {BLOCKS[kind] * 8 * (4 + 8):5d}"
          f"      d=64, h=256: {BLOCKS[kind] * 256 * (64 + 256):9d}")

print("\nPart C: forward+backward wall-clock on identical input, best of 15 trials")
print("(input batch x T x d; one thread; times in ms; ratio is relative to the RNN)")


def best_time_ms(kind, batch, T, d, h, trials=15):
    torch.manual_seed(0)
    layer = LAYER[kind](input_size=d, hidden_size=h, batch_first=True)
    x = torch.randn(batch, T, d)
    best = float("inf")
    for trial in range(trials + 2):                 # the first 2 runs are warm-up
        layer.zero_grad()
        start = time.perf_counter()
        out, _ = layer(x)
        out.pow(2).mean().backward()
        elapsed = time.perf_counter() - start
        if trial >= 2:
            best = min(best, elapsed)
    return 1000.0 * best


for batch, T, d, h in [(64, 50, 8, 16), (64, 50, 64, 256)]:
    print(f"\n  batch={batch}, T={T}, d={d}, h={h}")
    times = {kind: best_time_ms(kind, batch, T, d, h) for kind in ["RNN", "GRU", "LSTM"]}
    for kind in ["RNN", "GRU", "LSTM"]:
        print(f"    {kind:<5} {times[kind]:8.2f} ms   ratio to RNN = {times[kind] / times['RNN']:.2f}"
              f"   (parameter ratio {BLOCKS[kind]:.2f})")
    print(f"    LSTM / GRU time ratio = {times['LSTM'] / times['GRU']:.2f}"
          f"   (parameter ratio 1.33)")
