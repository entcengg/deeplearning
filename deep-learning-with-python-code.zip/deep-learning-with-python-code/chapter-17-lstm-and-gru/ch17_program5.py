# ch17_program5.py
# RNN vs. GRU vs. LSTM on the same long-range task: Chapter 16's
# recall-the-first-input task (hidden size 16, 200 full-batch epochs, 500
# training and 200 test sequences). Every cell type sees identical data.
# The gated cells are run twice: with PyTorch's default initialization and
# with this chapter's forget/update-gate bias of +2.0 (Program 3).
# Part A: Chapter 16's exact recipe, plain SGD at lr=0.5.
# Part B: Adam at lr=0.01 on longer sequences, three seeds per setting.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

HIDDEN = 16


def make_batch(seq_len, n_examples):
    seqs = np.random.choice([-1.0, 1.0], size=(n_examples, seq_len, 1)).astype(np.float32)
    labels = (seqs[:, 0, 0] > 0).astype(np.float32)
    return torch.tensor(seqs), torch.tensor(labels)


# Part A data: the same draws, in the same order, as Chapter 16 Program 3.
np.random.seed(0)
data = {L: (make_batch(L, 500), make_batch(L, 200)) for L in [5, 10, 20, 40]}
# Part B data: longer sequences, drawn once and shared by every model.
np.random.seed(1)
data_b = {L: (make_batch(L, 500), make_batch(L, 200)) for L in [20, 80, 160]}


class RecallNet(nn.Module):
    def __init__(self, kind, gate_bias=0.0):
        super().__init__()
        layer = {"RNN": nn.RNN, "GRU": nn.GRU, "LSTM": nn.LSTM}[kind]
        self.rnn = layer(input_size=1, hidden_size=HIDDEN, batch_first=True)
        self.head = nn.Linear(HIDDEN, 1)
        if gate_bias:
            # PyTorch gate order: GRU (r, z, n), LSTM (i, f, g, o) -- the
            # second block is the update gate z / the forget gate f.
            with torch.no_grad():
                self.rnn.bias_ih_l0[HIDDEN:2 * HIDDEN] += gate_bias

    def forward(self, x):
        _, h_n = self.rnn(x)
        if isinstance(h_n, tuple):        # the LSTM returns (h_n, c_n)
            h_n = h_n[0]
        return self.head(h_n.squeeze(0)).squeeze(-1)


def train_and_test(kind, seq_len, gate_bias=0.0, optimizer="sgd", seed=0, dataset=None):
    (X_train, y_train), (X_test, y_test) = (dataset or data)[seq_len]
    torch.manual_seed(seed)
    model = RecallNet(kind, gate_bias)
    if optimizer == "sgd":
        opt = optim.SGD(model.parameters(), lr=0.5)
    else:
        opt = optim.Adam(model.parameters(), lr=0.01)
    loss_fn = nn.BCEWithLogitsLoss()
    for epoch in range(200):
        opt.zero_grad()
        loss_fn(model(X_train), y_train).backward()
        opt.step()
    with torch.no_grad():
        preds = (torch.sigmoid(model(X_test)) > 0.5).float()
        return (preds == y_test).float().mean().item()


variants = [("RNN", 0.0), ("GRU", 0.0), ("LSTM", 0.0), ("GRU", 2.0), ("LSTM", 2.0)]
names = {v: v[0] + (f", bias +{v[1]:.0f}" if v[1] else ", default") for v in variants}

print("Part A: Chapter 16's recipe (SGD, lr=0.5), test accuracy (chance = 0.5)")
print(f"{'model':<18}{'params':>7}" + "".join(f"{'T=' + str(L):>8}" for L in [5, 10, 20, 40]))
for kind, b in variants:
    n_params = sum(p.numel() for p in RecallNet(kind, b).parameters())
    accs = [train_and_test(kind, L, b) for L in [5, 10, 20, 40]]
    print(f"{names[(kind, b)]:<18}{n_params:>7}" + "".join(f"{a:8.3f}" for a in accs))

print("\nPart B: Adam (lr=0.01); mean test accuracy over seeds 0-2,")
print("and in brackets how many of the 3 runs solved the task (accuracy >= 0.95)")
print(f"{'model':<18}" + "".join(f"{'T=' + str(L):>12}" for L in [20, 80, 160]))
for kind, b in variants:
    cells = ""
    for L in [20, 80, 160]:
        accs = [train_and_test(kind, L, b, "adam", seed, data_b) for seed in range(3)]
        cells += f"{np.mean(accs):8.3f} [{sum(a >= 0.95 for a in accs)}]"
    print(f"{names[(kind, b)]:<18}" + cells)
