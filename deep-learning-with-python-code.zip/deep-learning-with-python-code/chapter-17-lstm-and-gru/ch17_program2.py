# ch17_program2.py
# A GRU cell's forward pass, computed gate by gate with NumPy (all
# scalars, for hand-tractability) and checked against PyTorch's
# nn.GRUCell.

import numpy as np
import torch
import torch.nn as nn


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


# Scalar GRU (input_size=1, hidden_size=1) so every gate is one number.
w_ir, w_hr, b_ir, b_hr = 0.5, 0.2, 0.1, 0.0     # reset gate
w_iz, w_hz, b_iz, b_hz = 0.4, 0.3, -0.1, 0.0    # update gate
w_in, w_hn, b_in, b_hn = 0.6, -0.3, 0.2, 0.1    # candidate ("new") gate

h = 0.0
xs = [1.0, -0.5]

print("NumPy, gate by gate:")
for t, x in enumerate(xs, start=1):
    r = sigmoid(w_ir * x + b_ir + w_hr * h + b_hr)
    z = sigmoid(w_iz * x + b_iz + w_hz * h + b_hz)
    n = np.tanh(w_in * x + b_in + r * (w_hn * h + b_hn))
    h = (1 - z) * n + z * h
    print(f"  t={t}: r={r:.4f} z={z:.4f} n={n:.4f}  ->  h={h:.4f}")

# ---------------------------------------------------------------
# Same computation with PyTorch's nn.GRUCell. PyTorch stacks the 3
# gates, in the fixed order [reset, update, new], along the first
# dimension of weight_ih (shape 3*hidden x input) and weight_hh
# (shape 3*hidden x hidden).
# ---------------------------------------------------------------
cell = nn.GRUCell(input_size=1, hidden_size=1)
with torch.no_grad():
    cell.weight_ih.copy_(torch.tensor([[w_ir], [w_iz], [w_in]]))
    cell.weight_hh.copy_(torch.tensor([[w_hr], [w_hz], [w_hn]]))
    cell.bias_ih.copy_(torch.tensor([b_ir, b_iz, b_in]))
    cell.bias_hh.copy_(torch.tensor([b_hr, b_hz, b_hn]))

h_t = torch.zeros(1, 1)
print("\nPyTorch nn.GRUCell, step by step:")
for t, x in enumerate(xs, start=1):
    x_t = torch.tensor([[x]], dtype=torch.float32)
    h_t = cell(x_t, h_t)
    print(f"  t={t}: h={h_t.item():.4f}")
