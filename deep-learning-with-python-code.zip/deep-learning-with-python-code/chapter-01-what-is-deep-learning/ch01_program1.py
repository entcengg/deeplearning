# ch01_program1.py
# The smallest possible learning loop: one weight learns to double a number.

import numpy as np

# Training data: four inputs and the answers we want the model to produce.
x = np.array([1.0, 2.0, 3.0, 4.0])   # inputs
y = np.array([2.0, 4.0, 6.0, 8.0])   # desired outputs (each is 2 times x)

w = 0.0            # the single weight, starting with no knowledge at all
learning_rate = 0.05
epochs = 10        # one epoch = one pass through all four examples

print(f"{'epoch':>5} {'loss':>12} {'weight after update':>20}")
for epoch in range(1, epochs + 1):
    y_hat = w * x                              # step 1: predict
    loss = np.mean((y - y_hat) ** 2)           # step 2: measure the error
    gradient = 2 * np.mean(x * (y_hat - y))    # step 3: find the slope of the loss
    w = w - learning_rate * gradient           # step 4: adjust the weight
    print(f"{epoch:>5} {loss:>12.6f} {w:>20.6f}")

# Use the trained weight on an input the model has never seen.
print(f"\nPrediction for x = 5: {w * 5:.5f}  (true answer: 10)")
