# Chapter 10 · Backpropagation

Code for Chapter 10 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 9](../chapter-09-forward-propagation-and-multilayer-networks/README.md) · [Chapter 11 →](../chapter-11-gradient-descent-and-optimizers/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 10.3 Program 1: Verifying the Worked Example | The 2-2-1 network's full forward and backward pass, checked against a numerical gradient | [`ch10_program1.py`](ch10_program1.py) | [ch10_program1.txt](expected_output/ch10_program1.txt) | < 1 s |
| 2 | 10.5 Program 2: Backpropagation for Any Depth | General backpropagation, verified by gradient checking on a 3-layer network | [`ch10_program2.py`](ch10_program2.py) | [ch10_program2.txt](expected_output/ch10_program2.txt) | < 1 s |
| 3 | 10.7 Learning XOR From Scratch | Learning XOR with no hand-designed weights at all | [`ch10_program3.py`](ch10_program3.py) | [ch10_program3.txt](expected_output/ch10_program3.txt) | < 1 s |
| 4 | 10.8 When It Doesn't Work | The same training code, a different seed | [`ch10_program4.py`](ch10_program4.py) | [ch10_program4.txt](expected_output/ch10_program4.txt) | < 1 s |
| 5 | 10.9 Measuring Backpropagation's Speedup Directly | Timing one backprop call against the full numerical gradient, on the same network | [`ch10_program5.py`](ch10_program5.py) | [ch10_program5.txt](expected_output/ch10_program5.txt) | < 1 s |
| 6 | 10.10 Gradient Checking Catches a Real Bug | Gradient checking catches a deliberately planted bug | [`ch10_program6.py`](ch10_program6.py) | [ch10_program6.txt](expected_output/ch10_program6.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-10-backpropagation
python ch10_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch10_notebook.ipynb`](ch10_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.

## Notes

- The book prints only the part of Program 4 that is new (training with seed 4, then looking at what each hidden neuron learned); the rest is Program 3's code, and `ch10_program4.py` is the complete program, ready to run.
- Program 5 times backpropagation on your computer, so the milliseconds and the speedup will differ from the book; backpropagation should still win by a factor of thousands.
