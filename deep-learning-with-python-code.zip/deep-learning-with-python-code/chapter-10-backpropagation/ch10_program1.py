# ch10_program1.py
# Backpropagation through a tiny 2-2-1 network, worked in full: forward
# pass, backward pass, and a numerical gradient check on every parameter.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

x = np.array([0.5, 0.2])
y = 1.0

W1 = np.array([[0.3, -0.1], [0.2, 0.4]])   # hidden layer: 2 neurons, 2 inputs
b1 = np.array([0.1, -0.2])
W2 = np.array([[0.5, -0.3]])               # output layer: 1 neuron, 2 inputs
b2 = np.array([0.2])

# --- Forward pass (Chapter 9) ---
z1 = W1 @ x + b1
a1 = sigmoid(z1)
z2 = W2 @ a1 + b2
a2 = sigmoid(z2)
loss = bce(y, a2[0])
print(f"z1={z1}  a1={a1}")
print(f"z2={z2}  a2 (y_hat)={a2}")
print(f"loss = {loss:.6f}")

# --- Backward pass ---
delta2 = a2 - y                    # Chapter 8's clean BCE+sigmoid result
dW2 = np.outer(delta2, a1)
db2 = delta2

dL_da1 = W2.T @ delta2             # spread the output error back across hidden units
delta1 = dL_da1 * sigmoid_prime(z1)
dW1 = np.outer(delta1, x)
db1 = delta1

print(f"\ndelta2 = {delta2}")
print(f"dW2 = {dW2}")
print(f"db2 = {db2}")
print(f"delta1 = {delta1}")
print(f"dW1 = {dW1}")
print(f"db1 = {db1}")

# --- Gradient check: perturb each parameter, compare to a central difference ---
def full_loss(W1, b1, W2, b2):
    a1 = sigmoid(W1 @ x + b1)
    a2 = sigmoid(W2 @ a1 + b2)
    return bce(y, a2[0])

h = 1e-5
def numeric_grad(param, shape):
    grad = np.zeros(shape)
    it = np.nditer(np.zeros(shape), flags=["multi_index"])
    for _ in it:
        idx = it.multi_index
        orig = param[idx]
        param[idx] = orig + h
        loss_plus = full_loss(W1, b1, W2, b2)
        param[idx] = orig - h
        loss_minus = full_loss(W1, b1, W2, b2)
        param[idx] = orig
        grad[idx] = (loss_plus - loss_minus) / (2 * h)
    return grad

dW1_num = numeric_grad(W1, W1.shape)
dW2_num = numeric_grad(W2, W2.shape)
print(f"\ndW1 numeric = {dW1_num}")
print(f"dW2 numeric = {dW2_num}")
print(f"max |analytical - numeric| = {max(np.abs(dW1-dW1_num).max(), np.abs(dW2-dW2_num).max()):.2e}")
