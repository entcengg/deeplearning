# ch10_program5.py
# Measuring backpropagation's speedup directly, instead of just asserting
# it: time ONE backprop call against the FULL numerical-differentiation
# gradient (2 forward passes per parameter) on the exact same network.

import time
import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

def relu(z):
    return np.maximum(0, z)

def relu_prime(z):
    return (z > 0).astype(float)

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

def forward(x, layers):
    a = x
    cache = [(None, a)]
    for W, b, phi, _ in layers:
        z = W @ a + b
        a = phi(z)
        cache.append((z, a))
    return a, cache

def backward(y, layers, cache):
    L = len(layers)
    grads = [None] * L
    a_L = cache[L][1]
    delta = a_L - y
    for l in range(L - 1, -1, -1):
        W, b, phi, phi_prime = layers[l]
        a_prev = cache[l][1]
        grads[l] = (np.outer(delta, a_prev), delta.copy())
        if l > 0:
            z_prev = cache[l][0]
            prev_phi_prime = layers[l - 1][3]
            delta = (W.T @ delta) * prev_phi_prime(z_prev)
    return grads

# A moderately sized network -- still tiny by deep-learning standards, but
# large enough that the two approaches' costs are clearly distinguishable.
rng = np.random.default_rng(0)
sizes = [20, 50, 50, 10]
layers = []
for n_in, n_out, act in zip(sizes[:-1], sizes[1:], [relu, relu, sigmoid]):
    W = rng.normal(0, 0.3, (n_out, n_in))
    b = rng.normal(0, 0.1, n_out)
    phi_prime = relu_prime if act is relu else sigmoid_prime
    layers.append((W, b, act, phi_prime))

x = rng.normal(0, 1, sizes[0])
y = 1.0
n_params = sum(W.size + b.size for W, b, _, _ in layers)
print(f"network sizes={sizes}, total parameters={n_params}")

# Time backpropagation: average over many repeated calls for a stable read.
reps = 500
t0 = time.perf_counter()
for _ in range(reps):
    output, cache = forward(x, layers)
    grads = backward(y, layers, cache)
t_backprop = (time.perf_counter() - t0) / reps
print(f"one backprop call (forward+backward), averaged over {reps} runs: "
      f"{t_backprop * 1000:.4f} ms")

# Time the FULL numerical gradient: 2 forward passes PER parameter (weights
# and biases), exactly Chapter 10's gradient-checking procedure, with
# nothing skipped.
def full_loss(layers):
    a, _ = forward(x, layers)
    return bce(y, a[0])

h = 1e-5
t0 = time.perf_counter()
n_forward_passes = 0
for (W, b, phi, phi_prime) in layers:
    for i in range(W.shape[0]):
        for j in range(W.shape[1]):
            orig = W[i, j]
            W[i, j] = orig + h; full_loss(layers); n_forward_passes += 1
            W[i, j] = orig - h; full_loss(layers); n_forward_passes += 1
            W[i, j] = orig
    for i in range(b.shape[0]):
        orig = b[i]
        b[i] = orig + h; full_loss(layers); n_forward_passes += 1
        b[i] = orig - h; full_loss(layers); n_forward_passes += 1
        b[i] = orig
t_numerical = time.perf_counter() - t0
print(f"full numerical gradient ({n_forward_passes} forward passes): "
      f"{t_numerical * 1000:.2f} ms")

print(f"\nmeasured speedup: backprop is {t_numerical / t_backprop:.0f}x faster "
      f"on this {n_params}-parameter network")
print("(numerical differentiation needs 2 forward passes PER parameter, so")
print(" its cost grows linearly with every parameter added; backprop's cost")
print(" barely changes at all -- the gap above only widens on a larger network.)")
