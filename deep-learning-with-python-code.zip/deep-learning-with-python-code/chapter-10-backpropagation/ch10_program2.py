# ch10_program2.py
# General backpropagation for a network of ANY depth, verified with
# gradient checking on a 3-layer network.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

def relu(z):
    return np.maximum(0, z)

def relu_prime(z):
    return (z > 0).astype(float)

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

def forward(x, layers):
    """layers: list of (W, b, activation, activation_prime). Returns the
    output and a cache of every layer's (z, a), needed by backward()."""
    a = x
    cache = [(None, a)]           # layer 0 has no z
    for W, b, phi, _ in layers:
        z = W @ a + b
        a = phi(z)
        cache.append((z, a))
    return a, cache

def backward(y, layers, cache):
    """Returns a list of (dW, db) per layer, computed by the chain rule
    working backward from the output."""
    L = len(layers)
    grads = [None] * L
    a_L = cache[L][1]
    delta = a_L - y                          # true only for BCE/CCE + sigmoid/softmax output
    for l in range(L - 1, -1, -1):
        W, b, phi, phi_prime = layers[l]
        a_prev = cache[l][1]
        grads[l] = (np.outer(delta, a_prev), delta.copy())
        if l > 0:
            z_prev = cache[l][0]
            prev_phi_prime = layers[l - 1][3]
            delta = (W.T @ delta) * prev_phi_prime(z_prev)
    return grads

# A 3-layer network: 3 -> 4 (ReLU) -> 3 (ReLU) -> 1 (sigmoid)
rng = np.random.default_rng(0)
sizes = [3, 4, 3, 1]
layers = []
for n_in, n_out, act in zip(sizes[:-1], sizes[1:], [relu, relu, sigmoid]):
    W = rng.normal(0, 0.5, (n_out, n_in))
    b = rng.normal(0, 0.1, n_out)
    phi_prime = relu_prime if act is relu else sigmoid_prime
    layers.append((W, b, act, phi_prime))

x = np.array([1.0, -0.5, 0.3])
y = 1.0

output, cache = forward(x, layers)
grads = backward(y, layers, cache)
print("output:", output)
for i, (dW, db) in enumerate(grads, start=1):
    print(f"layer {i}: dW shape {dW.shape}, db shape {db.shape}")

# Gradient check every weight in every layer.
def full_loss(layers):
    a, _ = forward(x, layers)
    return bce(y, a[0])

h = 1e-5
worst = 0.0
for li, (W, b, phi, phi_prime) in enumerate(layers):
    dW_analytical, _ = grads[li]
    dW_numeric = np.zeros_like(W)
    for i in range(W.shape[0]):
        for j in range(W.shape[1]):
            orig = W[i, j]
            W[i, j] = orig + h
            loss_plus = full_loss(layers)
            W[i, j] = orig - h
            loss_minus = full_loss(layers)
            W[i, j] = orig
            dW_numeric[i, j] = (loss_plus - loss_minus) / (2 * h)
    err = np.max(np.abs(dW_numeric - dW_analytical))
    worst = max(worst, err)
    print(f"layer {li+1}: max |analytical - numeric| = {err:.2e}")
print(f"\nworst error across the whole network: {worst:.2e}")
