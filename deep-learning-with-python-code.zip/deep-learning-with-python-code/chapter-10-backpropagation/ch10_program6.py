# ch10_program6.py
# Gradient checking catching a real, deliberately-planted bug: Mistake 3's
# "using the wrong activation's derivative" (sigmoid_prime swapped in for
# relu_prime by a copy-paste error), on the exact 3-layer network from
# Program 2.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

def relu(z):
    return np.maximum(0, z)

def relu_prime(z):
    return (z > 0).astype(float)

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

def forward(x, layers):
    a = x
    cache = [(None, a)]
    for W, b, phi, _ in layers:
        z = W @ a + b
        a = phi(z)
        cache.append((z, a))
    return a, cache

def backward(y, layers, cache):
    L = len(layers)
    grads = [None] * L
    a_L = cache[L][1]
    delta = a_L - y
    for l in range(L - 1, -1, -1):
        W, b, phi, phi_prime = layers[l]
        a_prev = cache[l][1]
        grads[l] = (np.outer(delta, a_prev), delta.copy())
        if l > 0:
            z_prev = cache[l][0]
            prev_phi_prime = layers[l - 1][3]
            delta = (W.T @ delta) * prev_phi_prime(z_prev)
    return grads

# The exact same weights, biases, and architecture as Program 2.
rng = np.random.default_rng(0)
sizes = [3, 4, 3, 1]
Ws, bs = [], []
for n_in, n_out in zip(sizes[:-1], sizes[1:]):
    Ws.append(rng.normal(0, 0.5, (n_out, n_in)))
    bs.append(rng.normal(0, 0.1, n_out))
activations = [relu, relu, sigmoid]

def make_layers(phi_primes):
    return [(Ws[i], bs[i], activations[i], phi_primes[i]) for i in range(3)]

correct_primes = [relu_prime, relu_prime, sigmoid_prime]
buggy_primes = [sigmoid_prime, relu_prime, sigmoid_prime]   # layer 1's derivative swapped

x = np.array([1.0, -0.5, 0.3])
y = 1.0

def full_loss(layers):
    a, _ = forward(x, layers)
    return bce(y, a[0])

def gradient_check(layers, h=1e-5):
    _, cache = forward(x, layers)
    grads = backward(y, layers, cache)
    worst, worst_layer = 0.0, None
    for li, (W, b, phi, phi_prime) in enumerate(layers):
        dW_analytical, _ = grads[li]
        dW_numeric = np.zeros_like(W)
        for i in range(W.shape[0]):
            for j in range(W.shape[1]):
                orig = W[i, j]
                W[i, j] = orig + h; loss_plus = full_loss(layers)
                W[i, j] = orig - h; loss_minus = full_loss(layers)
                W[i, j] = orig
                dW_numeric[i, j] = (loss_plus - loss_minus) / (2 * h)
        rel_err = np.abs(dW_numeric - dW_analytical) / (
            np.abs(dW_numeric) + np.abs(dW_analytical) + 1e-12)
        err = rel_err.max()
        print(f"  layer {li + 1}: max relative error = {err:.2e}")
        if err > worst:
            worst, worst_layer = err, li + 1
    return worst, worst_layer

print("Correct implementation (relu_prime on the two ReLU layers):")
worst, layer = gradient_check(make_layers(correct_primes))
print(f"  -> worst relative error: {worst:.2e}, at layer {layer} (passes; below 1e-5)\n")

print("Buggy implementation (layer 1's relu_prime replaced by sigmoid_prime,")
print("a one-line copy-paste error -- shapes still match, so nothing crashes):")
worst, layer = gradient_check(make_layers(buggy_primes))
print(f"  -> worst relative error: {worst:.2e}, at layer {layer} -- FAILS gradient checking")
