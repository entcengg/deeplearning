# ch10_program3.py
# Learning XOR from scratch: no hand-designed weights, just random
# initialization, backpropagation, and gradient descent.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

def train_xor_network(seed, epochs, lr=1.0, n_hidden=2, report_at=()):
    rng = np.random.default_rng(seed)
    W1 = rng.normal(0, 1, (n_hidden, 2))
    b1 = np.zeros(n_hidden)
    W2 = rng.normal(0, 1, (1, n_hidden))
    b2 = np.zeros(1)

    for epoch in range(1, epochs + 1):
        dW1_sum = np.zeros_like(W1); db1_sum = np.zeros_like(b1)
        dW2_sum = np.zeros_like(W2); db2_sum = np.zeros_like(b2)
        total_loss = 0.0
        for x, y in zip(X, Y):
            z1 = W1 @ x + b1; a1 = sigmoid(z1)
            z2 = W2 @ a1 + b2; a2 = sigmoid(z2)
            total_loss += bce(y, a2[0])

            delta2 = a2 - y
            dW2_sum += np.outer(delta2, a1); db2_sum += delta2
            delta1 = (W2.T @ delta2) * sigmoid_prime(z1)
            dW1_sum += np.outer(delta1, x); db1_sum += delta1

        m = len(X)
        W1 -= lr * dW1_sum / m; b1 -= lr * db1_sum / m
        W2 -= lr * dW2_sum / m; b2 -= lr * db2_sum / m

        if epoch in report_at:
            print(f"  epoch {epoch:>5}: loss = {total_loss/m:.4f}")

    predictions = []
    for x in X:
        a1 = sigmoid(W1 @ x + b1)
        a2 = sigmoid(W2 @ a1 + b2)
        predictions.append(a2[0])
    return (W1, b1, W2, b2), predictions

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
Y = np.array([0, 1, 1, 0], dtype=float)

print("Training a 2-2-1 network on XOR from random initialization (seed=0):")
checkpoints = {1, 10, 100, 500, 1000, 2000, 5000}
(W1, b1, W2, b2), preds = train_xor_network(seed=0, epochs=5000, report_at=checkpoints)

print(f"\nfinal predictions: {[round(float(p), 4) for p in preds]}")
print(f"true labels:       {[float(v) for v in Y]}")
print(f"\nlearned W1 =\n{W1}")
print(f"learned b1 = {b1}")
print(f"learned W2 = {W2}")
print(f"learned b2 = {b2}")
