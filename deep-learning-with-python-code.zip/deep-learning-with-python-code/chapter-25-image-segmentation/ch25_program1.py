# ch25_program1.py
# Building pixel-level ground truth. Chapter 24 built synthetic scenes (1 or 2
# handwritten-digit sprites pasted onto a 32x32 canvas) and labeled each object
# with a bounding box. Segmentation needs a stricter answer: not just where an
# object roughly is, but which INDIVIDUAL PIXELS belong to it. Since a sprite's
# own grayscale values are already real ink intensities, "foreground" is
# defined the simplest possible way -- any pixel with nonzero ink -- so the
# mask traces the digit's actual handwritten stroke shape, not a rectangle.

import numpy as np
from sklearn.datasets import load_digits

CANVAS = 32
CELL = 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 11   # 0 = background, 1-10 = digits 0-9 (class label = digit + 1)

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    """Same scene construction as Chapter 24: 1 or 2 non-overlapping digit
    sprites on a blank canvas. The ground truth is now a per-pixel mask
    instead of a box: mask[y,x] = 0 (background) or digit_label+1."""
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    mask = np.zeros((CANVAS, CANVAS), dtype=np.int64)   # 0 = background
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        foreground = sprite > 0.0                 # any pixel with real ink
        patch = mask[y1:y2, x1:x2]
        patch[foreground] = label + 1              # class label = digit + 1
        mask[y1:y2, x1:x2] = patch
    return canvas, mask, placed


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, masks = [], []
    for _ in range(n_images):
        c, m, _ = make_one_image(rng)
        images.append(c); masks.append(m)
    return np.stack(images), np.stack(masks)


if __name__ == "__main__":
    train_images, train_masks = make_dataset(1200, seed=0)
    test_images, test_masks = make_dataset(300, seed=1)

    total_train_pixels = train_masks.size
    bg_train_pixels = int((train_masks == 0).sum())
    fg_train_pixels = total_train_pixels - bg_train_pixels
    print(f"Training set: {len(train_images)} images, {total_train_pixels} pixels total")
    print(f"  background pixels: {bg_train_pixels} ({100*bg_train_pixels/total_train_pixels:.2f}%)")
    print(f"  foreground (digit) pixels: {fg_train_pixels} ({100*fg_train_pixels/total_train_pixels:.2f}%)")

    total_test_pixels = test_masks.size
    bg_test_pixels = int((test_masks == 0).sum())
    print(f"Test set: {len(test_images)} images, {total_test_pixels} pixels total, "
          f"background {100*bg_test_pixels/total_test_pixels:.2f}%")

    # A fully worked example: one placed digit's own 8x8 (or 16x16) patch,
    # its raw intensities, and the binary foreground mask derived from them.
    rng = np.random.RandomState(0)
    _, _, placed = make_one_image(rng)   # first training image, same seed=0 stream
    label, x1, y1, x2, y2, gi, gj, sprite = placed[0]
    print(f"\nWorked example -- training image #0, first placed object:")
    print(f"  digit label={label}  box=({x1},{y1},{x2},{y2})  size={x2-x1}x{y2-y1}")
    print(f"  sprite intensities (rows are pixel rows within the sprite):")
    for row in sprite[:min(4, sprite.shape[0])]:
        print("   ", " ".join(f"{v:.2f}" for v in row[:min(8, sprite.shape[1])]))
    print("  ... (truncated for display)" if sprite.shape[0] > 4 or sprite.shape[1] > 8 else "")
    foreground = sprite > 0.0
    print(f"  foreground pixel count in this sprite: {int(foreground.sum())} / {sprite.size} "
          f"({100*foreground.sum()/sprite.size:.1f}%)")
    print(f"  mask value assigned to foreground pixels: {label + 1} (= digit label + 1)")

    # Confirm the mask array written into the full canvas matches this exactly.
    canvas0, mask0, placed0 = make_one_image(np.random.RandomState(0))
    written_fg = int((mask0[y1:y2, x1:x2] == label + 1).sum())
    print(f"  foreground pixels found at that location in the full 32x32 mask: {written_fg} "
          f"(should match {int(foreground.sum())})")
