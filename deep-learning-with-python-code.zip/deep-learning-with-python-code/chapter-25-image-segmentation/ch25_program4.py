# ch25_program4.py
# Training TinyUNet on the pixel-mask dataset, with and without skip
# connections, and comparing them on three metrics: pixel accuracy, mean
# IoU (mIoU) across classes, and mean Dice score -- not just one number,
# since (as Program 5 shows) pixel accuracy alone can look fine while mIoU
# reveals the network has barely learned to segment anything at all.

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.datasets import load_digits

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 11

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    mask = np.zeros((CANVAS, CANVAS), dtype=np.int64)
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        foreground = sprite > 0.0
        patch = mask[y1:y2, x1:x2]
        patch[foreground] = label + 1
        mask[y1:y2, x1:x2] = patch
    return canvas, mask


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, masks = [], []
    for _ in range(n_images):
        c, m = make_one_image(rng)
        images.append(c); masks.append(m)
    return torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(masks))


def conv_block(in_ch, out_ch):
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.ReLU(),
        nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.ReLU(),
    )


class TinyUNet(nn.Module):
    def __init__(self, use_skip=True):
        super().__init__()
        self.use_skip = use_skip
        self.enc1 = conv_block(1, 16)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = conv_block(16, 32)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = conv_block(32, 64)
        self.up2 = nn.ConvTranspose2d(64, 32, kernel_size=2, stride=2)
        self.dec2 = conv_block(64 if use_skip else 32, 32)
        self.up1 = nn.ConvTranspose2d(32, 16, kernel_size=2, stride=2)
        self.dec1 = conv_block(32 if use_skip else 16, 16)
        self.final = nn.Conv2d(16, NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        s1 = self.enc1(x)
        p1 = self.pool1(s1)
        s2 = self.enc2(p1)
        p2 = self.pool2(s2)
        b = self.bottleneck(p2)
        u2 = self.up2(b)
        d2 = self.dec2(torch.cat([u2, s2], dim=1) if self.use_skip else u2)
        u1 = self.up1(d2)
        d1 = self.dec1(torch.cat([u1, s1], dim=1) if self.use_skip else u1)
        return self.final(d1)


def dice_loss(probs, target_onehot, eps=1e-6):
    dims = (0, 2, 3)
    inter = (probs * target_onehot).sum(dim=dims)
    union = probs.sum(dim=dims) + target_onehot.sum(dim=dims)
    return 1 - ((2 * inter + eps) / (union + eps)).mean()


def combined_loss(logits, target):
    ce = F.cross_entropy(logits, target)
    probs = F.softmax(logits, dim=1)
    target_onehot = F.one_hot(target, NUM_CLASSES).permute(0, 3, 1, 2).float()
    dl = dice_loss(probs, target_onehot)
    return ce + dl


def evaluate(model, images, masks):
    model.eval()
    with torch.no_grad():
        logits = model(images.unsqueeze(1))
    preds = logits.argmax(dim=1)
    pixel_acc = (preds == masks).float().mean().item()

    ious, dices = [], []
    for c in range(NUM_CLASSES):
        pred_c = (preds == c)
        true_c = (masks == c)
        inter = (pred_c & true_c).sum().item()
        union = (pred_c | true_c).sum().item()
        if union == 0:
            continue   # class absent from both prediction and ground truth
        ious.append(inter / union)
        denom = pred_c.sum().item() + true_c.sum().item()
        dices.append(2 * inter / denom if denom > 0 else 0.0)
    return pixel_acc, float(np.mean(ious)), float(np.mean(dices)), len(ious)


torch.manual_seed(0)
train_images, train_masks = make_dataset(1200, seed=0)
test_images, test_masks = make_dataset(300, seed=1)

results = {}
for use_skip in [True, False]:
    torch.manual_seed(0)
    model = TinyUNet(use_skip=use_skip)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    name = "WITH skip connections" if use_skip else "WITHOUT skip connections"
    print(f"Training TinyUNet {name} ({sum(p.numel() for p in model.parameters()):,} params)...")

    batch_size, n_batches = 100, 1200 // 100
    checkpoints = {1, 10, 25, 50, 75, 100}
    for epoch in range(1, 101):
        perm = torch.randperm(len(train_images))
        epoch_loss = 0.0
        for b in range(n_batches):
            idx = perm[b * batch_size:(b + 1) * batch_size]
            logits = model(train_images[idx].unsqueeze(1))
            loss = combined_loss(logits, train_masks[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            epoch_loss += loss.item()
        if epoch in checkpoints:
            print(f"  epoch {epoch:3d}: mean training loss = {epoch_loss / n_batches:.4f}")

    pixel_acc, miou, mdice, n_classes_seen = evaluate(model, test_images, test_masks)
    print(f"  test-set pixel accuracy: {pixel_acc:.4f}")
    print(f"  test-set mean IoU (mIoU) over {n_classes_seen} classes present: {miou:.4f}")
    print(f"  test-set mean Dice score: {mdice:.4f}")
    results[use_skip] = (pixel_acc, miou, mdice)
    print()

print("Summary: skip connections vs. none, same architecture and training budget")
print(f"  {'':30s} pixel_acc   mIoU     mean_Dice")
print(f"  {'WITH skip connections':30s} {results[True][0]:.4f}     {results[True][1]:.4f}   {results[True][2]:.4f}")
print(f"  {'WITHOUT skip connections':30s} {results[False][0]:.4f}     {results[False][1]:.4f}   {results[False][2]:.4f}")
