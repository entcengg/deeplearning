# ch25_program3.py
# Two segmentation losses: per-pixel cross-entropy (Chapter 8's cross-entropy,
# applied independently to every pixel and averaged) and Dice loss (a "soft
# overlap" measure, 1 minus a differentiable version of Dice's coefficient,
# 2|A cap B| / (|A|+|B|)). Part A checks both against a tiny hand-computed
# example. Part B shows why they disagree sharply once the classes are
# imbalanced -- exactly the situation this chapter's own dataset is in
# (Chapter 25, Program 1: about 90% background, 10% foreground).

import math
import torch
import torch.nn.functional as F

NUM_CLASSES = 11


def pixel_ce_from_probs(probs_fg, target_fg):
    """Binary version for the hand examples: probs_fg is P(foreground) per
    pixel, target_fg is 0/1 per pixel. Returns the mean per-pixel cross-entropy."""
    losses = []
    for p, t in zip(probs_fg, target_fg):
        p_correct = p if t == 1 else (1 - p)
        losses.append(-math.log(p_correct))
    return sum(losses) / len(losses)


def dice_loss_from_probs(probs_fg, target_fg, eps=1e-6):
    """Soft Dice loss for the foreground class: 1 - 2*sum(p*t) / (sum(p)+sum(t))."""
    inter = sum(p * t for p, t in zip(probs_fg, target_fg))
    denom = sum(probs_fg) + sum(target_fg)
    dice = (2 * inter + eps) / (denom + eps)
    return 1 - dice


# --- Part A: a tiny 2x2 example, checked by hand ----------------------------
print("Part A: a 2x2 (4-pixel) mask, binary foreground/background")
target_fg = [0, 0, 1, 1]                 # pixels (0,0),(0,1),(1,0),(1,1)
probs_fg = [0.1, 0.2, 0.7, 0.4]          # each pixel's predicted P(foreground)
print(f"  target (foreground=1): {target_fg}")
print(f"  predicted P(foreground): {probs_fg}")

hand_ce_terms = [-math.log(1 - 0.1), -math.log(1 - 0.2), -math.log(0.7), -math.log(0.4)]
hand_ce = sum(hand_ce_terms) / 4
print(f"  per-pixel CE terms: {[round(v, 5) for v in hand_ce_terms]}")
print(f"  mean CE (by hand): {hand_ce:.6f}")
print(f"  mean CE (function): {pixel_ce_from_probs(probs_fg, target_fg):.6f}")

inter = 0.7 * 1 + 0.4 * 1
denom = sum(probs_fg) + sum(target_fg)
hand_dice = 2 * inter / denom
print(f"  Dice by hand: intersection={inter:.2f}  sum(p)+sum(t)={denom:.2f}  "
      f"Dice={hand_dice:.6f}  Dice loss={1-hand_dice:.6f}")
print(f"  Dice loss (function): {dice_loss_from_probs(probs_fg, target_fg, eps=0):.6f}")

# --- Part B: extreme imbalance (1 foreground pixel out of 100) -------------
print("\nPart B: an extreme 1-in-100 imbalance, two models compared")
n_pixels = 100
n_fg = 1
target_fg_b = [1] * n_fg + [0] * (n_pixels - n_fg)

# "Lazy" model: predicts the same low P(foreground) everywhere, having
# learned only the overall class frequency, not where the object actually is.
lazy_probs = [0.01] * n_pixels
# "Good" model: correctly confident at the one true foreground pixel.
good_probs = [0.9] + [0.01] * (n_pixels - 1)

for name, probs in [("lazy (background everywhere)", lazy_probs),
                     ("good (finds the foreground pixel)", good_probs)]:
    ce = pixel_ce_from_probs(probs, target_fg_b)
    dl = dice_loss_from_probs(probs, target_fg_b)
    print(f"  {name}:")
    print(f"    mean per-pixel CE: {ce:.6f}")
    print(f"    Dice loss:         {dl:.6f}")

print("\n  Cross-entropy shrinks by a factor of "
      f"{pixel_ce_from_probs(lazy_probs, target_fg_b) / pixel_ce_from_probs(good_probs, target_fg_b):.2f}x "
      "going from lazy to good, but both values LOOK small in absolute")
print("  terms -- 99 easy, correct background pixels dominate the average either way.")
print("  Dice loss goes from 0.99 (essentially zero overlap) to a value that directly")
print("  reflects the one foreground pixel actually being found.")

# --- Confirm the same formulas generalize to the real multi-class setting ---
print("\nMulti-class check: applying both losses to random logits via PyTorch,")
print("confirming the binary formulas above are the C=2 special case of the")
print("general multi-class versions used in Program 4:")
torch.manual_seed(0)
logits = torch.randn(1, NUM_CLASSES, 4, 4)
target = torch.randint(0, NUM_CLASSES, (1, 4, 4))
ce_general = F.cross_entropy(logits, target)
probs = F.softmax(logits, dim=1)
target_onehot = F.one_hot(target, NUM_CLASSES).permute(0, 3, 1, 2).float()
dims = (0, 2, 3)
inter_g = (probs * target_onehot).sum(dim=dims)
union_g = probs.sum(dim=dims) + target_onehot.sum(dim=dims)
dice_per_class = (2 * inter_g + 1e-6) / (union_g + 1e-6)
dice_loss_general = 1 - dice_per_class.mean()
print(f"  general per-pixel CE on a random 4x4, {NUM_CLASSES}-class example: {ce_general.item():.6f}")
print(f"  general mean Dice loss (averaged over all {NUM_CLASSES} classes): {dice_loss_general.item():.6f}")
