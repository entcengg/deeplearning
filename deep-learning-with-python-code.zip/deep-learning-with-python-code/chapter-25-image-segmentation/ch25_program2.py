# ch25_program2.py
# TinyUNet: a small encoder-decoder segmentation network. The encoder shrinks
# the image spatially while growing the channel count (like a classifier
# backbone); the decoder grows it back to full resolution one stage at a
# time. Skip connections carry each encoder stage's feature map directly
# across to the matching decoder stage, concatenated with the upsampled
# features -- giving the decoder both the coarse "what" and the fine "where"
# at every resolution, not just one or the other.

import torch
import torch.nn as nn

NUM_CLASSES = 11   # 0 = background, 1-10 = digits 0-9


def conv_block(in_ch, out_ch):
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.ReLU(),
        nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.ReLU(),
    )


class TinyUNet(nn.Module):
    def __init__(self, use_skip=True):
        super().__init__()
        self.use_skip = use_skip
        # Encoder
        self.enc1 = conv_block(1, 16)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = conv_block(16, 32)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = conv_block(32, 64)
        # Decoder
        self.up2 = nn.ConvTranspose2d(64, 32, kernel_size=2, stride=2)
        self.dec2 = conv_block(64 if use_skip else 32, 32)
        self.up1 = nn.ConvTranspose2d(32, 16, kernel_size=2, stride=2)
        self.dec1 = conv_block(32 if use_skip else 16, 16)
        self.final = nn.Conv2d(16, NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        s1 = self.enc1(x)              # skip 1: (16, 32, 32)
        p1 = self.pool1(s1)            # (16, 16, 16)
        s2 = self.enc2(p1)             # skip 2: (32, 16, 16)
        p2 = self.pool2(s2)            # (32, 8, 8)
        b = self.bottleneck(p2)        # (64, 8, 8)
        u2 = self.up2(b)               # (32, 16, 16)
        d2_in = torch.cat([u2, s2], dim=1) if self.use_skip else u2
        d2 = self.dec2(d2_in)          # (32, 16, 16)
        u1 = self.up1(d2)              # (16, 32, 32)
        d1_in = torch.cat([u1, s1], dim=1) if self.use_skip else u1
        d1 = self.dec1(d1_in)          # (16, 32, 32)
        return self.final(d1)          # (NUM_CLASSES, 32, 32)


if __name__ == "__main__":
    torch.manual_seed(0)
    model = TinyUNet(use_skip=True)
    x = torch.randn(2, 1, 32, 32)   # a batch of 2 dummy 32x32 grayscale images

    print("Shape trace through TinyUNet, batch of 2 images:")
    print(f"  input                          : {tuple(x.shape)}")
    s1 = model.enc1(x);   print(f"  enc1 (skip 1)                  : {tuple(s1.shape)}")
    p1 = model.pool1(s1); print(f"  pool1                          : {tuple(p1.shape)}")
    s2 = model.enc2(p1);  print(f"  enc2 (skip 2)                  : {tuple(s2.shape)}")
    p2 = model.pool2(s2); print(f"  pool2                          : {tuple(p2.shape)}")
    b  = model.bottleneck(p2); print(f"  bottleneck                     : {tuple(b.shape)}")
    u2 = model.up2(b);    print(f"  up2 (transposed conv, stride 2): {tuple(u2.shape)}")
    cat2 = torch.cat([u2, s2], dim=1)
    print(f"  concat(up2, skip2)             : {tuple(cat2.shape)}  "
          f"({u2.shape[1]} + {s2.shape[1]} channels)")
    d2 = model.dec2(cat2); print(f"  dec2                           : {tuple(d2.shape)}")
    u1 = model.up1(d2);   print(f"  up1 (transposed conv, stride 2): {tuple(u1.shape)}")
    cat1 = torch.cat([u1, s1], dim=1)
    print(f"  concat(up1, skip1)             : {tuple(cat1.shape)}  "
          f"({u1.shape[1]} + {s1.shape[1]} channels)")
    d1 = model.dec1(cat1); print(f"  dec1                           : {tuple(d1.shape)}")
    out = model.final(d1); print(f"  final (1x1 conv to NUM_CLASSES): {tuple(out.shape)}")

    full_out = model(x)
    print(f"\nFull forward() call matches the manual trace: "
          f"{torch.equal(full_out, out)}")

    n_params_skip = sum(p.numel() for p in TinyUNet(use_skip=True).parameters())
    n_params_noskip = sum(p.numel() for p in TinyUNet(use_skip=False).parameters())
    print(f"\nParameter count with skip connections:    {n_params_skip:,}")
    print(f"Parameter count without skip connections: {n_params_noskip:,}")
    print(f"(fewer, because dec1/dec2's first conv reads half as many input channels)")
