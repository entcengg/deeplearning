# ch25_program5.py
# The trivial "always predict background" baseline: a model that has learned
# nothing about where objects are, only that most pixels are background. If
# pixel accuracy alone said whether a segmentation model is any good, this
# baseline would look deceptively competitive. mIoU and Dice tell a very
# different story, because they do not let the easy, majority background
# class hide what happens on every other class.

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.datasets import load_digits

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 11

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    mask = np.zeros((CANVAS, CANVAS), dtype=np.int64)
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        foreground = sprite > 0.0
        patch = mask[y1:y2, x1:x2]
        patch[foreground] = label + 1
        mask[y1:y2, x1:x2] = patch
    return canvas, mask


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, masks = [], []
    for _ in range(n_images):
        c, m = make_one_image(rng)
        images.append(c); masks.append(m)
    return torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(masks))


def conv_block(in_ch, out_ch):
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.ReLU(),
        nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.ReLU(),
    )


class TinyUNet(nn.Module):
    def __init__(self, use_skip=True):
        super().__init__()
        self.use_skip = use_skip
        self.enc1 = conv_block(1, 16)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = conv_block(16, 32)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = conv_block(32, 64)
        self.up2 = nn.ConvTranspose2d(64, 32, kernel_size=2, stride=2)
        self.dec2 = conv_block(64 if use_skip else 32, 32)
        self.up1 = nn.ConvTranspose2d(32, 16, kernel_size=2, stride=2)
        self.dec1 = conv_block(32 if use_skip else 16, 16)
        self.final = nn.Conv2d(16, NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        s1 = self.enc1(x)
        p1 = self.pool1(s1)
        s2 = self.enc2(p1)
        p2 = self.pool2(s2)
        b = self.bottleneck(p2)
        u2 = self.up2(b)
        d2 = self.dec2(torch.cat([u2, s2], dim=1) if self.use_skip else u2)
        u1 = self.up1(d2)
        d1 = self.dec1(torch.cat([u1, s1], dim=1) if self.use_skip else u1)
        return self.final(d1)


def dice_loss(probs, target_onehot, eps=1e-6):
    dims = (0, 2, 3)
    inter = (probs * target_onehot).sum(dim=dims)
    union = probs.sum(dim=dims) + target_onehot.sum(dim=dims)
    return 1 - ((2 * inter + eps) / (union + eps)).mean()


def combined_loss(logits, target):
    ce = F.cross_entropy(logits, target)
    probs = F.softmax(logits, dim=1)
    target_onehot = F.one_hot(target, NUM_CLASSES).permute(0, 3, 1, 2).float()
    return ce + dice_loss(probs, target_onehot)


def metrics_from_preds(preds, masks):
    pixel_acc = (preds == masks).float().mean().item()
    ious, dices = [], []
    for c in range(NUM_CLASSES):
        pred_c = (preds == c)
        true_c = (masks == c)
        inter = (pred_c & true_c).sum().item()
        union = (pred_c | true_c).sum().item()
        if union == 0:
            continue
        ious.append(inter / union)
        denom = pred_c.sum().item() + true_c.sum().item()
        dices.append(2 * inter / denom if denom > 0 else 0.0)
    return pixel_acc, float(np.mean(ious)), float(np.mean(dices)), len(ious)


torch.manual_seed(0)
train_images, train_masks = make_dataset(1200, seed=0)
test_images, test_masks = make_dataset(300, seed=1)

# --- Baseline: always predict background (class 0), for every pixel -------
baseline_preds = torch.zeros_like(test_masks)
bl_acc, bl_miou, bl_dice, bl_nclasses = metrics_from_preds(baseline_preds, test_masks)
print("Baseline: predict background (class 0) for every pixel, no model at all")
print(f"  test pixels that really are background: "
      f"{100*(test_masks==0).float().mean().item():.2f}%")
print(f"  pixel accuracy: {bl_acc:.4f}")
print(f"  mIoU (over {bl_nclasses} classes present in the test set): {bl_miou:.4f}")
print(f"  mean Dice score: {bl_dice:.4f}")

# --- A real, trained TinyUNet (with skip connections) ----------------------
torch.manual_seed(0)
model = TinyUNet(use_skip=True)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
print(f"\nTraining a real TinyUNet (with skip connections) for comparison...")
batch_size, n_batches = 100, 1200 // 100
for epoch in range(1, 101):
    perm = torch.randperm(len(train_images))
    for b in range(n_batches):
        idx = perm[b * batch_size:(b + 1) * batch_size]
        logits = model(train_images[idx].unsqueeze(1))
        loss = combined_loss(logits, train_masks[idx])
        optimizer.zero_grad(); loss.backward(); optimizer.step()

model.eval()
with torch.no_grad():
    test_logits = model(test_images.unsqueeze(1))
model_preds = test_logits.argmax(dim=1)
m_acc, m_miou, m_dice, m_nclasses = metrics_from_preds(model_preds, test_masks)
print(f"  pixel accuracy: {m_acc:.4f}")
print(f"  mIoU (over {m_nclasses} classes present in the test set): {m_miou:.4f}")
print(f"  mean Dice score: {m_dice:.4f}")

print(f"\nSide by side:")
print(f"  {'':28s} pixel_acc   mIoU     mean_Dice")
print(f"  {'always-background baseline':28s} {bl_acc:.4f}     {bl_miou:.4f}   {bl_dice:.4f}")
print(f"  {'trained TinyUNet':28s} {m_acc:.4f}     {m_miou:.4f}   {m_dice:.4f}")
acc_gap = m_acc - bl_acc
miou_ratio = m_miou / bl_miou
print(f"\n  pixel accuracy gap: only {acc_gap:.4f} ({100*acc_gap:.2f} points) -- the baseline")
print(f"  looks almost competitive by this measure alone.")
print(f"  mIoU ratio: trained model is {miou_ratio:.2f}x the baseline's mIoU -- the real gap.")
