# Chapter 25 · Image Segmentation

Code for Chapter 25 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 24](../chapter-24-object-detection/README.md) · [Chapter 26 →](../chapter-26-deep-learning-for-time-series/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 25.1.1 Program 1: Building Pixel-Level Ground Truth | Building pixel-level segmentation ground truth by reusing Chapter 24's scene generator | [`ch25_program1.py`](ch25_program1.py) | [ch25_program1.txt](expected_output/ch25_program1.txt) | 1 s |
| 2 | 25.2.1 Program 2: TinyUNet — A Small Encoder-Decoder Network | TinyUNet: a small U-Net-style encoder-decoder with a skip-connection toggle | [`ch25_program2.py`](ch25_program2.py) | [ch25_program2.txt](expected_output/ch25_program2.txt) | 2 s |
| 3 | 25.3.1 Program 3: Comparing the Two Losses by Hand | Pixel-wise cross-entropy and Dice loss, verified by hand and compared under extreme class imbalance | [`ch25_program3.py`](ch25_program3.py) | [ch25_program3.txt](expected_output/ch25_program3.txt) | 2 s |
| 6 | 25.3.3 Program 6: Weighted Cross-Entropy and Tversky Loss Under Imbalance | Class-weighted cross-entropy and Tversky loss on Program 3's 1-in-100 imbalance scenario | [`ch25_program6.py`](ch25_program6.py) | [ch25_program6.txt](expected_output/ch25_program6.txt) | < 1 s |
| 4 | 25.4.1 Program 4: TinyUNet, With and Without Skip Connections | Training TinyUNet with and without skip connections, evaluated by pixel accuracy, mIoU, and mean Dice | [`ch25_program4.py`](ch25_program4.py) | [ch25_program4.txt](expected_output/ch25_program4.txt) | 11 min |
| 5 | 25.5.1 Program 5: A Trivial Baseline vs. a Trained Model | The always-background baseline against a real trained TinyUNet, on pixel accuracy, mIoU, and mean Dice | [`ch25_program5.py`](ch25_program5.py) | [ch25_program5.txt](expected_output/ch25_program5.txt) | 4 min |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-25-image-segmentation
python ch25_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch25_notebook.ipynb`](ch25_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, PyTorch.

## Notes

- The programs are listed in the order the book prints them: Program 6 (Section 25.3.3) comes before Programs 4 and 5.
