# ch25_program6.py
# Beyond Dice: two other standard responses to segmentation class imbalance.
# Part A: class-weighted cross-entropy, applied to Program 3's Part B
# 1-in-100 imbalance scenario (the same "lazy" vs. "good" probability
# vectors), to see whether simply reweighting the existing cross-entropy
# loss already fixes what plain cross-entropy could not. Part B: Tversky
# loss (a generalization of Dice with independent false-positive and
# false-negative weights alpha/beta), applied to the same scenario, first
# confirmed to reduce exactly to Program 3's Dice numbers at alpha=beta=0.5,
# then evaluated at alpha=0.3, beta=0.7 (Salehi et al., 2017's recall-favoring
# setting) to see how much further it separates the two models.

import math


def pixel_ce_from_probs(probs_fg, target_fg):
    losses = []
    for p, t in zip(probs_fg, target_fg):
        p_correct = p if t == 1 else (1 - p)
        losses.append(-math.log(p_correct))
    return sum(losses) / len(losses)


def weighted_ce_from_probs(probs_fg, target_fg, weight_fg, weight_bg):
    """Per-pixel cross-entropy, each term scaled by its TRUE class's weight,
    then averaged over all pixels (same denominator as the unweighted
    version, so the two are directly comparable term by term)."""
    losses = []
    for p, t in zip(probs_fg, target_fg):
        p_correct = p if t == 1 else (1 - p)
        w = weight_fg if t == 1 else weight_bg
        losses.append(-w * math.log(p_correct))
    return sum(losses) / len(losses)


def tversky_index(probs_fg, target_fg, alpha, beta, eps=1e-6):
    tp = sum(p * t for p, t in zip(probs_fg, target_fg))
    fp = sum(p * (1 - t) for p, t in zip(probs_fg, target_fg))
    fn = sum((1 - p) * t for p, t in zip(probs_fg, target_fg))
    return (tp + eps) / (tp + alpha * fp + beta * fn + eps), tp, fp, fn


def dice_loss_from_probs(probs_fg, target_fg, eps=1e-6):
    inter = sum(p * t for p, t in zip(probs_fg, target_fg))
    denom = sum(probs_fg) + sum(target_fg)
    dice = (2 * inter + eps) / (denom + eps)
    return 1 - dice


# --- Reconstruct Program 3's Part B scenario exactly --------------------
n_pixels = 100
n_fg = 1
target_fg_b = [1] * n_fg + [0] * (n_pixels - n_fg)
lazy_probs = [0.01] * n_pixels
good_probs = [0.9] + [0.01] * (n_pixels - 1)

print("Part A: class-weighted cross-entropy on Program 3's Part B scenario")
print("(1 foreground pixel out of 100; 'lazy' predicts P(fg)=0.01 everywhere;")
print(" 'good' correctly predicts P(fg)=0.9 at the one true foreground pixel)")

unweighted_ce_lazy = pixel_ce_from_probs(lazy_probs, target_fg_b)
unweighted_ce_good = pixel_ce_from_probs(good_probs, target_fg_b)
print(f"\n  unweighted CE -- lazy: {unweighted_ce_lazy:.6f}   good: {unweighted_ce_good:.6f}   "
      f"ratio: {unweighted_ce_lazy / unweighted_ce_good:.2f}x")

# Inverse-frequency weights: weight_c = 1 / (fraction of pixels of class c).
freq_fg, freq_bg = n_fg / n_pixels, (n_pixels - n_fg) / n_pixels
weight_fg, weight_bg = 1.0 / freq_fg, 1.0 / freq_bg
print(f"\n  class frequencies: background={freq_bg:.4f}  foreground={freq_fg:.4f}")
print(f"  inverse-frequency weights: weight_bg={weight_bg:.4f}  weight_fg={weight_fg:.4f}")

weighted_ce_lazy = weighted_ce_from_probs(lazy_probs, target_fg_b, weight_fg, weight_bg)
weighted_ce_good = weighted_ce_from_probs(good_probs, target_fg_b, weight_fg, weight_bg)
print(f"\n  weighted CE -- lazy: {weighted_ce_lazy:.6f}   good: {weighted_ce_good:.6f}   "
      f"ratio: {weighted_ce_lazy / weighted_ce_good:.2f}x")
print(f"\n  weighting the foreground pixel's error by {weight_fg:.1f}x widens the"
      f" lazy/good ratio")
print(f"  from {unweighted_ce_lazy / unweighted_ce_good:.2f}x to "
      f"{weighted_ce_lazy / weighted_ce_good:.2f}x")

print("\n\nPart B: Tversky loss on the same scenario")
print("(alpha, beta weight false positives and false negatives independently;")
print(" alpha=beta=0.5 is exactly Dice; beta>alpha favors recall)")

settings = [(0.5, 0.5, "alpha=beta=0.5 (= Dice)"),
            (0.3, 0.7, "alpha=0.3, beta=0.7 (recall-favoring)")]
for alpha, beta, tag in settings:
    ti_lazy, tp_l, fp_l, fn_l = tversky_index(lazy_probs, target_fg_b, alpha, beta, eps=0)
    ti_good, tp_g, fp_g, fn_g = tversky_index(good_probs, target_fg_b, alpha, beta, eps=0)
    print(f"\n  {tag}:")
    print(f"    lazy: TP={tp_l:.3f} FP={fp_l:.3f} FN={fn_l:.3f}  "
          f"Tversky index={ti_lazy:.6f}  Tversky loss={1-ti_lazy:.6f}")
    print(f"    good: TP={tp_g:.3f} FP={fp_g:.3f} FN={fn_g:.3f}  "
          f"Tversky index={ti_good:.6f}  Tversky loss={1-ti_good:.6f}")

dice_lazy = dice_loss_from_probs(lazy_probs, target_fg_b, eps=0)
dice_good = dice_loss_from_probs(good_probs, target_fg_b, eps=0)
print(f"\n  cross-check, Program 3's Dice loss: lazy={dice_lazy:.6f}"
      f"  good={dice_good:.6f}")

gap_dice = dice_lazy - dice_good
ti_lazy_rf, *_ = tversky_index(lazy_probs, target_fg_b, 0.3, 0.7, eps=0)
ti_good_rf, *_ = tversky_index(good_probs, target_fg_b, 0.3, 0.7, eps=0)
gap_tversky = (1 - ti_lazy_rf) - (1 - ti_good_rf)
print(f"\n  lazy-minus-good loss gap: Dice {gap_dice:.4f}"
      f"   Tversky(0.3, 0.7) {gap_tversky:.4f}")
