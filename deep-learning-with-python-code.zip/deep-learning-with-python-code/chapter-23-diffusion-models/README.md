# Chapter 23 · Diffusion Models

Code for Chapter 23 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 22](../chapter-22-generative-adversarial-networks/README.md) · [Chapter 24 →](../chapter-24-object-detection/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 23.1.1 Program 1: Forward Diffusion, Verified Two Ways | Corrupting an image step-by-step and in one closed-form jump, and confirming they agree exactly | [`ch23_program1.py`](ch23_program1.py) | [ch23_program1.txt](expected_output/ch23_program1.txt) | 3 s |
| 2 | 23.2.1 Program 2: Training a Denoiser and Sampling From It | Training a noise-prediction network and sampling new images from pure noise | [`ch23_program2.py`](ch23_program2.py) | [ch23_program2.txt](expected_output/ch23_program2.txt) | 58 s |
| 3 | 23.4.1 Program 3: All Three Generative Models, Head to Head | VAE, GAN, and diffusion, measured on the same realism and diversity axes | [`ch23_program3.py`](ch23_program3.py) | [ch23_program3.txt](expected_output/ch23_program3.txt) | 1 min |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-23-diffusion-models
python ch23_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch23_notebook.ipynb`](ch23_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, PyTorch.
