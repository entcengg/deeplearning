# ch23_program1.py
# The forward diffusion process: gradually destroy a real image by adding
# a little Gaussian noise at a time, for T steps, until nothing recognizable
# is left. Two ways to compute this are shown to agree exactly: applying
# the single-step rule T times in a row, and jumping straight to step T
# with one closed-form equation -- the same identity every real diffusion
# model relies on to train efficiently.

import numpy as np
import torch
from sklearn.datasets import load_digits

digits = load_digits()
# Diffusion adds zero-mean Gaussian noise, so data is scaled to [-1, 1]
# (zero-centered) rather than the [0, 1] scaling used in Chapters 21-22.
X = (digits.images.reshape(-1, 64).astype(np.float32) / 16.0) * 2 - 1

T = 200
betas = torch.linspace(1e-4, 0.04, T)
alphas = 1 - betas
alpha_bars = torch.cumprod(alphas, dim=0)

print(f"Noise schedule: T={T} steps, beta from {betas[0]:.4f} to {betas[-1]:.4f} (linear)")
print(f"alpha_bar_1   = {alpha_bars[0]:.4f}  (almost no corruption yet)")
print(f"alpha_bar_{T//2:<3} = {alpha_bars[T//2-1]:.4f}")
print(f"alpha_bar_{T}  = {alpha_bars[-1]:.4f}  (barely any of x_0 left)")

torch.manual_seed(0)
x0 = torch.from_numpy(X[0])  # one real digit image, 64 pixels

# --- Method 1: apply the single-step rule T times in a row ---------------
x = x0.clone()
eps_list = []
for t in range(T):
    eps_t = torch.randn(64)
    eps_list.append(eps_t)
    x = torch.sqrt(alphas[t]) * x + torch.sqrt(betas[t]) * eps_t
x_T_stepwise = x

# --- Method 2: the closed-form direct jump to step T ----------------------
# The T individual noise draws above can always be algebraically recombined
# into the single equivalent noise vector the closed form uses.
combined = torch.zeros(64)
alpha_bar_T = alpha_bars[-1]
for s in range(T):
    weight = torch.sqrt(betas[s] * alpha_bar_T / alpha_bars[s])
    combined += weight * eps_list[s]
epsilon_equivalent = combined / torch.sqrt(1 - alpha_bar_T)

x_T_closed_form = torch.sqrt(alpha_bar_T) * x0 + torch.sqrt(1 - alpha_bar_T) * epsilon_equivalent

max_diff = (x_T_stepwise - x_T_closed_form).abs().max().item()
print(f"\nOne real image, corrupted {T} steps two different ways:")
print(f"  step-by-step (Equation 23.1 applied {T} times), first 5 pixels:")
print(f"    {x_T_stepwise[:5].numpy()}")
print(f"  closed form (Equation 23.2, one jump), first 5 pixels:")
print(f"    {x_T_closed_form[:5].numpy()}")
print(f"  maximum absolute difference across all 64 pixels: {max_diff:.2e}")

# --- Show the progressive corruption at several intermediate steps --------
print(f"\nProgressive corruption of the same image at several steps (closed form):")
torch.manual_seed(1)
checkpoints = [1, 25, 50, 100, 150, 200]
for t in checkpoints:
    ab = alpha_bars[t - 1]
    eps = torch.randn(64)
    x_t = torch.sqrt(ab) * x0 + torch.sqrt(1 - ab) * eps
    signal_pct = torch.sqrt(ab).item() * 100
    print(f"  t={t:>3}: alpha_bar={ab:.4f}  signal retained~{signal_pct:5.1f}%  "
          f"pixel range=[{x_t.min():.2f}, {x_t.max():.2f}]")
