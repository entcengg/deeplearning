# ch23_program2.py
# Train a small network to predict the noise added at each diffusion step
# (Equation 23.3), then use it to run the reverse process: start from pure
# noise and repeatedly denoise, one step at a time, until an image is left.
# No labels are used, and the network never sees a "generate a digit"
# target -- only "what noise was added to get here."

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = (digits.images.reshape(-1, 64).astype(np.float32) / 16.0) * 2 - 1
X_train, X_test = train_test_split(X, test_size=0.2, random_state=0)
X_train_t = torch.from_numpy(X_train)
N_train = len(X_train)

T = 200
betas = torch.linspace(1e-4, 0.04, T)
alphas = 1 - betas
alpha_bars = torch.cumprod(alphas, dim=0)

class Denoiser(nn.Module):
    def __init__(self, T=T, time_dim=32, hidden=256):
        super().__init__()
        self.time_embed = nn.Embedding(T, time_dim)  # one learned vector per timestep,
        self.net = nn.Sequential(                     # looked up exactly as Chapter 20
            nn.Linear(64 + time_dim, hidden), nn.ReLU(),  # looked up a word's embedding
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 64),
        )

    def forward(self, x_t, t):
        te = self.time_embed(t)
        return self.net(torch.cat([x_t, te], dim=1))

torch.manual_seed(0)
model = Denoiser()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

print(f"Training a noise-prediction network (T={T} diffusion steps)...")
checkpoints = {1, 500, 1000, 2000, 3000, 4000}
for epoch in range(1, 4001):
    model.train()
    optimizer.zero_grad()
    t_idx = torch.randint(0, T, (N_train,))          # a random step for each training image
    eps = torch.randn(N_train, 64)                     # the noise actually added
    sqrt_ab = torch.sqrt(alpha_bars[t_idx]).unsqueeze(1)
    sqrt_1mab = torch.sqrt(1 - alpha_bars[t_idx]).unsqueeze(1)
    x_t = sqrt_ab * X_train_t + sqrt_1mab * eps         # Equation 23.2, one jump per example
    eps_pred = model(x_t, t_idx)
    loss = nn.functional.mse_loss(eps_pred, eps)        # Equation 23.3
    loss.backward()
    optimizer.step()
    if epoch in checkpoints:
        print(f"  epoch {epoch:>4}: noise-prediction MSE={loss.item():.4f}")
model.eval()

with torch.no_grad():
    for t_check in [10, 100, 199]:
        t_batch = torch.full((len(X_test),), t_check, dtype=torch.long)
        eps = torch.randn(len(X_test), 64)
        ab = alpha_bars[t_check]
        x_t = torch.sqrt(ab) * torch.from_numpy(X_test) + torch.sqrt(1 - ab) * eps
        eps_pred = model(x_t, t_batch)
        test_mse = nn.functional.mse_loss(eps_pred, eps).item()
        print(f"  test noise-prediction MSE at t={t_check:>3} (alpha_bar={ab:.4f}): {test_mse:.4f}")

# --- Reverse process: start from pure noise, denoise T times (Equation 23.4) ---
@torch.no_grad()
def sample(n, record_steps=None):
    x = torch.randn(n, 64)
    trajectory = {}
    for t in reversed(range(T)):
        t_batch = torch.full((n,), t, dtype=torch.long)
        eps_pred = model(x, t_batch)
        alpha_t, alpha_bar_t, beta_t = alphas[t], alpha_bars[t], betas[t]
        mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
        if t > 0:
            x = mean + torch.sqrt(beta_t) * torch.randn(n, 64)
        else:
            x = mean  # no noise added on the final step
        if record_steps and t in record_steps:
            trajectory[t] = x.clone()
    return x, trajectory

torch.manual_seed(123)
final_samples, trajectory = sample(6, record_steps={199, 150, 100, 50, 20, 0})
print(f"\nGenerated 6 images from pure noise via {T} reverse diffusion steps.")
print(f"Generated pixel stats: min={final_samples.min():.4f}  max={final_samples.max():.4f}  "
      f"mean={final_samples.mean():.4f}")
print(f"Real data pixel stats: min={X.min():.4f}  max={X.max():.4f}  mean={X.mean():.4f}")
