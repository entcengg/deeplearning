# ch23_program3.py
# Capstone: put all three generative approaches from Chapters 21-23 --
# VAE, GAN, and diffusion -- through the exact same two direct
# measurements Chapter 22 introduced: how convincing the generated
# images look to an independent judge classifier, and how diverse they
# are (the entropy of the judge's predicted-class histogram). Each
# model is trained fresh, matched as closely as the three mechanisms
# allow, and none of the three ever sees the judge during its own
# training.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X01 = digits.images.reshape(-1, 64).astype(np.float32) / 16.0          # [0,1], for VAE/GAN/judge
y = digits.target
X01_train, X01_test, y_train, y_test = train_test_split(X01, y, test_size=0.2, random_state=0)
X01_train_t, X01_test_t = torch.from_numpy(X01_train), torch.from_numpy(X01_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()
X01_t = torch.from_numpy(X01)
Xpm1_train_t = torch.from_numpy((X01_train * 2 - 1).astype(np.float32))  # [-1,1], for diffusion
N = len(X01)
N_GEN = 300

# --- GAN (Chapter 22) -----------------------------------------------------
NOISE_DIM = 16
class Generator(nn.Module):
    def __init__(self, noise_dim=NOISE_DIM):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(noise_dim, 32), nn.ReLU(),
                                  nn.Linear(32, 64), nn.Sigmoid())
    def forward(self, z):
        return self.net(z)

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 1))
    def forward(self, x):
        return self.net(x)

# --- VAE (Chapter 21) ------------------------------------------------------
class VAE(nn.Module):
    def __init__(self, latent_dim=4):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, latent_dim)
        self.logvar_head = nn.Linear(32, latent_dim)
        self.decoder = nn.Sequential(nn.Linear(latent_dim, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())
    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)
    def reparameterize(self, mu, logvar):
        return mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)
    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar

def vae_loss(recon, x, mu, logvar):
    recon_loss = ((recon - x) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    return recon_loss, kl

# --- Diffusion (this chapter) ----------------------------------------------
T = 200
betas = torch.linspace(1e-4, 0.04, T)
alphas = 1 - betas
alpha_bars = torch.cumprod(alphas, dim=0)

class Denoiser(nn.Module):
    def __init__(self, T=T, time_dim=32, hidden=256):
        super().__init__()
        self.time_embed = nn.Embedding(T, time_dim)
        self.net = nn.Sequential(
            nn.Linear(64 + time_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 64),
        )
    def forward(self, x_t, t):
        return self.net(torch.cat([x_t, self.time_embed(t)], dim=1))

# --- Judge (Chapter 22) -----------------------------------------------------
class Judge(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)
    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

def mean_confidence(judge, images):
    with torch.no_grad():
        probs = torch.softmax(judge(images), dim=1)
        return probs.max(dim=1).values.mean().item()

def class_entropy(judge, images, n_classes=10):
    with torch.no_grad():
        preds = judge(images).argmax(dim=1).numpy()
    counts = np.bincount(preds, minlength=n_classes).astype(np.float64)
    probs = counts / counts.sum()
    nonzero = probs[probs > 0]
    entropy = -(nonzero * np.log2(nonzero)).sum()
    return entropy, int((counts > 0).sum()), counts

# --- Train the GAN ----------------------------------------------------------
torch.manual_seed(0)
G, D = Generator(), Discriminator()
g_opt = optim.Adam(G.parameters(), lr=0.001, betas=(0.5, 0.999))
d_opt = optim.Adam(D.parameters(), lr=0.001, betas=(0.5, 0.999))
bce = nn.BCEWithLogitsLoss()
real_labels, fake_labels = torch.ones(N, 1), torch.zeros(N, 1)
for epoch in range(300):
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z).detach()
    d_opt.zero_grad()
    (bce(D(X01_t), real_labels) + bce(D(fake_images), fake_labels)).backward()
    d_opt.step()
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z)
    g_opt.zero_grad()
    bce(D(fake_images), real_labels).backward()
    g_opt.step()
G.eval()

# --- Train the VAE -----------------------------------------------------------
torch.manual_seed(0)
vae = VAE(latent_dim=4)
vae_opt = optim.Adam(vae.parameters(), lr=0.01)
for epoch in range(300):
    vae.train(); vae_opt.zero_grad()
    recon, mu, logvar = vae(X01_train_t)
    recon_loss, kl = vae_loss(recon, X01_train_t, mu, logvar)
    (recon_loss + kl).backward(); vae_opt.step()
vae.eval()

# --- Train the diffusion denoiser --------------------------------------------
torch.manual_seed(0)
denoiser = Denoiser()
d_opt2 = optim.Adam(denoiser.parameters(), lr=0.001)
for epoch in range(4000):
    denoiser.train(); d_opt2.zero_grad()
    t_idx = torch.randint(0, T, (len(Xpm1_train_t),))
    eps = torch.randn(len(Xpm1_train_t), 64)
    sqrt_ab = torch.sqrt(alpha_bars[t_idx]).unsqueeze(1)
    sqrt_1mab = torch.sqrt(1 - alpha_bars[t_idx]).unsqueeze(1)
    x_t = sqrt_ab * Xpm1_train_t + sqrt_1mab * eps
    loss = nn.functional.mse_loss(denoiser(x_t, t_idx), eps)
    loss.backward(); d_opt2.step()
denoiser.eval()
print(f"Diffusion denoiser final training loss: {loss.item():.4f}")

@torch.no_grad()
def diffusion_sample(n):
    x = torch.randn(n, 64)
    for t in reversed(range(T)):
        t_batch = torch.full((n,), t, dtype=torch.long)
        eps_pred = denoiser(x, t_batch)
        alpha_t, alpha_bar_t, beta_t = alphas[t], alpha_bars[t], betas[t]
        mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
        x = mean + torch.sqrt(beta_t) * torch.randn(n, 64) if t > 0 else mean
    return x

# --- Train the judge (real digits only, [0,1] scale) -------------------------
torch.manual_seed(1)
judge = Judge()
judge_opt = optim.Adam(judge.parameters(), lr=0.01)
for epoch in range(100):
    judge.train(); judge_opt.zero_grad()
    nn.functional.cross_entropy(judge(X01_train_t), y_train_t).backward()
    judge_opt.step()
judge.eval()
with torch.no_grad():
    judge_test_acc = (judge(X01_test_t).argmax(1) == y_test_t).float().mean().item()

# --- Generate N_GEN images from each model ------------------------------------
torch.manual_seed(42)
with torch.no_grad():
    gan_images = G(torch.randn(N_GEN, NOISE_DIM))
    vae_images = vae.decoder(torch.randn(N_GEN, 4))
diffusion_raw = diffusion_sample(N_GEN)                       # [-1,1] scale, unclipped
diffusion_images = ((diffusion_raw.clamp(-1, 1) + 1) / 2)      # rescaled to [0,1] for the judge

real_confidence = mean_confidence(judge, X01_test_t)
gan_confidence = mean_confidence(judge, gan_images)
vae_confidence = mean_confidence(judge, vae_images)
diff_confidence = mean_confidence(judge, diffusion_images)

max_entropy = np.log2(10)
real_entropy, real_nclasses, real_counts = class_entropy(judge, X01_test_t)
gan_entropy, gan_nclasses, gan_counts = class_entropy(judge, gan_images)
vae_entropy, vae_nclasses, vae_counts = class_entropy(judge, vae_images)
diff_entropy, diff_nclasses, diff_counts = class_entropy(judge, diffusion_images)

print(f"\nJudge classifier trained on real digits only (test accuracy={judge_test_acc:.4f})")
print(f"Generated {N_GEN} images each from the GAN, the VAE, and the diffusion model.")

print(f"\nRealism (mean top-class confidence):")
print(f"  real test images (ceiling reference): {real_confidence:.4f}")
print(f"  GAN:                                  {gan_confidence:.4f}")
print(f"  VAE:                                  {vae_confidence:.4f}")
print(f"  Diffusion:                             {diff_confidence:.4f}")

print(f"\nDiversity (entropy of predicted-class histogram, max={max_entropy:.4f} bits):")
print(f"  real test images (ceiling reference): entropy={real_entropy:.4f} bits ({real_nclasses}/10 classes)")
print(f"  GAN:                                  entropy={gan_entropy:.4f} bits ({gan_nclasses}/10 classes)")
print(f"  VAE:                                  entropy={vae_entropy:.4f} bits ({vae_nclasses}/10 classes)")
print(f"  Diffusion:                             entropy={diff_entropy:.4f} bits ({diff_nclasses}/10 classes)")

print(f"\nGAN predicted-class histogram:       {gan_counts.astype(int).tolist()}")
print(f"VAE predicted-class histogram:       {vae_counts.astype(int).tolist()}")
print(f"Diffusion predicted-class histogram: {diff_counts.astype(int).tolist()}")
