# ch14_program2.py
# Padding, stride, and the output-size formula; then max pooling.

import numpy as np
import torch
import torch.nn.functional as F

image = np.array([
    [1, 2, 3, 0, 1],
    [0, 1, 2, 3, 1],
    [1, 0, 1, 2, 0],
    [2, 1, 0, 1, 2],
    [0, 2, 1, 0, 1],
], dtype=np.float32)
kernel = np.array([[1, 0, -1], [1, 0, -1], [1, 0, -1]], dtype=np.float32)
img_t = torch.from_numpy(image).unsqueeze(0).unsqueeze(0)
ker_t = torch.from_numpy(kernel).unsqueeze(0).unsqueeze(0)

def out_size(n, f, p, s):
    return (n + 2*p - f) // s + 1

for name, p, s in [("valid (no padding)", 0, 1), ("same padding", 1, 1), ("stride 2", 0, 2)]:
    out = F.conv2d(img_t, ker_t, stride=s, padding=p)
    predicted = out_size(5, 3, p, s)
    print(f"{name:<20}: output shape {tuple(out.shape[-2:])}   "
          f"formula (n+2p-f)/s+1 = {predicted}")

# --- Max pooling ---
feature_map = np.array([
    [1, 3, 2, 4],
    [5, 6, 1, 2],
    [1, 2, 7, 8],
    [3, 1, 4, 2],
], dtype=np.float32)
fmap_t = torch.from_numpy(feature_map).unsqueeze(0).unsqueeze(0)
pooled = F.max_pool2d(fmap_t, kernel_size=2, stride=2)

print("\nfeature map:")
print(feature_map)
print("2x2 max pool, stride 2:")
print(pooled.squeeze().numpy())
