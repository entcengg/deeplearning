# ch14_program6.py
# A short real-image example: the same hand-designed kernels from
# earlier in this chapter, applied to an actual photograph instead of
# a synthetic 5x5 grid, using PyTorch's conv2d exactly as Program 1 did.

import numpy as np
import torch
import torch.nn.functional as F
import matplotlib.cbook as cbook
import matplotlib.pyplot as plt

# ---------------------------------------------------------------
# Load a real photograph (bundled with matplotlib for exactly this kind
# of demonstration), convert to grayscale, and downsample so a plain
# nested-loop-equivalent convolution stays fast and the feature maps
# stay easy to look at side by side.
# ---------------------------------------------------------------
path = cbook.get_sample_data("grace_hopper.jpg", asfileobj=False)
rgb = plt.imread(path).astype(np.float32) / 255.0          # (600, 512, 3)
gray = rgb @ np.array([0.299, 0.587, 0.114], dtype=np.float32)   # standard luminosity weights
gray = gray[::4, ::4]                                       # downsample to 150x128
print(f"original RGB shape: {rgb.shape}")
print(f"grayscale, downsampled shape: {gray.shape}")

img_t = torch.from_numpy(gray).unsqueeze(0).unsqueeze(0)    # (1, 1, H, W)

# The same vertical edge detector from Program 1, plus its horizontal
# counterpart (its transpose) and a simple averaging (blur) kernel.
vertical_edges = torch.tensor([[1., 0., -1.],
                                [1., 0., -1.],
                                [1., 0., -1.]]).unsqueeze(0).unsqueeze(0)
horizontal_edges = vertical_edges.transpose(2, 3).contiguous()
blur = (torch.ones(3, 3) / 9.0).unsqueeze(0).unsqueeze(0)

kernels = {"vertical edges": vertical_edges,
           "horizontal edges": horizontal_edges,
           "blur (3x3 average)": blur}

print(f"\n{'kernel':<20} {'output shape':<16} {'min':>8} {'max':>8} {'mean':>8}")
outputs = {}
for name, kernel in kernels.items():
    out = F.conv2d(img_t, kernel, stride=1, padding=1).squeeze().numpy()
    outputs[name] = out
    print(f"{name:<20} {str(out.shape):<16} {out.min():>8.3f} {out.max():>8.3f} {out.mean():>8.3f}")

np.savez("ch14_real_image_conv.npz", original=gray,
         vertical=outputs["vertical edges"], horizontal=outputs["horizontal edges"],
         blur=outputs["blur (3x3 average)"])
print("\nsaved original + 3 filtered versions to ch14_real_image_conv.npz")
