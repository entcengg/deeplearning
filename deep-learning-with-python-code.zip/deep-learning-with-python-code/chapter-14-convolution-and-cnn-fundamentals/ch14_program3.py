# ch14_program3.py
# Parameter counts: a fully connected layer versus a convolutional layer,
# as image size grows.

def fc_params(input_pixels, n_out):
    return input_pixels * n_out + n_out

def conv_params(kernel_h, kernel_w, in_channels, n_filters):
    return (kernel_h * kernel_w * in_channels + 1) * n_filters

print(f"{'image size':>12} {'pixels':>8} {'FC params':>12} {'conv params':>12}")
for side in [8, 16, 32, 64, 128, 256]:
    pixels = side * side
    fc = fc_params(pixels, 10)
    conv = conv_params(3, 3, 1, 10)
    print(f"{side}x{side:<8} {pixels:>8} {fc:>12,} {conv:>12,}")

print("\nThe convolutional layer's parameter count never changes -- the")
print("same 10 filters, each 3x3, slide across an image of any size.")
