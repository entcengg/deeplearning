# Chapter 14 · Convolution and CNN Fundamentals

Code for Chapter 14 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 13](../chapter-13-building-networks-with-pytorch-and-keras/README.md) · [Chapter 15 →](../chapter-15-cnn-architectures-and-transfer-learning/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 14.2.1 Program 1: Convolution, by Hand and by Framework | 2D convolution, computed directly and checked against PyTorch | [`ch14_program1.py`](ch14_program1.py) | [ch14_program1.txt](expected_output/ch14_program1.txt) | 2 s |
| 2 | 14.3.1 Program 2: Padding, Stride, and Pooling | Verifying Equation 14.1, then max pooling | [`ch14_program2.py`](ch14_program2.py) | [ch14_program2.txt](expected_output/ch14_program2.txt) | 2 s |
| 3 | 14.5.1 Program 3: The Gap, Quantified | Parameter counts as image size grows | [`ch14_program3.py`](ch14_program3.py) | [ch14_program3.txt](expected_output/ch14_program3.txt) | < 1 s |
| 4 | 14.7 Program 4: CNN Versus MLP, Trained | A small CNN and a parameter-matched MLP, trained on the digits dataset | [`ch14_program4.py`](ch14_program4.py) | [ch14_program4.txt](expected_output/ch14_program4.txt) | 7 s |
| 5 | 14.7.2 Visualizing What Convolutional Filters Learn | Visualizing `conv1`'s 8 learned feature maps on a trained test digit | [`ch14_program5.py`](ch14_program5.py) | [ch14_program5.txt](expected_output/ch14_program5.txt) | 5 s |
| 6 | 14.7.3 A Real-Image Example | Hand-designed kernels applied to a real photograph, not a synthetic grid | [`ch14_program6.py`](ch14_program6.py) | [ch14_program6.txt](expected_output/ch14_program6.txt) | 2 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-14-convolution-and-cnn-fundamentals
python ch14_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch14_notebook.ipynb`](ch14_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, Matplotlib, scikit-learn, PyTorch.

## Notes

- Program 5 saves the feature maps it computes as `ch14_feature_maps.npz` in this folder.
- Program 6 uses the photograph that ships with Matplotlib (no download) and saves its results as `ch14_real_image_conv.npz` in this folder.
