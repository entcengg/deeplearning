# ch14_program1.py
# 2D convolution (cross-correlation), computed by hand-equivalent NumPy
# code and checked against PyTorch's conv2d.

import numpy as np
import torch
import torch.nn.functional as F

image = np.array([
    [1, 2, 3, 0, 1],
    [0, 1, 2, 3, 1],
    [1, 0, 1, 2, 0],
    [2, 1, 0, 1, 2],
    [0, 2, 1, 0, 1],
], dtype=np.float32)

kernel = np.array([
    [1, 0, -1],
    [1, 0, -1],
    [1, 0, -1],
], dtype=np.float32)

def convolve2d(img, ker, stride=1):
    """Slide ker over img; at each position, multiply element-wise and sum."""
    h, w = img.shape
    kh, kw = ker.shape
    out_h = (h - kh) // stride + 1
    out_w = (w - kw) // stride + 1
    out = np.zeros((out_h, out_w))
    for i in range(out_h):
        for j in range(out_w):
            region = img[i*stride:i*stride+kh, j*stride:j*stride+kw]
            out[i, j] = np.sum(region * ker)
    return out

result = convolve2d(image, kernel)
print("NumPy result:")
print(result)

# Confirm against PyTorch's conv2d (which computes the same operation).
img_t = torch.from_numpy(image).unsqueeze(0).unsqueeze(0)      # (batch, channel, H, W)
ker_t = torch.from_numpy(kernel).unsqueeze(0).unsqueeze(0)     # (out_ch, in_ch, kH, kW)
torch_result = F.conv2d(img_t, ker_t, stride=1, padding=0)
print("\nPyTorch conv2d result:")
print(torch_result.squeeze().numpy())
