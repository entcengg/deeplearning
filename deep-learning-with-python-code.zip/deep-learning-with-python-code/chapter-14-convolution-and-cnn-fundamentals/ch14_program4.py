# ch14_program4.py
# A small CNN versus a roughly parameter-matched MLP, trained on the
# scikit-learn digits dataset (the same 8x8 images from Chapter 3).

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = digits.images.astype(np.float32) / 16.0     # scale pixel values to [0, 1]
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

X_train_img = torch.from_numpy(X_train).unsqueeze(1)    # (N, 1, 8, 8): add channel axis
X_test_img = torch.from_numpy(X_test).unsqueeze(1)
X_train_flat = torch.from_numpy(X_train.reshape(-1, 64))
X_test_flat = torch.from_numpy(X_test.reshape(-1, 64))
y_train_t = torch.from_numpy(y_train).long()
y_test_t = torch.from_numpy(y_test).long()

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)    # 8x8 -> 8x8x8
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)   # 4x4 -> 4x4x16
        self.fc = nn.Linear(16 * 2 * 2, 10)

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))     # -> (8, 4, 4)
        x = self.pool(torch.relu(self.conv2(x)))      # -> (16, 2, 2)
        x = x.view(x.size(0), -1)
        return self.fc(x)

class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

def train(model, X_train_in, X_test_in, epochs, report_at):
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    loss_fn = nn.CrossEntropyLoss()
    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad()
        loss = loss_fn(model(X_train_in), y_train_t)
        loss.backward()
        optimizer.step()
        if epoch in report_at:
            model.eval()
            with torch.no_grad():
                test_acc = (model(X_test_in).argmax(1) == y_test_t).float().mean().item()
            print(f"  epoch {epoch:>3}: train_loss={loss.item():.4f}  test_acc={test_acc:.4f}")

checkpoints = {1, 5, 10, 20, 30, 40, 50}

torch.manual_seed(0)
cnn = SmallCNN()
print("CNN parameters:", sum(p.numel() for p in cnn.parameters()))
train(cnn, X_train_img, X_test_img, 50, checkpoints)

torch.manual_seed(0)
mlp = MLP()
print("\nMLP parameters:", sum(p.numel() for p in mlp.parameters()))
train(mlp, X_train_flat, X_test_flat, 50, checkpoints)
