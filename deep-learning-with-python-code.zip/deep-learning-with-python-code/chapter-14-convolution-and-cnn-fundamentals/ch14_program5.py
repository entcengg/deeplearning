# ch14_program5.py
# Visualizing what Program 4's trained CNN actually learned: forward one
# test digit through the trained conv1 layer and inspect its 8 feature
# maps directly, rather than treating the convolution as a black box.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = digits.images.astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

X_train_img = torch.from_numpy(X_train).unsqueeze(1)
X_test_img = torch.from_numpy(X_test).unsqueeze(1)
y_train_t = torch.from_numpy(y_train).long()
y_test_t = torch.from_numpy(y_test).long()


class SmallCNN(nn.Module):
    """Identical architecture to Chapter 14 Program 4's SmallCNN."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)    # 8x8 -> 8x8x8
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)   # 4x4 -> 4x4x16
        self.fc = nn.Linear(16 * 2 * 2, 10)

    def forward(self, x):
        f1 = torch.relu(self.conv1(x))        # the feature maps we will visualize
        x = self.pool(f1)
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)
        return self.fc(x)

    def conv1_features(self, x):
        """Return conv1's post-ReLU feature maps without running the rest
        of the network -- exactly what Program 4's forward() computes
        internally as f1, exposed here for inspection."""
        return torch.relu(self.conv1(x))


# ---------------------------------------------------------------
# Train, identically to Program 4 (same seed, same 50 epochs), so the
# filters inspected below are the actual filters Program 4 reported on.
# ---------------------------------------------------------------
torch.manual_seed(0)
cnn = SmallCNN()
optimizer = torch.optim.Adam(cnn.parameters(), lr=0.01)
loss_fn = nn.CrossEntropyLoss()
for epoch in range(1, 51):
    cnn.train()
    optimizer.zero_grad()
    loss = loss_fn(cnn(X_train_img), y_train_t)
    loss.backward()
    optimizer.step()

cnn.eval()
with torch.no_grad():
    test_acc = (cnn(X_test_img).argmax(1) == y_test_t).float().mean().item()
print(f"trained CNN test accuracy after 50 epochs: {test_acc:.4f} (matches Program 4)")

# ---------------------------------------------------------------
# Pick one test image and look at its 8 conv1 feature maps.
# ---------------------------------------------------------------
sample_idx = 0
sample_image = X_test_img[sample_idx:sample_idx + 1]     # (1, 1, 8, 8)
sample_label = y_test[sample_idx]

with torch.no_grad():
    feature_maps = cnn.conv1_features(sample_image)       # (1, 8, 8, 8)
feature_maps = feature_maps.squeeze(0).numpy()             # (8, 8, 8)

print(f"\nsample test image: digit class {sample_label}, shape {tuple(sample_image.shape)}")
print(f"conv1 output shape (8 filters, each 8x8): {feature_maps.shape}")
print("\nper-filter activation statistics (post-ReLU, this one image):")
print(f"{'filter':>6} {'mean':>8} {'max':>8} {'frac_zero':>10}")
for f in range(8):
    fmap = feature_maps[f]
    frac_zero = float((fmap == 0).mean())
    print(f"{f:>6} {fmap.mean():>8.4f} {fmap.max():>8.4f} {frac_zero:>10.3f}")

most_active = int(feature_maps.reshape(8, -1).mean(axis=1).argmax())
most_sparse = int(feature_maps.reshape(8, -1).std(axis=1).argmin())
print(f"\nmost active filter overall: {most_active}")
print(f"most spatially uniform filter (lowest std): {most_sparse}")

np.savez("ch14_feature_maps.npz", image=sample_image.squeeze().numpy(),
         feature_maps=feature_maps, label=sample_label)
print("\nsaved sample image + feature maps to ch14_feature_maps.npz")
