# ch13_program2.py
# Learning XOR again -- same task as Chapter 10, but built from PyTorch's
# nn.Module, a library loss function, and a library optimizer.

import torch
import torch.nn as nn

torch.manual_seed(0)

class XORNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Linear(2, 2)     # replaces hand-built W1, b1
        self.output = nn.Linear(2, 1)     # replaces hand-built W2, b2

    def forward(self, x):
        a1 = torch.sigmoid(self.hidden(x))
        a2 = torch.sigmoid(self.output(a1))
        return a2

X = torch.tensor([[0., 0.], [0., 1.], [1., 0.], [1., 1.]])
Y = torch.tensor([[0.], [1.], [1.], [0.]])

model = XORNet()
loss_fn = nn.BCELoss()                                   # Chapter 8's binary cross-entropy
optimizer = torch.optim.SGD(model.parameters(), lr=1.0)  # Chapter 11's plain gradient descent

for epoch in range(1, 5001):
    optimizer.zero_grad()          # clear last step's gradients (Common Mistake 1)
    pred = model(X)                # forward pass
    loss = loss_fn(pred, Y)
    loss.backward()                # backward pass -- all of Chapter 10, one call
    optimizer.step()               # the gradient descent update
    if epoch in [1, 10, 100, 500, 1000, 2000, 5000]:
        print(f"epoch {epoch:>5}: loss = {loss.item():.4f}")

with torch.no_grad():
    final_preds = model(X)
print(f"\nfinal predictions: {[round(p, 4) for p in final_preds.squeeze().tolist()]}")
print(f"true labels:       {Y.squeeze().tolist()}")
