# ch13_program3.py
# The same XOR network and training run, this time in Keras.

import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"     # quiet TensorFlow's startup logging

import numpy as np
import keras
from keras import layers

keras.utils.set_random_seed(0)

X = np.array([[0., 0.], [0., 1.], [1., 0.], [1., 1.]])
Y = np.array([[0.], [1.], [1.], [0.]])

model = keras.Sequential([
    layers.Input(shape=(2,)),
    layers.Dense(2, activation="sigmoid"),   # the hidden layer
    layers.Dense(1, activation="sigmoid"),   # the output layer
])
model.compile(optimizer=keras.optimizers.SGD(learning_rate=1.0), loss="binary_crossentropy")

history = model.fit(X, Y, epochs=1000, verbose=0)
losses = history.history["loss"]
for epoch in [1, 10, 100, 500, 1000]:
    print(f"epoch {epoch:>5}: loss = {losses[epoch-1]:.4f}")

preds = model.predict(X, verbose=0)
print(f"\nfinal predictions: {[round(float(p[0]), 4) for p in preds]}")
print(f"true labels:       {Y.squeeze().tolist()}")
