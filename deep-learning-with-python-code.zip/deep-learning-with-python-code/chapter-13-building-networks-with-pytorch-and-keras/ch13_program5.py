# ch13_program5.py
# A complete, standard training workflow: a synthetic dataset wrapped in
# a PyTorch Dataset/DataLoader (batching), a train/validation split, a
# training loop that checkpoints the best validation model to disk, and
# a final reload of that checkpoint confirming it reproduces the
# recorded best validation loss exactly.

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split

torch.manual_seed(0)

# ---------------------------------------------------------------
# 1. Dataset: two noisy 2D Gaussian blobs, 240 points total -- a
#    slightly harder cousin of this book's XOR/AND toy problems,
#    now large enough that batching and a validation split make sense.
# ---------------------------------------------------------------
class BlobDataset(Dataset):
    def __init__(self, n_per_class=120, seed=0):
        g = torch.Generator().manual_seed(seed)
        class0 = torch.randn(n_per_class, 2, generator=g) * 0.9 + torch.tensor([-1.5, -1.5])
        class1 = torch.randn(n_per_class, 2, generator=g) * 0.9 + torch.tensor([1.5, 1.5])
        self.X = torch.cat([class0, class1], dim=0)
        self.y = torch.cat([torch.zeros(n_per_class), torch.ones(n_per_class)]).unsqueeze(1)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


full_dataset = BlobDataset()
n_val = 48                      # 20% held out for validation
n_train = len(full_dataset) - n_val
train_set, val_set = random_split(
    full_dataset, [n_train, n_val], generator=torch.Generator().manual_seed(0)
)
train_loader = DataLoader(train_set, batch_size=16, shuffle=True,
                           generator=torch.Generator().manual_seed(0))
val_loader = DataLoader(val_set, batch_size=16, shuffle=False)

print(f"train examples: {len(train_set)}, validation examples: {len(val_set)}, "
      f"batches per training epoch: {len(train_loader)}")


# ---------------------------------------------------------------
# 2. Model: the same small nn.Module style as Program 2's XORNet.
# ---------------------------------------------------------------
class BlobNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Linear(2, 8)
        self.output = nn.Linear(8, 1)

    def forward(self, x):
        a1 = torch.relu(self.hidden(x))
        return self.output(a1)        # raw logits -- BCEWithLogitsLoss expects these


def run_validation(model, loader, loss_fn):
    model.eval()
    total_loss, n = 0.0, 0
    with torch.no_grad():
        for xb, yb in loader:
            pred = model(xb)
            total_loss += loss_fn(pred, yb).item() * len(xb)
            n += len(xb)
    return total_loss / n


# ---------------------------------------------------------------
# 3. Training loop: batching, a validation pass every epoch, and a
#    checkpoint saved to disk whenever validation loss improves.
# ---------------------------------------------------------------
model = BlobNet()
optimizer = torch.optim.Adam(model.parameters(), lr=0.05)
loss_fn = nn.BCEWithLogitsLoss()

CHECKPOINT_PATH = "ch13_program5_checkpoint.pt"
best_val_loss = float("inf")

for epoch in range(1, 31):
    model.train()
    train_loss_sum, n_seen = 0.0, 0
    for xb, yb in train_loader:
        optimizer.zero_grad()
        pred = model(xb)
        loss = loss_fn(pred, yb)
        loss.backward()
        optimizer.step()
        train_loss_sum += loss.item() * len(xb)
        n_seen += len(xb)
    train_loss = train_loss_sum / n_seen

    val_loss = run_validation(model, val_loader, loss_fn)

    if val_loss < best_val_loss:
        best_val_loss = val_loss
        torch.save({
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "val_loss": val_loss,
        }, CHECKPOINT_PATH)

    if epoch in [1, 5, 10, 15, 20, 25, 30]:
        print(f"epoch {epoch:>3}: train_loss={train_loss:.4f}  val_loss={val_loss:.4f}")

print(f"\nbest validation loss seen during training: {best_val_loss:.4f}")

# ---------------------------------------------------------------
# 4. Reload the checkpointed model into a FRESH instance and confirm
#    it reproduces the recorded best validation loss exactly -- the
#    whole point of checkpointing is that this number must match.
# ---------------------------------------------------------------
checkpoint = torch.load(CHECKPOINT_PATH, weights_only=True)
reloaded_model = BlobNet()
reloaded_model.load_state_dict(checkpoint["model_state_dict"])
reloaded_val_loss = run_validation(reloaded_model, val_loader, loss_fn)

print(f"\ncheckpoint was saved at epoch {checkpoint['epoch']}, "
      f"recorded val_loss={checkpoint['val_loss']:.4f}")
print(f"reloaded model's recomputed val_loss={reloaded_val_loss:.4f}  "
      f"(matches recorded value: {abs(reloaded_val_loss - checkpoint['val_loss']) < 1e-6})")

torch.save(model.state_dict(), "ch13_program5_final_model.pt")
print("final-epoch model weights (not necessarily the best) saved separately.")
