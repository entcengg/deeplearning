# ch13_program1.py
# PyTorch's autograd reproduces Chapter 10's hand-derived backward pass
# for the exact same 2-2-1 network, exactly.

import torch

x = torch.tensor([0.5, 0.2])
y = torch.tensor(1.0)

W1 = torch.tensor([[0.3, -0.1], [0.2, 0.4]], requires_grad=True)
b1 = torch.tensor([0.1, -0.2], requires_grad=True)
W2 = torch.tensor([[0.5, -0.3]], requires_grad=True)
b2 = torch.tensor([0.2], requires_grad=True)

# Forward pass -- identical to Chapter 9 and Chapter 10, but every tensor
# with requires_grad=True is now secretly building a computation graph.
z1 = W1 @ x + b1
a1 = torch.sigmoid(z1)
z2 = W2 @ a1 + b2
a2 = torch.sigmoid(z2)

loss = torch.nn.functional.binary_cross_entropy(a2, y.unsqueeze(0))
print(f"y_hat = {a2.item():.4f}   loss = {loss.item():.4f}")

# One line replaces Chapter 10's entire hand-derived backward() function.
loss.backward()

print("\nW1.grad:", W1.grad)
print("b1.grad:", b1.grad)
print("W2.grad:", W2.grad)
print("b2.grad:", b2.grad)
