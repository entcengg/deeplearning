# Chapter 13 · Building Networks with PyTorch and Keras

Code for Chapter 13 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 12](../chapter-12-regularization-and-generalization/README.md) · [Chapter 14 →](../chapter-14-convolution-and-cnn-fundamentals/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 13.2.1 Program 1: Autograd Meets the Worked Example | PyTorch's autograd reproduces Chapter 10's hand-derived gradients | [`ch13_program1.py`](ch13_program1.py) | [ch13_program1.txt](expected_output/ch13_program1.txt) | 4 s |
| 2 | 13.4.1 Program 2: Learning XOR, the Framework Way | The full XOR training loop, built from `nn.Module`, a library loss, and a library optimizer | [`ch13_program2.py`](ch13_program2.py) | [ch13_program2.txt](expected_output/ch13_program2.txt) | 13 s |
| 3 | 13.5.1 Program 3: The Same Network, in Keras | XOR, trained in Keras | [`ch13_program3.py`](ch13_program3.py) | [ch13_program3.txt](expected_output/ch13_program3.txt) | 40 s |
| 4 | 13.7 Common Mistakes | The `zero_grad()` bug, demonstrated | [`ch13_program4.py`](ch13_program4.py) | [ch13_program4.txt](expected_output/ch13_program4.txt) | 2 s |
| 5 | 13.8.1 Program 5: Dataset, Batching, Validation, and Checkpointing, Together | A complete training workflow: batched data, a validation split, and checkpointing the best model to disk | [`ch13_program5.py`](ch13_program5.py) | [ch13_program5.txt](expected_output/ch13_program5.txt) | 4 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-13-building-networks-with-pytorch-and-keras
python ch13_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch13_notebook.ipynb`](ch13_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, PyTorch, TensorFlow/Keras.

## Notes

- Program 3 needs TensorFlow: from the top folder run `python -m pip install -r requirements-tensorflow.txt`.
- Program 5 saves `ch13_program5_checkpoint.pt` and `ch13_program5_final_model.pt` in this folder.
