# ch13_program4.py
# A real PyTorch bug: forgetting optimizer.zero_grad(). Gradients
# accumulate across steps instead of being recomputed fresh each time.

import torch

def loss_fn(w):
    return (w - 3) ** 2       # the same f(w) = (w-3)^2 from Chapter 11

print("Without zero_grad() -- BUGGY:")
w = torch.tensor(0.0, requires_grad=True)
for step in range(1, 4):
    loss = loss_fn(w)
    loss.backward()                      # gradients ADD to whatever was already there
    print(f"  step {step}: w.grad = {w.grad.item():.4f}")
    with torch.no_grad():
        w -= 0.1 * w.grad

print("\nWith zero_grad() -- CORRECT:")
w2 = torch.tensor(0.0, requires_grad=True)
for step in range(1, 4):
    if w2.grad is not None:
        w2.grad.zero_()
    loss = loss_fn(w2)
    loss.backward()
    print(f"  step {step}: w2.grad = {w2.grad.item():.4f}")
    with torch.no_grad():
        w2 -= 0.1 * w2.grad

print("\nCompare the correct column to Chapter 11's plain-GD trace:")
print("  Chapter 11: grad=-6.0000, then -4.8000, then -3.8400 -- an exact match.")
