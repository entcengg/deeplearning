# ch21_program4.py
# Walking through the latent space. Take two REAL digits, encode both,
# and decode every point on the straight line between their codes:
#     z(alpha) = (1 - alpha) * z_A + alpha * z_B,   alpha in [0, 1].
# Both models are exactly Program 3's (same code, same seeds), so every
# number here is about the same two models. For the VAE the code of a
# digit is its posterior MEAN mu(x). An independent judge classifier
# (trained on real digits only, as in Program 3) reports its predicted
# label and confidence at each step, so the answer is measured, not
# just eyeballed.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t, X_test_t = torch.from_numpy(X_train), torch.from_numpy(X_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()


class PlainAutoencoder2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 2))
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z


class VAE2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, 2)
        self.logvar_head = nn.Linear(32, 2)
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)
        return self.decoder(z), mu, logvar


class Judge(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))


# --- Train Program 3's three networks (identical protocol and seeds) ----
torch.manual_seed(0)
ae = PlainAutoencoder2D()
opt = optim.Adam(ae.parameters(), lr=0.01)
for epoch in range(300):
    opt.zero_grad()
    nn.functional.mse_loss(ae(X_train_t)[0], X_train_t).backward()
    opt.step()
ae.eval()

torch.manual_seed(0)
vae = VAE2D()
opt = optim.Adam(vae.parameters(), lr=0.01)
for epoch in range(300):
    opt.zero_grad()
    recon, mu, logvar = vae(X_train_t)
    recon_loss = ((recon - X_train_t) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    (recon_loss + kl).backward()
    opt.step()
vae.eval()

torch.manual_seed(1)
judge = Judge()
opt = optim.Adam(judge.parameters(), lr=0.01)
for epoch in range(100):
    opt.zero_grad()
    nn.functional.cross_entropy(judge(X_train_t), y_train_t).backward()
    opt.step()
judge.eval()

with torch.no_grad():                        # deterministic checks against Program 3
    ae_mse = [nn.functional.mse_loss(ae(x)[0], x).item() for x in (X_train_t, X_test_t)]
    judge_acc = (judge(X_test_t).argmax(1) == y_test_t).float().mean().item()
print("Program 3's models, retrained with the same code and seeds:")
print(f"  plain AE train / test MSE {ae_mse[0]:.4f} / {ae_mse[1]:.4f}"
      f"   judge test accuracy {judge_acc:.4f}")

# --- Hand check of the interpolation formula ---------------------------
zA, zB = np.array([-2.0, -2.0]), np.array([4.0, -5.0])
print("\nHand check of z(alpha) = (1-alpha) z_A + alpha z_B with "
      f"z_A={zA.tolist()}, z_B={zB.tolist()}:")
for a in (0.0, 0.25, 0.5, 1.0):
    print(f"  alpha={a:4.2f} -> z = {((1 - a) * zA + a * zB).tolist()}")


def codes(name, x):
    """The latent code of images x: the encoder output (AE) or mu (VAE)."""
    with torch.no_grad():
        return ae.encoder(x) if name == "ae" else vae.encode(x)[0]


def walk(code_a, code_b, decoder, alphas):
    """Decode the straight line between two codes; judge every image."""
    zs = torch.stack([(1 - a) * code_a + a * code_b for a in alphas])
    with torch.no_grad():
        imgs = decoder(zs)
        probs = torch.softmax(judge(imgs), dim=1)
    steps = ((imgs[1:] - imgs[:-1]) ** 2).mean(dim=1)       # pixel MSE between neighbours
    return zs, imgs, probs.argmax(1), probs.max(1).values, steps


def jumpiness(steps):
    return (steps.max() / steps.mean()).item()               # 1.0 = perfectly even steps


print("\nHand check of jumpiness = (largest step) / (mean step): steps "
      "[1,1,4,1,1,2] -> %.3f" % (4 / np.mean([1, 1, 4, 1, 1, 2])))

# --- Part A: one concrete pair -- the first real 0 and the first real 1 -
idx0, idx1 = int(np.where(y == 0)[0][0]), int(np.where(y == 1)[0][0])
alphas = np.linspace(0.0, 1.0, 7)
print(f"\nPart A: walk from real digit {y[idx0]} (index {idx0}) "
      f"to real digit {y[idx1]} (index {idx1}), 7 steps")
runs = {}
for name, decoder in [("ae", ae.decoder), ("vae", vae.decoder)]:
    ca = codes(name, torch.from_numpy(X[idx0:idx0 + 1]))[0]
    cb = codes(name, torch.from_numpy(X[idx1:idx1 + 1]))[0]
    zs, imgs, pred, conf, steps = walk(ca, cb, decoder, alphas)
    runs[name] = (zs, pred, conf, steps)
    title = "Plain AE" if name == "ae" else "VAE (posterior means)"
    print(f"\n{title}: code of the 0 = {ca.numpy().round(2)}, code of the 1 = {cb.numpy().round(2)}")
    print(f"{'alpha':>7}{'latent z':>18}{'judge':>7}{'conf':>8}{'step MSE':>10}")
    for k, a in enumerate(alphas):
        step = f"{steps[k - 1].item():10.4f}" if k > 0 else f"{'--':>10}"
        print(f"{a:7.3f}   ({zs[k, 0]:6.2f},{zs[k, 1]:6.2f}){pred[k].item():7d}"
              f"{conf[k].item():8.4f}{step}")
    print(f"  judge labels along the path: {pred.tolist()}   jumpiness = {jumpiness(steps):.2f}")

# --- Part B: 200 random pairs of test digits from different classes ----
rng = np.random.default_rng(0)
pairs = []
while len(pairs) < 200:
    i, j = rng.integers(0, len(X_test), size=2)
    if y_test[i] != y_test[j]:
        pairs.append((int(i), int(j)))

print("\nPart B: 200 random pairs of held-out digits from different classes, 7 steps each")
print(f"{'':42s}{'plain AE':>10}{'VAE':>10}")
rows = {"ae": [], "vae": []}
for name, decoder in [("ae", ae.decoder), ("vae", vae.decoder)]:
    ends = codes(name, X_test_t)
    for i, j in pairs:
        zs, imgs, pred, conf, steps = walk(ends[i], ends[j], decoder, alphas)
        rows[name].append((
            ((pred[0].item() == y_test[i]) + (pred[-1].item() == y_test[j])) / 2,  # endpoints judged correct
            (conf[0].item() + conf[-1].item()) / 2,                                # endpoint confidence
            conf[1:-1].mean().item(),                                              # interior confidence
            steps.mean().item(),                                                   # mean pixel change per step
            jumpiness(steps),
            int((pred[1:] != pred[:-1]).sum().item()),                             # label changes on the path
            (ends[i] - ends[j]).norm().item() / ends.std(dim=0).norm().item(),     # path length in std units
        ))
stats = {k: np.array(v).mean(axis=0) for k, v in rows.items()}
labels = ["endpoints judged correct (fraction)", "judge confidence at the 2 endpoints",
          "judge confidence at the 5 interior steps", "mean pixel change per step (MSE)",
          "jumpiness (largest / mean step)", "judge-label changes along the path",
          "endpoint distance / overall code spread"]
for r, label in enumerate(labels):
    print(f"{label:42s}{stats['ae'][r]:10.4f}{stats['vae'][r]:10.4f}")
