# ch21_program3.py
# Capstone: does regularizing the latent space toward a simple, known prior
# actually change where a model's data ends up living in latent space, and
# does that in turn change what happens when a brand-new latent point is
# invented and decoded? A plain autoencoder is trained purely for
# reconstruction, so nothing stops its latent space from settling anywhere,
# at any scale; a VAE adds a KL term that pulls every encoded point toward
# a standard normal prior. This program trains both, matched in every
# other respect, directly measures where each model's real data landed in
# latent space, and then tests what happens when new latent points are
# invented and decoded.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from scipy.spatial.distance import cdist

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t, X_test_t = torch.from_numpy(X_train), torch.from_numpy(X_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()


class PlainAutoencoder2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 2))
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z


class VAE2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, 2)
        self.logvar_head = nn.Linear(32, 2)
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + torch.randn_like(std) * std

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar


def vae_loss(recon, x, mu, logvar):
    recon_loss = ((recon - x) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    return recon_loss, kl


class Judge(nn.Module):
    """An independent classifier trained only on REAL digit images. Its
    confidence on a decoded image is a proxy for "does this look like a
    real digit" -- it never trains on anything decoded."""
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))


def nn_distance_ratio(z_all, random_points):
    real_dists = cdist(z_all, z_all)
    np.fill_diagonal(real_dists, np.inf)
    real_nn = real_dists.min(axis=1).mean()
    random_nn = cdist(random_points, z_all).min(axis=1).mean()
    return real_nn, random_nn, random_nn / real_nn


def mean_confidence(judge, images):
    with torch.no_grad():
        probs = torch.softmax(judge(images), dim=1)
        return probs.max(dim=1).values.mean().item()


# ---------------------------------------------------------------
# Train the plain 2D autoencoder and the 2D VAE -- same data, same
# optimizer, same epoch budget, same random-seed protocol.
# ---------------------------------------------------------------
torch.manual_seed(0)
ae = PlainAutoencoder2D()
ae_opt = optim.Adam(ae.parameters(), lr=0.01)
for epoch in range(300):
    ae.train(); ae_opt.zero_grad()
    recon, _ = ae(X_train_t)
    loss = nn.functional.mse_loss(recon, X_train_t)
    loss.backward(); ae_opt.step()
ae.eval()
with torch.no_grad():
    ae_train_mse = nn.functional.mse_loss(ae(X_train_t)[0], X_train_t).item()
    ae_test_mse = nn.functional.mse_loss(ae(X_test_t)[0], X_test_t).item()
    _, z_ae_all = ae(torch.from_numpy(X))
    z_ae_all = z_ae_all.numpy()

torch.manual_seed(0)
vae = VAE2D()
vae_opt = optim.Adam(vae.parameters(), lr=0.01)
for epoch in range(300):
    vae.train(); vae_opt.zero_grad()
    recon, mu, logvar = vae(X_train_t)
    recon_loss, kl = vae_loss(recon, X_train_t, mu, logvar)
    (recon_loss + kl).backward(); vae_opt.step()
vae.eval()
with torch.no_grad():
    vae_train_mse = nn.functional.mse_loss(vae(X_train_t)[0], X_train_t).item()
    vae_test_mse = nn.functional.mse_loss(vae(X_test_t)[0], X_test_t).item()
    mu_all, logvar_all = vae.encode(torch.from_numpy(X))
    z_vae_all = mu_all.numpy()

print("Part A: reconstruction quality (mean squared error per pixel)")
print(f"  plain autoencoder:  train_mse={ae_train_mse:.4f}  test_mse={ae_test_mse:.4f}")
print(f"  VAE:                train_mse={vae_train_mse:.4f}  test_mse={vae_test_mse:.4f}")

# ---------------------------------------------------------------
# Part B1: where did each model's REAL data actually end up in latent
# space? Measured directly -- no sampling involved yet.
# ---------------------------------------------------------------
box = 2.0
ae_in_box = ((np.abs(z_ae_all[:, 0]) <= box) & (np.abs(z_ae_all[:, 1]) <= box)).mean()
vae_in_box = ((np.abs(z_vae_all[:, 0]) <= box) & (np.abs(z_vae_all[:, 1]) <= box)).mean()

print(f"\nPart B1: where the real data landed in latent space")
print(f"  plain AE : mean=({z_ae_all[:,0].mean():6.2f},{z_ae_all[:,1].mean():6.2f})  "
      f"std=({z_ae_all[:,0].std():.2f},{z_ae_all[:,1].std():.2f})  "
      f"{ae_in_box*100:5.1f}% of points fall inside the box [-2,2]x[-2,2]")
print(f"  VAE      : mean=({z_vae_all[:,0].mean():6.2f},{z_vae_all[:,1].mean():6.2f})  "
      f"std=({z_vae_all[:,0].std():.2f},{z_vae_all[:,1].std():.2f})  "
      f"{vae_in_box*100:5.1f}% of points fall inside the box [-2,2]x[-2,2]")

# ---------------------------------------------------------------
# Part B2: invent new latent points using each model's natural sampling
# procedure, decode them, and check whether the result lands near real
# data (by two independent measures).
#   plain AE : no known target region -- must first encode real data just
#              to find a sensible region to sample from
#   VAE      : sample directly from N(0, 1), the SAME fixed prior used
#              during training -- no need to look at any data first
# ---------------------------------------------------------------
rng = np.random.default_rng(42)
n_probe = 300

x_lo, x_hi = z_ae_all[:, 0].min(), z_ae_all[:, 0].max()
y_lo, y_hi = z_ae_all[:, 1].min(), z_ae_all[:, 1].max()
ae_random_points = np.column_stack([
    rng.uniform(x_lo, x_hi, n_probe),
    rng.uniform(y_lo, y_hi, n_probe),
])
vae_random_points = rng.normal(0.0, 1.0, size=(n_probe, 2))

ae_real_nn, ae_random_nn, ae_ratio = nn_distance_ratio(z_ae_all, ae_random_points)
vae_real_nn, vae_random_nn, vae_ratio = nn_distance_ratio(z_vae_all, vae_random_points)

print("\nPart B2: nearest-neighbor distance from invented latent points")
print("         to the nearest REAL encoded point (lower = more in-distribution)")
print(f"  plain AE : sampled from its own real-data bounding box (had to be measured first)")
print(f"             real-to-real baseline={ae_real_nn:.3f}  random-to-real={ae_random_nn:.3f}  "
      f"ratio={ae_ratio:.2f}x")
print(f"  VAE      : sampled from the fixed prior N(0,1) (no data lookup needed)")
print(f"             real-to-real baseline={vae_real_nn:.3f}  random-to-real={vae_random_nn:.3f}  "
      f"ratio={vae_ratio:.2f}x")

with torch.no_grad():
    ae_decoded = ae.decoder(torch.tensor(ae_random_points, dtype=torch.float32))
    vae_decoded = vae.decoder(torch.tensor(vae_random_points, dtype=torch.float32))

torch.manual_seed(1)
judge = Judge()
judge_opt = optim.Adam(judge.parameters(), lr=0.01)
judge_loss_fn = nn.CrossEntropyLoss()
for epoch in range(100):
    judge.train(); judge_opt.zero_grad()
    loss = judge_loss_fn(judge(X_train_t), y_train_t)
    loss.backward(); judge_opt.step()
judge.eval()
with torch.no_grad():
    judge_test_acc = (judge(X_test_t).argmax(1) == y_test_t).float().mean().item()

real_confidence = mean_confidence(judge, X_test_t)
ae_confidence = mean_confidence(judge, ae_decoded)
vae_confidence = mean_confidence(judge, vae_decoded)

print(f"\nAn independent judge classifier (trained only on real digits, "
      f"test accuracy={judge_test_acc:.4f})")
print("scores how digit-like each decoded image looks (a proxy, not ground truth):")
print(f"  mean confidence on real test images          : {real_confidence:.4f}  (ceiling reference)")
print(f"  mean confidence on plain-AE's random decodes  : {ae_confidence:.4f}")
print(f"  mean confidence on VAE's random decodes       : {vae_confidence:.4f}")
