# ch21_program2.py
# Shrink the bottleneck to exactly 2 numbers so the latent space can
# be plotted directly. After training, look at where the 10 digit
# classes land (no label was ever used in training) -- then probe
# whether a RANDOM point in that same latent region decodes into
# anything reasonable, or whether the space has "holes."

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from scipy.spatial.distance import cdist

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t = torch.from_numpy(X_train)
X_test_t = torch.from_numpy(X_test)


class Autoencoder2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 2),
        )
        self.decoder = nn.Sequential(
            nn.Linear(2, 32), nn.ReLU(),
            nn.Linear(32, 64), nn.Sigmoid(),
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z


torch.manual_seed(0)
model = Autoencoder2D()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
loss_fn = nn.MSELoss()

print("Training a 2D-bottleneck autoencoder (64 -> 32 -> 2 -> 32 -> 64)...")
for epoch in range(1, 201):
    model.train()
    optimizer.zero_grad()
    recon, _ = model(X_train_t)
    loss = loss_fn(recon, X_train_t)
    loss.backward()
    optimizer.step()
    if epoch in {1, 50, 100, 150, 200}:
        model.eval()
        with torch.no_grad():
            test_recon, _ = model(X_test_t)
            test_loss = loss_fn(test_recon, X_test_t)
        print(f"  epoch {epoch:>3}: train_mse={loss.item():.4f}  test_mse={test_loss.item():.4f}")

model.eval()
with torch.no_grad():
    _, z_all = model(torch.from_numpy(X))
z_all = z_all.numpy()

print(f"\nEncoded all {len(X)} digits to 2D latent points.")
print("Latent bounding box:")
print(f"  x in [{z_all[:,0].min():.3f}, {z_all[:,0].max():.3f}]")
print(f"  y in [{z_all[:,1].min():.3f}, {z_all[:,1].max():.3f}]")

print("\nMean latent position per digit class (shows label clusters emerge")
print("with NO label information ever used in training):")
for digit in range(10):
    mean_pos = z_all[y == digit].mean(axis=0)
    print(f"  digit {digit}: ({mean_pos[0]:6.2f}, {mean_pos[1]:6.2f})")

# --- The "holes" experiment ---------------------------------------------
rng = np.random.default_rng(42)
n_probe = 300
x_lo, x_hi = z_all[:, 0].min(), z_all[:, 0].max()
y_lo, y_hi = z_all[:, 1].min(), z_all[:, 1].max()
random_points = np.column_stack([
    rng.uniform(x_lo, x_hi, n_probe),
    rng.uniform(y_lo, y_hi, n_probe),
])

# Baseline: how far apart are REAL encoded points from their nearest neighbor?
real_dists = cdist(z_all, z_all)
np.fill_diagonal(real_dists, np.inf)
real_nn_dist = real_dists.min(axis=1).mean()

# How far is a RANDOM point in the bounding box from its nearest real point?
random_dists = cdist(random_points, z_all)
random_nn_dist = random_dists.min(axis=1).mean()

print(f"\nNearest-neighbor distance in latent space:")
print(f"  real encoded points, to their nearest OTHER real point (baseline): {real_nn_dist:.3f}")
print(f"  random bounding-box points, to their nearest real point:           {random_nn_dist:.3f}")
print(f"  ratio (random / real baseline): {random_nn_dist / real_nn_dist:.2f}x")

with torch.no_grad():
    decoded_random = model.decoder(torch.tensor(random_points, dtype=torch.float32))
print(f"\nDecoded {n_probe} random bounding-box points into images (see Figure for examples).")
print(f"Mean pixel value of decoded random images: {decoded_random.numpy().mean():.4f}")
print(f"Mean pixel value of real images:            {X.mean():.4f}")
