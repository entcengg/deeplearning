# Chapter 21 · Autoencoders and Variational Autoencoders

Code for Chapter 21 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 20](../chapter-20-deep-learning-for-nlp/README.md) · [Chapter 22 →](../chapter-22-generative-adversarial-networks/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 21.1.1 Program 1: Training a Plain Autoencoder | Training a plain autoencoder on the digits dataset | [`ch21_program1.py`](ch21_program1.py) | [ch21_program1.txt](expected_output/ch21_program1.txt) | 5 s |
| 2 | 21.2.1 Program 2: A 2-D Latent Space | A 2-D-bottleneck autoencoder, its latent space, and the "holes" experiment | [`ch21_program2.py`](ch21_program2.py) | [ch21_program2.txt](expected_output/ch21_program2.txt) | 5 s |
| 3 | 21.4.1 Program 3: Plain Autoencoder vs. VAE | Where each model's data lands in latent space, and what happens when new points are invented and decoded | [`ch21_program3.py`](ch21_program3.py) | [ch21_program3.txt](expected_output/ch21_program3.txt) | 6 s |
| 4 | 21.5.1 Program 4: Interpolating Between Real Digits | Decoding straight latent paths between real digits with the plain autoencoder and the VAE, read by the judge classifier | [`ch21_program4.py`](ch21_program4.py) | [ch21_program4.txt](expected_output/ch21_program4.txt) | 6 s |
| 5 | 21.7.1 Program 5: Reconstruction Error as an Anomaly Score | Anomaly detection by reconstruction error with an autoencoder, PCA and a VAE, and the autoencoder versus PCA as dimensionality reducers | [`ch21_program5.py`](ch21_program5.py) | [ch21_program5.txt](expected_output/ch21_program5.txt) | 13 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-21-autoencoders-and-variational-autoencoders
python ch21_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch21_notebook.ipynb`](ch21_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, SciPy, PyTorch.
