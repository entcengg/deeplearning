# ch21_program5.py
# Anomaly detection with reconstruction error. Train on "normal" data only
# (digits 0-8), never showing the model a single anomaly, then ask how
# well the per-image reconstruction error
#     s(x) = (1/d) * sum_i (x_i - x_hat_i)^2
# separates held-out normal digits from (a) the unseen class, digit 9, and
# (b) normal digits corrupted by noise. The threshold is chosen on
# VALIDATION normals only. PCA's reconstruction error is the linear
# baseline, and a VAE's the probabilistic one.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.metrics import roc_auc_score

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target


class Autoencoder(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, k))
        self.decoder = nn.Sequential(nn.Linear(k, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, x):
        return self.decoder(self.encoder(x))


class VAE(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head, self.logvar_head = nn.Linear(32, k), nn.Linear(32, k)
        self.decoder = nn.Sequential(nn.Linear(k, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)

    def forward(self, x):
        mu, logvar = self.encode(x)
        return self.decoder(mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)), mu, logvar


def fit_ae(x_train, k):
    torch.manual_seed(0)
    model, data = Autoencoder(k), torch.from_numpy(x_train)
    opt = optim.Adam(model.parameters(), lr=0.01)
    for epoch in range(300):
        opt.zero_grad()
        nn.functional.mse_loss(model(data), data).backward()
        opt.step()
    return model.eval()


def fit_vae(x_train, k):
    torch.manual_seed(0)
    model, data = VAE(k), torch.from_numpy(x_train)
    opt = optim.Adam(model.parameters(), lr=0.01)
    for epoch in range(300):
        opt.zero_grad()
        recon, mu, logvar = model(data)
        rec = ((recon - data) ** 2).sum(dim=1).mean()
        kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
        (rec + kl).backward()
        opt.step()
    return model.eval()


def score_ae(model, x):                      # s(x): per-image reconstruction MSE
    with torch.no_grad():
        return ((torch.from_numpy(x) - model(torch.from_numpy(x))) ** 2).mean(dim=1).numpy()


def score_vae(model, x):                     # reconstruct from the posterior mean
    with torch.no_grad():
        xt = torch.from_numpy(x)
        return ((xt - model.decoder(model.encode(xt)[0])) ** 2).mean(dim=1).numpy()


def score_pca(pca, x):
    return ((x - pca.inverse_transform(pca.transform(x))) ** 2).mean(axis=1)


def auc(s_normal, s_anomaly):
    labels = np.r_[np.zeros(len(s_normal)), np.ones(len(s_anomaly))]
    return roc_auc_score(labels, np.r_[s_normal, s_anomaly])


def split(held_out):
    """Normal = every digit except held_out; 60% train / 20% validation / 20% test."""
    normal = X[y != held_out]
    order = np.random.default_rng(0).permutation(len(normal))
    a, b = int(0.6 * len(normal)), int(0.8 * len(normal))
    return normal[order[:a]], normal[order[a:b]], normal[order[b:]], X[y == held_out]


# --- Hand check: ROC-AUC = P(random anomaly scores above random normal) --
normal_s, anomaly_s = [0.02, 0.03, 0.05], [0.04, 0.09]
wins = sum(a > n for a in anomaly_s for n in normal_s)
print(f"Hand check: 3 normal scores {normal_s}, 2 anomaly scores {anomaly_s}")
print(f"  anomaly > normal in {wins} of 6 pairs -> AUC = {wins}/6 = {wins / 6:.4f};  "
      f"roc_auc_score = {auc(normal_s, anomaly_s):.4f}")

# --- Part A: unseen class = digit 9 -------------------------------------
x_tr, x_va, x_te, x_9 = split(9)
print(f"\nPart A: normal = digits 0-8 (train {len(x_tr)}, validation {len(x_va)}, "
      f"test {len(x_te)})")
print(f"        unseen anomaly = digit 9 ({len(x_9)} images)")
ae8, vae8, pca8 = fit_ae(x_tr, 8), fit_vae(x_tr, 8), PCA(n_components=8).fit(x_tr)
detectors = {"plain AE (8-D code)": lambda x: score_ae(ae8, x),
             "PCA (8 components)": lambda x: score_pca(pca8, x),
             "VAE (8-D code, beta=1)": lambda x: score_vae(vae8, x)}
print(f"{'detector':24s}{'mean s, normal':>15}{'mean s, digit 9':>16}{'AUC':>7}"
      f"{'9s flagged':>11}{'false alarms':>13}")
for name, score in detectors.items():
    s_va, s_te, s_9 = score(x_va), score(x_te), score(x_9)
    tau = np.percentile(s_va, 95)            # threshold from validation normals only
    print(f"{name:24s}{s_te.mean():15.4f}{s_9.mean():16.4f}{auc(s_te, s_9):7.3f}"
          f"{(s_9 > tau).mean():11.1%}{(s_te > tau).mean():13.1%}")

# --- Part B: corrupted inputs (Gaussian noise added to the test normals) -
print("\nPart B: AUC for telling clean test normals from the same images plus Gaussian noise")
print(f"{'noise std':>10}" + "".join(f"{n:>24s}" for n in detectors))
rng = np.random.default_rng(1)
for std in (0.1, 0.2, 0.3):
    noisy = np.clip(x_te + rng.normal(0.0, std, x_te.shape), 0.0, 1.0).astype(np.float32)
    print(f"{std:10.1f}" + "".join(f"{auc(f(x_te), f(noisy)):24.3f}" for f in detectors.values()))

# --- Part C: how wide may the bottleneck be? (anomaly = digit 9) ---------
print("\nPart C: bottleneck size k vs. digit-9 AUC and test reconstruction MSE")
print(f"{'k':>4}{'AE AUC':>9}{'PCA AUC':>9}{'AE test MSE':>13}{'PCA test MSE':>14}")
for k in (2, 4, 8, 16, 32):
    ae_k, pca_k = (ae8, pca8) if k == 8 else (fit_ae(x_tr, k), PCA(n_components=k).fit(x_tr))
    print(f"{k:4d}{auc(score_ae(ae_k, x_te), score_ae(ae_k, x_9)):9.3f}"
          f"{auc(score_pca(pca_k, x_te), score_pca(pca_k, x_9)):9.3f}"
          f"{score_ae(ae_k, x_te).mean():13.4f}{score_pca(pca_k, x_te).mean():14.4f}")

# --- Part D: is digit 9 typical? Hold out each digit in turn (k = 8) ----
print("\nPart D: AUC when each digit in turn is the unseen class (8-D code / 8 components)")
rows = {"AE": [], "PCA": []}
for held in range(10):
    x_tr_h, _, x_te_h, x_h = split(held)
    ae_h, pca_h = (ae8, pca8) if held == 9 else (fit_ae(x_tr_h, 8), PCA(n_components=8).fit(x_tr_h))
    rows["AE"].append(auc(score_ae(ae_h, x_te_h), score_ae(ae_h, x_h)))
    rows["PCA"].append(auc(score_pca(pca_h, x_te_h), score_pca(pca_h, x_h)))
print(f"{'unseen digit':>13}" + "".join(f"{d:6d}" for d in range(10)) + f"{'mean':>8}")
for name, vals in rows.items():
    print(f"{name:>13}" + "".join(f"{v:6.3f}" for v in vals) + f"{np.mean(vals):8.3f}")
