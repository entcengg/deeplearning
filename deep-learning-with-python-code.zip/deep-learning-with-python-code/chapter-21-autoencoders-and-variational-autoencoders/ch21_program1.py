# ch21_program1.py
# A plain (undercomplete) autoencoder: compress each 64-pixel digit
# image down to just 8 numbers, then reconstruct the original 64
# pixels from those 8. Trained purely to minimize reconstruction
# error -- no labels used anywhere.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
X_train, X_test = train_test_split(X, test_size=0.2, random_state=0)
X_train_t = torch.from_numpy(X_train)
X_test_t = torch.from_numpy(X_test)

print(f"Loaded sklearn digits: {len(X)} images, 8x8 = 64 pixels, scaled to [0, 1]")
print(f"Train: {len(X_train)} images   Test: {len(X_test)} images")


class Autoencoder(nn.Module):
    def __init__(self, latent_dim=8):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, latent_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 32), nn.ReLU(),
            nn.Linear(32, 64), nn.Sigmoid(),
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z


torch.manual_seed(0)
model = Autoencoder(latent_dim=8)
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
loss_fn = nn.MSELoss()

print(f"\nTraining a plain autoencoder (64 -> 32 -> 8 -> 32 -> 64)...")
checkpoints = {1, 10, 25, 50, 75, 100}
for epoch in range(1, 101):
    model.train()
    optimizer.zero_grad()
    recon, _ = model(X_train_t)
    loss = loss_fn(recon, X_train_t)
    loss.backward()
    optimizer.step()
    if epoch in checkpoints:
        model.eval()
        with torch.no_grad():
            test_recon, _ = model(X_test_t)
            test_loss = loss_fn(test_recon, X_test_t)
        print(f"  epoch {epoch:>3}: train_mse={loss.item():.4f}  test_mse={test_loss.item():.4f}")

model.eval()
with torch.no_grad():
    sample = X_test_t[0:1]
    recon, _ = model(sample)
orig_grid = sample.numpy().reshape(8, 8)
recon_grid = recon.numpy().reshape(8, 8)
print("\nOne test image, original vs reconstructed (rounded to 2 decimals):")
print("original:")
print(np.round(orig_grid, 2))
print("reconstructed:")
print(np.round(recon_grid, 2))
print(f"per-pixel absolute error (mean): {np.abs(orig_grid - recon_grid).mean():.4f}")
