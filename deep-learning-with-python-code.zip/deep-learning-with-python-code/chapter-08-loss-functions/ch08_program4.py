# ch08_program4.py
# Class imbalance: the accuracy paradox, weighted binary cross-entropy, and
# focal loss. All three use the SAME small, imbalanced, hand-inspectable
# dataset so the effect of each fix can be seen directly in the numbers.

import numpy as np

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

# --- A tiny, 9-to-1 imbalanced dataset of predictions a trained model
# might plausibly produce: 90 easy negatives, 5 easy positives, and 5
# HARD positives the model still gets wrong at the standard 0.5 threshold.
y_true = np.array([0] * 90 + [1] * 10)
y_hat = np.array([0.05] * 90 + [0.85] * 5 + [0.30] * 5)
group = np.array(["easy_neg"] * 90 + ["easy_pos"] * 5 + ["hard_pos"] * 5)

print("=== Part 1: the accuracy paradox ===")
pred_label = (y_hat >= 0.5).astype(int)
accuracy = np.mean(pred_label == y_true)
tp = np.sum((pred_label == 1) & (y_true == 1))
fp = np.sum((pred_label == 1) & (y_true == 0))
fn = np.sum((pred_label == 0) & (y_true == 1))
precision = tp / (tp + fp)
recall = tp / (tp + fn)
f1 = 2 * precision * recall / (precision + recall)
print(f"dataset: {np.sum(y_true==0)} negatives, {np.sum(y_true==1)} positives (9:1 imbalance)")
print(f"accuracy  = {accuracy:.4f}")
print(f"precision = {precision:.4f}   recall = {recall:.4f}   F1 = {f1:.4f}")
print("(a model that looks excellent on accuracy alone is only catching")
print(" half of the class that actually matters)")

print("\n=== Part 2: weighted binary cross-entropy ===")
n = len(y_true)
n0, n1 = np.sum(y_true == 0), np.sum(y_true == 1)
n_classes = 2
w0 = n / (n_classes * n0)       # sklearn's "balanced" class-weight formula
w1 = n / (n_classes * n1)
print(f"class counts: n0={n0}, n1={n1}  ->  balanced weights: w0={w0:.4f}, w1={w1:.4f}")
print(f"(w1/w0 = {w1/w0:.2f}x -- every positive example's loss term now")
print(" counts this many times more than a negative example's does)")

per_example_bce = bce(y_true, y_hat)
weights = np.where(y_true == 1, w1, w0)
unweighted_mean = np.mean(per_example_bce)
weighted_mean = np.mean(weights * per_example_bce)
print(f"\nunweighted mean BCE: {unweighted_mean:.5f}")
print(f"weighted mean BCE:   {weighted_mean:.5f}")

share_pos_unweighted = np.sum(per_example_bce[y_true == 1]) / np.sum(per_example_bce)
share_pos_weighted = np.sum((weights * per_example_bce)[y_true == 1]) / np.sum(weights * per_example_bce)
print(f"positive class's share of total loss: unweighted {share_pos_unweighted:.1%}  "
      f"-> weighted {share_pos_weighted:.1%}")

print("\n=== Part 3: focal loss ===")
def focal_loss(y, y_hat, alpha=0.25, gamma=2.0, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)
    p_t = np.where(y == 1, y_hat, 1 - y_hat)          # prob. assigned to the TRUE class
    alpha_t = np.where(y == 1, alpha, 1 - alpha)
    modulator = (1 - p_t) ** gamma
    return -alpha_t * modulator * np.log(p_t), modulator, p_t

fl, modulator, p_t = focal_loss(y_true, y_hat)
print("per-group focusing factor (1-p_t)^gamma, gamma=2 -- how much of the")
print("ordinary cross-entropy loss focal loss actually keeps:")
for g in ["easy_neg", "easy_pos", "hard_pos"]:
    mask = group == g
    print(f"  {g:>8}: p_t={p_t[mask][0]:.2f}  modulator=(1-p_t)^2={modulator[mask][0]:.4f}  "
          f"focal_loss={fl[mask][0]:.5f}  plain_bce={per_example_bce[mask][0]:.5f}")

ratio_easy_to_hard = modulator[group == "hard_pos"][0] / modulator[group == "easy_neg"][0]
print(f"\nthe hard positive's modulating factor is {ratio_easy_to_hard:.1f}x the easy")
print("negative's -- focal loss leaves the hard example's gradient almost")
print("untouched while suppressing the easy, already-correct ones.")

# Sanity check: gamma=0 must recover (alpha-)weighted cross-entropy exactly.
fl_gamma0, _, _ = focal_loss(y_true, y_hat, gamma=0.0)
alpha_t_check = np.where(y_true == 1, 0.25, 0.75)
weighted_bce_check = alpha_t_check * per_example_bce
max_diff = np.max(np.abs(fl_gamma0 - weighted_bce_check))
print(f"\ngamma=0 sanity check: max|focal_loss - alpha_weighted_bce| = {max_diff:.2e}")
