# ch08_program1.py
# Regression losses: MSE versus MAE, and their sensitivity to outliers.

import numpy as np

y = np.array([2.0, 3.0, 4.0, 20.0])      # the last point is an outlier
y_hat = np.array([2.5, 3.5, 4.5, 5.0])   # a model that ignores the outlier

errors = y - y_hat
print("errors (y - y_hat):", errors)

mse = np.mean(errors ** 2)
mae = np.mean(np.abs(errors))
print(f"MSE = {mse:.4f}")
print(f"MAE = {mae:.4f}")

print("\nWithout the outlier (first three points only):")
mse_no_outlier = np.mean(errors[:3] ** 2)
mae_no_outlier = np.mean(np.abs(errors[:3]))
print(f"MSE = {mse_no_outlier:.4f}   MAE = {mae_no_outlier:.4f}")
print("\nMSE moved far more than MAE when the outlier was added --")
print("squaring a large error makes it dominate the average.")
