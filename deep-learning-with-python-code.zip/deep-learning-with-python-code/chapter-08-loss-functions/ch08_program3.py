# ch08_program3.py
# Categorical cross-entropy paired with softmax, and its equally clean
# gradient with respect to the logits.

import numpy as np

def softmax(z):
    z = z - np.max(z)          # the Chapter 7 stability trick
    e = np.exp(z)
    return e / np.sum(e)

def categorical_cross_entropy(y_onehot, probs, eps=1e-12):
    return -np.sum(y_onehot * np.log(probs + eps))

logits = np.array([2.0, 1.0, 0.1])
probs = softmax(logits)
print("logits:", logits)
print("softmax probabilities:", np.round(probs, 4))

y_true_A = np.array([1, 0, 0])     # true class is A (the most likely one)
y_true_C = np.array([0, 0, 1])     # true class is C (the least likely one)

print(f"\nCCE if true class is A: {categorical_cross_entropy(y_true_A, probs):.4f}")
print(f"CCE if true class is C: {categorical_cross_entropy(y_true_C, probs):.4f}")
print("(being right but unsure costs little; being wrong costs a lot more)")

# The gradient of CCE+softmax w.r.t. the logits: probs - y_onehot.
grad_analytical = probs - y_true_A
print(f"\ndL/dz (analytical, true class A): {np.round(grad_analytical, 5)}")

def cce_of_logits(z, y_onehot):
    return categorical_cross_entropy(y_onehot, softmax(z))

h = 1e-5
numeric_grad = np.zeros(3)
for i in range(3):
    z_plus = logits.copy(); z_plus[i] += h
    z_minus = logits.copy(); z_minus[i] -= h
    numeric_grad[i] = (cce_of_logits(z_plus, y_true_A) - cce_of_logits(z_minus, y_true_A)) / (2 * h)
print(f"dL/dz (numerical):               {np.round(numeric_grad, 5)}")
