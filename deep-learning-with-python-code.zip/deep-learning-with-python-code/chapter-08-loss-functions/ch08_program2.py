# ch08_program2.py
# Binary cross-entropy: the formula, and the clean gradient it produces
# when paired with a sigmoid output -- compared against MSE's gradient,
# which vanishes exactly where it matters most.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def bce(y, y_hat, eps=1e-12):
    y_hat = np.clip(y_hat, eps, 1 - eps)   # avoid log(0)
    return -(y * np.log(y_hat) + (1 - y) * np.log(1 - y_hat))

print("Binary cross-entropy cost for true label y=1:")
for y_hat in [0.8, 0.5, 0.2, 0.01]:
    print(f"  y_hat={y_hat:<5}: BCE = {bce(1, y_hat):.5f}")

print("\nThe gradient reaching a sigmoid neuron, MSE vs BCE, when the")
print("model is CONFIDENTLY WRONG (true label y=1, z very negative):")
z = -4.0
y = 1.0
y_hat = sigmoid(z)
print(f"z={z}, sigmoid(z)=y_hat={y_hat:.5f}")

sigmoid_prime = y_hat * (1 - y_hat)
grad_mse = -2 * (y - y_hat) * sigmoid_prime
grad_bce = y_hat - y          # the clean result derived in the text
print(f"MSE:  dL/dz = -2(y-y_hat)*sigmoid'(z) = {grad_mse:.6f}   (nearly zero!)")
print(f"BCE:  dL/dz = y_hat - y                = {grad_bce:.6f}   (large, correctly urgent)")

# Numerical check of the BCE gradient via central difference.
def bce_of_z(z, y):
    return bce(y, sigmoid(z))

h = 1e-5
numeric = (bce_of_z(z + h, y) - bce_of_z(z - h, y)) / (2 * h)
print(f"BCE gradient, numerical check: {numeric:.6f}")
