# Chapter 8 · Loss Functions

Code for Chapter 8 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 7](../chapter-07-activation-functions/README.md) · [Chapter 9 →](../chapter-09-forward-propagation-and-multilayer-networks/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 8.1.1 Program 1: Outlier Sensitivity | MSE versus MAE on data containing one outlier | [`ch08_program1.py`](ch08_program1.py) | [ch08_program1.txt](expected_output/ch08_program1.txt) | < 1 s |
| 2 | 8.3.1 Program 2: The Gradient, Compared | Binary cross-entropy's cost, and its gradient compared against MSE's | [`ch08_program2.py`](ch08_program2.py) | [ch08_program2.txt](expected_output/ch08_program2.txt) | < 1 s |
| 3 | 8.4.1 Program 3: Categorical Cross-Entropy | Categorical cross-entropy and its gradient | [`ch08_program3.py`](ch08_program3.py) | [ch08_program3.txt](expected_output/ch08_program3.txt) | < 1 s |
| 4 | 8.7.1 Why Class Imbalance Breaks the Default Assumptions | The accuracy paradox on a 9-to-1 imbalanced dataset | [`ch08_program4.py`](ch08_program4.py) | [ch08_program4.txt](expected_output/ch08_program4.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-08-loss-functions
python ch08_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch08_notebook.ipynb`](ch08_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.

## Notes

- The book prints Program 4 in 3 parts, with explanation in between; `ch08_program4.py` is the whole program.
