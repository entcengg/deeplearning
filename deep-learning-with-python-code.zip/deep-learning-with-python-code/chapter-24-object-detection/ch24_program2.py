# ch24_program2.py
# Building a synthetic object-detection dataset. Real detection datasets
# (COCO, Pascal VOC) need a download and thousands of hand-drawn boxes; here
# we build a small dataset where the ground-truth boxes are exact by
# construction: take real handwritten-digit sprites (8x8, from
# sklearn.datasets.load_digits) and paste 1 or 2 of them onto a blank 32x32
# canvas at random, non-overlapping positions. Because we chose where to
# paste each sprite, its bounding box is known exactly -- no labeling noise.

import numpy as np
from sklearn.datasets import load_digits

CANVAS = 32     # canvas is 32x32 pixels
CELL = 8        # each grid cell is 8x8 pixels
S = CANVAS // CELL   # S=4 -> a 4x4 grid of cells
SIZES = [8, 16]      # each pasted digit is either "small" (8x8, native) or
                      # "large" (16x16, nearest-neighbor upsampled 2x)

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0   # (1797, 8, 8), [0,1]
DIGIT_LABELS = digits.target.astype(np.int64)             # (1797,), 0-9


def make_sprite(img8x8, size):
    """Return the digit at the requested pixel size (8 = as-is, 16 = 2x
    nearest-neighbor upsample, implemented with a Kronecker product)."""
    if size == 8:
        return img8x8
    factor = size // 8
    return np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    """Build one canvas with 1 or 2 non-overlapping digit sprites, plus the
    ground-truth targets a detector is trained to predict."""
    n_objects = rng.choice([1, 2])
    placed = []  # each entry: (label, x1, y1, x2, y2, gi, gj, sprite)
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1))
        y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)   # responsible cell (row, col)

        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)):
                collision = True
                break
            if (gi, gj) == (ogi, ogj):   # two objects can't share one cell
                collision = True          # in this single-box-per-cell design
                break
        if collision:
            continue

        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    objectness = np.zeros((S, S), dtype=np.float32)
    box_target = np.zeros((S, S, 4), dtype=np.float32)   # (t_x, t_y, t_w, t_h)
    class_target = np.zeros((S, S), dtype=np.int64)
    gt_boxes = []   # (label, x1, y1, x2, y2), for later evaluation

    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        cell_left, cell_top = gj * CELL, gi * CELL
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        box_target[gi, gj] = [
            (cx - cell_left) / CELL,   # t_x: fraction across the cell, in [0,1)
            (cy - cell_top) / CELL,    # t_y: same, vertically
            (x2 - x1) / CELL,          # t_w: width in units of one cell
            (y2 - y1) / CELL,          # t_h: height in units of one cell
        ]
        objectness[gi, gj] = 1.0
        class_target[gi, gj] = label
        gt_boxes.append((label, x1, y1, x2, y2))

    return canvas, objectness, box_target, class_target, gt_boxes


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, obj_t, box_t, cls_t, gt_all = [], [], [], [], []
    for _ in range(n_images):
        c, o, b, k, g = make_one_image(rng)
        images.append(c); obj_t.append(o); box_t.append(b); cls_t.append(k)
        gt_all.append(g)
    return (np.stack(images), np.stack(obj_t), np.stack(box_t),
            np.stack(cls_t), gt_all)


if __name__ == "__main__":
    images, obj_t, box_t, cls_t, gt_all = make_dataset(1200, seed=0)
    test_images, test_obj_t, test_box_t, test_cls_t, test_gt_all = \
        make_dataset(300, seed=1)

    n_with_1 = sum(1 for g in gt_all if len(g) == 1)
    n_with_2 = sum(1 for g in gt_all if len(g) == 2)
    total_objects = sum(len(g) for g in gt_all)
    n_small = sum(1 for g in gt_all for (_, x1, y1, x2, y2) in g if x2 - x1 == 8)
    n_large = total_objects - n_small

    print(f"Training set: {len(images)} images, {total_objects} objects total")
    print(f"  images with 1 object: {n_with_1}   images with 2 objects: {n_with_2}")
    print(f"  small (8x8) sprites: {n_small}   large (16x16) sprites: {n_large}")
    print(f"Test set: {len(test_images)} images, "
          f"{sum(len(g) for g in test_gt_all)} objects total")

    # A fully worked, hand-checkable example: the first training image with
    # exactly 2 objects.
    idx = next(i for i, g in enumerate(gt_all) if len(g) == 2)
    print(f"\nWorked example -- training image #{idx} (2 objects):")
    print("  ground-truth boxes (label, x1, y1, x2, y2):")
    for box in gt_all[idx]:
        print(f"    {box}")
    print("  objectness grid (1 = an object's center falls in this cell):")
    print(objectness_str := "\n".join(
        "    " + " ".join(f"{v:.0f}" for v in row) for row in obj_t[idx]))
    print("  class grid (only meaningful where objectness=1):")
    print("\n".join("    " + " ".join(f"{v:d}" for v in row) for row in cls_t[idx]))
    print("  box_target at each occupied cell (t_x, t_y, t_w, t_h):")
    for gi in range(S):
        for gj in range(S):
            if obj_t[idx, gi, gj] == 1.0:
                tx, ty, tw, th = box_t[idx, gi, gj]
                print(f"    cell(row={gi},col={gj}): "
                      f"t_x={tx:.3f} t_y={ty:.3f} t_w={tw:.3f} t_h={th:.3f}")
    print(f"  canvas pixel stats: min={images[idx].min():.3f} "
          f"max={images[idx].max():.3f} mean={images[idx].mean():.3f}")
