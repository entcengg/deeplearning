# ch24_program4.py
# Training a small one-stage detector: a CNN backbone whose spatial output
# resolution is deliberately shrunk (via three 2x max-pools) to exactly match
# the S=4 grid used for the ground-truth targets, followed by a 1x1
# convolution that turns each of the 16 cells' 64 features into 15 numbers:
# 1 confidence logit, 4 box-regression values, and 10 class logits.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 10
LAMBDA_COORD, LAMBDA_NOOBJ = 5.0, 0.5

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    objectness = np.zeros((S, S), dtype=np.float32)
    box_target = np.zeros((S, S, 4), dtype=np.float32)
    class_target = np.zeros((S, S), dtype=np.int64)
    gt_boxes = []
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        cell_left, cell_top = gj * CELL, gi * CELL
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        box_target[gi, gj] = [(cx - cell_left) / CELL, (cy - cell_top) / CELL,
                               (x2 - x1) / CELL, (y2 - y1) / CELL]
        objectness[gi, gj] = 1.0
        class_target[gi, gj] = label
        gt_boxes.append((label, x1, y1, x2, y2))
    return canvas, objectness, box_target, class_target, gt_boxes


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, obj_t, box_t, cls_t, gt_all = [], [], [], [], []
    for _ in range(n_images):
        c, o, b, k, g = make_one_image(rng)
        images.append(c); obj_t.append(o); box_t.append(b); cls_t.append(k); gt_all.append(g)
    return (torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(obj_t)),
            torch.from_numpy(np.stack(box_t)), torch.from_numpy(np.stack(cls_t)), gt_all)


def detection_loss(pred, obj_target, box_target, cls_target):
    conf_logit = pred[..., 0]
    box_pred = pred[..., 1:5]
    class_logits = pred[..., 5:]
    obj_mask, noobj_mask = obj_target, 1.0 - obj_target
    bce = nn.BCEWithLogitsLoss(reduction='none')
    conf_loss_obj = (bce(conf_logit, obj_target) * obj_mask).sum()
    conf_loss_noobj = (bce(conf_logit, torch.zeros_like(conf_logit)) * noobj_mask).sum()
    box_sse = ((box_pred - box_target) ** 2).sum(dim=-1)
    box_loss = (box_sse * obj_mask).sum()
    ce = nn.CrossEntropyLoss(reduction='none')
    class_loss_flat = ce(class_logits.reshape(-1, NUM_CLASSES), cls_target.reshape(-1))
    class_loss = (class_loss_flat.reshape(obj_mask.shape) * obj_mask).sum()
    batch = pred.shape[0]
    total = (LAMBDA_COORD * box_loss + conf_loss_obj + LAMBDA_NOOBJ * conf_loss_noobj + class_loss) / batch
    return total


class TinyDetector(nn.Module):
    """Backbone: 3 conv+pool stages shrink 32x32 -> 4x4, matching the S=4
    grid exactly. Head: a 1x1 conv turns 64 features per cell into 15
    outputs (1 confidence + 4 box + 10 class)."""
    def __init__(self):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),   # 32->16
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),   # 16->8
            nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),   # 8->4
        )
        self.head = nn.Conv2d(64, 5 + NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        features = self.backbone(x)              # (batch, 64, 4, 4)
        out = self.head(features)                 # (batch, 15, 4, 4)
        return out.permute(0, 2, 3, 1)             # (batch, 4, 4, 15)


def decode_box(gi, gj, t_x, t_y, t_w, t_h):
    cx = gj * CELL + t_x * CELL
    cy = gi * CELL + t_y * CELL
    w, h = t_w * CELL, t_h * CELL
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a; bx1, by1, bx2, by2 = box_b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    union = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1) + max(0.0, bx2 - bx1) * max(0.0, by2 - by1) - inter
    return inter / union if union > 0 else 0.0


torch.manual_seed(0)
train_images, train_obj, train_box, train_cls, train_gt = make_dataset(1200, seed=0)
test_images, test_obj, test_box, test_cls, test_gt = make_dataset(300, seed=1)
train_x = train_images.unsqueeze(1)   # (1200, 1, 32, 32)
test_x = test_images.unsqueeze(1)

model = TinyDetector()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

print(f"Training TinyDetector on {len(train_x)} synthetic scenes "
      f"({int(train_obj.sum().item())} objects total)...")
batch_size = 100
n_batches = len(train_x) // batch_size
checkpoints = {1, 25, 50, 100, 150, 200, 250, 300}
for epoch in range(1, 301):
    perm = torch.randperm(len(train_x))
    epoch_loss = 0.0
    for b in range(n_batches):
        idx = perm[b * batch_size:(b + 1) * batch_size]
        pred = model(train_x[idx])
        loss = detection_loss(pred, train_obj[idx], train_box[idx], train_cls[idx])
        optimizer.zero_grad(); loss.backward(); optimizer.step()
        epoch_loss += loss.item()
    if epoch in checkpoints:
        print(f"  epoch {epoch:3d}: mean training loss = {epoch_loss / n_batches:.4f}")

# --- Evaluate on the held-out test set --------------------------------------
model.eval()
with torch.no_grad():
    test_pred = model(test_x)

conf_pred = torch.sigmoid(test_pred[..., 0])
conf_binary = (conf_pred > 0.5).float()
objectness_accuracy = (conf_binary == test_obj).float().mean().item()

ious, class_correct, n_obj_cells = [], 0, 0
for b in range(len(test_x)):
    for gi in range(S):
        for gj in range(S):
            if test_obj[b, gi, gj] == 1.0:
                n_obj_cells += 1
                t_x, t_y, t_w, t_h = test_pred[b, gi, gj, 1:5].tolist()
                pred_box = decode_box(gi, gj, t_x, t_y, t_w, t_h)
                # Reconstructing the true box through the same decode_box() formula
                # (rather than reading gt_boxes directly) keeps this an apples-to-apples
                # comparison: any decoding convention error would affect both equally.
                true_box = decode_box(gi, gj, *test_box[b, gi, gj].tolist())
                ious.append(iou(pred_box, true_box))
                pred_class = test_pred[b, gi, gj, 5:].argmax().item()
                if pred_class == test_cls[b, gi, gj].item():
                    class_correct += 1

mean_iou = float(np.mean(ious))
class_accuracy = class_correct / n_obj_cells
print(f"\nTest-set evaluation ({n_obj_cells} ground-truth objects, "
      f"{S*S*len(test_x)} total cells):")
print(f"  per-cell objectness accuracy (obj vs. no-obj, all cells): {objectness_accuracy:.4f}")
print(f"  mean IoU between predicted and true box, at true object cells: {mean_iou:.4f}")
print(f"  classification accuracy at true object cells: {class_accuracy:.4f}")
print(f"  IoU distribution: min={min(ious):.3f}  "
      f"median={float(np.median(ious)):.3f}  max={max(ious):.3f}")
frac_above_50 = float(np.mean(np.array(ious) >= 0.5))
print(f"  fraction of objects with IoU >= 0.5: {frac_above_50:.4f}")
