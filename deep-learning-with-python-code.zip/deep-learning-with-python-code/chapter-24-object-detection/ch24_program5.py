# ch24_program5.py
# Non-Maximum Suppression (NMS): a trained detector often fires confidently
# on more than one cell for the same real object (a large object's edges
# fall inside a neighboring cell's receptive field too). NMS cleans this up:
# keep the most confident box, throw away every other box that overlaps it
# too much (same predicted class), and repeat with whatever is left.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 10
LAMBDA_COORD, LAMBDA_NOOBJ = 5.0, 0.5

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    objectness = np.zeros((S, S), dtype=np.float32)
    box_target = np.zeros((S, S, 4), dtype=np.float32)
    class_target = np.zeros((S, S), dtype=np.int64)
    gt_boxes = []
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        cell_left, cell_top = gj * CELL, gi * CELL
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        box_target[gi, gj] = [(cx - cell_left) / CELL, (cy - cell_top) / CELL,
                               (x2 - x1) / CELL, (y2 - y1) / CELL]
        objectness[gi, gj] = 1.0
        class_target[gi, gj] = label
        gt_boxes.append((label, x1, y1, x2, y2))
    return canvas, objectness, box_target, class_target, gt_boxes


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, obj_t, box_t, cls_t, gt_all = [], [], [], [], []
    for _ in range(n_images):
        c, o, b, k, g = make_one_image(rng)
        images.append(c); obj_t.append(o); box_t.append(b); cls_t.append(k); gt_all.append(g)
    return (torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(obj_t)),
            torch.from_numpy(np.stack(box_t)), torch.from_numpy(np.stack(cls_t)), gt_all)


def detection_loss(pred, obj_target, box_target, cls_target):
    conf_logit = pred[..., 0]; box_pred = pred[..., 1:5]; class_logits = pred[..., 5:]
    obj_mask, noobj_mask = obj_target, 1.0 - obj_target
    bce = nn.BCEWithLogitsLoss(reduction='none')
    conf_loss_obj = (bce(conf_logit, obj_target) * obj_mask).sum()
    conf_loss_noobj = (bce(conf_logit, torch.zeros_like(conf_logit)) * noobj_mask).sum()
    box_sse = ((box_pred - box_target) ** 2).sum(dim=-1)
    box_loss = (box_sse * obj_mask).sum()
    ce = nn.CrossEntropyLoss(reduction='none')
    class_loss_flat = ce(class_logits.reshape(-1, NUM_CLASSES), cls_target.reshape(-1))
    class_loss = (class_loss_flat.reshape(obj_mask.shape) * obj_mask).sum()
    batch = pred.shape[0]
    return (LAMBDA_COORD * box_loss + conf_loss_obj + LAMBDA_NOOBJ * conf_loss_noobj + class_loss) / batch


class TinyDetector(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.head = nn.Conv2d(64, 5 + NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        out = self.head(self.backbone(x))
        return out.permute(0, 2, 3, 1)


def decode_box(gi, gj, t_x, t_y, t_w, t_h):
    cx, cy = gj * CELL + t_x * CELL, gi * CELL + t_y * CELL
    w, h = t_w * CELL, t_h * CELL
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a; bx1, by1, bx2, by2 = box_b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    union = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1) + max(0.0, bx2 - bx1) * max(0.0, by2 - by1) - inter
    return inter / union if union > 0 else 0.0


def nms(detections, iou_threshold=0.5):
    """detections: list of dicts with keys box, confidence, class_id.
    Returns the surviving detections, suppressing lower-confidence boxes of
    the SAME class that overlap a kept box by more than iou_threshold."""
    kept = []
    by_class = {}
    for d in detections:
        by_class.setdefault(d['class_id'], []).append(d)
    for class_id, dets in by_class.items():
        remaining = sorted(dets, key=lambda d: -d['confidence'])
        while remaining:
            best = remaining.pop(0)
            kept.append(best)
            remaining = [d for d in remaining if iou(best['box'], d['box']) <= iou_threshold]
    return kept


# --- Part A: NMS on a small, hand-built example -----------------------------
print("Part A: NMS on 4 hand-built boxes, IoU threshold 0.5")
hand_dets = [
    {'name': 'P', 'box': (0, 0, 10, 10), 'confidence': 0.90, 'class_id': 0},
    {'name': 'Q', 'box': (1, 1, 11, 11), 'confidence': 0.75, 'class_id': 0},
    {'name': 'R', 'box': (2, 0, 12, 10), 'confidence': 0.60, 'class_id': 0},
    {'name': 'S', 'box': (20, 20, 30, 30), 'confidence': 0.80, 'class_id': 0},
]
print("  IoU(P,Q)={:.4f}  IoU(P,R)={:.4f}  IoU(P,S)={:.4f}".format(
    iou(hand_dets[0]['box'], hand_dets[1]['box']),
    iou(hand_dets[0]['box'], hand_dets[2]['box']),
    iou(hand_dets[0]['box'], hand_dets[3]['box'])))
survivors = nms(hand_dets, iou_threshold=0.5)
print("  input, sorted by confidence:", [d['name'] for d in sorted(hand_dets, key=lambda d: -d['confidence'])])
print("  survivors after NMS:", [d['name'] for d in survivors],
      "-- P suppresses Q and R (all high IoU with P); S is untouched (disjoint)")

# --- Part B: raw duplicate detections from the trained detector ------------
torch.manual_seed(0)
train_images, train_obj, train_box, train_cls, train_gt = make_dataset(1200, seed=0)
test_images, test_obj, test_box, test_cls, test_gt = make_dataset(300, seed=1)
train_x, test_x = train_images.unsqueeze(1), test_images.unsqueeze(1)

model = TinyDetector()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
batch_size, n_batches = 100, 1200 // 100
for epoch in range(1, 301):
    perm = torch.randperm(len(train_x))
    for b in range(n_batches):
        idx = perm[b * batch_size:(b + 1) * batch_size]
        pred = model(train_x[idx])
        loss = detection_loss(pred, train_obj[idx], train_box[idx], train_cls[idx])
        optimizer.zero_grad(); loss.backward(); optimizer.step()
model.eval()
with torch.no_grad():
    test_pred = model(test_x)
conf_all = torch.sigmoid(test_pred[..., 0])

CONF_THRESH = 0.3
img_idx = 25   # a single-object test image where a neighboring cell also fires
raw_dets = []
for gi in range(S):
    for gj in range(S):
        c = conf_all[img_idx, gi, gj].item()
        if c > CONF_THRESH:
            t_x, t_y, t_w, t_h = test_pred[img_idx, gi, gj, 1:5].tolist()
            box = decode_box(gi, gj, t_x, t_y, t_w, t_h)
            class_id = test_pred[img_idx, gi, gj, 5:].argmax().item()
            raw_dets.append({'box': box, 'confidence': c, 'class_id': class_id, 'cell': (gi, gj)})

print(f"\nPart B: test image #{img_idx} -- ground truth: {test_gt[img_idx]}")
print(f"  raw detections above confidence {CONF_THRESH}: {len(raw_dets)}")
for d in raw_dets:
    print(f"    cell={d['cell']}  confidence={d['confidence']:.3f}  "
          f"class={d['class_id']}  box=({d['box'][0]:.1f},{d['box'][1]:.1f},"
          f"{d['box'][2]:.1f},{d['box'][3]:.1f})")
if len(raw_dets) >= 2:
    print(f"  IoU between the two raw boxes: {iou(raw_dets[0]['box'], raw_dets[1]['box']):.4f}"
          f"  (both are claiming the same physical object)")
after_nms = nms(raw_dets, iou_threshold=0.5)
print(f"  after NMS: {len(after_nms)} detection(s) survive "
      f"(cell={after_nms[0]['cell']}, confidence={after_nms[0]['confidence']:.3f})")

# --- Part C: precision/recall on the full test set, with vs. without NMS ---
def evaluate(use_nms, conf_thresh=0.3, iou_match=0.5):
    tp, fp, fn = 0, 0, 0
    for b in range(len(test_x)):
        dets = []
        for gi in range(S):
            for gj in range(S):
                c = conf_all[b, gi, gj].item()
                if c > conf_thresh:
                    t_x, t_y, t_w, t_h = test_pred[b, gi, gj, 1:5].tolist()
                    box = decode_box(gi, gj, t_x, t_y, t_w, t_h)
                    class_id = test_pred[b, gi, gj, 5:].argmax().item()
                    dets.append({'box': box, 'confidence': c, 'class_id': class_id})
        if use_nms:
            dets = nms(dets, iou_threshold=0.5)
        dets = sorted(dets, key=lambda d: -d['confidence'])

        gt_remaining = list(test_gt[b])   # (label, x1,y1,x2,y2)
        for d in dets:
            match_idx = -1
            for gi_, (label, x1, y1, x2, y2) in enumerate(gt_remaining):
                if label == d['class_id'] and iou(d['box'], (x1, y1, x2, y2)) >= iou_match:
                    match_idx = gi_
                    break
            if match_idx >= 0:
                tp += 1
                gt_remaining.pop(match_idx)
            else:
                fp += 1
        fn += len(gt_remaining)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    return tp, fp, fn, precision, recall


print(f"\nPart C: detection quality on the full test set "
      f"(confidence>{CONF_THRESH}, matched at IoU>=0.5)")
for use_nms, label in [(False, "without NMS"), (True, "with NMS")]:
    tp, fp, fn, precision, recall = evaluate(use_nms)
    print(f"  {label:>12s}: TP={tp:4d}  FP={fp:4d}  FN={fn:4d}  "
          f"precision={precision:.4f}  recall={recall:.4f}")
