# Chapter 24 · Object Detection

Code for Chapter 24 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 23](../chapter-23-diffusion-models/README.md) · [Chapter 25 →](../chapter-25-image-segmentation/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 24.1.1 Program 1: IoU From Scratch, Verified by Hand | Intersection over Union, implemented from scratch and checked against boxes whose answer can be verified by hand | [`ch24_program1.py`](ch24_program1.py) | [ch24_program1.txt](expected_output/ch24_program1.txt) | < 1 s |
| 2 | 24.2.1 Program 2: A Synthetic Multi-Object Detection Dataset | Building the synthetic detection dataset and printing one fully worked example | [`ch24_program2.py`](ch24_program2.py) | [ch24_program2.txt](expected_output/ch24_program2.txt) | 1 s |
| 3 | 24.3.1 Program 3: Verifying the Loss by Hand | The detection loss, verified on one cell by hand and on a full batch of perfect vs. bad predictions | [`ch24_program3.py`](ch24_program3.py) | [ch24_program3.txt](expected_output/ch24_program3.txt) | 3 s |
| 4 | 24.4.1 Program 4: Training TinyDetector End to End | Building and training TinyDetector, then evaluating it with IoU-based metrics on held-out data | [`ch24_program4.py`](ch24_program4.py) | [ch24_program4.txt](expected_output/ch24_program4.txt) | 6 min |
| 5 | 24.5.2 Program 5: NMS From Scratch, Verified by Hand and Applied | Non-Maximum Suppression: a hand-built check, applied to the trained detector's raw output, and its effect on test-set precision/recall | [`ch24_program5.py`](ch24_program5.py) | [ch24_program5.txt](expected_output/ch24_program5.txt) | 6 min |
| 6 | 24.6.3 Program 6: AP and mAP From Scratch, Checked by Hand | Average precision and mean average precision from scratch, on a hand-checkable toy test set | [`ch24_program6.py`](ch24_program6.py) | [ch24_program6.txt](expected_output/ch24_program6.txt) | 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-24-object-detection
python ch24_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch24_notebook.ipynb`](ch24_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, PyTorch.
