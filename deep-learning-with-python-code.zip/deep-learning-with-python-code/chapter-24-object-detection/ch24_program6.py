# ch24_program6.py
# Average precision (AP) and mean average precision (mAP), from scratch.
# A toy test set small enough to check on paper: 2 images, class A with 3
# ground-truth boxes and class B with 2. Every detection is matched to the
# ground truth, ranked by confidence, turned into precision/recall points,
# and summarized as AP; mAP averages AP over classes, and COCO-style mAP
# also averages over ten IoU thresholds.

import numpy as np
from sklearn.metrics import average_precision_score


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    area_a = (ax2 - ax1) * (ay2 - ay1)
    area_b = (bx2 - bx1) * (by2 - by1)
    return inter / (area_a + area_b - inter)


def match_detections(candidates, gts_per_image, cls, iou_thr):
    """Label every detection of ONE class as a true positive (1) or a false
    positive (0). candidates: list of (confidence, image_index, box);
    gts_per_image[i]: list of (label, x1, y1, x2, y2) for image i.
    Walking down from the most confident detection, each detection claims
    the not-yet-claimed ground-truth box of this class, in its own image,
    with the highest IoU: a TP if that IoU >= iou_thr, else a FP. A box can
    be claimed only once, so a duplicate detection is a FP.
    Returns [(confidence, is_tp, best_iou_any, image_index)], most confident
    first; best_iou_any (overlap with ANY box of this class) is for display."""
    claimed = set()
    records = []
    for conf, img, box in sorted(candidates, key=lambda c: -c[0]):
        best_iou, best_j, best_any = 0.0, -1, 0.0
        for j, (label, x1, y1, x2, y2) in enumerate(gts_per_image[img]):
            if label != cls:
                continue
            v = iou(box, (x1, y1, x2, y2))
            best_any = max(best_any, v)
            if (img, j) not in claimed and v > best_iou:
                best_iou, best_j = v, j
        if best_j >= 0 and best_iou >= iou_thr:
            claimed.add((img, best_j))
            records.append((conf, 1, best_any, img))
        else:
            records.append((conf, 0, best_any, img))
    return records


def pr_points(records, n_gt):
    """Precision P_k = TP_k / k and recall R_k = TP_k / n_gt after the k most
    confident detections, k = 1..K."""
    is_tp = np.array([r[1] for r in records], dtype=float)
    tp_cum = np.cumsum(is_tp)
    k = np.arange(1, len(records) + 1)
    return tp_cum / k, tp_cum / n_gt


def interpolated(precision):
    """p_interp at every rank: the best precision at this rank or any later
    (higher-recall) rank -- a running maximum taken from the end."""
    return np.maximum.accumulate(precision[::-1])[::-1]


def average_precision(records, n_gt, interpolate=True):
    """All-point AP = sum_k (R_k - R_{k-1}) * p_interp(R_k), with R_0 = 0
    (PASCAL VOC 2010 onward). interpolate=False uses the raw P_k instead."""
    p, r = pr_points(records, n_gt)
    p_used = interpolated(p) if interpolate else p
    recall_gain = np.diff(np.concatenate(([0.0], r)))
    return float(np.sum(recall_gain * p_used))


def average_precision_11pt(records, n_gt):
    """VOC2007-style AP: mean of p_interp at recall = 0, 0.1, ..., 1."""
    p, r = pr_points(records, n_gt)
    p_int = interpolated(p)
    total = 0.0
    for level in np.linspace(0.0, 1.0, 11):
        reachable = r >= level - 1e-12
        total += p_int[reachable][0] if reachable.any() else 0.0
    return total / 11.0


toy_gt = [
    [(0, 0, 0, 10, 10), (0, 20, 0, 30, 10), (1, 0, 20, 10, 30)],    # image 1
    [(0, 5, 5, 15, 15), (1, 20, 20, 30, 30)],                       # image 2
]
toy_cands = {   # class -> [(confidence, image index, box)]; class A = 0, B = 1
    0: [(0.95, 0, (40, 0, 50, 10)), (0.90, 0, (0, 0, 9, 9)),
        (0.85, 1, (5, 5, 15, 15)), (0.80, 0, (1, 0, 11, 10)),
        (0.70, 0, (20, 2, 30, 12)), (0.60, 1, (30, 30, 40, 40))],
    1: [(0.92, 0, (0, 20, 10, 30)), (0.55, 1, (22, 22, 32, 32))],
}

records = match_detections(toy_cands[0], toy_gt, cls=0, iou_thr=0.5)
p, r = pr_points(records, 3)
p_int = interpolated(p)
print("Class A (3 ground-truth boxes), IoU threshold 0.5:")
print("  rank  conf  img   IoU  outcome   TP  FP  precision  recall  p_interp")
tp_cum = 0
for k, (conf, is_tp, best_any, img) in enumerate(records, start=1):
    tp_cum += is_tp
    if is_tp:
        outcome = "TP"
    elif best_any >= 0.5:
        outcome = "FP (dup)"
    else:
        outcome = "FP"
    print(f"  {k:4d}  {conf:.2f}   {img + 1}  {best_any:.3f}  {outcome:<8s}"
          f"  {tp_cum:2d}  {k - tp_cum:2d}     {p[k-1]:.4f}  {r[k-1]:.4f}    {p_int[k-1]:.4f}")

hand_ap = (1 / 3) * (2 / 3) + (1 / 3) * (2 / 3) + (1 / 3) * (3 / 5)
print(f"\n  hand-computed AP_A = 1/3*2/3 + 1/3*2/3 + 1/3*3/5 = {hand_ap:.4f}")
print(f"  function (all-point, interpolated):         {average_precision(records, 3):.4f}")
hand_raw = (1 / 3) * (1 / 2) + (1 / 3) * (2 / 3) + (1 / 3) * (3 / 5)
print(f"  without the envelope: hand {hand_raw:.4f}, function "
      f"{average_precision(records, 3, interpolate=False):.4f}")
sk = average_precision_score([rec[1] for rec in records], [rec[0] for rec in records])
print(f"  sklearn average_precision_score (no envelope): {sk:.4f}")
print(f"  11-point AP (VOC2007 style):                {average_precision_11pt(records, 3):.4f}")
# The rank-4 detection is a duplicate of rank 2's object -- exactly what NMS
# exists to remove (its IoU with the rank-2 box is above 0.5).
no_dup = [c for c in toy_cands[0] if c[2] != (1, 0, 11, 10)]
ap_nodup = average_precision(match_detections(no_dup, toy_gt, cls=0, iou_thr=0.5), 3)
print(f"  with the duplicate removed (as NMS would):  {ap_nodup:.4f}")

records_b = match_detections(toy_cands[1], toy_gt, cls=1, iou_thr=0.5)
ap_a = average_precision(records, 3)
ap_b = average_precision(records_b, 2)
print(f"\nClass B: one TP (IoU 1.000), one near-miss FP (IoU {records_b[1][2]:.3f}):"
      f" AP_B = {ap_b:.4f}")
print(f"mAP@0.5 = (AP_A + AP_B) / 2 = ({ap_a:.4f} + {ap_b:.4f}) / 2 = {(ap_a + ap_b) / 2:.4f}")

COCO_THRESHOLDS = [0.5 + 0.05 * k for k in range(10)]     # 0.50, 0.55, ..., 0.95
print("\nThe same detections at stricter IoU thresholds (COCO averages all ten):")
print("  IoU thr: " + " ".join(f"{t:.2f}" for t in COCO_THRESHOLDS))
toy_a, toy_m = [], []
for t in COCO_THRESHOLDS:
    a = average_precision(match_detections(toy_cands[0], toy_gt, 0, t), 3)
    b = average_precision(match_detections(toy_cands[1], toy_gt, 1, t), 2)
    toy_a.append(a)
    toy_m.append((a + b) / 2)
print("  AP_A:    " + " ".join(f"{v:.2f}" for v in toy_a))
print("  mAP:     " + " ".join(f"{v:.2f}" for v in toy_m))
print(f"  COCO-style mAP@[.5:.95] = mean of the ten mAP values = {np.mean(toy_m):.4f}")
