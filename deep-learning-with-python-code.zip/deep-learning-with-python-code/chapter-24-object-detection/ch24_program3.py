# ch24_program3.py
# The detection loss: four terms added together -- a box-coordinate term
# (only for cells responsible for a real object), a "there IS an object here"
# confidence term (responsible cells), a "there is NOT an object here" term
# (every other cell), and a classification term (responsible cells only).
# Weights lambda_coord=5, lambda_noobj=0.5 follow the original YOLO paper
# (Redmon et al., 2016), which found that without them the many empty-cell
# confidence terms drown out the far rarer box and class terms.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 10
LAMBDA_COORD, LAMBDA_NOOBJ = 5.0, 0.5

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))

    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    objectness = np.zeros((S, S), dtype=np.float32)
    box_target = np.zeros((S, S, 4), dtype=np.float32)
    class_target = np.zeros((S, S), dtype=np.int64)
    gt_boxes = []
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        cell_left, cell_top = gj * CELL, gi * CELL
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        box_target[gi, gj] = [(cx - cell_left) / CELL, (cy - cell_top) / CELL,
                               (x2 - x1) / CELL, (y2 - y1) / CELL]
        objectness[gi, gj] = 1.0
        class_target[gi, gj] = label
        gt_boxes.append((label, x1, y1, x2, y2))
    return canvas, objectness, box_target, class_target, gt_boxes


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, obj_t, box_t, cls_t, gt_all = [], [], [], [], []
    for _ in range(n_images):
        c, o, b, k, g = make_one_image(rng)
        images.append(c); obj_t.append(o); box_t.append(b); cls_t.append(k); gt_all.append(g)
    return (torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(obj_t)),
            torch.from_numpy(np.stack(box_t)), torch.from_numpy(np.stack(cls_t)), gt_all)


def detection_loss(pred, obj_target, box_target, cls_target):
    """pred: (batch, S, S, 15) = [confidence_logit, t_x,t_y,t_w,t_h, 10 class logits]."""
    conf_logit = pred[..., 0]
    box_pred = pred[..., 1:5]
    class_logits = pred[..., 5:]
    obj_mask, noobj_mask = obj_target, 1.0 - obj_target

    bce = nn.BCEWithLogitsLoss(reduction='none')
    conf_loss_obj = (bce(conf_logit, obj_target) * obj_mask).sum()
    conf_loss_noobj = (bce(conf_logit, torch.zeros_like(conf_logit)) * noobj_mask).sum()

    box_sse = ((box_pred - box_target) ** 2).sum(dim=-1)
    box_loss = (box_sse * obj_mask).sum()

    ce = nn.CrossEntropyLoss(reduction='none')
    class_loss_flat = ce(class_logits.reshape(-1, NUM_CLASSES), cls_target.reshape(-1))
    class_loss = (class_loss_flat.reshape(obj_mask.shape) * obj_mask).sum()

    batch = pred.shape[0]
    total = (LAMBDA_COORD * box_loss + conf_loss_obj + LAMBDA_NOOBJ * conf_loss_noobj + class_loss) / batch
    parts = {'box': (LAMBDA_COORD * box_loss / batch).item(),
             'conf_obj': (conf_loss_obj / batch).item(),
             'conf_noobj': (LAMBDA_NOOBJ * conf_loss_noobj / batch).item(),
             'class': (class_loss / batch).item()}
    return total, parts


# --- Part A: one cell's box loss, computed by hand -------------------------
tx_true, ty_true, tw_true, th_true = 0.125, 0.500, 2.000, 2.000
tx_pred, ty_pred, tw_pred, th_pred = 0.200, 0.400, 1.800, 2.100
hand_sse = (tx_true - tx_pred) ** 2 + (ty_true - ty_pred) ** 2 + \
           (tw_true - tw_pred) ** 2 + (th_true - th_pred) ** 2
print("Part A: one occupied cell's box loss, by hand")
print(f"  target (t_x,t_y,t_w,t_h) = ({tx_true},{ty_true},{tw_true},{th_true})")
print(f"  pred   (t_x,t_y,t_w,t_h) = ({tx_pred},{ty_pred},{tw_pred},{th_pred})")
print(f"  sum of squared errors = {hand_sse:.6f}")
print(f"  weighted by lambda_coord={LAMBDA_COORD}: {LAMBDA_COORD * hand_sse:.6f}")

t_true = torch.tensor([tx_true, ty_true, tw_true, th_true])
t_pred = torch.tensor([tx_pred, ty_pred, tw_pred, th_pred])
tensor_sse = ((t_true - t_pred) ** 2).sum().item()
print(f"  torch tensor SSE (should match): {tensor_sse:.6f}")

# --- Part B: perfect vs. bad predictions on a real batch --------------------
torch.manual_seed(0)
images, obj_t, box_t, cls_t, gt_all = make_dataset(4, seed=7)

# "Perfect" prediction: exactly reproduce the targets, with strongly
# confident (but finite) confidence logits and one-hot-ish class logits.
perfect_conf = torch.where(obj_t == 1.0, torch.tensor(10.0), torch.tensor(-10.0))
perfect_class = torch.full((4, S, S, NUM_CLASSES), -10.0)
for b in range(4):
    for gi in range(S):
        for gj in range(S):
            if obj_t[b, gi, gj] == 1.0:
                perfect_class[b, gi, gj, cls_t[b, gi, gj]] = 10.0
perfect_pred = torch.cat([perfect_conf.unsqueeze(-1), box_t, perfect_class], dim=-1)

# "Bad" prediction: confidently wrong about everything.
bad_conf = torch.where(obj_t == 1.0, torch.tensor(-10.0), torch.tensor(10.0))  # inverted
bad_box = box_t + 1.5          # every box shifted/resized by 1.5 cell units
bad_class = torch.full((4, S, S, NUM_CLASSES), 0.0)  # uniform -> unsure of every class
bad_pred = torch.cat([bad_conf.unsqueeze(-1), bad_box, bad_class], dim=-1)

total_perfect, parts_perfect = detection_loss(perfect_pred, obj_t, box_t, cls_t)
total_bad, parts_bad = detection_loss(bad_pred, obj_t, box_t, cls_t)

print(f"\nPart B: perfect vs. bad predictions on a real batch of {4} images "
      f"({int(obj_t.sum().item())} objects total)")
print(f"  perfect prediction: total loss = {total_perfect.item():.4f}")
for k, v in parts_perfect.items():
    print(f"    {k:>10s}: {v:.4f}")
print(f"  bad prediction:     total loss = {total_bad.item():.4f}")
for k, v in parts_bad.items():
    print(f"    {k:>10s}: {v:.4f}")
