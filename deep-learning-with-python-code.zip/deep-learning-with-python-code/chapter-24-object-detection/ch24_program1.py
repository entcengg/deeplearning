# ch24_program1.py
# Intersection over Union (IoU): the standard way to measure how well a
# predicted bounding box overlaps a ground-truth box. Boxes are stored as
# (x1, y1, x2, y2) -- top-left and bottom-right corners, in pixel coordinates.

import numpy as np


def box_area(box):
    x1, y1, x2, y2 = box
    return max(0.0, x2 - x1) * max(0.0, y2 - y1)


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    # Corners of the intersection rectangle
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)

    inter_area = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    union_area = box_area(box_a) + box_area(box_b) - inter_area

    if union_area <= 0.0:
        return 0.0
    return inter_area / union_area


# --- Hand-checkable case 1: two unit squares overlapping in a 1x1 corner ---
box_a = (0.0, 0.0, 2.0, 2.0)   # 2x2 square, area 4
box_b = (1.0, 1.0, 3.0, 3.0)   # 2x2 square, area 4, shifted by (1,1)
# Intersection: x in [1,2], y in [1,2] -> a 1x1 square, area 1
# Union: 4 + 4 - 1 = 7
print("Case 1: two 2x2 squares overlapping in a 1x1 corner")
print(f"  area(A)={box_area(box_a):.1f}  area(B)={box_area(box_b):.1f}")
print(f"  hand-computed intersection=1.0  union=7.0  IoU=1/7={1/7:.4f}")
print(f"  function result: IoU={iou(box_a, box_b):.4f}")

# --- Case 2: identical boxes -> IoU must be exactly 1.0 ---
box_c = (5.0, 5.0, 9.0, 9.0)
print("\nCase 2: identical boxes")
print(f"  IoU={iou(box_c, box_c):.4f}  (expected 1.0)")

# --- Case 3: disjoint boxes -> IoU must be exactly 0.0 ---
box_d = (0.0, 0.0, 4.0, 4.0)
box_e = (10.0, 10.0, 14.0, 14.0)
print("\nCase 3: disjoint boxes (no overlap)")
print(f"  IoU={iou(box_d, box_e):.4f}  (expected 0.0)")

# --- Case 4: one box fully inside another -> IoU = area(small)/area(big) ---
box_f = (0.0, 0.0, 10.0, 10.0)   # area 100
box_g = (4.0, 4.0, 8.0, 8.0)     # area 16, fully inside box_f
print("\nCase 4: small box fully inside a larger box")
print(f"  area(F)={box_area(box_f):.1f}  area(G)={box_area(box_g):.1f}")
print(f"  hand-computed IoU = 16/100 = {16/100:.4f}")
print(f"  function result: IoU={iou(box_f, box_g):.4f}")

# --- Sweep: how IoU changes as two same-size boxes slide apart -----------
print("\nIoU as a 4x4 box slides away from a fixed 4x4 box at the origin:")
fixed = (0.0, 0.0, 4.0, 4.0)
for shift in [0, 1, 2, 3, 4, 6]:
    sliding = (float(shift), 0.0, float(shift + 4), 4.0)
    print(f"  shift={shift}:  IoU={iou(fixed, sliding):.4f}")
