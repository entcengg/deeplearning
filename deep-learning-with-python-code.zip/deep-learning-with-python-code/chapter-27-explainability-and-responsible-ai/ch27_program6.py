# ch27_program6.py
# Model-agnostic explanations. Programs 1-3 needed gradients and a CNN's
# internals; here an explainer may only CALL the model, f(X) -> scores. Two
# explainers are built from scratch and checked against each other and
# against closed forms: (1) exact Shapley values (the quantity SHAP
# estimates), by enumerating every coalition of features; (2) LIME, a
# kernel-weighted linear surrogate fitted to perturbations of one instance.
# The model explained is Section 4's tabular fairness model, widened from
# one input (Program 4's biased score) to four, so there is something to
# attribute. Program 4's data generator is reused unchanged.

import itertools
import math
import numpy as np
import torch
import torch.nn as nn
from scipy.stats import spearmanr
from sklearn.model_selection import train_test_split

# --- reused unchanged from Program 4 (ch27_program4.py) ---
np.random.seed(0)
torch.manual_seed(0)

def make_dataset(n_per_group=2000):
    """Returns X (observed feature, what the model is trained on), Y (true
    qualification label), S (sensitive group, withheld from training), and Q
    (true qualification score, for diagnostics only)."""
    Q0 = np.random.normal(0.0, 1.0, size=n_per_group)
    Q1 = np.random.normal(0.0, 1.0, size=n_per_group)   # same distribution as group 0
    Q = np.concatenate([Q0, Q1])
    S = np.concatenate([np.zeros(n_per_group), np.ones(n_per_group)]).astype(np.int64)

    Y = (Q > 0).astype(np.int64)   # ground truth: qualified iff true score exceeds 0

    # X is what actually gets measured and handed to the model: a noisy proxy
    # for Q that is biased LOW and made noisier specifically for group 1.
    noise0 = np.random.normal(0.0, 0.5, size=n_per_group)
    noise1 = np.random.normal(-0.6, 1.0, size=n_per_group)
    noise = np.concatenate([noise0, noise1])
    X = (Q + noise).astype(np.float32)

    perm = np.random.permutation(len(Q))
    return X[perm], Y[perm], S[perm], Q[perm]

# --- end of Program 4 code ---

torch.set_num_threads(1)

FEATURES = ["assessment", "interview", "postcode", "noise"]

def make_wide_dataset():
    """Program 4's (X, Y, S, Q) plus three new columns. S is still withheld."""
    np.random.seed(0)
    X, Y, S, Q = make_dataset(n_per_group=2000)       # X: group-biased score
    rng = np.random.RandomState(1)
    interview = Q + rng.normal(0.0, 1.5, len(Q))      # unbiased but noisy
    postcode = S + rng.normal(0.0, 0.8, len(Q))       # leaks the group label
    noise = rng.normal(0.0, 1.0, len(Q))              # irrelevant by design
    F = np.column_stack([X, interview, postcode, noise]).astype(np.float32)
    return F, Y, S, Q

def make_model(kind):
    if kind == "logistic":
        return nn.Linear(4, 1)
    return nn.Sequential(nn.Linear(4, 16), nn.ReLU(),
                         nn.Linear(16, 16), nn.ReLU(), nn.Linear(16, 1))

def fit_scorer(kind, F, y, seed=0):
    """Train a logistic model (one nn.Linear) or a small MLP, then convert
    to float64 so closed-form checks hold to rounding error."""
    torch.manual_seed(seed)
    model = make_model(kind)
    epochs, lr = (300, 0.1) if kind == "logistic" else (500, 0.01)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    X, t = torch.from_numpy(F), torch.from_numpy(y.astype(np.float32))
    for _ in range(epochs):
        loss = nn.functional.binary_cross_entropy_with_logits(
            model(X).squeeze(-1), t)
        opt.zero_grad(); loss.backward(); opt.step()
    return model.double().eval()

def black_box(model, scale="logit"):
    """The only thing an explainer may use: rows in, one score per row out."""
    def f(X):
        with torch.no_grad():
            z = model(torch.from_numpy(np.asarray(X, dtype=np.float64)))
            z = z.squeeze(-1)
            return (torch.sigmoid(z) if scale == "prob" else z).numpy()
    return f


# ---- Shapley values: enumerate every coalition S of "present" features ----
def coalition_values(f, x, B):
    """v[S] = average of f over the background rows B, with the features in
    S set to the instance's values and the others left as in each row of B."""
    d, v = len(x), {}
    for r in range(d + 1):
        for S in itertools.combinations(range(d), r):
            H = B.copy()
            if S:
                H[:, list(S)] = x[list(S)]
            v[S] = f(H).mean()
    return v

def exact_shapley(f, x, B):
    d = len(x)
    v = coalition_values(f, x, B)
    phi = np.zeros(d)
    for i in range(d):
        rest = [j for j in range(d) if j != i]
        for r in range(d):
            w = math.factorial(r) * math.factorial(d - r - 1) / math.factorial(d)
            for S in itertools.combinations(rest, r):
                phi[i] += w * (v[tuple(sorted(S + (i,)))] - v[S])
    return phi, v[()], v[tuple(range(d))]

def shapley_by_orderings(v, d):
    """Same quantity from its definition: average marginal contribution of
    feature i over all d! orders in which the features could be revealed."""
    phi = np.zeros(d)
    for order in itertools.permutations(range(d)):
        S = ()
        for i in order:
            T = tuple(sorted(S + (i,)))
            phi[i] += v[T] - v[S]
            S = T
    return phi / math.factorial(d)

def kernel_shap(v, d):
    """LIME-style weighted regression on coalitions with the Shapley kernel
    (Lundberg and Lee, 2017); the efficiency constraint is solved exactly by
    eliminating the last coefficient."""
    subsets = [S for r in range(1, d)
               for S in itertools.combinations(range(d), r)]
    m = len(subsets)
    Z, y, w = np.zeros((m, d)), np.zeros(m), np.zeros(m)
    for k, S in enumerate(subsets):
        Z[k, list(S)] = 1.0
        y[k] = v[S] - v[()]
        w[k] = (d - 1) / (math.comb(d, len(S)) * len(S) * (d - len(S)))
    gap = v[tuple(range(d))] - v[()]
    Zr, yr = Z[:, :d - 1] - Z[:, [d - 1]], y - Z[:, d - 1] * gap
    phi = np.zeros(d)
    phi[:d - 1] = np.linalg.solve(Zr.T @ (Zr * w[:, None]), Zr.T @ (w * yr))
    phi[d - 1] = gap - phi[:d - 1].sum()
    return phi


# ---- LIME: perturb, kernel-weight, fit a weighted linear surrogate ----
def lime_slopes(f, x, sd, n=1000, width=1.5, ridge=1.0, seed=0):
    """Fit g(z) = b0 + sum_i beta_i (z_i - x_i)/sd_i to f on n perturbations
    of x, each weighted by exp(-D^2/width^2). Returns beta (per-SD slopes)."""
    rng = np.random.RandomState(seed)
    E = rng.standard_normal((n, len(x)))              # perturbations, in SD units
    E[0] = 0.0                                        # row 0 is x itself
    weights = np.exp(-(E ** 2).sum(axis=1) / width ** 2)
    A = np.column_stack([np.ones(n), E])
    penalty = ridge * np.eye(A.shape[1]); penalty[0, 0] = 0.0
    lhs = A.T @ (A * weights[:, None]) + penalty
    return np.linalg.solve(lhs, A.T @ (weights * f(x + sd * E)))[1:]

def lime_contribution(beta, x, mu, sd):
    """Slope times how far x sits from the baseline, in output units."""
    return beta * (x - mu) / sd

if __name__ == "__main__":
    F, Y, S, Q = make_wide_dataset()
    F_tr, F_te, y_tr, y_te, s_tr, s_te, q_tr, q_te = train_test_split(
        F, Y, S, Q, test_size=0.25, random_state=0, stratify=S)
    print(f"Widened fairness data: {len(F_tr)} train / {len(F_te)} test rows, "
          f"{len(FEATURES)} features")
    print("  group means  g0:", np.round(F_tr[s_tr == 0].mean(0), 3),
          " g1:", np.round(F_tr[s_tr == 1].mean(0), 3))

    logistic = fit_scorer("logistic", F_tr, y_tr)
    mlp = fit_scorer("mlp", F_tr, y_tr)
    f_lin, f_mlp = black_box(logistic), black_box(mlp)
    f_prob = black_box(mlp, "prob")
    print(f"Test accuracy: logistic {((f_lin(F_te) > 0) == y_te).mean():.4f}, "
          f"MLP {((f_mlp(F_te) > 0) == y_te).mean():.4f}")

    rows = np.random.RandomState(2).choice(len(F_tr), 200, replace=False)
    B = F_tr[rows].astype(np.float64)       # background for "absent" features
    mu, sd = B.mean(0), F_tr.astype(np.float64).std(0)

    print("\n[1] Hand-checkable game: f = x1 + x2 + x1*x2, x=(1,1), baseline (0,0)")
    toy = lambda X: X[:, 0] + X[:, 1] + X[:, 0] * X[:, 1]
    x_toy, B_toy = np.array([1.0, 1.0]), np.zeros((1, 2))
    phi_toy, base_toy, fx_toy = exact_shapley(toy, x_toy, B_toy)
    v_toy = coalition_values(toy, x_toy, B_toy)
    print("  v(empty)=%.0f v({1})=%.0f v({2})=%.0f v({1,2})=%.0f" % (
        v_toy[()], v_toy[(0,)], v_toy[(1,)], v_toy[(0, 1)]))
    print(f"  Shapley values {phi_toy}, sum {phi_toy.sum():.1f} = f(x) - f(b) = "
          f"{fx_toy - base_toy:.1f}")

    # The applicant explained below: first qualified group-1 test applicant
    # whom the MLP rejects with approval probability between 0.25 and 0.45.
    p_mlp = f_prob(F_te)
    pick = (s_te == 1) & (y_te == 1) & (p_mlp > 0.25) & (p_mlp < 0.45)
    i0 = int(np.where(pick)[0][0])
    x = F_te[i0].astype(np.float64)
    print(f"\nApplicant (test row {i0}): group 1, truly qualified (Q={q_te[i0]:.2f}), "
          f"MLP approval probability {p_mlp[i0]:.3f}")
    print("  feature values: " + ", ".join(
        f"{n}={val:.3f}" for n, val in zip(FEATURES, x)))

    print("\n[2] Linear model, log-odds output: Shapley = w_i * (x_i - mean_i)")
    phi, base, fx = exact_shapley(f_lin, x, B)
    w_lin = logistic.weight.detach().numpy()[0]
    closed = w_lin * (x - mu)
    print(f"  {'feature':<11}{'x_i':>8}{'mean_i':>8}{'w_i':>8}"
          f"{'w(x-mean)':>11}{'enumerated':>12}")
    for j, name in enumerate(FEATURES):
        print(f"  {name:<11}{x[j]:8.3f}{mu[j]:8.3f}{w_lin[j]:8.3f}"
              f"{closed[j]:11.4f}{phi[j]:12.4f}")
    print(f"  max |enumerated - closed form| = {np.abs(phi - closed).max():.1e}; "
          f"sum = {phi.sum():.4f}; f(x) - E[f] = {fx - base:.4f}")
    c_lin = lime_contribution(lime_slopes(f_lin, x, sd), x, mu, sd)
    print(f"  LIME (1000 samples, width 1.5): max |LIME - closed form| = "
          f"{np.abs(c_lin - closed).max():.4f}")

    print("\n[3] MLP, log-odds output: SHAP and LIME on the same applicant")
    phi, base, fx = exact_shapley(f_mlp, x, B)
    beta = lime_slopes(f_mlp, x, sd)
    c = lime_contribution(beta, x, mu, sd)
    print(f"  baseline E[f] = {base:.4f}, f(x) = {fx:.4f}, gap = {fx - base:.4f}")
    print(f"  {'feature':<11}{'SHAP':>9}{'LIME slope/SD':>15}{'LIME contrib':>14}")
    for j, name in enumerate(FEATURES):
        print(f"  {name:<11}{phi[j]:9.4f}{beta[j]:15.4f}{c[j]:14.4f}")
    print(f"  {'sum':<11}{phi.sum():9.4f}{'':15}{c.sum():14.4f}")
    v = coalition_values(f_mlp, x, B)
    print(f"  Same SHAP values from all {math.factorial(4)} orderings: max diff "
          f"{np.abs(shapley_by_orderings(v, 4) - phi).max():.1e}")
    print(f"  Same SHAP values from Shapley-kernel regression: max diff "
          f"{np.abs(kernel_shap(v, 4) - phi).max():.1e}")

    print("\n[4] Agreement of SHAP and LIME over the first 100 test applicants")
    for scale, f in (("log-odds", f_mlp), ("probability", f_prob)):
        rho, top1, sign, eff = [], [], [], []
        for k in range(100):
            xk = F_te[k].astype(np.float64)
            ph, b0, fk = exact_shapley(f, xk, B)
            ck = lime_contribution(lime_slopes(f, xk, sd, seed=k), xk, mu, sd)
            rho.append(spearmanr(np.abs(ph), np.abs(ck))[0])
            top1.append(np.argmax(np.abs(ph)) == np.argmax(np.abs(ck)))
            sign.append((np.sign(ph) == np.sign(ck)).mean())
            eff.append([abs(ck.sum() - (fk - b0)), abs(fk - b0)])
        eff = np.mean(eff, axis=0)
        print(f"  {scale:<12} rank corr {np.mean(rho):.3f}; same top feature "
              f"{np.mean(top1):.2f}; same sign {np.mean(sign):.2f}")
        print(f"  {'':<12} LIME's sum misses f - E[f] by {eff[0]:.3f} on average "
              f"(mean |f - E[f]| = {eff[1]:.3f})")

    print("\n[5] Where does the group gap come from? Mean SHAP by group (test set)")
    P = np.array([exact_shapley(f_mlp, r.astype(np.float64), B)[0] for r in F_te])
    g0, g1 = P[s_te == 0].mean(0), P[s_te == 1].mean(0)
    logit_gap = f_mlp(F_te)[s_te == 0].mean() - f_mlp(F_te)[s_te == 1].mean()
    print(f"  {'feature':<11}{'group 0':>9}{'group 1':>9}{'difference':>12}"
          f"{'mean |SHAP|':>13}")
    for j, name in enumerate(FEATURES):
        print(f"  {name:<11}{g0[j]:9.4f}{g1[j]:9.4f}{g0[j] - g1[j]:12.4f}"
              f"{np.abs(P[:, j]).mean():13.4f}")
    print(f"  sum of differences = {(g0 - g1).sum():.4f}; mean log-odds gap "
          f"between the groups = {logit_gap:.4f}")
