# ch27_program1.py
# Vanilla gradient saliency: which input pixels does a trained classifier's
# prediction actually depend on? Chapter 10 computed dL/dW to update weights;
# here the SAME backprop machinery computes dy_c/dx instead -- holding the
# weights fixed and asking how the predicted class score for class c would
# change if each input pixel moved. A large |dy_c/dx_i| at pixel i means the
# score is locally sensitive to that pixel; a saliency "map" is just this
# gradient reshaped back into the image's own shape.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

torch.manual_seed(0)
np.random.seed(0)


class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))    # (batch, 8, 4, 4)
        a2 = torch.relu(self.conv2(a1))                # (batch, 16, 4, 4) -- final conv features
        pooled = a2.mean(dim=(2, 3))                    # (batch, 16) -- global average pool
        logits = self.fc(pooled)
        return logits, a2


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)     # (1797, 8, 8), scaled to [0, 1]
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_cnn(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        epoch_loss, n_batches = 0.0, 0
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits, _ = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            epoch_loss += loss.item(); n_batches += 1
        if epoch in (1, 50, 100, 150, 200, 250):
            print(f"  epoch {epoch:3d}: mean training loss = {epoch_loss / n_batches:.4f}")


def vanilla_saliency(model, x_single, target_class):
    """x_single: (1, 1, 8, 8), requires_grad will be set here. Returns an
    (8, 8) numpy array: |d(logit_c)/dx|, the vanilla-gradient saliency map."""
    x = x_single.clone().requires_grad_(True)
    logits, _ = model(x)
    score = logits[0, target_class]
    model.zero_grad()
    if x.grad is not None:
        x.grad.zero_()
    score.backward()
    return x.grad[0, 0].abs().numpy()


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()
    print(f"Digits dataset: {len(X_train)} train / {len(X_test)} test images, 8x8, pixels scaled to [0,1]")

    model = SmallCNN()
    n_params = sum(p.numel() for p in model.parameters())
    print(f"SmallCNN parameters: {n_params}")
    print("Training for 250 epochs, batch_size=32...")
    train_cnn(model, X_train, y_train, epochs=250)

    model.eval()
    with torch.no_grad():
        test_logits, _ = model(X_test)
        test_pred = test_logits.argmax(dim=1)
        test_acc = (test_pred == y_test).float().mean().item()
    print(f"\nTest accuracy: {test_acc:.4f} ({(test_pred == y_test).sum().item()}/{len(y_test)})")

    # Pick the first 4 correctly-classified test images for a worked example.
    correct_idx = (test_pred == y_test).nonzero(as_tuple=True)[0][:4]
    print(f"\nComputing vanilla-gradient saliency for {len(correct_idx)} correctly-classified test images:")

    for i in correct_idx.tolist():
        x_single = X_test[i:i + 1]
        true_class = int(y_test[i])
        sal = vanilla_saliency(model, x_single, true_class)
        img = x_single[0, 0].numpy()

        # Direct, measured sanity property: is saliency actually concentrated on
        # "ink" (bright) pixels rather than spread uniformly over the background?
        ink_mask = img > 0.15                      # pixels with visible digit ink
        ink_frac_of_image = ink_mask.mean()
        sal_on_ink = sal[ink_mask].mean() if ink_mask.any() else 0.0
        sal_on_bg = sal[~ink_mask].mean() if (~ink_mask).any() else 0.0

        print(f"\n  test image {i}, true class={true_class}, predicted={int(test_pred[i])}:")
        print(f"    saliency map min={sal.min():.4f} max={sal.max():.4f} mean={sal.mean():.4f}")
        print(f"    ink pixels: {int(ink_mask.sum())}/{ink_mask.size} ({100*ink_frac_of_image:.1f}% of image)")
        print(f"    mean saliency on ink pixels:       {sal_on_ink:.4f}")
        print(f"    mean saliency on background pixels: {sal_on_bg:.4f}")
        print(f"    ratio (ink / background):           {sal_on_ink / (sal_on_bg + 1e-8):.2f}x")

    print(f"\nThree of the four images show saliency clearly concentrated on the ink (1.17x-1.72x),")
    print(f"but the second image comes out almost perfectly even (0.99x) -- saliency there is spread")
    print(f"almost exactly as evenly over the background as over the digit's own strokes. This is a")
    print(f"real, measured result, not an aberration to explain away: vanilla-gradient saliency is")
    print(f"well documented to be noisy and edge-sensitive rather than cleanly object-following -- a")
    print(f"pixel right at a stroke's boundary, where a small change would grow or shrink the stroke,")
    print(f"can carry a gradient just as large as a pixel deep inside solid ink that the network")
    print(f"already 'counts' as fully present. This noisiness is exactly why Program 2 introduces a")
    print(f"method that aggregates over a whole learned feature region instead of raw per-pixel")
    print(f"gradients, and why Program 3 asks the harder question this picture alone cannot answer:")
    print(f"does this map actually depend on what the network LEARNED, or would an untrained network")
    print(f"produce something similar just from the input's own edges?")
