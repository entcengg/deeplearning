# ch27_program5.py
# Adversarial robustness: the Fast Gradient Sign Method (FGSM, Goodfellow et
# al., 2015) builds a small, deliberately-DIRECTED perturbation of an input --
# not by making it noisier in general, but by nudging every pixel exactly
# along the direction that increases the model's own loss the fastest. This
# program measures how much damage a given perturbation SIZE does when it is
# aimed this way, versus when an equally-sized perturbation is applied in a
# random direction, to separate "how big" from "which way" as the source of
# a network's fragility.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

torch.manual_seed(0)
np.random.seed(0)


class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))    # (batch, 8, 4, 4)
        a2 = torch.relu(self.conv2(a1))                # (batch, 16, 4, 4) -- final conv features
        pooled = a2.mean(dim=(2, 3))                    # (batch, 16) -- global average pool
        logits = self.fc(pooled)
        return logits, a2


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_cnn(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits, _ = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def fgsm_attack(model, x, y_true, epsilon):
    """x: (batch, 1, 8, 8), y_true: (batch,). Returns x_adv, the same shape,
    clipped back into the valid [0, 1] pixel range."""
    x_adv_input = x.clone().requires_grad_(True)
    logits, _ = model(x_adv_input)
    loss = nn.functional.cross_entropy(logits, y_true)
    model.zero_grad()
    loss.backward()
    perturbation = epsilon * x_adv_input.grad.sign()
    x_adv = (x + perturbation).clamp(0.0, 1.0)
    return x_adv.detach()


def random_noise_attack(model, x, epsilon, generator):
    """Same L-infinity magnitude as fgsm_attack (every pixel moves by exactly
    +-epsilon), but in a direction drawn uniformly at random rather than
    aligned with the loss gradient."""
    random_signs = torch.randint(0, 2, x.shape, generator=generator).float() * 2 - 1
    x_adv = (x + epsilon * random_signs).clamp(0.0, 1.0)
    return x_adv


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    model = SmallCNN()
    print("Training for 250 epochs, batch_size=32 (identical setup to Programs 1-2)...")
    train_cnn(model, X_train, y_train, epochs=250)
    model.eval()

    with torch.no_grad():
        clean_logits, _ = model(X_test)
        clean_pred = clean_logits.argmax(dim=1)
        clean_acc = (clean_pred == y_test).float().mean().item()
    print(f"\nClean test accuracy (no attack): {clean_acc:.4f}")

    gen = torch.Generator().manual_seed(0)
    epsilons = [0.0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3]
    print(f"\nAccuracy under FGSM vs. equal-magnitude random-sign noise, swept over epsilon")
    print(f"(epsilon is the maximum per-pixel change, out of a [0,1] pixel range):")
    print(f"{'epsilon':>8} {'FGSM acc':>10} {'random acc':>12}")

    fgsm_accs, random_accs = [], []
    for eps in epsilons:
        if eps == 0.0:
            fgsm_acc = random_acc = clean_acc
        else:
            x_fgsm = fgsm_attack(model, X_test, y_test, eps)
            with torch.no_grad():
                fgsm_logits, _ = model(x_fgsm)
                fgsm_acc = (fgsm_logits.argmax(dim=1) == y_test).float().mean().item()

            x_rand = random_noise_attack(model, X_test, eps, gen)
            with torch.no_grad():
                rand_logits, _ = model(x_rand)
                random_acc = (rand_logits.argmax(dim=1) == y_test).float().mean().item()
        fgsm_accs.append(fgsm_acc)
        random_accs.append(random_acc)
        print(f"{eps:8.2f} {fgsm_acc:10.4f} {random_acc:12.4f}")

    print(f"\nAt the largest tested epsilon (0.3), FGSM cuts accuracy from {clean_acc:.4f} to")
    print(f"{fgsm_accs[-1]:.4f}, while random noise of the exact same per-pixel magnitude only")
    print(f"moves it to {random_accs[-1]:.4f} -- confirming the direction of the perturbation, not")
    print(f"merely its size, is what does the damage.")

    # One fully worked example: find the first correctly-classified test image
    # whose prediction flips at a moderate epsilon.
    example_eps = 0.15
    correct_idx = (clean_pred == y_test).nonzero(as_tuple=True)[0]
    flip_i = None
    for i in correct_idx.tolist():
        x_single = X_test[i:i + 1]
        y_single = y_test[i:i + 1]
        x_adv_single = fgsm_attack(model, x_single, y_single, example_eps)
        with torch.no_grad():
            adv_logits, _ = model(x_adv_single)
            adv_pred = int(adv_logits.argmax(dim=1)[0])
        if adv_pred != int(y_single[0]):
            flip_i = i
            break

    print(f"\nWorked example at epsilon={example_eps} (searching test images in order for the first")
    print(f"prediction flip):")
    if flip_i is not None:
        x_single = X_test[flip_i:flip_i + 1]
        y_single = int(y_test[flip_i])
        x_adv_single = fgsm_attack(model, x_single, y_test[flip_i:flip_i + 1], example_eps)
        with torch.no_grad():
            clean_logits_single, _ = model(x_single)
            adv_logits_single, _ = model(x_adv_single)
        clean_probs = torch.softmax(clean_logits_single, dim=1)[0]
        adv_probs = torch.softmax(adv_logits_single, dim=1)[0]
        clean_pred_single = int(clean_probs.argmax())
        adv_pred_single = int(adv_probs.argmax())
        max_pixel_change = (x_adv_single - x_single).abs().max().item()

        print(f"  test image {flip_i}, true class={y_single}")
        print(f"  clean prediction:      class {clean_pred_single}, confidence {clean_probs[clean_pred_single]:.4f}")
        print(f"  adversarial prediction: class {adv_pred_single}, confidence {adv_probs[adv_pred_single]:.4f}")
        print(f"  model's confidence in the TRUE class after the attack: {adv_probs[y_single]:.4f}")
        print(f"  maximum per-pixel change actually applied: {max_pixel_change:.4f} (budget was {example_eps})")
        print(f"  every one of the 64 pixels moved by exactly +{example_eps} or -{example_eps} --")
        print(f"  FGSM always uses the full epsilon budget at every pixel, just in whichever sign")
        print(f"  direction locally increases the loss.")
    else:
        print(f"  no prediction flipped among the {len(correct_idx)} correctly-classified test images")
        print(f"  at this epsilon.")

    print(f"\nFGSM's own attack is a single step, so it does not always find the smallest possible")
    print(f"perturbation that flips a given image -- some images need a larger epsilon than others, and")
    print(f"a small fraction may resist every epsilon tested here. On these 8x8 digit images an epsilon")
    print(f"of 0.15 is not a subtle change -- a per-pixel shift that size is visible on close inspection,")
    print(f"not hidden the way a much smaller epsilon can be on higher-resolution photographs. What stays")
    print(f"true regardless of image size is the comparison that matters: at every epsilon tested, moving")
    print(f"each pixel by that exact amount in the loss-increasing direction does far more damage than")
    print(f"moving it by the same amount in a random direction -- the network's fragility is specific to")
    print(f"a direction in pixel space, not just to a magnitude of change.")
