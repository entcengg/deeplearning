# ch27_program8.py
# Three responsible-AI risks that test accuracy cannot see, each measured on
# this chapter's own models and data:
#   A. privacy       -- can an outsider tell whether an image was in the
#                       training set? (membership inference, by thresholding
#                       the per-example loss)
#   B. dataset bias  -- what do an under-represented group (sampling bias) and
#                       biased historical labels do to Program 4/6's classifier?
#   C. security      -- can a few poisoned training images plant a backdoor
#                       that leaves ordinary test accuracy untouched?

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import ks_2samp, rankdata
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_digits
import itertools
import math
from scipy.stats import spearmanr

# --- reused unchanged from Program 1 (ch27_program1.py) ---
torch.manual_seed(0)
np.random.seed(0)

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))    # (batch, 8, 4, 4)
        a2 = torch.relu(self.conv2(a1))                # (batch, 16, 4, 4) -- final conv features
        pooled = a2.mean(dim=(2, 3))                    # (batch, 16) -- global average pool
        logits = self.fc(pooled)
        return logits, a2


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)     # (1797, 8, 8), scaled to [0, 1]
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))

# --- end of Program 1 code ---

# --- reused unchanged from Program 4 (ch27_program4.py) ---
np.random.seed(0)
torch.manual_seed(0)

def make_dataset(n_per_group=2000):
    """Returns X (observed feature, what the model is trained on), Y (true
    qualification label), S (sensitive group, withheld from training), and Q
    (true qualification score, for diagnostics only)."""
    Q0 = np.random.normal(0.0, 1.0, size=n_per_group)
    Q1 = np.random.normal(0.0, 1.0, size=n_per_group)   # same distribution as group 0
    Q = np.concatenate([Q0, Q1])
    S = np.concatenate([np.zeros(n_per_group), np.ones(n_per_group)]).astype(np.int64)

    Y = (Q > 0).astype(np.int64)   # ground truth: qualified iff true score exceeds 0

    # X is what actually gets measured and handed to the model: a noisy proxy
    # for Q that is biased LOW and made noisier specifically for group 1.
    noise0 = np.random.normal(0.0, 0.5, size=n_per_group)
    noise1 = np.random.normal(-0.6, 1.0, size=n_per_group)
    noise = np.concatenate([noise0, noise1])
    X = (Q + noise).astype(np.float32)

    perm = np.random.permutation(len(Q))
    return X[perm], Y[perm], S[perm], Q[perm]


class LogisticClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        return self.linear(x).squeeze(-1)


def train_classifier(X_train, y_train, epochs=300, lr=0.1):
    model = LogisticClassifier()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()
    X_t = torch.from_numpy(X_train).unsqueeze(-1)
    y_t = torch.from_numpy(y_train.astype(np.float32))
    for epoch in range(epochs):
        logits = model(X_t)
        loss = loss_fn(logits, y_t)
        optimizer.zero_grad(); loss.backward(); optimizer.step()
    return model


def predict(model, X):
    with torch.no_grad():
        logits = model(torch.from_numpy(X).unsqueeze(-1))
        return (torch.sigmoid(logits) > 0.5).numpy().astype(np.int64)


def group_metrics(pred, y, s, group):
    mask = (s == group)
    y_g, pred_g = y[mask], pred[mask]
    acc = (pred_g == y_g).mean()
    pos_rate = pred_g.mean()
    pos_mask, neg_mask = (y_g == 1), (y_g == 0)
    tpr = pred_g[pos_mask].mean() if pos_mask.any() else float("nan")
    fpr = pred_g[neg_mask].mean() if neg_mask.any() else float("nan")
    return acc, pos_rate, tpr, fpr

# --- end of Program 4 code ---

# --- reused unchanged from Program 6 (ch27_program6.py) ---
torch.set_num_threads(1)
FEATURES = ["assessment", "interview", "postcode", "noise"]

def make_wide_dataset():
    """Program 4's (X, Y, S, Q) plus three new columns. S is still withheld."""
    np.random.seed(0)
    X, Y, S, Q = make_dataset(n_per_group=2000)       # X: group-biased score
    rng = np.random.RandomState(1)
    interview = Q + rng.normal(0.0, 1.5, len(Q))      # unbiased but noisy
    postcode = S + rng.normal(0.0, 0.8, len(Q))       # leaks the group label
    noise = rng.normal(0.0, 1.0, len(Q))              # irrelevant by design
    F = np.column_stack([X, interview, postcode, noise]).astype(np.float32)
    return F, Y, S, Q


def make_model(kind):
    if kind == "logistic":
        return nn.Linear(4, 1)
    return nn.Sequential(nn.Linear(4, 16), nn.ReLU(),
                         nn.Linear(16, 16), nn.ReLU(), nn.Linear(16, 1))


def fit_scorer(kind, F, y, seed=0):
    """Train a logistic model (one nn.Linear) or a small MLP, then convert
    to float64 so closed-form checks hold to rounding error."""
    torch.manual_seed(seed)
    model = make_model(kind)
    epochs, lr = (300, 0.1) if kind == "logistic" else (500, 0.01)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    X, t = torch.from_numpy(F), torch.from_numpy(y.astype(np.float32))
    for _ in range(epochs):
        loss = nn.functional.binary_cross_entropy_with_logits(
            model(X).squeeze(-1), t)
        opt.zero_grad(); loss.backward(); opt.step()
    return model.double().eval()


def black_box(model, scale="logit"):
    """The only thing an explainer may use: rows in, one score per row out."""
    def f(X):
        with torch.no_grad():
            z = model(torch.from_numpy(np.asarray(X, dtype=np.float64)))
            z = z.squeeze(-1)
            return (torch.sigmoid(z) if scale == "prob" else z).numpy()
    return f

# --- end of Program 6 code ---

torch.set_num_threads(1)

def logits_of(model, X):
    out = model(X)
    return out[0] if isinstance(out, tuple) else out

def wide_mlp():                                          # 17,226 parameters
    return nn.Sequential(nn.Flatten(), nn.Linear(64, 128), nn.ReLU(),
                         nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, 10))

def train(model, X, y, epochs, lr=1e-3, batch=32, checkpoints=(), report=None):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(len(X))
        for b in range(0, len(X), batch):
            i = perm[b:b + batch]
            loss = nn.functional.cross_entropy(logits_of(model, X[i]), y[i])
            opt.zero_grad(); loss.backward(); opt.step()
        if epoch in checkpoints:
            report(epoch)
    return model.eval()

def per_example_loss(model, X, y):
    with torch.no_grad():
        return nn.functional.cross_entropy(logits_of(model, X), y,
                                           reduction="none").numpy()

def membership_scores(loss_in, loss_out):
    """AUC of the rule 'smaller loss => member' (the chance a random member
    has a smaller loss than a random non-member) and the attacker's best
    advantage, max over thresholds of TPR - FPR (the KS distance)."""
    n_in, n_out = len(loss_in), len(loss_out)
    ranks = rankdata(-np.concatenate([loss_in, loss_out]))
    auc = (ranks[:n_in].sum() - n_in * (n_in + 1) / 2) / (n_in * n_out)
    return auc, ks_2samp(loss_in, loss_out).statistic

def stamp(X):
    """The backdoor trigger: a 2x2 patch of full-intensity pixels, bottom right."""
    X = X.clone(); X[:, :, 6:8, 6:8] = 1.0
    return X

if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    print("A. Membership inference (100 member images, 100 non-member images)")
    rng = np.random.RandomState(0)
    mem = torch.from_numpy(rng.permutation(len(X_train))[:100])
    non = torch.from_numpy(rng.permutation(len(X_test))[:100])
    X_in, y_in, X_out, y_out = X_train[mem], y_train[mem], X_test[non], y_test[non]

    def make_report(model, X_m, y_m, X_n, y_n):
        def report(epoch):
            l_in = per_example_loss(model, X_m, y_m)
            l_out = per_example_loss(model, X_n, y_n)
            with torch.no_grad():
                acc_in = (logits_of(model, X_m).argmax(1) == y_m).float().mean()
                pred_all = logits_of(model, X_test).argmax(1)
                acc_out = (pred_all == y_test).float().mean()
            auc, adv = membership_scores(l_in, l_out)
            print(f"   {epoch:5d} {acc_in:9.3f} {acc_out:9.3f} {l_in.mean():9.3f} "
                  f"{l_out.mean():9.3f} {auc:7.3f} {adv:9.3f}")
        return report

    se = np.sqrt((100 + 100 + 1) / (12 * 100 * 100))
    print(f"  (a useless attack scores AUC 0.5 with standard error {se:.3f} "
          f"at this sample size)")
    head = "   epoch  train acc  test acc  loss(in)  loss(out)    AUC  advantage"
    for name, build in (("SmallCNN (1,418 parameters)", SmallCNN),
                        ("wide MLP (17,226 parameters)", wide_mlp)):
        print(f"  {name}, trained on the 100 members only:\n{head}")
        torch.manual_seed(0)
        model = build()
        train(model, X_in, y_in, 300, lr=3e-3, checkpoints=(10, 30, 100, 300),
              report=make_report(model, X_in, y_in, X_out, y_out))
    print("  wide MLP trained on all 1347 images (non-members: all 450 test images):")
    print(head)
    torch.manual_seed(0)
    model = wide_mlp()
    train(model, X_train, y_train, 100, lr=3e-3, checkpoints=(100,),
          report=make_report(model, X_train, y_train, X_test, y_test))

    print("\nB. Dataset bias on the fairness data")
    np.random.seed(0)
    X, Y, S, Q = make_dataset(n_per_group=2000)           # Program 4's data
    X_tr, X_te, y_tr, y_te, s_tr, s_te = train_test_split(
        X, Y, S, test_size=0.25, random_state=0, stratify=S)
    print("  Sampling bias: keep all group-0 rows, thin group 1 (mean of 10 draws)")
    print("   share of group 1   acc g0   acc g1   TPR gap   threshold on X")
    for share in (0.5, 0.2, 0.1, 0.05):
        n1 = int(round(share / (1 - share) * (s_tr == 0).sum()))
        rows = []
        for draw in range(10):
            g1 = np.random.RandomState(draw).choice(
                np.where(s_tr == 1)[0], n1, replace=False)
            keep = np.concatenate([np.where(s_tr == 0)[0], g1])
            torch.manual_seed(0)
            model = train_classifier(X_tr[keep], y_tr[keep], epochs=300)
            pred = predict(model, X_te)
            a0, _, t0, _ = group_metrics(pred, y_te, s_te, 0)
            a1, _, t1, _ = group_metrics(pred, y_te, s_te, 1)
            rows.append([a0, a1, abs(t0 - t1),
                         -model.linear.bias.item() / model.linear.weight.item()])
        m = np.mean(rows, axis=0)
        print(f"   {share:16.2f} {m[0]:8.3f} {m[1]:8.3f} {m[2]:9.3f} {m[3]:15.3f}")

    print("  Label bias: a qualified group-1 applicant keeps the positive label "
          "only with")
    print("  probability 1-p (4-feature data of Program 6, logistic model, "
          "true-label test)")
    print("       p   flipped   TPR g0   TPR g1   TPR gap   weight on postcode")
    F, Y4, S4, Q4 = make_wide_dataset()
    F_tr, F_te, y4_tr, y4_te, s4_tr, s4_te = train_test_split(
        F, Y4, S4, test_size=0.25, random_state=0, stratify=S4)
    u = np.random.RandomState(5).rand(len(y4_tr))     # same draws for every p
    for p in (0.0, 0.2, 0.4, 0.6):
        flip = (s4_tr == 1) & (y4_tr == 1) & (u < p)
        y_biased = y4_tr.copy(); y_biased[flip] = 0
        model = fit_scorer("logistic", F_tr, y_biased)
        pred = (black_box(model)(F_te) > 0).astype(int)
        _, _, t0, _ = group_metrics(pred, y4_te, s4_te, 0)
        _, _, t1, _ = group_metrics(pred, y4_te, s4_te, 1)
        print(f"   {p:5.1f} {flip.sum():9d} {t0:8.3f} {t1:8.3f} {abs(t0 - t1):9.3f} "
              f"{model.weight.detach().numpy()[0, 2]:15.3f}")

    print("\nC. Backdoor poisoning of the digit classifier (trigger -> class 0)")
    print("   poisoned images  clean test accuracy  triggered images sent to class 0")
    target, results = 0, {}
    for frac in (0.0, 0.05):
        X_fit, y_fit = X_train.clone(), y_train.clone()
        n_poison = int(frac * len(X_train))
        if n_poison > 0:
            others = np.where(y_train.numpy() != target)[0]
            pick = torch.from_numpy(np.random.RandomState(0).choice(
                others, n_poison, replace=False))
            X_fit[pick], y_fit[pick] = stamp(X_train[pick]), target
        torch.manual_seed(0)
        model = train(SmallCNN(), X_fit, y_fit, 100, lr=3e-3, batch=64)
        with torch.no_grad():
            pred = logits_of(model, X_test).argmax(1)
            others = y_test != target
            hijacked = logits_of(model, stamp(X_test[others])).argmax(1) == target
        results[frac] = pred
        print(f"   {n_poison:15d} {(pred == y_test).float().mean():20.4f} "
              f"{hijacked.float().mean():28.4f}")
    agree = (results[0.0] == results[0.05]).float().mean()
    print(f"   (the two models still give different labels on {1 - agree:.3f} of the "
          f"clean test images)")
