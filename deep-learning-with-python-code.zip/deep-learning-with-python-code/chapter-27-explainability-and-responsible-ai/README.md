# Chapter 27 · Explainability and Responsible AI

Code for Chapter 27 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 26](../chapter-26-deep-learning-for-time-series/README.md) · [Chapter 28 →](../chapter-28-deploying-deep-learning-models/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 27.1.1 Program 1: Vanilla-Gradient Saliency on a Digit Classifier | Vanilla-gradient saliency maps for a small CNN digit classifier | [`ch27_program1.py`](ch27_program1.py) | [ch27_program1.txt](expected_output/ch27_program1.txt) | 24 s |
| 2 | 27.2.1 Program 2: Grad-CAM with a Closed-Form Implementation Check | Grad-CAM with a raw 4×4 localization map, nearest-neighbor upsampling, and a closed-form implementation check | [`ch27_program2.py`](ch27_program2.py) | [ch27_program2.txt](expected_output/ch27_program2.txt) | 24 s |
| 3 | 27.3.1 Program 3: The Model-Parameter-Randomization Test | Comparing trained-vs.-random-weight explanations by cosine similarity, for both vanilla-gradient saliency and Grad-CAM | [`ch27_program3.py`](ch27_program3.py) | [ch27_program3.txt](expected_output/ch27_program3.txt) | 24 s |
| 4 | 27.4.1 Program 4: Measuring Fairness Gaps Directly | A synthetic dataset with identical true qualification across groups, a group-biased observed feature, and a classifier trained without the sensitive attribute | [`ch27_program4.py`](ch27_program4.py) | [ch27_program4.txt](expected_output/ch27_program4.txt) | 5 s |
| 5 | 27.5.1 Program 5: Directed vs. Random Perturbations | FGSM vs. equal-magnitude random noise, swept over ε, plus one fully worked prediction flip | [`ch27_program5.py`](ch27_program5.py) | [ch27_program5.txt](expected_output/ch27_program5.txt) | 25 s |
| 6 | 27.6.1 Program 6: Exact Shapley Values and LIME, From Scratch | Exact Shapley values by enumerating coalitions, and LIME as a kernel-weighted linear surrogate, checked against closed forms and each other | [`ch27_program6.py`](ch27_program6.py) | [ch27_program6.txt](expected_output/ch27_program6.txt) | 7 s |
| 7 | 27.7.1 Program 7: Six Checks on Two Explainers | Validating SHAP and LIME: determinism, seed and kernel-width stability, background choice, model randomization and deletion faithfulness | [`ch27_program7.py`](ch27_program7.py) | [ch27_program7.txt](expected_output/ch27_program7.txt) | 8 s |
| 8 | 27.8.1 Program 8: Membership Inference, Biased Data and a Backdoor | Measuring three risks that test accuracy cannot see: membership inference, sampling and label bias, and a backdoor | [`ch27_program8.py`](ch27_program8.py) | [ch27_program8.txt](expected_output/ch27_program8.txt) | 27 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-27-explainability-and-responsible-ai
python ch27_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch27_notebook.ipynb`](ch27_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, SciPy, PyTorch.
