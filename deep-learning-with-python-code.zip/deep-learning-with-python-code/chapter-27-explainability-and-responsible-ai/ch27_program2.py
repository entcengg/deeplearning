# ch27_program2.py
# Grad-CAM (Gradient-weighted Class Activation Mapping): instead of a raw
# per-pixel gradient (Program 1), Grad-CAM asks a coarser, more stable
# question -- which SPATIAL REGION of the last convolutional layer's feature
# maps mattered most for this prediction? It weights each of that layer's
# channels by how much the target class score depends on it (a single number
# per channel, averaged over space), then combines the channels into one
# localization map at the feature layer's own resolution.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

torch.manual_seed(0)
np.random.seed(0)


class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))    # (batch, 8, 4, 4)
        a2 = torch.relu(self.conv2(a1))                # (batch, 16, 4, 4) -- final conv features
        pooled = a2.mean(dim=(2, 3))                    # (batch, 16) -- global average pool
        logits = self.fc(pooled)
        return logits, a2


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_cnn(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits, _ = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def upsample_nearest(small_map, out_size):
    """Nearest-neighbor upsampling of a (h, w) map to (out_size, out_size),
    with no extra dependency beyond numpy."""
    h, w = small_map.shape
    row_idx = (np.arange(out_size) * h // out_size)
    col_idx = (np.arange(out_size) * w // out_size)
    return small_map[np.ix_(row_idx, col_idx)]


def grad_cam(model, x_single, target_class):
    """x_single: (1, 1, 8, 8). Returns (alpha, cam_small, cam_upsampled):
    alpha (16,) the per-channel weights, cam_small (4,4) the raw Grad-CAM map
    at the last conv layer's own resolution, cam_upsampled (8,8) resized to
    the input's resolution for overlay."""
    x = x_single.clone()
    logits, features = model(x)                 # features: (1, 16, 4, 4), requires_grad via model params
    features.retain_grad()
    score = logits[0, target_class]
    model.zero_grad()
    score.backward()

    grads = features.grad[0]                    # (16, 4, 4)
    activations = features.detach()[0]           # (16, 4, 4)
    alpha = grads.mean(dim=(1, 2))                # (16,) -- global-average-pooled gradient per channel

    cam = torch.zeros(activations.shape[1:])      # (4, 4)
    for k in range(activations.shape[0]):
        cam += alpha[k] * activations[k]
    cam = torch.relu(cam).numpy()                 # ReLU: keep only features that INCREASE the class score
    cam_upsampled = upsample_nearest(cam, 8)
    return alpha.numpy(), cam, cam_upsampled


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()
    print(f"Digits dataset: {len(X_train)} train / {len(X_test)} test images, 8x8, pixels scaled to [0,1]")

    model = SmallCNN()
    print("Training for 250 epochs, batch_size=32 (identical setup to Program 1)...")
    train_cnn(model, X_train, y_train, epochs=250)

    model.eval()
    test_logits, _ = model(X_test)
    test_pred = test_logits.argmax(dim=1)
    test_acc = (test_pred == y_test).float().mean().item()
    print(f"\nTest accuracy: {test_acc:.4f} ({(test_pred == y_test).sum().item()}/{len(y_test)})")

    # This architecture ends in global-average-pool + one linear layer, so
    # Grad-CAM's alpha_k has a closed form: d(logit_c)/d(a2[k,i,j]) = fc.weight[c,k]/16
    # at every spatial position (the 1/16 from averaging over the 4x4=16 GAP
    # inputs), so alpha_k (itself an average over the same 16 positions) should
    # equal fc.weight[c,k]/16 exactly. Checking this on one example verifies
    # the implementation before trusting any of its maps.
    x_check = X_test[0:1]
    c_check = int(y_test[0])
    alpha_check, _, _ = grad_cam(model, x_check, c_check)
    direct_check = (model.fc.weight[c_check].detach().numpy()) / 16.0
    max_abs_diff = np.abs(alpha_check - direct_check).max()
    print(f"\nImplementation check on test image 0 (class {c_check}): Grad-CAM's alpha via backprop")
    print(f"  vs. fc.weight[{c_check}]/16 computed directly -- max abs difference: {max_abs_diff:.2e}")

    correct_idx = (test_pred == y_test).nonzero(as_tuple=True)[0][:4]
    print(f"\nComputing Grad-CAM for the same {len(correct_idx)} correctly-classified test images"
          f"\nused in Program 1 (last conv layer: 16 channels, 4x4 spatial):")

    for i in correct_idx.tolist():
        x_single = X_test[i:i + 1]
        true_class = int(y_test[i])
        alpha, cam_small, cam_up = grad_cam(model, x_single, true_class)
        img = X_test[i, 0].numpy()

        ink_mask = img > 0.15
        # Localization-quality proxy: does the map's top quartile (by upsampled
        # value) overlap with where the digit's ink actually is?
        threshold = np.quantile(cam_up, 0.75)
        top_quartile_mask = cam_up >= threshold
        overlap_frac = (top_quartile_mask & ink_mask).sum() / max(1, top_quartile_mask.sum())

        print(f"\n  test image {i}, true class={true_class}, predicted={int(test_pred[i])}:")
        print(f"    channel weights alpha: min={alpha.min():.4f} max={alpha.max():.4f} "
              f"({int((alpha > 0).sum())}/16 positive)")
        print(f"    raw CAM (4x4, before upsampling):")
        for row in cam_small:
            print(f"      [{row[0]:.4f} {row[1]:.4f} {row[2]:.4f} {row[3]:.4f}]")
        print(f"    upsampled CAM (8x8) top-quartile pixels landing on ink: "
              f"{int((top_quartile_mask & ink_mask).sum())}/{int(top_quartile_mask.sum())} "
              f"({100*overlap_frac:.1f}%)")

    print(f"\nUnlike Program 1's per-pixel saliency, Grad-CAM's raw map lives at the last conv")
    print(f"layer's own 4x4 resolution -- coarser than the 8x8 input by construction, since it")
    print(f"summarizes 16 whole feature channels rather than 64 individual pixels. Upsampling it")
    print(f"back to 8x8 trades pixel-level precision for a map that reflects which LEARNED feature")
    print(f"channels the network actually weighted positively (alpha > 0) for this specific class,")
    print(f"not just which input pixels have a large local gradient. Localization quality is still")
    print(f"uneven across examples (top-quartile-on-ink overlap ranges from 37.5% to 87.5% here),")
    print(f"but three of the four land well above the roughly 48% a same-sized random patch of this")
    print(f"image would overlap by chance, unlike Program 1's much noisier per-pixel picture.")
