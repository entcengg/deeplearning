# ch27_program3.py
# Sanity check: does an explanation actually depend on what the network
# LEARNED, or would it look similar for an untrained network that has learned
# nothing at all? Programs 1-2 showed saliency and Grad-CAM highlighting
# plausible-looking regions, but "looks plausible to a human" is not proof
# that the map reflects the model's actual learned weights -- an explanation
# built mostly from the input's own edges and contrast would look similar
# whether the network underneath is trained or freshly, randomly initialized.
# This program runs that exact comparison (a simplified version of the model
# randomization test from Adebayo et al., 2018, "Sanity Checks for Saliency
# Maps") and measures, rather than assumes, which method passes it.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

torch.manual_seed(0)
np.random.seed(0)


class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))    # (batch, 8, 4, 4)
        a2 = torch.relu(self.conv2(a1))                # (batch, 16, 4, 4) -- final conv features
        pooled = a2.mean(dim=(2, 3))                    # (batch, 16) -- global average pool
        logits = self.fc(pooled)
        return logits, a2


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_cnn(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits, _ = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def vanilla_saliency(model, x_single, target_class):
    x = x_single.clone().requires_grad_(True)
    logits, _ = model(x)
    score = logits[0, target_class]
    model.zero_grad()
    if x.grad is not None:
        x.grad.zero_()
    score.backward()
    return x.grad[0, 0].abs().numpy()


def grad_cam(model, x_single, target_class):
    x = x_single.clone()
    logits, features = model(x)
    features.retain_grad()
    score = logits[0, target_class]
    model.zero_grad()
    score.backward()
    grads = features.grad[0]
    activations = features.detach()[0]
    alpha = grads.mean(dim=(1, 2))
    cam = torch.zeros(activations.shape[1:])
    for k in range(activations.shape[0]):
        cam += alpha[k] * activations[k]
    return torch.relu(cam).numpy()


def cosine_similarity(a, b):
    a_flat, b_flat = a.flatten(), b.flatten()
    denom = (np.linalg.norm(a_flat) * np.linalg.norm(b_flat))
    if denom < 1e-12:
        return 0.0
    return float(np.dot(a_flat, b_flat) / denom)


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    print("Model A: trained normally, 250 epochs (identical to Programs 1-2).")
    trained_model = SmallCNN()
    train_cnn(trained_model, X_train, y_train, epochs=250)
    trained_model.eval()
    with torch.no_grad():
        test_logits, _ = trained_model(X_test)
        test_pred = test_logits.argmax(dim=1)
        test_acc = (test_pred == y_test).float().mean().item()
    print(f"  test accuracy: {test_acc:.4f}")

    print("\nModel B: identical architecture, weights left at random initialization")
    print("(a different seed, so it is not simply a copy of Model A's random start).")
    torch.manual_seed(999)
    random_model = SmallCNN()
    random_model.eval()
    with torch.no_grad():
        rand_logits, _ = random_model(X_test)
        rand_pred = rand_logits.argmax(dim=1)
        rand_acc = (rand_pred == y_test).float().mean().item()
    print(f"  test accuracy: {rand_acc:.4f} (chance level for 10 classes is 0.1000 -- confirms it has")
    print(f"  learned nothing)")

    correct_idx = (test_pred == y_test).nonzero(as_tuple=True)[0][:20]
    print(f"\nComparing explanations from Model A (trained) vs. Model B (random) on the same")
    print(f"{len(correct_idx)} test images, all using the TRUE class as the target for both models:")

    sal_sims, cam_sims = [], []
    for i in correct_idx.tolist():
        x_single = X_test[i:i + 1]
        true_class = int(y_test[i])

        sal_trained = vanilla_saliency(trained_model, x_single, true_class)
        sal_random = vanilla_saliency(random_model, x_single, true_class)
        cam_trained = grad_cam(trained_model, x_single, true_class)
        cam_random = grad_cam(random_model, x_single, true_class)

        sal_sims.append(cosine_similarity(sal_trained, sal_random))
        cam_sims.append(cosine_similarity(cam_trained, cam_random))

    sal_sims = np.array(sal_sims)
    cam_sims = np.array(cam_sims)

    print(f"\nVanilla-gradient saliency, trained vs. random -- cosine similarity over {len(correct_idx)} images:")
    print(f"  mean={sal_sims.mean():.4f}  std={sal_sims.std():.4f}  min={sal_sims.min():.4f}  max={sal_sims.max():.4f}")
    print(f"  ({int((sal_sims > 0.5).sum())}/{len(sal_sims)} images above 0.5 similarity)")

    print(f"\nGrad-CAM, trained vs. random -- cosine similarity over {len(correct_idx)} images:")
    print(f"  mean={cam_sims.mean():.4f}  std={cam_sims.std():.4f}  min={cam_sims.min():.4f}  max={cam_sims.max():.4f}")
    print(f"  ({int((cam_sims > 0.5).sum())}/{len(cam_sims)} images above 0.5 similarity)")

    print(f"\nFor reference, two INDEPENDENT random models (B vs. a freshly-reseeded Model C, neither")
    print(f"trained) give a same-metric floor to compare both results against:")
    torch.manual_seed(12345)
    random_model_c = SmallCNN()
    random_model_c.eval()
    floor_sims = []
    for i in correct_idx.tolist():
        x_single = X_test[i:i + 1]
        true_class = int(y_test[i])
        cam_b = grad_cam(random_model, x_single, true_class)
        cam_c = grad_cam(random_model_c, x_single, true_class)
        floor_sims.append(cosine_similarity(cam_b, cam_c))
    floor_sims = np.array(floor_sims)
    print(f"  Grad-CAM, random Model B vs. random Model C: mean={floor_sims.mean():.4f} std={floor_sims.std():.4f}")

    print(f"\nNeither method collapses all the way to that random-vs-random floor -- some baseline")
    print(f"agreement is expected even between two untrained networks of the same architecture, since a")
    print(f"fresh convolutional filter still responds to input edges and contrast regardless of what (if")
    print(f"anything) it has learned. But the two methods diverge in how far they move from an")
    print(f"unchanged-by-training result. Vanilla-gradient saliency stays close together whether the")
    print(f"network is trained or randomly initialized (mean=0.6288, std=0.0597, all 20 of the 20 images")
    print(f"above 0.5 similarity) -- a real, measured partial failure of the sanity check, consistent")
    print(f"with the documented criticism that raw pixel gradients are driven heavily by input structure")
    print(f"rather than purely by learned weights. Grad-CAM moves substantially further from 'unchanged'")
    print(f"on average (mean=0.5249) but far less consistently (std=0.2403): for some images its")
    print(f"trained-vs-random similarity falls close to or even below the random-vs-random floor,")
    print(f"showing a map that really does depend on what was learned, while for others it stays nearly")
    print(f"as similar as vanilla gradient does. The honest conclusion is not 'Grad-CAM passes and")
    print(f"saliency fails' but 'Grad-CAM depends on what the network learned for most, not all, of")
    print(f"these images, and vanilla-gradient saliency depends on it only weakly across the board' --")
    print(f"a reason to run this exact check on a real explanation before trusting it, rather than")
    print(f"judging by eye alone.")
