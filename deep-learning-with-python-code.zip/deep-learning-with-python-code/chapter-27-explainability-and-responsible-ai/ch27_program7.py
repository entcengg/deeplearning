# ch27_program7.py
# Validating the explainers themselves. Program 6 produced one SHAP and one
# LIME explanation per applicant; this program asks how far each can be
# trusted, with six checks that need nothing beyond the model:
#   A. determinism      -- does the same call return the same explanation?
#   B. seed stability   -- does LIME's answer survive a change of random seed?
#   C. kernel width     -- does it survive a change of LIME's own setting?
#   D. baseline choice  -- how much does SHAP depend on what "absent" means?
#   E. model dependence -- Program 3's randomization test, run on SHAP / LIME.
#   F. faithfulness     -- does deleting the top-ranked feature move the output?
# The data, models and both explainers come from Program 6, unchanged.

import numpy as np
import torch
from scipy.stats import spearmanr
from sklearn.model_selection import train_test_split
import itertools
import math
import torch.nn as nn

# --- reused unchanged from Program 6 (ch27_program6.py) ---
# --- reused unchanged from Program 4 (ch27_program4.py) ---
np.random.seed(0)
torch.manual_seed(0)

def make_dataset(n_per_group=2000):
    """Returns X (observed feature, what the model is trained on), Y (true
    qualification label), S (sensitive group, withheld from training), and Q
    (true qualification score, for diagnostics only)."""
    Q0 = np.random.normal(0.0, 1.0, size=n_per_group)
    Q1 = np.random.normal(0.0, 1.0, size=n_per_group)   # same distribution as group 0
    Q = np.concatenate([Q0, Q1])
    S = np.concatenate([np.zeros(n_per_group), np.ones(n_per_group)]).astype(np.int64)

    Y = (Q > 0).astype(np.int64)   # ground truth: qualified iff true score exceeds 0

    # X is what actually gets measured and handed to the model: a noisy proxy
    # for Q that is biased LOW and made noisier specifically for group 1.
    noise0 = np.random.normal(0.0, 0.5, size=n_per_group)
    noise1 = np.random.normal(-0.6, 1.0, size=n_per_group)
    noise = np.concatenate([noise0, noise1])
    X = (Q + noise).astype(np.float32)

    perm = np.random.permutation(len(Q))
    return X[perm], Y[perm], S[perm], Q[perm]

# --- end of Program 4 code ---
torch.set_num_threads(1)
FEATURES = ["assessment", "interview", "postcode", "noise"]

def make_wide_dataset():
    """Program 4's (X, Y, S, Q) plus three new columns. S is still withheld."""
    np.random.seed(0)
    X, Y, S, Q = make_dataset(n_per_group=2000)       # X: group-biased score
    rng = np.random.RandomState(1)
    interview = Q + rng.normal(0.0, 1.5, len(Q))      # unbiased but noisy
    postcode = S + rng.normal(0.0, 0.8, len(Q))       # leaks the group label
    noise = rng.normal(0.0, 1.0, len(Q))              # irrelevant by design
    F = np.column_stack([X, interview, postcode, noise]).astype(np.float32)
    return F, Y, S, Q


def make_model(kind):
    if kind == "logistic":
        return nn.Linear(4, 1)
    return nn.Sequential(nn.Linear(4, 16), nn.ReLU(),
                         nn.Linear(16, 16), nn.ReLU(), nn.Linear(16, 1))


def fit_scorer(kind, F, y, seed=0):
    """Train a logistic model (one nn.Linear) or a small MLP, then convert
    to float64 so closed-form checks hold to rounding error."""
    torch.manual_seed(seed)
    model = make_model(kind)
    epochs, lr = (300, 0.1) if kind == "logistic" else (500, 0.01)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    X, t = torch.from_numpy(F), torch.from_numpy(y.astype(np.float32))
    for _ in range(epochs):
        loss = nn.functional.binary_cross_entropy_with_logits(
            model(X).squeeze(-1), t)
        opt.zero_grad(); loss.backward(); opt.step()
    return model.double().eval()


def black_box(model, scale="logit"):
    """The only thing an explainer may use: rows in, one score per row out."""
    def f(X):
        with torch.no_grad():
            z = model(torch.from_numpy(np.asarray(X, dtype=np.float64)))
            z = z.squeeze(-1)
            return (torch.sigmoid(z) if scale == "prob" else z).numpy()
    return f


def coalition_values(f, x, B):
    """v[S] = average of f over the background rows B, with the features in
    S set to the instance's values and the others left as in each row of B."""
    d, v = len(x), {}
    for r in range(d + 1):
        for S in itertools.combinations(range(d), r):
            H = B.copy()
            if S:
                H[:, list(S)] = x[list(S)]
            v[S] = f(H).mean()
    return v


def exact_shapley(f, x, B):
    d = len(x)
    v = coalition_values(f, x, B)
    phi = np.zeros(d)
    for i in range(d):
        rest = [j for j in range(d) if j != i]
        for r in range(d):
            w = math.factorial(r) * math.factorial(d - r - 1) / math.factorial(d)
            for S in itertools.combinations(rest, r):
                phi[i] += w * (v[tuple(sorted(S + (i,)))] - v[S])
    return phi, v[()], v[tuple(range(d))]


def lime_slopes(f, x, sd, n=1000, width=1.5, ridge=1.0, seed=0):
    """Fit g(z) = b0 + sum_i beta_i (z_i - x_i)/sd_i to f on n perturbations
    of x, each weighted by exp(-D^2/width^2). Returns beta (per-SD slopes)."""
    rng = np.random.RandomState(seed)
    E = rng.standard_normal((n, len(x)))              # perturbations, in SD units
    E[0] = 0.0                                        # row 0 is x itself
    weights = np.exp(-(E ** 2).sum(axis=1) / width ** 2)
    A = np.column_stack([np.ones(n), E])
    penalty = ridge * np.eye(A.shape[1]); penalty[0, 0] = 0.0
    lhs = A.T @ (A * weights[:, None]) + penalty
    return np.linalg.solve(lhs, A.T @ (weights * f(x + sd * E)))[1:]


def lime_contribution(beta, x, mu, sd):
    """Slope times how far x sits from the baseline, in output units."""
    return beta * (x - mu) / sd

# --- end of Program 6 code ---

def rank_agreement(C):
    """Mean Spearman correlation between the |attribution| rankings of every
    pair of runs (rows of C); share of runs that name the modal top feature."""
    rhos = [spearmanr(np.abs(C[a]), np.abs(C[b]))[0]
            for a in range(len(C)) for b in range(a + 1, len(C))]
    return np.nanmean(rhos), np.bincount(np.argmax(np.abs(C), 1)).max() / len(C)

def total_weight(n, width, d=4):
    """Sum of LIME's kernel weights over the n perturbations (seed 0)."""
    E = np.random.RandomState(0).standard_normal((n, d)); E[0] = 0.0
    return np.exp(-(E ** 2).sum(axis=1) / width ** 2).sum()

def cosine(a, b):
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))

if __name__ == "__main__":
    F, Y, S, Q = make_wide_dataset()
    F_tr, F_te, y_tr, y_te, s_tr, s_te = train_test_split(
        F, Y, S, test_size=0.25, random_state=0, stratify=S)[:6]
    f = black_box(fit_scorer("mlp", F_tr, y_tr))
    rows = np.random.RandomState(2).choice(len(F_tr), 200, replace=False)
    B = F_tr[rows].astype(np.float64)
    mu, sd = B.mean(0), F_tr.astype(np.float64).std(0)
    x = F_te[8].astype(np.float64)                  # Program 6's applicant
    phi, base, fx = exact_shapley(f, x, B)
    R = 30

    print("A. Determinism: exact Shapley values, 30 repeated calls")
    runs = np.array([exact_shapley(f, x, B)[0] for _ in range(R)])
    print(f"   max |difference| between any two calls: "
          f"{np.abs(runs - runs[0]).max():.2e}")

    print("\nB. LIME across 30 random seeds (same applicant, same model)")
    widths, sizes = (0.5, 1.5, 3.0), (50, 200, 1000)
    agree, top = {}, {}
    for w in widths:
        for n in sizes:
            C = np.array([lime_contribution(
                lime_slopes(f, x, sd, n, w, seed=1000 + r), x, mu, sd)
                for r in range(R)])
            agree[w, n], top[w, n] = rank_agreement(C)
            if (w, n) in ((1.5, 1000), (0.5, 200)):
                print(f"   contributions over seeds, width {w}, {n} samples:")
                for j, name in enumerate(FEATURES):
                    print(f"     {name:<11} SHAP {phi[j]:8.4f}   LIME mean "
                          f"{C[:, j].mean():8.4f}  sd {C[:, j].std():.4f}")
    print("   mean pairwise rank agreement (Spearman); rows = kernel width,")
    print("   columns = number of perturbations:")
    print("   " + " " * 6 + "".join(f"{n:>8d}" for n in sizes))
    for w in widths:
        print(f"   {w:<6}" + "".join(f"{agree[w, n]:8.2f}" for n in sizes))
    print("   share of the 30 runs that agree on the top feature:")
    for w in widths:
        print(f"   {w:<6}" + "".join(f"{top[w, n]:8.2f}" for n in sizes))

    print("\nC. LIME across kernel widths (5000 perturbations, one seed)")
    print(f"   {'width':<7}" + "".join(f"{n:>12}" for n in FEATURES)
          + f"{'sum':>9}{'weight':>9}")
    for w in (0.25, 0.5, 1.0, 1.5, 3.0, 6.0):
        c = lime_contribution(lime_slopes(f, x, sd, 5000, w), x, mu, sd)
        print(f"   {w:<7}" + "".join(f"{v:12.4f}" for v in c)
              + f"{c.sum():9.4f}{total_weight(5000, w):9.1f}")
    print(f"   {'SHAP':<7}" + "".join(f"{v:12.4f}" for v in phi)
          + f"{phi.sum():9.4f}")

    print("\nD. SHAP depends on its background (same applicant, same model)")
    for name, mask in (("all groups", np.ones(len(F_tr), bool)),
                       ("group 0 only", s_tr == 0), ("group 1 only", s_tr == 1)):
        pick = np.random.RandomState(2).choice(np.where(mask)[0], 200, replace=False)
        ph, b0, _ = exact_shapley(f, x, F_tr[pick].astype(np.float64))
        print(f"   {name:<13} E[f]={b0:7.4f}  SHAP "
              + " ".join(f"{v:8.4f}" for v in ph))

    print("\nE. Does the explanation depend on the trained model? (100 applicants)")
    torch.manual_seed(999)
    random_f = black_box(make_model("mlp").double().eval())
    retrained_f = black_box(fit_scorer("mlp", F_tr, y_tr, seed=1))
    sims = {k: [] for k in ("SHAP trained vs. random weights",
                            "SHAP trained vs. retrained",
                            "LIME trained vs. random weights",
                            "LIME trained vs. retrained")}
    for k in range(100):
        xk = F_te[k].astype(np.float64)
        shap_, lime_ = {}, {}
        for tag, g in (("t", f), ("r", random_f), ("m", retrained_f)):
            shap_[tag] = exact_shapley(g, xk, B)[0]
            lime_[tag] = lime_contribution(lime_slopes(g, xk, sd, seed=k), xk, mu, sd)
        sims["SHAP trained vs. random weights"].append(cosine(shap_["t"], shap_["r"]))
        sims["SHAP trained vs. retrained"].append(cosine(shap_["t"], shap_["m"]))
        sims["LIME trained vs. random weights"].append(cosine(lime_["t"], lime_["r"]))
        sims["LIME trained vs. retrained"].append(cosine(lime_["t"], lime_["m"]))
    for k, v in sims.items():
        print(f"   {k:<33} mean cosine {np.mean(v):6.3f}  (sd {np.std(v):.3f})")

    print("\nF. Faithfulness: delete one feature (set it to its background mean)")
    drop = {k: [] for k in ("SHAP top-ranked", "LIME top-ranked", "random feature",
                            "SHAP bottom-ranked", "LIME bottom-ranked",
                            "best possible pick")}
    for k in range(200):
        xk = F_te[k].astype(np.float64)
        ph = exact_shapley(f, xk, B)[0]
        c = lime_contribution(lime_slopes(f, xk, sd, seed=k), xk, mu, sd)
        change = np.zeros(4)
        for j in range(4):
            x_del = xk.copy(); x_del[j] = mu[j]
            change[j] = abs(f(x_del[None])[0] - f(xk[None])[0])
        drop["SHAP top-ranked"].append(change[np.argmax(np.abs(ph))])
        drop["LIME top-ranked"].append(change[np.argmax(np.abs(c))])
        drop["random feature"].append(change.mean())
        drop["SHAP bottom-ranked"].append(change[np.argmin(np.abs(ph))])
        drop["LIME bottom-ranked"].append(change[np.argmin(np.abs(c))])
        drop["best possible pick"].append(change.max())
    print("   mean |change in log-odds| over 200 applicants:")
    for k, v in drop.items():
        print(f"     {k:<20}{np.mean(v):8.4f}")
