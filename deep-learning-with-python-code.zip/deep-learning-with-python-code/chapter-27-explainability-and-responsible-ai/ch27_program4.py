# ch27_program4.py
# Fairness and disparate impact: does leaving a sensitive attribute OUT of
# training make a classifier fair? This program builds a synthetic dataset
# where that intuition -- "fairness through unawareness" -- is put to a
# direct, measured test. Two groups share exactly the same distribution of
# TRUE qualification, so a perfectly fair classifier would treat them
# identically. But the feature actually available for training is a noisy,
# group-dependent PROXY for true qualification (think: a historically biased
# assessment score), and the sensitive group label itself is withheld from
# the model entirely. The question is whether that omission is enough.

import numpy as np
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split

np.random.seed(0)
torch.manual_seed(0)


def make_dataset(n_per_group=2000):
    """Returns X (observed feature, what the model is trained on), Y (true
    qualification label), S (sensitive group, withheld from training), and Q
    (true qualification score, for diagnostics only)."""
    Q0 = np.random.normal(0.0, 1.0, size=n_per_group)
    Q1 = np.random.normal(0.0, 1.0, size=n_per_group)   # same distribution as group 0
    Q = np.concatenate([Q0, Q1])
    S = np.concatenate([np.zeros(n_per_group), np.ones(n_per_group)]).astype(np.int64)

    Y = (Q > 0).astype(np.int64)   # ground truth: qualified iff true score exceeds 0

    # X is what actually gets measured and handed to the model: a noisy proxy
    # for Q that is biased LOW and made noisier specifically for group 1.
    noise0 = np.random.normal(0.0, 0.5, size=n_per_group)
    noise1 = np.random.normal(-0.6, 1.0, size=n_per_group)
    noise = np.concatenate([noise0, noise1])
    X = (Q + noise).astype(np.float32)

    perm = np.random.permutation(len(Q))
    return X[perm], Y[perm], S[perm], Q[perm]


class LogisticClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        return self.linear(x).squeeze(-1)


def train_classifier(X_train, y_train, epochs=300, lr=0.1):
    model = LogisticClassifier()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()
    X_t = torch.from_numpy(X_train).unsqueeze(-1)
    y_t = torch.from_numpy(y_train.astype(np.float32))
    for epoch in range(epochs):
        logits = model(X_t)
        loss = loss_fn(logits, y_t)
        optimizer.zero_grad(); loss.backward(); optimizer.step()
    return model


def predict(model, X):
    with torch.no_grad():
        logits = model(torch.from_numpy(X).unsqueeze(-1))
        return (torch.sigmoid(logits) > 0.5).numpy().astype(np.int64)


def group_metrics(pred, y, s, group):
    mask = (s == group)
    y_g, pred_g = y[mask], pred[mask]
    acc = (pred_g == y_g).mean()
    pos_rate = pred_g.mean()
    pos_mask, neg_mask = (y_g == 1), (y_g == 0)
    tpr = pred_g[pos_mask].mean() if pos_mask.any() else float("nan")
    fpr = pred_g[neg_mask].mean() if neg_mask.any() else float("nan")
    return acc, pos_rate, tpr, fpr


if __name__ == "__main__":
    X, Y, S, Q = make_dataset(n_per_group=2000)
    (X_train, X_test, y_train, y_test, s_train, s_test,
     Q_train, Q_test) = train_test_split(
        X, Y, S, Q, test_size=0.25, random_state=0, stratify=S)

    print(f"Dataset: {len(X_train)} train / {len(X_test)} test examples, balanced across 2 groups.")
    print(f"True qualification Q is drawn from the SAME distribution for both groups by construction")
    print(f"(group 0 mean Q={Q[S==0].mean():.4f}, group 1 mean Q={Q[S==1].mean():.4f}) -- any disparity")
    print(f"measured below is not because one group is really less qualified.")
    print(f"\nObserved feature X (what the model actually sees) is a biased proxy for Q:")
    print(f"  group 0: mean X={X[S==0].mean():.4f}, std X={X[S==0].std():.4f}")
    print(f"  group 1: mean X={X[S==1].mean():.4f}, std X={X[S==1].std():.4f}")

    print(f"\nTraining a logistic classifier on X alone. The sensitive attribute S is NOT one of its")
    print(f"inputs -- this is 'fairness through unawareness'.")
    model = train_classifier(X_train, y_train, epochs=300)
    pred_test = predict(model, X_test)

    overall_acc = (pred_test == y_test).mean()
    print(f"\nOverall test accuracy: {overall_acc:.4f}")

    acc0, pos0, tpr0, fpr0 = group_metrics(pred_test, y_test, s_test, 0)
    acc1, pos1, tpr1, fpr1 = group_metrics(pred_test, y_test, s_test, 1)

    print(f"\nGroup 0 (less-biased measurement): accuracy={acc0:.4f}  P(pred=1)={pos0:.4f}  "
          f"TPR={tpr0:.4f}  FPR={fpr0:.4f}")
    print(f"Group 1 (more-biased measurement): accuracy={acc1:.4f}  P(pred=1)={pos1:.4f}  "
          f"TPR={tpr1:.4f}  FPR={fpr1:.4f}")

    dp_gap = abs(pos0 - pos1)
    tpr_gap = abs(tpr0 - tpr1)
    fpr_gap = abs(fpr0 - fpr1)
    print(f"\nDemographic parity gap  |P(pred=1|group=0) - P(pred=1|group=1)|: {dp_gap:.4f}")
    print(f"Equalized-odds TPR gap  |TPR_0 - TPR_1|:                          {tpr_gap:.4f}")
    print(f"Equalized-odds FPR gap  |FPR_0 - FPR_1|:                          {fpr_gap:.4f}")

    print(f"\nFor comparison, an 'oracle' classifier trained directly on the TRUE qualification Q")
    print(f"(never actually available in practice, shown here only to isolate the effect of the")
    print(f"biased measurement) would remove the group-dependent noise entirely:")
    oracle_model = train_classifier(Q_train.astype(np.float32), y_train, epochs=300)
    oracle_pred = predict(oracle_model, Q_test.astype(np.float32))

    oracle_acc = (oracle_pred == y_test).mean()
    o_acc0, o_pos0, o_tpr0, o_fpr0 = group_metrics(oracle_pred, y_test, s_test, 0)
    o_acc1, o_pos1, o_tpr1, o_fpr1 = group_metrics(oracle_pred, y_test, s_test, 1)
    o_dp_gap = abs(o_pos0 - o_pos1)
    o_tpr_gap = abs(o_tpr0 - o_tpr1)

    print(f"  oracle overall accuracy: {oracle_acc:.4f}")
    print(f"  oracle group 0: accuracy={o_acc0:.4f}  P(pred=1)={o_pos0:.4f}  TPR={o_tpr0:.4f}  FPR={o_fpr0:.4f}")
    print(f"  oracle group 1: accuracy={o_acc1:.4f}  P(pred=1)={o_pos1:.4f}  TPR={o_tpr1:.4f}  FPR={o_fpr1:.4f}")
    print(f"  oracle demographic parity gap: {o_dp_gap:.4f}   oracle equalized-odds TPR gap: {o_tpr_gap:.4f}")

    print(f"\nExcluding the sensitive attribute S from training did not, by itself, make the two")
    print(f"groups' outcomes similar: the biased-measurement classifier's demographic parity gap")
    print(f"({dp_gap:.4f}) and TPR gap ({tpr_gap:.4f}) are both far larger than the oracle's")
    print(f"({o_dp_gap:.4f} and {o_tpr_gap:.4f}), even though S was never a model input in either")
    print(f"case and both groups have IDENTICAL true-qualification distributions. The disparity comes")
    print(f"entirely from X being a worse, group-correlated stand-in for Q in group 1 -- 'fairness")
    print(f"through unawareness' fails whenever the attribute you dropped is still predictable from")
    print(f"the attributes you kept.")
