# Appendix C · PyTorch Reference

Companion file for Appendix C of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Appendix B](../appendix-b-numpy-reference/README.md) · [Appendix D →](../appendix-d-tensorflow-keras-reference/README.md)

Every code listing in Appendix C comes from one file, [`appC_snippets.py`](appC_snippets.py), in the order the appendix prints them, and every output listing in the appendix comes from running it. Its complete output is in [`expected_output/appC_snippets.txt`](expected_output/appC_snippets.txt). Runtime: 3 s on a 2-core CPU.

```bash
cd appendix-c-pytorch-reference
python appC_snippets.py
```

The notebook [`appC_notebook.ipynb`](appC_notebook.ipynb) runs the same file in Jupyter or Google Colab.

## Listings in this file

| Listing | What it shows |
|:--|:--|
| Listing C.1 | Creating tensors and checking their dtype and shape |
| Listing C.3 | A two-parameter model, one `backward()` call, both gradients |
| Listing C.5 | Instantiating four layers and counting their parameters |
| Listing C.7 | Three of this book's four losses, on small hand-checkable inputs |
| Listing C.9 | The training loop skeleton: fit y = 2x + 1 with a single linear layer |
| Listing C.11 | Saving and reloading a model's state_dict |
| Listing C.13 | Global average pooling, done the way Chapter 27's SmallCNN does it |
| Listing C.15 | The standard (if unused-in-this-book) device-placement pattern |
| Listing C.17 | Gradients accumulate across `backward()` calls unless explicitly cleared |
| Listing C.19 | The same BatchNorm layer, same input, different mode — different output |

## Libraries used

PyTorch.

## Notes

- Running the file saves `appC_demo_model.pt` in this folder (Listing C.11). The device listing prints `cuda` instead of `cpu` on a computer with an NVIDIA GPU, such as a Colab GPU runtime.
