# Appendix C companion file: every snippet quoted in "PyTorch Reference"
# lives here, in the order it appears in the appendix, so the whole
# file can be run top to bottom to reproduce every captured output.

import torch
import torch.nn as nn

print("=== C.1 creating tensors and dtypes ===")
t1 = torch.tensor([1.0, 2.0, 3.0])
t2 = torch.tensor([1, 2, 3])
t3 = torch.zeros(2, 3)
t4 = torch.arange(0, 10, 2)
print(t1.dtype, t2.dtype)
print(t3)
print(t4)
print(t1.shape, t1.numel())

print("=== C.2 autograd: requires_grad, backward, grad ===")
w = torch.tensor(2.0, requires_grad=True)
b = torch.tensor(-1.0, requires_grad=True)
x = torch.tensor(3.0)
y = torch.tensor(10.0)

y_hat = w * x + b
loss = (y_hat - y) ** 2
loss.backward()
print(f"y_hat={y_hat.item()}, loss={loss.item()}")
print(f"w.grad={w.grad.item()}, b.grad={b.grad.item()}")

print("=== C.3 the nn.Module layer zoo ===")
torch.manual_seed(0)
linear = nn.Linear(4, 2)
conv = nn.Conv2d(1, 8, kernel_size=3)
lstm = nn.LSTM(input_size=4, hidden_size=8, batch_first=True)
seq = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Linear(8, 2))
print(sum(p.numel() for p in linear.parameters()))
print(sum(p.numel() for p in conv.parameters()))
print(sum(p.numel() for p in lstm.parameters()))
print(seq)

print("=== C.4 loss functions ===")
mse = nn.MSELoss()
ce = nn.CrossEntropyLoss()
bce_logits = nn.BCEWithLogitsLoss()

pred = torch.tensor([0.0, 2.0, -1.0])
target_reg = torch.tensor([0.5, 1.5, 0.0])
print(round(mse(pred, target_reg).item(), 4))

logits = torch.tensor([[2.0, 0.5, 0.1]])
target_cls = torch.tensor([0])
print(round(ce(logits, target_cls).item(), 4))

logit = torch.tensor([3.0])
target_bin = torch.tensor([1.0])
print(round(bce_logits(logit, target_bin).item(), 4))

print("=== C.5 optimizers and the training loop ===")
torch.manual_seed(0)
X = torch.tensor([[0.0], [1.0], [2.0], [3.0]])
Y = torch.tensor([[1.0], [3.0], [5.0], [7.0]])

model = nn.Linear(1, 1)
loss_fn = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.1)

for epoch in range(1, 201):
    optimizer.zero_grad()
    pred = model(X)
    loss = loss_fn(pred, Y)
    loss.backward()
    optimizer.step()
    if epoch in [1, 50, 100, 200]:
        print(f"epoch {epoch:>3}: loss = {loss.item():.4f}")

print("learned weight:", round(model.weight.item(), 4), "learned bias:", round(model.bias.item(), 4))

print("=== C.6 saving and loading models ===")
torch.save(model.state_dict(), "appC_demo_model.pt")
model2 = nn.Linear(1, 1)
model2.load_state_dict(torch.load("appC_demo_model.pt"))
print(round(model2.weight.item(), 4), round(model2.bias.item(), 4))

print("=== C.7 mechanism-first: global average pooling via .mean() ===")
a2 = torch.randn(2, 16, 4, 4)
pooled = a2.mean(dim=(2, 3))
print(pooled.shape)

print("=== C.8 device placement ===")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
xd = torch.tensor([1.0, 2.0])
xd = xd.to(device)
print(xd.device)

print("=== C.9 mistake: forgetting zero_grad ===")
wg = torch.tensor(5.0, requires_grad=True)
loss1 = (wg - 3) ** 2
loss1.backward()
print("grad after 1st backward:", wg.grad.item())

loss2 = (wg - 3) ** 2
loss2.backward()
print("grad after 2nd backward (no zero_grad):", wg.grad.item())

wg.grad.zero_()
loss3 = (wg - 3) ** 2
loss3.backward()
print("grad after zero_grad + 3rd backward:", wg.grad.item())

print("=== C.9 mistake: forgetting eval() with BatchNorm ===")
torch.manual_seed(0)
bn = nn.BatchNorm1d(3)
bn.train()
xb = torch.randn(4, 3)
out_train = bn(xb)

bn.eval()
out_eval = bn(xb)
print(torch.allclose(out_train, out_eval))
