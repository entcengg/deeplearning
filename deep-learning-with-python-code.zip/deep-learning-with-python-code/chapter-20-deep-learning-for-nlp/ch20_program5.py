# ch20_program5.py
# Pretraining and fine-tuning vs. training from scratch. Part A
# pretrains an embedding + Transformer-encoder backbone with a small
# masked-language-modeling (MLM) objective -- predict one randomly
# masked token from its context, exactly BERT's idea (Chapter 19's
# encoder-only family) -- on a LARGE pool of UNLABELED sentences from
# Program 3's negation-scope task. Part B then compares, at several
# LABELED training-set sizes, fine-tuning that pretrained backbone
# against training the identical architecture from scratch, with every
# other condition (data, optimizer, epochs, initial head weights) held
# fixed. The only thing that differs between the two conditions is
# whether the backbone passed through Part A's pretraining first.

import copy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

# --- Program 3's negation-scope task, reproduced here unchanged ---------
pos_words = ["good", "great", "nice", "wonderful"]
neg_words = ["bad", "terrible", "awful", "poor"]
sentiment_words = pos_words + neg_words

vocab = {"not": 0, "but": 1}
for w in sentiment_words:
    vocab[w] = len(vocab)
polarity = {w: 1 for w in pos_words}
polarity.update({w: 0 for w in neg_words})
VOCAB_SIZE = len(vocab)        # 10 real tokens
MASK_ID = VOCAB_SIZE           # 1 extra id reserved for <mask>
VOCAB_SIZE_MLM = VOCAB_SIZE + 1
D_MODEL = 16
SEQ_LEN = 4


def make_example(rng):
    A = sentiment_words[rng.integers(0, 8)]
    B = sentiment_words[rng.integers(0, 8)]
    if rng.integers(0, 2) == 0:
        tokens = ["not", A, "but", B]
        label = polarity[B]
    else:
        tokens = [A, "but", "not", B]
        label = 1 - polarity[B]
    return [vocab[t] for t in tokens], label


def make_labeled_batch(n, rng):
    X, y = [], []
    for _ in range(n):
        ids, label = make_example(rng)
        X.append(ids)
        y.append(label)
    return torch.tensor(X), torch.tensor(y, dtype=torch.float32)


def make_unlabeled_mlm_batch(n, rng):
    """n sentences from the SAME distribution, labels discarded -- this
    is the "cheap to collect" pool a real pretraining stage draws on.
    One random position per sentence is masked; the target is the
    ORIGINAL token id that sat there."""
    X = np.zeros((n, SEQ_LEN), dtype=np.int64)
    for i in range(n):
        ids, _ = make_example(rng)
        X[i] = ids
    mask_pos = rng.integers(0, SEQ_LEN, size=n)
    targets = X[np.arange(n), mask_pos].copy()
    X_masked = X.copy()
    X_masked[np.arange(n), mask_pos] = MASK_ID
    return torch.tensor(X_masked), torch.tensor(targets, dtype=torch.long), mask_pos


def positional_encoding(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe.astype(np.float32)


class Backbone(nn.Module):
    """Embedding + positional encoding + one Transformer encoder layer
    (Chapter 19) -- shared between MLM pretraining and the eventual
    sentiment classifier."""

    def __init__(self, vocab_size=VOCAB_SIZE_MLM, d_model=D_MODEL, max_len=SEQ_LEN):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.register_buffer("pe", torch.tensor(positional_encoding(max_len, d_model)))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=2, dim_feedforward=32,
                                            dropout=0.0, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=1)

    def forward(self, x):
        T = x.shape[1]
        e = self.embed(x) + self.pe[:T]
        return self.encoder(e)   # (batch, T, d_model)


class MLMHead(nn.Module):
    def __init__(self, d_model=D_MODEL, vocab_size=VOCAB_SIZE_MLM):
        super().__init__()
        self.proj = nn.Linear(d_model, vocab_size)

    def forward(self, h):
        return self.proj(h)


class ClassifierHead(nn.Module):
    def __init__(self, d_model=D_MODEL):
        super().__init__()
        self.proj = nn.Linear(d_model, 1)

    def forward(self, h):
        return self.proj(h.mean(dim=1)).squeeze(-1)


# ---------------------------------------------------------------
# Part A: pretrain the backbone with masked-language-modeling on 4000
# UNLABELED sentences -- no sentiment label is ever used here.
# ---------------------------------------------------------------
torch.manual_seed(0)
backbone = Backbone()
initial_backbone_state = copy.deepcopy(backbone.state_dict())   # pristine, pre-pretraining init
mlm_head = MLMHead()
opt = optim.Adam(list(backbone.parameters()) + list(mlm_head.parameters()), lr=0.01)

X_unlab, y_unlab, pos_unlab = make_unlabeled_mlm_batch(4000, np.random.default_rng(7))
pos_unlab_t = torch.tensor(pos_unlab)

print("Part A: pretraining on 4000 UNLABELED sentences (masked-token prediction)")
print(f"{'epoch':>7}{'mlm_loss':>12}{'mlm_token_acc':>16}")
for epoch in range(1, 151):
    opt.zero_grad()
    h = backbone(X_unlab)
    h_at_mask = h[torch.arange(len(X_unlab)), pos_unlab_t]
    logits = mlm_head(h_at_mask)
    loss = F.cross_entropy(logits, y_unlab)
    loss.backward()
    opt.step()
    if epoch in {1, 25, 50, 100, 150}:
        with torch.no_grad():
            acc = (logits.argmax(dim=1) == y_unlab).float().mean().item()
        print(f"{epoch:7d}{loss.item():12.4f}{acc:16.4f}")

# ---------------------------------------------------------------
# Part B: at several LABELED-set sizes, compare fine-tuning the
# pretrained backbone against training an identically-initialized
# backbone from scratch -- same labeled data, same epochs, same
# optimizer, same initial classifier-head weights at each size, every
# time. The ONLY difference is whether Part A happened first.
# ---------------------------------------------------------------
def train_classifier(start_state, n_label, data_seed, head_seed, epochs=150, lr=0.01):
    bb = Backbone()
    bb.load_state_dict(start_state)
    torch.manual_seed(head_seed)
    head = ClassifierHead()
    opt = optim.Adam(list(bb.parameters()) + list(head.parameters()), lr=lr)
    X_train, y_train = make_labeled_batch(n_label, np.random.default_rng(data_seed))
    for _ in range(epochs):
        opt.zero_grad()
        pred = head(bb(X_train))
        loss = F.binary_cross_entropy_with_logits(pred, y_train)
        loss.backward()
        opt.step()
    return bb, head


def test_accuracy(bb, head, test_seed):
    X_test, y_test = make_labeled_batch(500, np.random.default_rng(test_seed))
    with torch.no_grad():
        pred = torch.sigmoid(head(bb(X_test)))
        return ((pred > 0.5).float() == y_test).float().mean().item()


pretrained_state = copy.deepcopy(backbone.state_dict())
sizes = [20, 40, 100, 400, 1000]
scratch_accs, finetuned_accs = [], []

print("\nPart B: fine-tuned (pretrained) vs. trained-from-scratch sentiment classifier")
print(f"{'n_labeled':>10}{'scratch_acc':>14}{'finetuned_acc':>16}{'gap':>9}")
for n in sizes:
    data_seed, test_seed, head_seed = 1000 + n, 2000 + n, 3000 + n
    bb_s, head_s = train_classifier(initial_backbone_state, n, data_seed, head_seed)
    acc_scratch = test_accuracy(bb_s, head_s, test_seed)

    bb_f, head_f = train_classifier(pretrained_state, n, data_seed, head_seed)
    acc_finetuned = test_accuracy(bb_f, head_f, test_seed)

    scratch_accs.append(acc_scratch)
    finetuned_accs.append(acc_finetuned)
    print(f"{n:10d}{acc_scratch:14.4f}{acc_finetuned:16.4f}{acc_finetuned - acc_scratch:9.4f}")
