# ch20_program2.py
# Word embeddings: a lookup table E of shape (vocab_size, embed_dim),
# where row i is word i's dense vector. Looking up a token is just
# selecting a row -- and because of that, backpropagating through an
# embedding layer only ever updates the rows of E that were actually
# looked up in this batch. A word that appears twice in the batch gets
# its row's gradient counted twice (accumulated); a word that never
# appears gets a gradient of exactly zero.

import numpy as np
import torch
import torch.nn as nn

vocab = ["<pad>", "cat", "dog", "fish", "bird"]
embed_dim = 3

E = np.array([[0.0, 0.0, 0.0],    # <pad>  (index 0)
              [1.0, 0.0, 1.0],    # cat    (index 1)
              [0.0, 1.0, 1.0],    # dog    (index 2)
              [1.0, 1.0, 0.0],    # fish   (index 3)
              [2.0, 0.0, 1.0]])   # bird   (index 4)

token_ids = [1, 2, 1]   # "cat dog cat" -- cat (index 1) appears TWICE
print(f"Sentence: {[vocab[i] for i in token_ids]}  (token ids {token_ids})")

print("\nNumPy, by hand:")
looked_up = E[token_ids]
print(f"  looked-up embeddings =\n{looked_up}")
loss = looked_up.sum()
print(f"  loss = sum of all looked-up entries = {loss:.4f}")

# d(loss)/d(looked_up) is all ones (derivative of a sum), so each
# position sends a gradient of (1,1,1) straight back to whichever row
# of E it came from -- and those contributions ADD UP when a row is
# looked up more than once.
grad_E = np.zeros_like(E)
for pos, idx in enumerate(token_ids):
    grad_E[idx] += np.ones(embed_dim)
print(f"  hand-computed dL/dE =\n{grad_E}")
print(f"  row 'cat' (index 1) received the sum of 2 contributions: {grad_E[1]}")
print(f"  row 'bird' (index 4) was never looked up: {grad_E[4]}")

print("\nPyTorch, nn.Embedding + autograd:")
embedding = nn.Embedding(len(vocab), embed_dim)
with torch.no_grad():
    embedding.weight.copy_(torch.tensor(E, dtype=torch.float32))

ids_t = torch.tensor(token_ids)
out = embedding(ids_t)
loss_t = out.sum()
loss_t.backward()

print(f"  looked-up embeddings =\n{out.detach().numpy()}")
print(f"  loss = {loss_t.item():.4f}")
print(f"  embedding.weight.grad =\n{embedding.weight.grad.numpy()}")
print(f"  matches hand computation? {np.allclose(embedding.weight.grad.numpy(), grad_E)}")
