# ch20_program3.py
# The payoff: a sentiment task that genuinely needs word order, not
# just word presence. "not GOOD but BAD" and "GOOD but not BAD" contain
# the exact same four words -- only their order differs -- yet "not"
# negates a DIFFERENT word in each, so the two sentences have OPPOSITE
# overall sentiment. Part A compares a bag-of-embeddings classifier
# (mean-pool the raw embeddings, no order information at all) against
# a Transformer classifier (Chapter 19's encoder block, with positional
# encoding) on this task. Part B makes the mechanism visible: it feeds
# both trained models the exact same four words in both orders and
# checks whether each model can tell the two sentences apart at all.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

pos_words = ["good", "great", "nice", "wonderful"]
neg_words = ["bad", "terrible", "awful", "poor"]
sentiment_words = pos_words + neg_words

vocab = {"not": 0, "but": 1}
for w in sentiment_words:
    vocab[w] = len(vocab)
polarity = {w: 1 for w in pos_words}
polarity.update({w: 0 for w in neg_words})
vocab_size = len(vocab)
d_model = 16


def make_example(rng):
    """Two templates share the SAME four words {not, but, A, B} in a
    different order. Template 0 leaves B un-negated (label=polarity of
    B); template 1 negates B (label = the OPPOSITE of B's polarity).
    A never affects the label -- it is there purely as a distractor."""
    A = sentiment_words[rng.integers(0, 8)]
    B = sentiment_words[rng.integers(0, 8)]
    if rng.integers(0, 2) == 0:
        tokens = ["not", A, "but", B]
        label = polarity[B]
    else:
        tokens = [A, "but", "not", B]
        label = 1 - polarity[B]
    return [vocab[t] for t in tokens], label


def make_batch(n, rng):
    X, y = [], []
    for _ in range(n):
        ids, label = make_example(rng)
        X.append(ids)
        y.append(label)
    return torch.tensor(X), torch.tensor(y, dtype=torch.float32)


class BagOfEmbeddings(nn.Module):
    """Embed each token, mean-pool over the sequence, classify. No
    positional encoding, no attention -- pooling order never matters."""

    def __init__(self):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        pooled = self.embed(x).mean(dim=1)
        return self.head(pooled).squeeze(-1)


def positional_encoding(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe.astype(np.float32)


class TransformerClassifier(nn.Module):
    """Embed, add positional encoding, run one Chapter 19 encoder block
    (Program 3 already verified nn.TransformerEncoderLayer matches a
    from-scratch block exactly, so it is used directly here), then
    mean-pool and classify."""

    def __init__(self):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.register_buffer("pe", torch.tensor(positional_encoding(10, d_model)))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=2, dim_feedforward=32,
                                            dropout=0.0, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=1)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        T = x.shape[1]
        e = self.embed(x) + self.pe[:T]
        pooled = self.encoder(e).mean(dim=1)
        return self.head(pooled).squeeze(-1)


def train_model(model_fn, epochs=300, lr=0.01, seed=0):
    torch.manual_seed(seed)
    model = model_fn()
    opt = optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()
    X_train, y_train = make_batch(2000, np.random.default_rng(1))
    for _ in range(epochs):
        opt.zero_grad()
        loss = loss_fn(model(X_train), y_train)
        loss.backward()
        opt.step()
    return model


def test_accuracy(model, test_rng):
    X_test, y_test = make_batch(500, test_rng)
    with torch.no_grad():
        pred = torch.sigmoid(model(X_test))
        return ((pred > 0.5).float() == y_test).float().mean().item()


# ---------------------------------------------------------------
# Part A: test accuracy, bag-of-embeddings vs Transformer classifier.
# ---------------------------------------------------------------
print("Part A: test accuracy on the negation-scope sentiment task")
bow_model = train_model(BagOfEmbeddings)
bow_acc = test_accuracy(bow_model, np.random.default_rng(999))
print(f"  bag-of-embeddings   test accuracy = {bow_acc:.4f}")

tf_model = train_model(TransformerClassifier)
tf_acc = test_accuracy(tf_model, np.random.default_rng(999))
print(f"  Transformer classifier test accuracy = {tf_acc:.4f}")

# ---------------------------------------------------------------
# Part B: the exact same four words, in both orders. Bag-of-embeddings
# pools a SUM/mean over the same set of vectors regardless of order,
# so it is mathematically forced to give an identical prediction to
# both -- while the true labels are always opposite by construction.
# ---------------------------------------------------------------
A, B = "great", "bad"
sentence1 = ["not", A, "but", B]                # "not great but bad"
sentence2 = [A, "but", "not", B]                # "great but not bad"
label1, label2 = polarity[B], 1 - polarity[B]
ids1 = torch.tensor([[vocab[t] for t in sentence1]])
ids2 = torch.tensor([[vocab[t] for t in sentence2]])

print(f"\nPart B: the same four words, reordered")
print(f"  sentence 1: {' '.join(sentence1)!r}  (true label: positive={bool(label1)})")
print(f"  sentence 2: {' '.join(sentence2)!r}  (true label: positive={bool(label2)})")

with torch.no_grad():
    p1_bow, p2_bow = torch.sigmoid(bow_model(ids1)).item(), torch.sigmoid(bow_model(ids2)).item()
    p1_tf, p2_tf = torch.sigmoid(tf_model(ids1)).item(), torch.sigmoid(tf_model(ids2)).item()

print(f"  bag-of-embeddings:      P(positive|sent1)={p1_bow:.6f}  "
      f"P(positive|sent2)={p2_bow:.6f}  difference={abs(p1_bow - p2_bow):.8f}")
print(f"  Transformer classifier: P(positive|sent1)={p1_tf:.6f}  "
      f"P(positive|sent2)={p2_tf:.6f}  difference={abs(p1_tf - p2_tf):.8f}")
