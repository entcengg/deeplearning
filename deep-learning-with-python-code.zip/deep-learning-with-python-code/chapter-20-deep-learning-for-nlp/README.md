# Chapter 20 · Deep Learning for NLP

Code for Chapter 20 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 19](../chapter-19-transformers/README.md) · [Chapter 21 →](../chapter-21-autoencoders-and-variational-autoencoders/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 20.1.1 Program 1: Tokenize, Encode, Pad, Mask | A complete tokenize-encode-pad-mask pipeline | [`ch20_program1.py`](ch20_program1.py) | [ch20_program1.txt](expected_output/ch20_program1.txt) | < 1 s |
| 2 | 20.2.1 Program 2: Embedding Lookup and Its Gradient, by Hand | Embedding lookup and its gradient, verified against `nn.Embedding` | [`ch20_program2.py`](ch20_program2.py) | [ch20_program2.txt](expected_output/ch20_program2.txt) | 2 s |
| 3 | 20.4.1 Program 3: Bag-of-Embeddings vs. Transformer Classifier | Bag-of-embeddings vs. Transformer classifier on a task that needs word order | [`ch20_program3.py`](ch20_program3.py) | [ch20_program3.txt](expected_output/ch20_program3.txt) | 9 s |
| 4 | 20.5.1 Program 4: Byte-Pair Encoding from Scratch | Byte-Pair Encoding, learned from a small corpus and applied to unseen words | [`ch20_program4.py`](ch20_program4.py) | [ch20_program4.txt](expected_output/ch20_program4.txt) | < 1 s |
| 5 | 20.6.1 Program 5: Pretraining and Fine-Tuning vs. Training From Scratch | Pretraining a backbone with masked-token prediction, then fine-tuning it vs. training the same architecture from scratch, across several labeled-set sizes | [`ch20_program5.py`](ch20_program5.py) | [ch20_program5.txt](expected_output/ch20_program5.txt) | 15 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-20-deep-learning-for-nlp
python ch20_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch20_notebook.ipynb`](ch20_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, PyTorch.
