# ch20_program1.py
# From raw text to tensors: tokenize a toy corpus, build a vocabulary
# (with special <pad> and <unk> tokens), encode each sentence as a
# sequence of integer IDs, pad every sequence to the same length, and
# build the padding mask that tells later layers which positions are
# real tokens and which are just padding.

corpus = [
    "the food was great",
    "the service was bad",
    "the staff were kind and helpful",
    "great food",
]

PAD, UNK = "<pad>", "<unk>"


def tokenize(sentence):
    return sentence.lower().split()


def build_vocab(sentences):
    vocab = {PAD: 0, UNK: 1}
    for sentence in sentences:
        for token in tokenize(sentence):
            if token not in vocab:
                vocab[token] = len(vocab)
    return vocab


def encode(sentence, vocab):
    return [vocab.get(token, vocab[UNK]) for token in tokenize(sentence)]


def pad_batch(sequences, pad_id):
    max_len = max(len(seq) for seq in sequences)
    padded, mask = [], []
    for seq in sequences:
        n_pad = max_len - len(seq)
        padded.append(seq + [pad_id] * n_pad)
        mask.append([1] * len(seq) + [0] * n_pad)
    return padded, mask


vocab = build_vocab(corpus)
print(f"Vocabulary ({len(vocab)} tokens):")
print(f"  {vocab}")

encoded = [encode(sentence, vocab) for sentence in corpus]
print("\nTokenized and encoded (before padding):")
for sentence, ids in zip(corpus, encoded):
    print(f"  {sentence!r:38s} -> {ids}")

padded, mask = pad_batch(encoded, vocab[PAD])
print("\nPadded to a common length, with mask (1 = real token, 0 = padding):")
for sentence, ids, m in zip(corpus, padded, mask):
    print(f"  {sentence!r:38s} -> ids={ids}  mask={m}")

# A word not seen during vocabulary building maps to <unk>, never crashes.
unseen = "the food was cold and cheap"
print(f"\nEncoding an unseen sentence: {unseen!r}")
print(f"  tokens = {tokenize(unseen)}")
print(f"  ids    = {encode(unseen, vocab)}  ({vocab[UNK]} = <unk>, for 'cold' and 'cheap')")
