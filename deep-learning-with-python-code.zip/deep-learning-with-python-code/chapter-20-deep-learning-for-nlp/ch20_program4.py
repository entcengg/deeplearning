# ch20_program4.py
# Byte-Pair Encoding (BPE) from scratch: start from individual
# characters and iteratively merge the most frequent adjacent pair,
# building a subword vocabulary bottom-up instead of Section 20.1's
# fixed whole-word one. Section 20.1 already named BPE/WordPiece in
# passing; this program actually runs the algorithm, then uses the
# result to tokenize brand-new words that never appeared during
# training -- the exact situation that forced Program 1's vocabulary
# to fall back on <unk>.

from collections import Counter

# A small toy corpus of (word, frequency) pairs -- frequency is simply
# how many times that whole word appeared in the training corpus.
word_freqs = {"low": 5, "lower": 2, "newest": 6, "widest": 3, "new": 2}

END = "</w>"  # marks a real word boundary, so e.g. "er" at the end of a
              # word is tracked separately from "er" in the middle of one


def split_into_symbols(word_freqs):
    return {tuple(list(word) + [END]): freq for word, freq in word_freqs.items()}


def get_pair_counts(word_symbols):
    pairs = Counter()
    for symbols, freq in word_symbols.items():
        for i in range(len(symbols) - 1):
            pairs[(symbols[i], symbols[i + 1])] += freq
    return pairs


def apply_merge(pair, symbols):
    merged = pair[0] + pair[1]
    new_symbols, i = [], 0
    while i < len(symbols):
        if i < len(symbols) - 1 and (symbols[i], symbols[i + 1]) == pair:
            new_symbols.append(merged)
            i += 2
        else:
            new_symbols.append(symbols[i])
            i += 1
    return new_symbols


def merge_pair_in_corpus(pair, word_symbols):
    new_word_symbols = {}
    for symbols, freq in word_symbols.items():
        new_symbols = tuple(apply_merge(pair, list(symbols)))
        new_word_symbols[new_symbols] = new_word_symbols.get(new_symbols, 0) + freq
    return new_word_symbols


word_symbols = split_into_symbols(word_freqs)
print(f"Corpus (word: frequency): {word_freqs}")
print(f"Starting symbols (every word split into characters + {END}):")
for word in word_freqs:
    print(f"  {word!r:10s} -> {tuple(list(word) + [END])}")

num_merges = 8
merge_rules = []
print(f"\nLearning {num_merges} BPE merges (always merge the single most frequent adjacent pair):")
for step in range(1, num_merges + 1):
    pairs = get_pair_counts(word_symbols)
    if not pairs:
        break
    best_pair, best_count = pairs.most_common(1)[0]
    word_symbols = merge_pair_in_corpus(best_pair, word_symbols)
    merge_rules.append(best_pair)
    print(f"  merge {step}: {best_pair} -> {best_pair[0] + best_pair[1]!r:12s} "
          f"(occurred {best_count} times)")

print("\nEach training word's final symbol sequence after all merges:")
for word in word_freqs:
    symbols = list(word) + [END]
    for pair in merge_rules:
        symbols = apply_merge(pair, symbols)
    print(f"  {word!r:10s} -> {symbols}")


def bpe_tokenize(word, merge_rules):
    symbols = list(word) + [END]
    for pair in merge_rules:
        symbols = apply_merge(pair, symbols)
    return symbols


# The payoff: tokenize words that never appeared ANYWHERE in training.
# Section 20.1's word-level vocabulary could only map these to <unk>,
# discarding everything about them. BPE instead falls back to whatever
# previously-learned PIECES actually apply.
print("\nTokenizing words NEVER SEEN during training, with the learned merges:")
for unseen in ["lowest", "newer", "wide", "wider"]:
    pieces = bpe_tokenize(unseen, merge_rules)
    print(f"  {unseen!r:10s} -> {pieces}")
