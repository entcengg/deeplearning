# ch22_program5.py
# Why a Wasserstein critic keeps giving the generator a useful signal when
# a standard GAN discriminator stops. Real data: 2-D points from N(0, I).
# The "generator" has one parameter, a shift delta along the first axis:
# fake = z + (delta, 0) with z ~ N(0, I). The true distances are therefore
# known exactly: W1 = delta, and the Jensen-Shannon divergence (JSD) is
# that of N(0,1) and N(delta,1), computed numerically. For each delta we
#   (a) train a standard GAN discriminator (binary cross-entropy), and
#   (b) train a WGAN-GP critic (Wasserstein loss + gradient penalty),
# then read off what each reports about the distance, and the gradient
# each hands the generator with respect to delta.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

LAMBDA, STEPS, N = 10.0, 1000, 2000


def exact_jsd(delta):
    """JSD between N(0,1) and N(delta,1), in nats, by numerical integration."""
    x = np.linspace(-12.0, 12.0 + delta, 200001)
    p = np.exp(-x ** 2 / 2) / np.sqrt(2 * np.pi)
    q = np.exp(-(x - delta) ** 2 / 2) / np.sqrt(2 * np.pi)
    m = (p + q) / 2
    return float(np.sum(p * np.log(p / m) + q * np.log(q / m)) / 2 * (x[1] - x[0]))


def small_net():
    return nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 32), nn.ReLU(),
                         nn.Linear(32, 1))


torch.manual_seed(0)
real = torch.randn(N, 2)
z = torch.randn(N, 2)
e1 = torch.tensor([1.0, 0.0])            # the direction of the shift


def train_discriminator(fake):
    D = small_net()
    opt = optim.Adam(D.parameters(), lr=0.001)
    bce = nn.BCEWithLogitsLoss()
    for _ in range(STEPS):
        opt.zero_grad()
        loss = bce(D(real), torch.ones(N, 1)) + bce(D(fake), torch.zeros(N, 1))
        loss.backward()
        opt.step()
    return D, loss.item()


def train_critic(fake):
    f = small_net()
    opt = optim.Adam(f.parameters(), lr=0.001, betas=(0.5, 0.9))
    for _ in range(STEPS):
        eps = torch.rand(N, 1)                       # random points between pairs
        x_hat = (eps * real + (1 - eps) * fake).requires_grad_(True)
        grad = torch.autograd.grad(f(x_hat).sum(), x_hat, create_graph=True)[0]
        penalty = ((grad.norm(dim=1) - 1) ** 2).mean()
        opt.zero_grad()
        loss = f(fake).mean() - f(real).mean() + LAMBDA * penalty
        loss.backward()
        opt.step()
    return f


def generator_gradient(kind, delta_value, D, f):
    """d(generator loss)/d(delta) for one of the three generator losses."""
    delta = torch.tensor(delta_value, requires_grad=True)
    out_fake = z + delta * e1
    if kind == "minimax":              # G minimizes  E log(1 - D(G(z)))
        loss = nn.functional.logsigmoid(-D(out_fake)).mean()
    elif kind == "non-saturating":     # G minimizes -E log D(G(z))
        loss = -nn.functional.logsigmoid(D(out_fake)).mean()
    else:                              # G minimizes -E f(G(z))
        loss = -f(out_fake).mean()
    loss.backward()
    return delta.grad.item()


print("JSD:  exact, and the discriminator's estimate (ln 4 - L_D) / 2")
print("W1:   exact (= delta), and the critic's estimate E f(real) - E f(fake)")
print("soft: delta + delta^2 / (2 lambda), the critic's value predicted when the")
print("      gradient penalty is a soft rather than a hard constraint")
print("dL/d(delta): gradient handed to the generator by each generator loss")
print(f"\n{'':6}{'---------- standard GAN ----------':>35}{'-------- WGAN-GP --------':>26}")
print(f"{'delta':>5} {'JSD':>6} {'D est.':>7} {'minimax':>9} {'non-sat':>8}"
      f" {'W1':>5} {'critic':>7} {'soft':>6} {'Wass.':>6}")
for delta_value in [0.5, 1.0, 2.0, 4.0, 8.0]:
    torch.manual_seed(1)
    fake = z + delta_value * e1
    D, loss_d = train_discriminator(fake)
    f = train_critic(fake)
    with torch.no_grad():
        w_est = (f(real).mean() - f(fake).mean()).item()
    g_mm, g_ns, g_w = (generator_gradient(k, delta_value, D, f)
                       for k in ["minimax", "non-saturating", "wasserstein"])
    soft = delta_value + delta_value ** 2 / (2 * LAMBDA)
    print(f"{delta_value:>5.1f} {exact_jsd(delta_value):>6.3f} {(np.log(4) - loss_d) / 2:>7.3f}"
          f" {g_mm:>9.2e} {g_ns:>8.3f} {delta_value:>5.1f} {w_est:>7.3f} {soft:>6.2f}"
          f" {g_w:>6.3f}")
print(f"\nJSD can never exceed ln 2 = {np.log(2):.3f}; W1 grows without bound.")
