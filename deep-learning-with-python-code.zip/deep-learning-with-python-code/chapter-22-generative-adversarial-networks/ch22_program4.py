# ch22_program4.py
# A conditional GAN: Program 2's networks and training recipe, except that
# the generator and the discriminator both also receive the digit's class
# as a one-hot vector. Control is MEASURED rather than eyeballed: request
# each class 200 times and ask Program 3's judge -- trained on real digits
# only -- which digit every generated image shows.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_t, y_t = torch.from_numpy(X), torch.from_numpy(y).long()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t, X_test_t = torch.from_numpy(X_train), torch.from_numpy(X_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()
NOISE_DIM, N_CLASSES, N = 16, 10, len(X)


def one_hot(labels):
    return nn.functional.one_hot(labels, N_CLASSES).float()


class CondGenerator(nn.Module):
    """G(z, y): Program 2's generator with the class appended to the noise."""
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(NOISE_DIM + N_CLASSES, 32), nn.ReLU(),
                                 nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, z, labels):
        return self.net(torch.cat([z, one_hot(labels)], dim=1))


class CondDiscriminator(nn.Module):
    """D(x, y): Program 2's discriminator with the class appended to the image."""
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(64 + N_CLASSES, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x, labels):
        return self.net(torch.cat([x, one_hot(labels)], dim=1))


class Judge(nn.Module):
    """Program 3's judge: trained only on REAL digits, never on generated ones."""
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))


# --- The judge, exactly as in Program 3 -----------------------------------
torch.manual_seed(1)
judge = Judge()
opt = optim.Adam(judge.parameters(), lr=0.01)
for epoch in range(100):
    opt.zero_grad()
    nn.functional.cross_entropy(judge(X_train_t), y_train_t).backward()
    opt.step()
judge.eval()
with torch.no_grad():
    acc = (judge(X_test_t).argmax(1) == y_test_t).float().mean().item()
print(f"judge test accuracy on real digits: {acc:.4f}")


def measure_control(G):
    """Request every class 200 times; return, per class, the fraction the
    judge reads as the requested digit, and the generated images. The noise
    comes from a private generator: measuring never alters training."""
    noise = torch.Generator().manual_seed(42)
    hits, images = [], []
    with torch.no_grad():
        for c in range(N_CLASSES):
            imgs = G(torch.randn(200, NOISE_DIM, generator=noise), torch.full((200,), c))
            hits.append((judge(imgs).argmax(1) == c).float().mean().item())
            images.append(imgs)
    return np.array(hits), images


# --- Train the conditional GAN (Program 2's recipe, labels added) --------
torch.manual_seed(0)
G, D = CondGenerator(), CondDiscriminator()
g_opt = optim.Adam(G.parameters(), lr=0.001, betas=(0.5, 0.999))
d_opt = optim.Adam(D.parameters(), lr=0.001, betas=(0.5, 0.999))
bce = nn.BCEWithLogitsLoss()
ones, zeros = torch.ones(N, 1), torch.zeros(N, 1)
print("\n epoch  d_loss  g_loss   judged as requested: mean  worst class")
for epoch in range(1, 2001):
    fake = G(torch.randn(N, NOISE_DIM), y_t).detach()          # one fake per real label
    d_opt.zero_grad()
    d_loss = bce(D(X_t, y_t), ones) + bce(D(fake, y_t), zeros)
    d_loss.backward()
    d_opt.step()
    g_opt.zero_grad()
    g_loss = bce(D(G(torch.randn(N, NOISE_DIM), y_t), y_t), ones)   # non-saturating
    g_loss.backward()
    g_opt.step()
    if epoch in (300, 1000, 1500, 2000):
        hits, _ = measure_control(G)
        note = "   <- Program 2's budget" if epoch == 300 else ""
        print(f"{epoch:>6}  {d_loss.item():.3f}   {g_loss.item():.3f}"
              f"                       {hits.mean():.3f}        {hits.min():.3f}{note}")

# --- Per-class report after 2000 epochs -----------------------------------
hits, images = measure_control(G)
print("\nafter 2000 epochs, 200 requests per class:")
print("requested  judged as requested  most common other answer  diversity vs. real")
ratios = []
for c in range(N_CLASSES):
    with torch.no_grad():
        votes = np.bincount(judge(images[c]).argmax(1).numpy(), minlength=N_CLASSES)
    votes[c] = -1
    other = int(np.argmax(votes))
    ratio = (torch.pdist(images[c]).mean() / torch.pdist(X_t[y_t == c]).mean()).item()
    ratios.append(ratio)
    print(f"{c:>9}  {hits[c]:>19.3f}  {other:>17d} ({votes[other] / 200:.3f})"
          f"  {ratio:>17.3f}")
print(f"\nmean: judged as requested {hits.mean():.3f} (chance 0.100); "
      f"diversity ratio {np.mean(ratios):.3f}")
print("(diversity ratio = mean pairwise distance between the 200 generated images")
print(" divided by the same quantity for the real images of that class)")
