# Chapter 22 · Generative Adversarial Networks

Code for Chapter 22 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 21](../chapter-21-autoencoders-and-variational-autoencoders/README.md) · [Chapter 23 →](../chapter-23-diffusion-models/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 22.1.1 Program 1: The Two Networks, and Why the Generator's Loss Is Not What the Minimax Game Suggests | The generator and discriminator architectures, one forward pass before training, and the saturating-vs. non-saturating generator-loss gradient proof | [`ch22_program1.py`](ch22_program1.py) | [ch22_program1.txt](expected_output/ch22_program1.txt) | 3 s |
| 2 | 22.2.1 Program 2: Training a GAN on Digit Images | Training a GAN on the digits dataset with alternating discriminator/generator updates | [`ch22_program2.py`](ch22_program2.py) | [ch22_program2.txt](expected_output/ch22_program2.txt) | 6 s |
| 3 | 22.4.1 Program 3: Measuring Realism and Diversity Directly | GAN vs. VAE: judge-classifier confidence and predicted-class diversity, plus a demonstration of why diversity must be measured directly | [`ch22_program3.py`](ch22_program3.py) | [ch22_program3.txt](expected_output/ch22_program3.txt) | 8 s |
| 4 | 22.5.1 Program 4: A Conditional GAN, and Measuring How Well It Obeys | A conditional GAN on the digits, with control measured per class by Program 3's judge | [`ch22_program4.py`](ch22_program4.py) | [ch22_program4.txt](expected_output/ch22_program4.txt) | 15 s |
| 5 | 22.6.1 Program 5: What a Discriminator and a Critic Report as the Distributions Separate | A standard GAN discriminator and a WGAN-GP critic, measured against the exact Jensen–Shannon and Wasserstein distances | [`ch22_program5.py`](ch22_program5.py) | [ch22_program5.txt](expected_output/ch22_program5.txt) | 32 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-22-generative-adversarial-networks
python ch22_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch22_notebook.ipynb`](ch22_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, PyTorch.
