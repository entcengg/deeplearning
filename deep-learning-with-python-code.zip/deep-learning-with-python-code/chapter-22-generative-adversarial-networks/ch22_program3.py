# ch22_program3.py
# Capstone: train a GAN and a VAE (Chapter 21) on the same digits data,
# generate a batch of new images from each, and measure two different
# things directly: (A) how convincing the generated images look to an
# independent judge classifier that never saw either model's output
# during its own training, and (B) how DIVERSE the generated images
# are -- whether the generator explores all 10 digit shapes or has
# collapsed onto just a few, measured as the entropy of the judge's
# predicted-class histogram over many generated samples. Part C then
# shows why the diversity measurement in Part B is necessary at all:
# a VAE with a latent space too large for this data can look just as
# convincing on confidence alone while having completely collapsed.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t, X_test_t = torch.from_numpy(X_train), torch.from_numpy(X_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()
X_t = torch.from_numpy(X)
N = len(X)
NOISE_DIM = 16
N_GEN = 300  # number of images generated for the diversity/confidence measurements

class Generator(nn.Module):
    def __init__(self, noise_dim=NOISE_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(noise_dim, 32), nn.ReLU(),
            nn.Linear(32, 64), nn.Sigmoid(),
        )

    def forward(self, z):
        return self.net(z)

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        return self.net(x)

class VAE(nn.Module):
    def __init__(self, latent_dim):
        super().__init__()
        self.latent_dim = latent_dim
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, latent_dim)
        self.logvar_head = nn.Linear(32, latent_dim)
        self.decoder = nn.Sequential(nn.Linear(latent_dim, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + torch.randn_like(std) * std

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar

class Judge(nn.Module):
    """An independent classifier trained only on REAL digit images. It
    never trains on anything either generative model produces."""
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

def vae_loss(recon, x, mu, logvar):
    recon_loss = ((recon - x) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    return recon_loss, kl

def train_vae(latent_dim, seed=0):
    torch.manual_seed(seed)
    vae = VAE(latent_dim)
    opt = optim.Adam(vae.parameters(), lr=0.01)
    for epoch in range(300):
        vae.train(); opt.zero_grad()
        recon, mu, logvar = vae(X_train_t)
        recon_loss, kl = vae_loss(recon, X_train_t, mu, logvar)
        (recon_loss + kl).backward(); opt.step()
    vae.eval()
    return vae

def mean_confidence(judge, images):
    with torch.no_grad():
        probs = torch.softmax(judge(images), dim=1)
        return probs.max(dim=1).values.mean().item()

def class_entropy(judge, images, n_classes=10):
    with torch.no_grad():
        preds = judge(images).argmax(dim=1).numpy()
    counts = np.bincount(preds, minlength=n_classes).astype(np.float64)
    probs = counts / counts.sum()
    nonzero = probs[probs > 0]
    entropy = -(nonzero * np.log2(nonzero)).sum()
    n_classes_used = int((counts > 0).sum())
    return entropy, n_classes_used, counts

# --- Train the GAN (Program 2's architecture and recipe) ----------------
torch.manual_seed(0)
G = Generator()
D = Discriminator()
g_opt = optim.Adam(G.parameters(), lr=0.001, betas=(0.5, 0.999))
d_opt = optim.Adam(D.parameters(), lr=0.001, betas=(0.5, 0.999))
bce = nn.BCEWithLogitsLoss()
real_labels, fake_labels = torch.ones(N, 1), torch.zeros(N, 1)
for epoch in range(300):
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z).detach()
    d_opt.zero_grad()
    d_loss = bce(D(X_t), real_labels) + bce(D(fake_images), fake_labels)
    d_loss.backward(); d_opt.step()

    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z)
    g_opt.zero_grad()
    g_loss = bce(D(fake_images), real_labels)
    g_loss.backward(); g_opt.step()
G.eval()

# --- Train two VAEs: a healthy one (latent=4) and an oversized one (latent=16) ---
vae_healthy = train_vae(latent_dim=4, seed=0)
vae_oversized = train_vae(latent_dim=16, seed=0)

with torch.no_grad():
    mu_healthy, _ = vae_healthy.encode(torch.from_numpy(X))
    mu_oversized, _ = vae_oversized.encode(torch.from_numpy(X))
healthy_mu_std = mu_healthy.std(dim=0).mean().item()
oversized_mu_std = mu_oversized.std(dim=0).mean().item()

# --- Train the judge (real digits only) ----------------------------------
torch.manual_seed(1)
judge = Judge()
judge_opt = optim.Adam(judge.parameters(), lr=0.01)
judge_loss_fn = nn.CrossEntropyLoss()
for epoch in range(100):
    judge.train(); judge_opt.zero_grad()
    loss = judge_loss_fn(judge(X_train_t), y_train_t)
    loss.backward(); judge_opt.step()
judge.eval()
with torch.no_grad():
    judge_test_acc = (judge(X_test_t).argmax(1) == y_test_t).float().mean().item()

# --- Generate N_GEN images from each model --------------------------------
torch.manual_seed(42)
with torch.no_grad():
    gan_images = G(torch.randn(N_GEN, NOISE_DIM))
    vae_healthy_images = vae_healthy.decoder(torch.randn(N_GEN, 4))
    vae_oversized_images = vae_oversized.decoder(torch.randn(N_GEN, 16))

real_confidence = mean_confidence(judge, X_test_t)
gan_confidence = mean_confidence(judge, gan_images)
vae_h_confidence = mean_confidence(judge, vae_healthy_images)
vae_o_confidence = mean_confidence(judge, vae_oversized_images)

max_entropy = np.log2(10)
real_entropy, real_nclasses, real_counts = class_entropy(judge, X_test_t)
gan_entropy, gan_nclasses, gan_counts = class_entropy(judge, gan_images)
vae_h_entropy, vae_h_nclasses, vae_h_counts = class_entropy(judge, vae_healthy_images)
vae_o_entropy, vae_o_nclasses, vae_o_counts = class_entropy(judge, vae_oversized_images)

print(f"Judge classifier trained on real digits only (test accuracy={judge_test_acc:.4f})")
print(f"Generated {N_GEN} images each from the GAN and two VAEs (latent size 4 and 16).")
print(f"VAE(latent=4) mean encoded std per dimension:  {healthy_mu_std:.4f}")
print(f"VAE(latent=16) mean encoded std per dimension: {oversized_mu_std:.4f}  "
      f"(near zero -- posterior collapse, Chapter 21 Common Mistake 5)")

print(f"\nPart A: how convincing do the generated images look? (mean top-class confidence)")
print(f"  real test images (ceiling reference): {real_confidence:.4f}")
print(f"  GAN generated images:                 {gan_confidence:.4f}")
print(f"  VAE(latent=4) generated images:       {vae_h_confidence:.4f}")

print(f"\nPart B: how diverse are the generated images? (entropy of the judge's")
print(f"predicted-class histogram over {N_GEN} images; max possible = "
      f"log2(10) = {max_entropy:.4f} bits, i.e. all 10 digits equally represented)")
print(f"  real test images (ceiling reference): entropy={real_entropy:.4f} bits  "
      f"({real_nclasses}/10 classes seen)")
print(f"  GAN generated images:                 entropy={gan_entropy:.4f} bits  "
      f"({gan_nclasses}/10 classes seen)")
print(f"  VAE(latent=4) generated images:       entropy={vae_h_entropy:.4f} bits  "
      f"({vae_h_nclasses}/10 classes seen)")
print(f"  GAN predicted-class histogram: {gan_counts.astype(int).tolist()}")
print(f"  VAE(latent=4) predicted-class histogram: {vae_h_counts.astype(int).tolist()}")

print(f"\nPart C: does confidence alone catch a collapsed generator? Same VAE")
print(f"design, latent size 16 instead of 4 -- nothing else changed:")
print(f"  VAE(latent=16) confidence: {vae_o_confidence:.4f}  "
      f"(looks fine -- close to the GAN's {gan_confidence:.4f})")
print(f"  VAE(latent=16) entropy:    {vae_o_entropy:.4f} bits, "
      f"{vae_o_nclasses}/10 classes seen")
print(f"  VAE(latent=16) predicted-class histogram: {vae_o_counts.astype(int).tolist()}")
print(f"  Confidence alone would have called this model healthy; only the")
print(f"  diversity measurement in Part B exposes the collapse.")
