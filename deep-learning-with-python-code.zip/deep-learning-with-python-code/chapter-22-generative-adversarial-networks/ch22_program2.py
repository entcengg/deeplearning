# ch22_program2.py
# Train a GAN on the digits dataset: alternate one discriminator update
# (learn to tell real from fake) with one generator update (learn to
# fool the discriminator, using the non-saturating loss from Program 1).
# No labels are used -- the generator only ever sees random noise, and
# the discriminator only ever sees pixels.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
X_t = torch.from_numpy(X)
NOISE_DIM = 16
N = len(X)

class Generator(nn.Module):
    def __init__(self, noise_dim=NOISE_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(noise_dim, 32), nn.ReLU(),
            nn.Linear(32, 64), nn.Sigmoid(),
        )

    def forward(self, z):
        return self.net(z)

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        return self.net(x)

torch.manual_seed(0)
G = Generator()
D = Discriminator()
g_opt = torch.optim.Adam(G.parameters(), lr=0.001, betas=(0.5, 0.999))
d_opt = torch.optim.Adam(D.parameters(), lr=0.001, betas=(0.5, 0.999))
bce = nn.BCEWithLogitsLoss()

print(f"Training a GAN on {N} digit images (8x8 pixels, no labels used)...")
print(f"Generator: noise(16) -> 32 -> 64.  Discriminator: 64 -> 32 -> 1.")

checkpoints = {1, 25, 50, 100, 150, 200, 250, 300}
saved_samples = {}
real_labels = torch.ones(N, 1)
fake_labels = torch.zeros(N, 1)

for epoch in range(1, 301):
    # --- Discriminator step: tell real from fake ---
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z).detach()
    d_opt.zero_grad()
    d_loss_real = bce(D(X_t), real_labels)
    d_loss_fake = bce(D(fake_images), fake_labels)
    d_loss = d_loss_real + d_loss_fake
    d_loss.backward()
    d_opt.step()

    # --- Generator step: fool the discriminator (non-saturating loss) ---
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z)
    g_opt.zero_grad()
    g_loss = bce(D(fake_images), real_labels)  # -log(D(G(z))) via BCE with target=1
    g_loss.backward()
    g_opt.step()

    if epoch in checkpoints:
        with torch.no_grad():
            d_fake_prob = torch.sigmoid(D(fake_images)).mean().item()
            d_real_prob = torch.sigmoid(D(X_t)).mean().item()
        print(f"  epoch {epoch:>3}: d_loss={d_loss.item():.4f}  g_loss={g_loss.item():.4f}  "
              f"D(real)={d_real_prob:.4f}  D(fake)={d_fake_prob:.4f}")
        with torch.no_grad():
            torch.manual_seed(123)  # same noise every checkpoint, to watch one seed improve
            fixed_z = torch.randn(6, NOISE_DIM)
            saved_samples[epoch] = G(fixed_z).numpy().copy()

print(f"\nFinal check -- an ideal converged GAN drives both probabilities to 0.5")
print(f"(the discriminator can no longer tell real from fake better than chance).")

with torch.no_grad():
    torch.manual_seed(123)
    fixed_z = torch.randn(6, NOISE_DIM)
    final_samples = G(fixed_z).numpy()
print(f"\n6 generated images at epoch 300, pixel stats: "
      f"min={final_samples.min():.4f}  max={final_samples.max():.4f}  mean={final_samples.mean():.4f}")
print(f"Same 6 images at epoch 1 (same noise vectors), pixel stats: "
      f"min={saved_samples[1].min():.4f}  max={saved_samples[1].max():.4f}  mean={saved_samples[1].mean():.4f}")
