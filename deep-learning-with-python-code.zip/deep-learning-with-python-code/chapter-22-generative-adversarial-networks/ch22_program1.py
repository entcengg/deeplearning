# ch22_program1.py
# Set up the two networks a GAN is built from -- a generator that maps
# random noise to fake images, and a discriminator that scores an image
# as real or fake -- take one look at what they produce before any
# training, and then prove by hand (and verify with autograd) why the
# generator is trained with a "non-saturating" loss instead of the
# textbook minimax loss.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
NOISE_DIM = 16

class Generator(nn.Module):
    def __init__(self, noise_dim=NOISE_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(noise_dim, 32), nn.ReLU(),
            nn.Linear(32, 64), nn.Sigmoid(),
        )

    def forward(self, z):
        return self.net(z)

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        return self.net(x)  # raw logit; sigmoid applied where needed

torch.manual_seed(0)
G = Generator()
D = Discriminator()

print(f"Generator:  noise (dim {NOISE_DIM}) -> 32 -> 64 (Sigmoid, matches [0,1] pixel scale)")
print(f"Discriminator: 64 -> 32 -> 1 (raw logit; sigmoid gives P(real))")

# --- One forward pass before any training -------------------------------
z = torch.randn(4, NOISE_DIM)
fake_images = G(z)
print(f"\nSampled 4 noise vectors z ~ N(0,1), generated 4 fake images (untrained G).")
print(f"Fake image pixel range: [{fake_images.min().item():.4f}, {fake_images.max().item():.4f}]  "
      f"mean={fake_images.mean().item():.4f}")

real_images = torch.from_numpy(X[:4])
d_real_logits = D(real_images)
d_fake_logits = D(fake_images)
d_real_probs = torch.sigmoid(d_real_logits)
d_fake_probs = torch.sigmoid(d_fake_logits)
print(f"\nUntrained discriminator's P(real) on 4 real images:  "
      f"{[f'{p:.4f}' for p in d_real_probs.detach().flatten().tolist()]}")
print(f"Untrained discriminator's P(real) on 4 fake images:  "
      f"{[f'{p:.4f}' for p in d_fake_probs.detach().flatten().tolist()]}")

bce = nn.BCEWithLogitsLoss()
d_loss = bce(d_real_logits, torch.ones(4, 1)) + bce(d_fake_logits, torch.zeros(4, 1))
print(f"\nDiscriminator's loss on this batch (Chapter 8's binary cross-entropy,")
print(f"real images labeled 1, fake images labeled 0): {d_loss.item():.4f}")

# --- The saturating-vs-non-saturating generator loss, proved by hand ----
print(f"\n{'-'*70}")
print("Why the generator is NOT trained by minimizing log(1 - D(G(z))):")
print(f"{'-'*70}")
print("Let s be D's raw logit on a fake image, so D(G(z)) = sigma(s).")
print("  original minimax loss:   L_G  = log(1 - sigma(s))")
print("  non-saturating loss:     L_G' = -log(sigma(s))")
print("By the chain rule through the sigmoid (sigma' = sigma(1-sigma)):")
print("  dL_G/ds  = -sigma(s)")
print("  dL_G'/ds = -(1 - sigma(s))")
print()
print(f"{'D(G(z))':>10} {'s (logit)':>12} {'dL_G/ds':>12} {'dL_G_prime/ds':>16} {'|ratio|':>10}")
sigma_targets = [0.01, 0.1, 0.5, 0.9, 0.99]
for sig in sigma_targets:
    s_val = float(np.log(sig / (1 - sig)))
    s = torch.tensor([s_val], requires_grad=True)
    L_G = torch.log(1 - torch.sigmoid(s))
    L_G.backward()
    grad_orig = s.grad.item()

    s2 = torch.tensor([s_val], requires_grad=True)
    L_Gp = -torch.log(torch.sigmoid(s2))
    L_Gp.backward()
    grad_nonsat = s2.grad.item()

    ratio = abs(grad_nonsat) / abs(grad_orig)
    print(f"{sig:10.2f} {s_val:12.4f} {grad_orig:12.4f} {grad_nonsat:16.4f} {ratio:10.2f}")

print(f"\nEarly in training D easily rejects G's output, so D(G(z)) is close to 0.01.")
print(f"At that point the original loss's gradient is nearly 0 (saturated) --")
print(f"exactly when the generator most needs a strong learning signal. The")
print(f"non-saturating loss gives a gradient 99x larger in that same regime,")
print(f"and the two losses agree when D is unsure (D(G(z))=0.5). All values")
print(f"above were computed analytically and confirmed with PyTorch autograd.")
