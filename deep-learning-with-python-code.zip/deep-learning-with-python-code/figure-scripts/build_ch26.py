import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import math
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

# ============================================================================
# Shared setup (mirrors programs/ch26_program1.py through ch26_program5.py)
# ============================================================================
N = 1000
PERIOD = 50
TREND_A = 20.0
TREND_B = 0.03
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60
SPLIT_T = 800
HORIZON = 10


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def make_windows(y, window=WINDOW, t_start=0, t_end=None):
    if t_end is None:
        t_end = len(y)
    X, targets, target_t = [], [], []
    for t in range(max(t_start, window), t_end):
        X.append(y[t - window:t]); targets.append(y[t]); target_t.append(t)
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32), np.array(target_t)


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def persistence_forecast(y, t_start, t_end):
    return np.array([y[t - 1] for t in range(t_start, t_end)])


def seasonal_naive_forecast(y, t_start, t_end, period=PERIOD):
    return np.array([y[t - period] for t in range(t_start, t_end)])


class LSTMForecaster(nn.Module):
    """One-step forecaster (matches programs/ch26_program3.py and _program5.py
    exactly): fixed single output, always squeezed to shape (batch,)."""
    def __init__(self, hidden_size=8):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.head(h_n[-1]).squeeze(-1)


class LSTMForecasterMS(nn.Module):
    """Multi-step forecaster (matches programs/ch26_program4.py exactly):
    out_dim=1 for the recursive strategy's one-step model, out_dim=HORIZON for
    the direct strategy's one-shot model. Output is never squeezed, since the
    direct model's (batch, HORIZON) output must stay multi-dimensional and the
    recursive model's (batch, 1) output is trained against an unsqueezed
    (batch, 1) target -- squeezing either one here would silently corrupt the
    loss through shape broadcasting."""
    def __init__(self, hidden_size=8, out_dim=1):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, out_dim)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.head(h_n[-1])   # (batch, out_dim)


def train_model(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            pred = model(X_train[idx])
            loss = loss_fn(pred, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def positional_encoding(seq_len, d_model):
    pe = torch.zeros(seq_len, d_model)
    position = torch.arange(seq_len).unsqueeze(1).float()
    div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
    pe[:, 0::2] = torch.sin(position * div_term)
    pe[:, 1::2] = torch.cos(position * div_term)
    return pe


class TransformerForecaster(nn.Module):
    def __init__(self, d_model=8, nhead=2, dim_feedforward=16, num_layers=1, max_len=200):
        super().__init__()
        self.input_proj = nn.Linear(1, d_model)
        self.register_buffer("pe", positional_encoding(max_len, d_model))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead,
                                            dim_feedforward=dim_feedforward, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_layers)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        seq_len = x.shape[1]
        h = self.input_proj(x) + self.pe[:seq_len].unsqueeze(0)
        h = self.encoder(h)
        pooled = h[:, -1, :]
        return self.head(pooled).squeeze(-1)


t, y, trend, seasonal, noise = make_series()

# ============================================================================
# Figure 1: the synthetic series and its decomposition
# ============================================================================
fig, axes = plt.subplots(4, 1, figsize=(8.5, 8), sharex=True)
window_show = slice(600, 800)
axes[0].plot(t[window_show], y[window_show], color=BLUE, linewidth=1.0)
axes[0].set_ylabel("y(t)"); axes[0].set_title("Synthetic series y(t) = trend(t) + seasonal(t) + noise(t)  (steps 600-800 shown)")
axes[0].grid(alpha=0.3)
axes[1].plot(t[window_show], trend[window_show], color=ORANGE, linewidth=1.5)
axes[1].set_ylabel("trend(t)"); axes[1].set_title(f"trend(t) = {TREND_A} + {TREND_B}$\\cdot$t")
axes[1].grid(alpha=0.3)
axes[2].plot(t[window_show], seasonal[window_show], color=GREEN, linewidth=1.5)
axes[2].set_ylabel("seasonal(t)")
axes[2].set_title(f"seasonal(t) = {SEASONAL_AMP}$\\cdot$sin(2$\\pi$t/{PERIOD})  (exact period {PERIOD} steps)")
axes[2].grid(alpha=0.3)
axes[3].plot(t[window_show], noise[window_show], color=GRAY, linewidth=0.8)
axes[3].set_ylabel("noise(t)"); axes[3].set_xlabel("t")
axes[3].set_title(f"noise(t) ~ N(0, {NOISE_STD}$^2$), i.i.d.")
axes[3].grid(alpha=0.3)
plt.tight_layout()
plt.savefig("../figures/ch26_dataset_decomposition.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch26_dataset_decomposition.png")

# ============================================================================
# Figure 2: baselines and the raw-vs-differenced LSTM, on a test-period slice
# ============================================================================
X_all, y_all, t_all = make_windows(y, window=WINDOW)
train_mask = t_all < SPLIT_T
X_train_raw, y_train_raw = X_all[train_mask], y_all[train_mask]
X_test_raw, y_test_raw = X_all[~train_mask], y_all[~train_mask]
yhat_persist = persistence_forecast(y, SPLIT_T, N)
yhat_seasonal = seasonal_naive_forecast(y, SPLIT_T, N)

mu, sigma = X_train_raw.mean(), X_train_raw.std()
X_train_a = torch.from_numpy((X_train_raw - mu) / sigma).unsqueeze(-1)
y_train_a = torch.from_numpy((y_train_raw - mu) / sigma)
X_test_a = torch.from_numpy((X_test_raw - mu) / sigma).unsqueeze(-1)
torch.manual_seed(0)
model_a = LSTMForecaster(hidden_size=8)
train_model(model_a, X_train_a, y_train_a, epochs=100)
model_a.eval()
with torch.no_grad():
    yhat_a = model_a(X_test_a).numpy() * sigma + mu

Xd_train_raw = np.diff(X_train_raw, axis=1); Xd_test_raw = np.diff(X_test_raw, axis=1)
last_train, last_test = X_train_raw[:, -1], X_test_raw[:, -1]
delta_train_raw = y_train_raw - last_train
mu_x, sigma_x = Xd_train_raw.mean(), Xd_train_raw.std()
mu_d, sigma_d = delta_train_raw.mean(), delta_train_raw.std()
Xd_train = torch.from_numpy((Xd_train_raw - mu_x) / sigma_x).unsqueeze(-1)
Xd_test = torch.from_numpy((Xd_test_raw - mu_x) / sigma_x).unsqueeze(-1)
yd_train = torch.from_numpy((delta_train_raw - mu_d) / sigma_d)
torch.manual_seed(0)
model_b = LSTMForecaster(hidden_size=8)
train_model(model_b, Xd_train, yd_train, epochs=100)
model_b.eval()
with torch.no_grad():
    delta_pred = model_b(Xd_test).numpy() * sigma_d + mu_d
yhat_b = last_test + delta_pred

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
show = slice(0, 60)
tt = np.arange(SPLIT_T, SPLIT_T + 60)
axes[0].plot(tt, y_test_raw[show], color="black", linewidth=1.8, label="actual")
axes[0].plot(tt, yhat_persist[show], color=GRAY, linewidth=1.2, linestyle="--", label="persistence")
axes[0].plot(tt, yhat_a[show], color=RED, linewidth=1.2, label="LSTM, raw level (Part A)")
axes[0].plot(tt, yhat_b[show], color=BLUE, linewidth=1.2, label="LSTM, differenced (Part B)")
axes[0].set_xlabel("t"); axes[0].set_ylabel("y(t)")
axes[0].set_title("First 60 test steps: Part A lags behind the rising\nseries, Part B tracks it")
axes[0].legend(fontsize=8); axes[0].grid(alpha=0.3)

names = ["persistence", "seasonal\n-naive", "LSTM\nraw (A)", "LSTM\ndiff. (B)"]
maes = [mae(y_test_raw, yhat_persist), mae(y_test_raw, yhat_seasonal),
        mae(y_test_raw, yhat_a), mae(y_test_raw, yhat_b)]
colors = [GRAY, GRAY, RED, BLUE]
axes[1].bar(names, maes, color=colors)
for i, v in enumerate(maes):
    axes[1].text(i, v + 0.02, f"{v:.3f}", ha="center", fontsize=9)
axes[1].set_ylabel("MAE on test set"); axes[1].set_title("Only the differenced LSTM (B) beats\nthe better baseline (persistence)")
axes[1].grid(alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("../figures/ch26_baseline_and_lstm.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch26_baseline_and_lstm.png")

# ============================================================================
# Figure 3: multi-step forecasting, recursive vs. direct, at two hidden sizes
# ============================================================================
def make_multistep_windows(y, window=WINDOW, horizon=HORIZON, t_start=0, t_end=None):
    if t_end is None:
        t_end = len(y)
    X, targets, anchor_t = [], [], []
    for t in range(max(t_start, window), t_end - horizon + 1):
        X.append(y[t - window:t]); targets.append(y[t:t + horizon]); anchor_t.append(t)
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32), np.array(anchor_t)


def run_comparison(y, hidden_size):
    X_ms, targets_ms, anchor_t = make_multistep_windows(y, t_start=SPLIT_T - 1)
    X_all_1, y_all_1 = [], []
    for tt2 in range(WINDOW, SPLIT_T):
        X_all_1.append(y[tt2 - WINDOW:tt2]); y_all_1.append(y[tt2])
    X_all_1 = np.array(X_all_1, dtype=np.float32); y_all_1 = np.array(y_all_1, dtype=np.float32)
    Xd_train_raw = np.diff(X_all_1, axis=1)
    last_train = X_all_1[:, -1]
    delta_train_raw = y_all_1 - last_train
    mu_x, sigma_x = Xd_train_raw.mean(), Xd_train_raw.std()
    mu_d, sigma_d = delta_train_raw.mean(), delta_train_raw.std()
    Xd_train = torch.from_numpy((Xd_train_raw - mu_x) / sigma_x).unsqueeze(-1)
    yd_train = torch.from_numpy((delta_train_raw - mu_d) / sigma_d).unsqueeze(-1)

    torch.manual_seed(0)
    onestep_model = LSTMForecasterMS(hidden_size=hidden_size, out_dim=1)
    train_model(onestep_model, Xd_train, yd_train, epochs=100)
    onestep_model.eval()

    def normalize_x(a): return (a - mu_x) / sigma_x
    def denorm_d(a): return a * sigma_d + mu_d

    recursive_preds = np.zeros((len(X_ms), HORIZON), dtype=np.float32)
    with torch.no_grad():
        for i in range(len(X_ms)):
            window = X_ms[i].copy()
            for h in range(HORIZON):
                xd = normalize_x(np.diff(window)).astype(np.float32)
                xd_t = torch.from_numpy(xd).view(1, WINDOW - 1, 1)
                pred_delta = denorm_d(onestep_model(xd_t).item())
                next_val = window[-1] + pred_delta
                recursive_preds[i, h] = next_val
                window = np.append(window[1:], next_val)

    X_ms_train, targets_ms_train, _ = make_multistep_windows(y, t_start=WINDOW, t_end=SPLIT_T)
    Xd_direct_train_raw = np.diff(X_ms_train, axis=1)
    anchor_train = X_ms_train[:, -1:]
    delta_targets_train_raw = targets_ms_train - anchor_train
    mu_xD, sigma_xD = Xd_direct_train_raw.mean(), Xd_direct_train_raw.std()
    mu_dD, sigma_dD = delta_targets_train_raw.mean(), delta_targets_train_raw.std()
    Xd_direct_train = torch.from_numpy((Xd_direct_train_raw - mu_xD) / sigma_xD).unsqueeze(-1)
    yd_direct_train = torch.from_numpy((delta_targets_train_raw - mu_dD) / sigma_dD)

    torch.manual_seed(0)
    direct_model = LSTMForecasterMS(hidden_size=hidden_size, out_dim=HORIZON)
    train_model(direct_model, Xd_direct_train, yd_direct_train, epochs=100)
    direct_model.eval()

    Xd_ms_test_raw = np.diff(X_ms, axis=1)
    anchor_test = X_ms[:, -1:]
    Xd_ms_test = torch.from_numpy((Xd_ms_test_raw - mu_xD) / sigma_xD).unsqueeze(-1)
    with torch.no_grad():
        pred_delta_direct_norm = direct_model(Xd_ms_test).numpy()
    direct_preds = anchor_test + pred_delta_direct_norm * sigma_dD + mu_dD

    rec_mae_by_h = np.array([mae(targets_ms[:, h], recursive_preds[:, h]) for h in range(HORIZON)])
    dir_mae_by_h = np.array([mae(targets_ms[:, h], direct_preds[:, h]) for h in range(HORIZON)])
    return rec_mae_by_h, dir_mae_by_h


fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), sharey=True)
horizons = np.arange(1, HORIZON + 1)
for ax, hidden in zip(axes, [8, 32]):
    rec_mae_by_h, dir_mae_by_h = run_comparison(y, hidden)
    ax.plot(horizons, rec_mae_by_h, color=BLUE, marker="o", markersize=4, label="recursive")
    ax.plot(horizons, dir_mae_by_h, color=ORANGE, marker="s", markersize=4, label="direct")
    ax.set_xlabel("horizon step h"); ax.set_title(f"hidden_size = {hidden}")
    ax.grid(alpha=0.3); ax.legend(fontsize=9)
axes[0].set_ylabel("MAE at horizon step h")
fig.suptitle("Recursive vs. direct multi-step forecasting: which wins depends on model capacity")
plt.tight_layout()
plt.savefig("../figures/ch26_multistep_horizon.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch26_multistep_horizon.png")

# ============================================================================
# Figure 4: does attention help? LSTM vs. Transformer, both window lengths
# ============================================================================
def build_onestep_dataset(y, window, t_start, t_end):
    X, targets = [], []
    for t in range(t_start, t_end):
        X.append(y[t - window:t]); targets.append(y[t])
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32)


def run_at_window(y, window, hidden_lstm=8, epochs=100):
    X_train_raw, y_train_raw = build_onestep_dataset(y, window, window, SPLIT_T)
    X_test_raw, y_test_raw = build_onestep_dataset(y, window, SPLIT_T, N)
    Xd_train_raw = np.diff(X_train_raw, axis=1); Xd_test_raw = np.diff(X_test_raw, axis=1)
    last_train, last_test = X_train_raw[:, -1], X_test_raw[:, -1]
    delta_train_raw = y_train_raw - last_train
    delta_test_raw = y_test_raw - last_test
    mu_x, sigma_x = Xd_train_raw.mean(), Xd_train_raw.std()
    mu_d, sigma_d = delta_train_raw.mean(), delta_train_raw.std()
    Xd_train = torch.from_numpy((Xd_train_raw - mu_x) / sigma_x).unsqueeze(-1)
    Xd_test = torch.from_numpy((Xd_test_raw - mu_x) / sigma_x).unsqueeze(-1)
    yd_train = torch.from_numpy((delta_train_raw - mu_d) / sigma_d)

    torch.manual_seed(0)
    lstm_model = LSTMForecaster(hidden_size=hidden_lstm)
    train_model(lstm_model, Xd_train, yd_train, epochs=epochs)
    lstm_model.eval()
    with torch.no_grad():
        yhat_lstm = last_test + lstm_model(Xd_test).numpy() * sigma_d + mu_d

    torch.manual_seed(0)
    tfm_model = TransformerForecaster(max_len=window)
    train_model(tfm_model, Xd_train, yd_train, epochs=epochs)
    tfm_model.eval()
    with torch.no_grad():
        yhat_tfm = last_test + tfm_model(Xd_test).numpy() * sigma_d + mu_d
    return y_test_raw, yhat_lstm, yhat_tfm


fig, ax = plt.subplots(figsize=(7, 4.5))
window_lengths = [60, 150]
x_pos = np.arange(len(window_lengths))
bar_w = 0.35
lstm_maes, tfm_maes = [], []
for window in window_lengths:
    y_true, yhat_lstm, yhat_tfm = run_at_window(y, window)
    lstm_maes.append(mae(y_true, yhat_lstm)); tfm_maes.append(mae(y_true, yhat_tfm))
ax.bar(x_pos - bar_w / 2, lstm_maes, bar_w, color=BLUE, label="LSTM")
ax.bar(x_pos + bar_w / 2, tfm_maes, bar_w, color=PURPLE, label="Transformer")
for i in range(len(window_lengths)):
    ax.text(i - bar_w / 2, lstm_maes[i] + 0.01, f"{lstm_maes[i]:.3f}", ha="center", fontsize=9)
    ax.text(i + bar_w / 2, tfm_maes[i] + 0.01, f"{tfm_maes[i]:.3f}", ha="center", fontsize=9)
ax.set_xticks(x_pos); ax.set_xticklabels([f"window={w}" for w in window_lengths])
ax.set_ylabel("MAE on test set")
ax.set_title("Does attention help this forecasting task? The LSTM wins\nat both window lengths tested")
ax.legend(loc="lower right"); ax.grid(alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("../figures/ch26_lstm_vs_transformer.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch26_lstm_vs_transformer.png")

print("\nAll Chapter 26 figures built.")

# =================================================================
# 5. ch26_validation_schemes.png -- a shuffled split vs. rolling-origin
#    validation with expanding and rolling training windows. Fold
#    boundaries are Program 7's (ch26_program7.py): test blocks start at
#    600, 700, 800, 900; expanding training starts at t=60; rolling keeps
#    the latest 540 targets.
# =================================================================
from matplotlib.patches import Patch

fig, axes = plt.subplots(3, 1, figsize=(10, 6.4),
                         gridspec_kw={"height_ratios": [1, 2.2, 2.2]}, sharex=True)
TRAIN_C, TEST_C, UNUSED_C = BLUE, ORANGE, "#EAECEE"

ax = axes[0]
rng_fig = np.random.default_rng(0)
targets = np.arange(60, 900)
is_test = np.zeros(len(targets), dtype=bool)
is_test[rng_fig.permutation(len(targets))[: int(0.2 * len(targets))]] = True
for t_, te in zip(targets, is_test):
    ax.barh(0, 1, left=t_, height=0.6, color=TEST_C if te else TRAIN_C, lw=0)
ax.set_yticks([0]); ax.set_yticklabels(["shuffled"])
ax.set_title("Random 80/20 split of overlapping windows: test windows sit between training windows",
             fontsize=10, loc="left")
ax.set_ylim(-0.6, 0.6)

for ax, scheme in zip(axes[1:], ["expanding", "rolling"]):
    for k, origin in enumerate([600, 700, 800, 900]):
        row = 3 - k
        start = 60 if scheme == "expanding" else origin - 540
        ax.barh(row, N - 0, left=0, height=0.6, color=UNUSED_C, lw=0)
        ax.barh(row, origin - start, left=start, height=0.6, color=TRAIN_C, lw=0)
        ax.barh(row, 100, left=origin, height=0.6, color=TEST_C, lw=0)
        ax.text(origin - 8, row, f"{origin - start} windows", ha="right", va="center",
                fontsize=8.5, color="white", fontweight="bold")
    ax.set_yticks(range(4)); ax.set_yticklabels([f"fold {k}" for k in (4, 3, 2, 1)])
    ax.set_ylim(-0.6, 3.6)
    title = ("Expanding window: every origin trains on all history up to it"
             if scheme == "expanding" else
             "Rolling window: every origin trains on the latest 540 targets only")
    ax.set_title(title, fontsize=10, loc="left")
axes[-1].set_xlim(0, N)
axes[-1].set_xlabel("time step $t$ of the forecast target")
fig.legend(handles=[Patch(color=TRAIN_C, label="training targets"),
                    Patch(color=TEST_C, label="test targets"),
                    Patch(color=UNUSED_C, label="not used in this fold")],
           loc="lower center", ncol=3, fontsize=9, frameon=False, bbox_to_anchor=(0.5, -0.02))
plt.tight_layout(rect=(0, 0.04, 1, 1))
plt.savefig("../figures/ch26_validation_schemes.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch26_validation_schemes.png")
