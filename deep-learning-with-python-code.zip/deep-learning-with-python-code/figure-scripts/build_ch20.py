import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"


def box(ax, cx, cy, w, h, text, fc, fontsize=10.5):
    ax.add_patch(plt.Rectangle((cx - w / 2, cy - h / 2), w, h,
                                facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fontsize)


def arrow(ax, x0, y0, x1, y1, color="black", lw=1.6):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw))


# =================================================================
# 1. ch20_tokenization_pipeline.png -- text -> tokens -> ids -> padded
# =================================================================
fig, ax = plt.subplots(figsize=(11.6, 3.6))
ax.set_xlim(0, 14.6); ax.set_ylim(0, 3.6); ax.axis("off")

box(ax, 1.5, 1.8, 2.6, 1.1, '"the food\nwas great"', "#FCF3CF", fontsize=10)
arrow(ax, 2.8, 1.8, 3.6, 1.8)
box(ax, 5.3, 1.8, 2.9, 1.1, "['the','food',\n'was','great']", "#D4E6F1", fontsize=9.5)
arrow(ax, 6.75, 1.8, 7.55, 1.8)
box(ax, 9.1, 1.8, 2.3, 1.1, "[2, 3,\n4, 5]", "#D5F5E3", fontsize=10.5)
arrow(ax, 10.25, 1.8, 11.05, 1.8)

box(ax, 13.0, 2.35, 3.0, 0.75, "ids  = [2,3,4,5,0,0]", "#FADBD8", fontsize=9.5)
box(ax, 13.0, 1.25, 3.0, 0.75, "mask = [1,1,1,1,0,0]", "#FADBD8", fontsize=9.5)

ax.text(2.2, 2.55, "tokenize", ha="center", fontsize=9.5, style="italic", color=GRAY)
ax.text(6.15, 2.55, "look up in\nvocabulary", ha="center", fontsize=9, style="italic", color=GRAY)
ax.text(10.65, 2.55, "pad to batch\nmax length\n(0 = <pad>)", ha="center", fontsize=8.8,
        style="italic", color=GRAY)

ax.set_title("From raw text to a padded, masked tensor", fontsize=12.5)
plt.tight_layout()
plt.savefig("../figures/ch20_tokenization_pipeline.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch20_embedding_gradient.png -- lookup table + Program 2's actual
#    gradient matrix as a heatmap
# =================================================================
vocab = ["<pad>", "cat", "dog", "fish", "bird"]
embed_dim = 3
E = np.array([[0.0, 0.0, 0.0],
              [1.0, 0.0, 1.0],
              [0.0, 1.0, 1.0],
              [1.0, 1.0, 0.0],
              [2.0, 0.0, 1.0]])
token_ids = [1, 2, 1]
grad_E = np.zeros_like(E)
for idx in token_ids:
    grad_E[idx] += 1.0

fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.4))

ax0 = axes[0]
ax0.set_xlim(0, 6); ax0.set_ylim(0, 6); ax0.axis("off")
box(ax0, 1.3, 5.0, 1.6, 0.7, "cat", "#D4E6F1", fontsize=10)
box(ax0, 1.3, 3.7, 1.6, 0.7, "dog", "#D4E6F1", fontsize=10)
box(ax0, 1.3, 2.4, 1.6, 0.7, "cat", "#D4E6F1", fontsize=10)
ax0.text(1.3, 1.5, "sentence:\n\"cat dog cat\"", ha="center", fontsize=9.5, color=GRAY)
arrow(ax0, 2.1, 5.0, 3.3, 4.85)
arrow(ax0, 2.1, 3.7, 3.3, 3.75)
arrow(ax0, 2.1, 2.4, 3.3, 3.65)
box(ax0, 4.6, 4.2, 2.2, 2.4, "embedding\ntable $E$\n(row = word)", "#FCF3CF", fontsize=10)
ax0.set_title("Looking up a repeated word\ntwice sends gradient to\nits row twice", fontsize=10.5)

ax1 = axes[1]
im = ax1.imshow(grad_E, cmap="Oranges", aspect="auto", vmin=0)
ax1.set_yticks(range(5)); ax1.set_yticklabels(vocab)
ax1.set_xticks(range(3)); ax1.set_xticklabels([f"dim {j}" for j in range(3)])
for i in range(5):
    for j in range(3):
        ax1.text(j, i, f"{grad_E[i, j]:.0f}", ha="center", va="center",
                  fontsize=11, color="white" if grad_E[i, j] > 1 else "black")
ax1.set_title("Program 2's actual $dL/dE$:\n'cat' row = 2 (used twice),\nunused rows = exactly 0", fontsize=10.5)

plt.tight_layout()
plt.savefig("../figures/ch20_embedding_gradient.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch20_negation_task.png -- Program 3's accuracy bars + matched-pair
#    prediction bars
# =================================================================
pos_words = ["good", "great", "nice", "wonderful"]
neg_words = ["bad", "terrible", "awful", "poor"]
sentiment_words = pos_words + neg_words
vocab_map = {"not": 0, "but": 1}
for w in sentiment_words:
    vocab_map[w] = len(vocab_map)
polarity = {w: 1 for w in pos_words}
polarity.update({w: 0 for w in neg_words})
vocab_size = len(vocab_map)
d_model = 16


def make_example(rng):
    A = sentiment_words[rng.integers(0, 8)]
    B = sentiment_words[rng.integers(0, 8)]
    if rng.integers(0, 2) == 0:
        tokens = ["not", A, "but", B]
        label = polarity[B]
    else:
        tokens = [A, "but", "not", B]
        label = 1 - polarity[B]
    return [vocab_map[t] for t in tokens], label


def make_batch(n, rng):
    X, y = [], []
    for _ in range(n):
        ids, label = make_example(rng)
        X.append(ids); y.append(label)
    return torch.tensor(X), torch.tensor(y, dtype=torch.float32)


class BagOfEmbeddings(nn.Module):
    def __init__(self):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        return self.head(self.embed(x).mean(dim=1)).squeeze(-1)


def positional_encoding(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe.astype(np.float32)


class TransformerClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.register_buffer("pe", torch.tensor(positional_encoding(10, d_model)))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=2, dim_feedforward=32,
                                            dropout=0.0, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=1)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        T = x.shape[1]
        e = self.embed(x) + self.pe[:T]
        return self.head(self.encoder(e).mean(dim=1)).squeeze(-1)


def train_model(model_fn, epochs=300, lr=0.01, seed=0):
    torch.manual_seed(seed)
    model = model_fn()
    opt = optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()
    X_train, y_train = make_batch(2000, np.random.default_rng(1))
    for _ in range(epochs):
        opt.zero_grad()
        loss = loss_fn(model(X_train), y_train)
        loss.backward()
        opt.step()
    return model


def test_accuracy(model, test_rng):
    X_test, y_test = make_batch(500, test_rng)
    with torch.no_grad():
        pred = torch.sigmoid(model(X_test))
        return ((pred > 0.5).float() == y_test).float().mean().item()


bow_model = train_model(BagOfEmbeddings)
tf_model = train_model(TransformerClassifier)
bow_acc = test_accuracy(bow_model, np.random.default_rng(999))
tf_acc = test_accuracy(tf_model, np.random.default_rng(999))

A, B = "great", "bad"
sentence1 = ["not", A, "but", B]
sentence2 = [A, "but", "not", B]
ids1 = torch.tensor([[vocab_map[t] for t in sentence1]])
ids2 = torch.tensor([[vocab_map[t] for t in sentence2]])
with torch.no_grad():
    p1_bow, p2_bow = torch.sigmoid(bow_model(ids1)).item(), torch.sigmoid(bow_model(ids2)).item()
    p1_tf, p2_tf = torch.sigmoid(tf_model(ids1)).item(), torch.sigmoid(tf_model(ids2)).item()

fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.6))

ax0 = axes[0]
bars = ax0.bar(["bag-of-\nembeddings", "Transformer\nclassifier"], [bow_acc, tf_acc],
               color=[GRAY, BLUE], width=0.5)
ax0.axhline(0.5, color="black", lw=1.0, ls="--", alpha=0.6, label="chance")
ax0.set_ylabel("test accuracy")
ax0.set_title("Negation-scope sentiment task")
ax0.set_ylim(0, 1.08)
ax0.legend(fontsize=9, loc="center right")
for bar, acc in zip(bars, [bow_acc, tf_acc]):
    ax0.text(bar.get_x() + bar.get_width() / 2, acc + 0.03, f"{acc:.3f}",
              ha="center", fontsize=10)
ax0.grid(alpha=0.3, axis="y")

ax1 = axes[1]
width = 0.35
xpos = np.arange(2)
ax1.bar(xpos - width / 2, [p1_bow, p2_bow], width, color=GRAY, label="bag-of-embeddings")
ax1.bar(xpos + width / 2, [p1_tf, p2_tf], width, color=BLUE, label="Transformer classifier")
ax1.axhline(0.5, color="black", lw=1.0, ls="--", alpha=0.6)
ax1.set_xticks(xpos)
ax1.set_xticklabels(["'not great\nbut bad'\n(negative)", "'great but\nnot bad'\n(positive)"])
ax1.set_ylabel("predicted $P$(positive)")
ax1.set_title("Same four words, reordered")
ax1.legend(fontsize=8.5)
ax1.set_ylim(0, 1.05)
ax1.grid(alpha=0.3, axis="y")

plt.tight_layout()
plt.savefig("../figures/ch20_negation_task.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 3 figures written")
print(f"bow_acc={bow_acc:.4f} tf_acc={tf_acc:.4f}")
print(f"p1_bow={p1_bow:.6f} p2_bow={p2_bow:.6f} p1_tf={p1_tf:.6f} p2_tf={p2_tf:.6f}")

# =================================================================
# 4. ch20_pretrain_finetune.png -- Program 5's sweep: fine-tuned
#    (pretrained) vs. trained-from-scratch test accuracy across several
#    labeled-set sizes, on the negation-scope task.
# =================================================================
import copy
import torch.nn.functional as Fnn

MASK_ID = vocab_size
VOCAB_SIZE_MLM = vocab_size + 1
SEQ_LEN = 4


def positional_encoding_pe(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe.astype(np.float32)


def make_unlabeled_mlm_batch(n, rng):
    X = np.zeros((n, SEQ_LEN), dtype=np.int64)
    for i in range(n):
        ids, _ = make_example(rng)
        X[i] = ids
    mask_pos = rng.integers(0, SEQ_LEN, size=n)
    targets = X[np.arange(n), mask_pos].copy()
    X_masked = X.copy()
    X_masked[np.arange(n), mask_pos] = MASK_ID
    return torch.tensor(X_masked), torch.tensor(targets, dtype=torch.long), mask_pos


class Backbone(nn.Module):
    def __init__(self, vocab_size=VOCAB_SIZE_MLM, d_model=16, max_len=SEQ_LEN):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.register_buffer("pe", torch.tensor(positional_encoding_pe(max_len, d_model)))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=2, dim_feedforward=32,
                                            dropout=0.0, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=1)

    def forward(self, x):
        T = x.shape[1]
        e = self.embed(x) + self.pe[:T]
        return self.encoder(e)


class MLMHead(nn.Module):
    def __init__(self, d_model=16, vocab_size=VOCAB_SIZE_MLM):
        super().__init__()
        self.proj = nn.Linear(d_model, vocab_size)

    def forward(self, h):
        return self.proj(h)


class ClassifierHead(nn.Module):
    def __init__(self, d_model=16):
        super().__init__()
        self.proj = nn.Linear(d_model, 1)

    def forward(self, h):
        return self.proj(h.mean(dim=1)).squeeze(-1)


torch.manual_seed(0)
pre_backbone = Backbone()
initial_backbone_state = copy.deepcopy(pre_backbone.state_dict())
mlm_head = MLMHead()
opt = optim.Adam(list(pre_backbone.parameters()) + list(mlm_head.parameters()), lr=0.01)
X_unlab, y_unlab, pos_unlab = make_unlabeled_mlm_batch(4000, np.random.default_rng(7))
pos_unlab_t = torch.tensor(pos_unlab)
for epoch in range(150):
    opt.zero_grad()
    h = pre_backbone(X_unlab)
    logits = mlm_head(h[torch.arange(len(X_unlab)), pos_unlab_t])
    loss = Fnn.cross_entropy(logits, y_unlab)
    loss.backward(); opt.step()
pretrained_state = copy.deepcopy(pre_backbone.state_dict())


def train_classifier(start_state, n_label, data_seed, head_seed, epochs=150, lr=0.01):
    bb = Backbone(); bb.load_state_dict(start_state)
    torch.manual_seed(head_seed)
    head = ClassifierHead()
    opt = optim.Adam(list(bb.parameters()) + list(head.parameters()), lr=lr)
    X_train, y_train = make_batch(n_label, np.random.default_rng(data_seed))
    for _ in range(epochs):
        opt.zero_grad()
        pred = head(bb(X_train))
        loss = Fnn.binary_cross_entropy_with_logits(pred, y_train)
        loss.backward(); opt.step()
    return bb, head


def test_acc_pf(bb, head, test_seed):
    X_test, y_test = make_batch(500, np.random.default_rng(test_seed))
    with torch.no_grad():
        pred = torch.sigmoid(head(bb(X_test)))
        return ((pred > 0.5).float() == y_test).float().mean().item()


pf_sizes = [20, 40, 100, 400, 1000]
pf_scratch, pf_finetuned = [], []
for n in pf_sizes:
    data_seed, test_seed, head_seed = 1000 + n, 2000 + n, 3000 + n
    bb_s, head_s = train_classifier(initial_backbone_state, n, data_seed, head_seed)
    pf_scratch.append(test_acc_pf(bb_s, head_s, test_seed))
    bb_f, head_f = train_classifier(pretrained_state, n, data_seed, head_seed)
    pf_finetuned.append(test_acc_pf(bb_f, head_f, test_seed))

fig, ax = plt.subplots(figsize=(7.2, 5.2))
ax.plot(pf_sizes, pf_scratch, "o-", color=GRAY, lw=2, ms=7, label="trained from scratch")
ax.plot(pf_sizes, pf_finetuned, "o-", color=BLUE, lw=2, ms=7, label="pretrained + fine-tuned")
ax.set_xscale("log")
ax.set_xticks(pf_sizes); ax.set_xticklabels([str(s) for s in pf_sizes])
ax.set_xlabel("number of LABELED training examples")
ax.set_ylabel("test accuracy")
ax.set_title("Fine-tuning a pretrained backbone vs.\ntraining the same architecture from scratch")
ax.set_ylim(0.45, 1.05)
ax.axhline(0.5, color="black", lw=1.0, ls="--", alpha=0.5, label="chance")
ax.legend(fontsize=9.5, loc="lower right")
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("../figures/ch20_pretrain_finetune.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch20_pretrain_finetune.png")
print(f"pf_scratch={pf_scratch}")
print(f"pf_finetuned={pf_finetuned}")
