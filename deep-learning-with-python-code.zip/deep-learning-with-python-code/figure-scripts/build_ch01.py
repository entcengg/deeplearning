import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
GRID = dict(alpha=0.25)
BLUE = "#2E86C1"; ORANGE = "#E67E22"; GREEN = "#1C783C"

# ---------- 1. ch01_ai_ml_dl.png : nested fields ----------
fig, ax = plt.subplots(figsize=(6.8, 4.6))
ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")
e1 = mpatches.Ellipse((5, 3.4), 9.4, 6.4, facecolor="#EAF2F8", edgecolor="black", lw=1.4)
e2 = mpatches.Ellipse((5, 2.9), 6.6, 4.4, facecolor="#D4E6F1", edgecolor="black", lw=1.4)
e3 = mpatches.Ellipse((5, 2.35), 3.9, 2.5, facecolor="#A9CCE3", edgecolor="black", lw=1.4)
for e in (e1, e2, e3): ax.add_patch(e)
ax.text(5, 6.05, "Artificial Intelligence", ha="center", fontsize=12, fontweight="bold")
ax.text(5, 6.05 - 0.55, "machines that behave in ways we call intelligent", ha="center", fontsize=8.5, style="italic")
ax.text(5, 4.55, "Machine Learning", ha="center", fontsize=11.5, fontweight="bold")
ax.text(5, 4.55 - 0.5, "programs that improve from examples", ha="center", fontsize=8.5, style="italic")
ax.text(5, 2.6, "Deep Learning", ha="center", fontsize=11, fontweight="bold")
ax.text(5, 2.6 - 0.5, "learning with many-layered\nneural networks", ha="center", fontsize=8.5, style="italic")
plt.tight_layout(); plt.savefig("../figures/ch01_ai_ml_dl.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 2. ch01_two_pipelines.png : hand-designed vs learned features ----------
fig, ax = plt.subplots(figsize=(9.6, 4.4))
ax.set_xlim(0, 14); ax.set_ylim(0, 8); ax.axis("off")

def box(x, y, w, h, text, fc="#EAF2F8", fs=9.5, ec="black"):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h,
                 boxstyle="round,pad=0.08", facecolor=fc, edgecolor=ec, lw=1.3))
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=fs)

def arrow(x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color="black", lw=1.4))

# Row 1: classical machine learning
ax.text(0.2, 7.35, "Classical machine learning", fontsize=11, fontweight="bold")
box(0.3, 5.4, 2.5, 1.3, "Raw data\n(pixels of a digit)")
box(3.9, 5.4, 3.6, 1.3, "Features designed\nby a person\n(loop count, stroke width)", fc="#FDEBD0")
box(8.6, 5.4, 2.6, 1.3, "Learning\nalgorithm")
box(12.0, 5.4, 1.7, 1.3, "\u201c7\u201d")
arrow(2.8, 6.05, 3.9, 6.05); arrow(7.5, 6.05, 8.6, 6.05); arrow(11.2, 6.05, 12.0, 6.05)

# Row 2: deep learning
ax.text(0.2, 3.6, "Deep learning", fontsize=11, fontweight="bold")
box(0.3, 1.6, 2.5, 1.3, "Raw data\n(pixels of a digit)")
box(3.9, 1.6, 7.3, 1.3, "Neural network: features are learned, layer by layer\n(edges $\\rightarrow$ strokes $\\rightarrow$ loops $\\rightarrow$ digit shapes)", fc="#D4E6F1")
box(12.0, 1.6, 1.7, 1.3, "\u201c7\u201d")
arrow(2.8, 2.25, 3.9, 2.25); arrow(11.2, 2.25, 12.0, 2.25)

plt.tight_layout(); plt.savefig("../figures/ch01_two_pipelines.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 3. ch01_learning_loop.png : predict -> measure -> adjust ----------
fig, ax = plt.subplots(figsize=(6.8, 4.8))
ax.set_xlim(0, 10); ax.set_ylim(0, 9); ax.axis("off")

def lbox(x, y, w, h, title, sub, fc):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h,
                 boxstyle="round,pad=0.1", facecolor=fc, edgecolor="black", lw=1.4))
    ax.text(x + w/2, y + h*0.63, title, ha="center", va="center", fontsize=11, fontweight="bold")
    ax.text(x + w/2, y + h*0.28, sub, ha="center", va="center", fontsize=8.5, style="italic")

lbox(3.1, 6.7, 3.8, 1.7, "1. Predict", "run inputs through\nthe current weights", "#D4E6F1")
lbox(5.9, 3.0, 3.8, 1.7, "2. Measure", "compare predictions\nwith true answers (loss)", "#FDEBD0")
lbox(0.3, 3.0, 3.8, 1.7, "3. Adjust", "nudge every weight to\nmake the loss smaller", "#D5F5E3")

kw = dict(arrowstyle="-|>", color="black", lw=1.6,
          connectionstyle="arc3,rad=-0.25")
ax.annotate("", xy=(8.2, 4.9), xytext=(6.4, 6.8), arrowprops=kw)
ax.annotate("", xy=(3.6, 3.35), xytext=(6.2, 3.35),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
ax.annotate("", xy=(3.4, 6.8), xytext=(1.7, 4.9), arrowprops=kw)
ax.text(5, 1.6, "One trip around the loop for the whole dataset is called an epoch.\nTraining repeats the loop until the loss stops improving.",
        ha="center", fontsize=9)
plt.tight_layout(); plt.savefig("../figures/ch01_learning_loop.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 4. ch01_loss_curve.png : real loss values from ch01_program1.py ----------
x = np.array([1.0, 2.0, 3.0, 4.0]); y = np.array([2.0, 4.0, 6.0, 8.0])
w, lr = 0.0, 0.05
losses = []
for _ in range(10):
    y_hat = w * x
    losses.append(np.mean((y - y_hat) ** 2))
    w -= lr * 2 * np.mean(x * (y_hat - y))
epochs = np.arange(1, 11)
fig, ax = plt.subplots(figsize=(6.5, 4.3))
ax.plot(epochs, losses, marker="o", color=BLUE, lw=2.2)
for e, l in list(zip(epochs, losses))[:4]:
    ax.annotate(f"{l:.4g}", (e, l), textcoords="offset points", xytext=(8, 4), fontsize=9)
ax.set_xlabel("epoch"); ax.set_ylabel("loss (mean squared error)")
ax.set_xticks(epochs)
ax.set_title("Loss of the one-weight model, falling as training proceeds")
ax.grid(**GRID)
plt.tight_layout(); plt.savefig("../figures/ch01_loss_curve.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 5. ch01_genai_foundation.png : generative AI and foundation models, two axes inside DL ----------
fig, ax = plt.subplots(figsize=(8.6, 5.6))
ax.set_xlim(0, 10); ax.set_ylim(0, 7.2); ax.axis("off")

outer = mpatches.FancyBboxPatch((0.25, 0.25), 9.5, 6.55, boxstyle="round,pad=0.05",
             facecolor="#F4F6F7", edgecolor="black", lw=1.6, zorder=1)
ax.add_patch(outer)
ax.text(5.0, 6.55, "Deep Learning", ha="center", fontsize=13, fontweight="bold")

e_gen = mpatches.Ellipse((3.85, 3.25), 5.6, 4.0, facecolor=BLUE, edgecolor="black",
                          lw=1.4, alpha=0.35, zorder=2)
e_fdn = mpatches.Ellipse((6.35, 3.25), 5.6, 4.0, facecolor=ORANGE, edgecolor="black",
                          lw=1.4, alpha=0.35, zorder=2)
ax.add_patch(e_gen); ax.add_patch(e_fdn)

ax.text(1.95, 4.75, "Generative AI", ha="center", fontsize=11.5, fontweight="bold",
        color="#1A5276", zorder=3)
ax.text(1.95, 4.2, "output IS new content:\ntext, images, audio, code",
        ha="center", fontsize=8, style="italic", zorder=3)
ax.text(1.95, 1.55, "e.g. a small GAN\ntrained from scratch\non one dataset (Ch. 22)",
        ha="center", fontsize=8, zorder=3)

ax.text(8.25, 4.75, "Foundation Models", ha="center", fontsize=11.5, fontweight="bold",
        color="#A04000", zorder=3)
ax.text(8.25, 4.2, "trained once, at scale,\nadapted to many tasks",
        ha="center", fontsize=8, style="italic", zorder=3)
ax.text(8.25, 1.55, "e.g. a pretrained text\nencoder fine-tuned\nfor one classifier",
        ha="center", fontsize=8, zorder=3)

ax.text(5.1, 3.05, "e.g. GPT-style\nchat assistants,\ntext-to-image models",
        ha="center", fontsize=8.3, fontweight="bold", zorder=3)

ax.text(5.0, 0.65,
        "Different axes of the same system --- WHAT it outputs versus HOW it was built and reused ---\n"
        "so the two overlap heavily without either containing the other.",
        ha="center", fontsize=8.7, zorder=3)

plt.tight_layout(); plt.savefig("../figures/ch01_genai_foundation.png", dpi=200, bbox_inches="tight"); plt.close()

print("saved 5 figures")
