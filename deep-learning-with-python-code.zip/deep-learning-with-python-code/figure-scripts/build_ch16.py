import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

# =================================================================
# 1. ch16_unrolled_bptt.png -- forward unroll + backward BPTT arrows
# =================================================================
fig, axes = plt.subplots(2, 1, figsize=(9.5, 6.6))

def draw_chain(ax, arrow_color, arrow_dir, title):
    ax.set_xlim(0, 10); ax.set_ylim(0, 4); ax.axis("off")
    ax.set_title(title, fontsize=11.5, loc="left")
    centers = [1.8, 4.4, 7.0, 9.4]
    labels = ["$h_0$", "$h_1$", "$h_2$", "$h_3$"]
    for i, cx in enumerate(centers):
        if i == 0:
            ax.add_patch(plt.Circle((cx, 2.0), 0.38, facecolor="#EAECEE",
                                     edgecolor="black", lw=1.2))
        else:
            ax.add_patch(plt.Rectangle((cx - 0.55, 1.6), 1.1, 0.8,
                                        facecolor="#D4E6F1", edgecolor="black", lw=1.3))
            ax.text(cx, 2.85, f"$x_{i}$", ha="center", fontsize=10.5)
            ax.annotate("", xy=(cx, 2.42), xytext=(cx, 2.75),
                        arrowprops=dict(arrowstyle="-|>", color="black", lw=1.3))
            ax.text(cx, 0.95, f"$y_{i}$", ha="center", fontsize=10.5, color=GRAY)
            ax.annotate("", xy=(cx, 1.28), xytext=(cx, 1.58),
                        arrowprops=dict(arrowstyle="-|>", color=GRAY, lw=1.1))
        ax.text(cx, 2.0, labels[i], ha="center", va="center", fontsize=10.5)
    for i in range(len(centers) - 1):
        x0, x1 = centers[i] + (0.38 if i == 0 else 0.55), centers[i + 1] - 0.55
        if arrow_dir == "forward":
            ax.annotate("", xy=(x1, 2.0), xytext=(x0, 2.0),
                        arrowprops=dict(arrowstyle="-|>", color=arrow_color, lw=2.0))
        else:
            ax.annotate("", xy=(x0, 1.75), xytext=(x1, 1.75),
                        arrowprops=dict(arrowstyle="-|>", color=arrow_color, lw=2.0))
    ax.text(5.6, 3.55, r"same $W_{xh}, W_{hh}, b_h$ reused at every step",
            ha="center", fontsize=9.5, style="italic", color=GRAY)

draw_chain(axes[0], BLUE, "forward", "Forward pass: unrolled through time")
draw_chain(axes[1], RED, "backward",
           r"Backpropagation through time: $\partial L/\partial h_t$ flows right to left")
axes[1].text(5.6, 0.35,
             r"each step back multiplies by $W_{hh}^\top$ and $\tanh'(z_t)$ "
             r"$-$ repeated $T$ times over a length-$T$ sequence",
             ha="center", fontsize=9, style="italic", color=RED)

plt.tight_layout()
plt.savefig("../figures/ch16_unrolled_bptt.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch16_vanishing_time.png -- ||dL/dh_t|| vs timestep
# =================================================================
torch.manual_seed(0)
T, H = 50, 20
cell = nn.RNNCell(input_size=1, hidden_size=H, nonlinearity="tanh")
torch.manual_seed(0)
xs = [torch.randn(1, 1) for _ in range(T)]
h = torch.zeros(1, H)
hs = [h]
for x in xs:
    h = cell(x, h)
    h.retain_grad()
    hs.append(h)
target = torch.randn(1, H)
loss = ((hs[-1] - target) ** 2).mean()
loss.backward()
grad_norms = np.array([hs[t].grad.norm().item() for t in range(1, T + 1)])
np.savez("ch16_vanishing_time.npz", grad_norms=grad_norms)

fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(np.arange(1, T + 1), grad_norms, "o-", color=ORANGE, ms=3.5)
ax.set_yscale("log")
ax.set_xlabel("timestep $t$ (1 = earliest, 50 = latest)")
ax.set_ylabel(r"$\|\partial L/\partial h_t\|$ (log scale)")
ax.set_title("Gradient magnitude vs. timestep, 50-step plain RNN")
ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig("../figures/ch16_vanishing_time.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch16_recall_task.png -- test accuracy vs sequence length
# =================================================================
def make_batch(seq_len, n_examples):
    seqs = np.random.choice([-1.0, 1.0], size=(n_examples, seq_len, 1)).astype(np.float32)
    labels = (seqs[:, 0, 0] > 0).astype(np.float32)
    return torch.tensor(seqs), torch.tensor(labels)


class RecallRNN(nn.Module):
    def __init__(self, hidden_size=16):
        super().__init__()
        self.rnn = nn.RNN(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, h_n = self.rnn(x)
        return self.head(h_n.squeeze(0)).squeeze(-1)


np.random.seed(0)
seq_lens = [5, 10, 20, 40]
accs = []
for seq_len in seq_lens:
    torch.manual_seed(0)
    model = RecallRNN()
    opt = optim.SGD(model.parameters(), lr=0.5)
    loss_fn = nn.BCEWithLogitsLoss()
    X_train, y_train = make_batch(seq_len, 500)
    X_test, y_test = make_batch(seq_len, 200)
    for epoch in range(200):
        model.train(); opt.zero_grad()
        loss_fn(model(X_train), y_train).backward()
        opt.step()
    model.eval()
    with torch.no_grad():
        preds = (torch.sigmoid(model(X_test)) > 0.5).float()
        accs.append((preds == y_test).float().mean().item())
np.savez("ch16_recall_task.npz", seq_lens=np.array(seq_lens), accs=np.array(accs))

fig, ax = plt.subplots(figsize=(6.8, 4.8))
ax.bar([str(s) for s in seq_lens], accs, color=GREEN)
ax.axhline(0.5, color=GRAY, ls="--", lw=1.3, label="chance level")
ax.set_xlabel("sequence length $T$")
ax.set_ylabel("test accuracy")
ax.set_ylim(0, 1.05)
ax.set_title("Recalling the first input: plain RNN, plain SGD")
ax.legend(fontsize=9)
ax.grid(alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("../figures/ch16_recall_task.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 3 figures written")

# =================================================================
# 4. ch16_sequence_patterns.png -- one-to-many, many-to-one, and the
#    two many-to-many patterns (aligned, and encoder-decoder)
# =================================================================
def draw_pattern(ax, has_in, has_out, title, example, n_enc=None):
    n = len(has_in)
    xs = [0.9 + 1.45 * i for i in range(n)]
    ax.set_xlim(0, xs[-1] + 0.9); ax.set_ylim(-0.35, 4.6); ax.axis("off")
    ax.text(0.05, 4.45, title, fontsize=11, fontweight="bold", va="top")
    ax.text(0.05, 3.95, example, fontsize=8.8, style="italic", color=GRAY, va="top")
    k_in = k_out = 0
    for i, cx in enumerate(xs):
        enc = n_enc is None or i < n_enc
        ax.add_patch(plt.Rectangle((cx - 0.42, 1.45), 0.84, 0.62,
                                   facecolor="#D4E6F1" if enc else "#FDEBD0",
                                   edgecolor="black", lw=1.2))
        ax.text(cx, 1.76, f"$h_{i + 1}$", ha="center", va="center", fontsize=10)
        if has_in[i]:
            k_in += 1
            lab = "$x$" if sum(has_in) == 1 else f"$x_{k_in}$"
            ax.text(cx, 0.35, lab, ha="center", va="center", fontsize=10)
            ax.annotate("", xy=(cx, 1.43), xytext=(cx, 0.62),
                        arrowprops=dict(arrowstyle="-|>", color="black", lw=1.2))
        if has_out[i]:
            k_out += 1
            lab = "$y$" if sum(has_out) == 1 else f"$y_{k_out}$"
            ax.text(cx, 3.05, lab, ha="center", va="center", fontsize=10, color=ORANGE)
            ax.annotate("", xy=(cx, 2.8), xytext=(cx, 2.09),
                        arrowprops=dict(arrowstyle="-|>", color=ORANGE, lw=1.2))
        if i < n - 1:
            ax.annotate("", xy=(xs[i + 1] - 0.44, 1.76), xytext=(cx + 0.44, 1.76),
                        arrowprops=dict(arrowstyle="-|>", color=BLUE, lw=1.6))
    if n_enc is not None:
        xm = (xs[n_enc - 1] + xs[n_enc]) / 2
        ax.plot([xm, xm], [0.05, 2.75], ls="--", color=GRAY, lw=1)
        ax.text((xs[0] + xs[n_enc - 1]) / 2, -0.2, "encoder reads", ha="center",
                fontsize=8.5, color=GRAY)
        ax.text((xs[n_enc] + xs[-1]) / 2, -0.2, "decoder writes", ha="center",
                fontsize=8.5, color=GRAY)

fig, axes = plt.subplots(2, 2, figsize=(11, 6.2))
draw_pattern(axes[0, 0], [1, 0, 0, 0], [1, 1, 1, 1], "One-to-many",
             "one input, a sequence out: image captioning, music generation")
draw_pattern(axes[0, 1], [1, 1, 1, 1], [0, 0, 0, 1], "Many-to-one",
             "a sequence in, one output: sentiment of a review;\n"
             "this chapter's Programs 3 and 5")
draw_pattern(axes[1, 0], [1, 1, 1, 1], [1, 1, 1, 1], "Many-to-many, aligned",
             "one output per input step: a tag for every word,\n"
             "a flag for every sensor reading")
draw_pattern(axes[1, 1], [1, 1, 1, 0, 0, 0], [0, 0, 0, 1, 1, 1],
             "Many-to-many, encoder-decoder",
             "read the whole input, then write an output of any\n"
             "length: machine translation", n_enc=3)
plt.tight_layout(h_pad=1.5, w_pad=2.0)
plt.savefig("../figures/ch16_sequence_patterns.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch16_sequence_patterns.png")

# =================================================================
# 5. ch16_sensor_lag.png -- the spike-sign task (Program 5)
#    Accuracies are Program 5's printed results (ch16_program5.py),
#    hardcoded here rather than retrained.
# =================================================================
lags = np.array([0, 4, 6, 8, 14])
accs = np.array([1.0000, 1.0000, 1.0000, 0.5050, 0.5100])
rs = np.random.RandomState(0)                        # same generator as Program 5
stream = rs.normal(0.0, 0.3, size=25)
stream[16] = 2.0                                     # one spike, 8 readings before the end

fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 3.6), gridspec_kw={"width_ratios": [1.15, 1]})
a1.plot(np.arange(25), stream, color=BLUE, lw=1.4, marker="o", ms=3)
a1.plot([16], [2.0], "o", color=RED, ms=7, zorder=5)
a1.annotate("spike (sign = label)", xy=(16, 2.0), xytext=(4.5, 1.75), fontsize=9, color=RED,
            arrowprops=dict(arrowstyle="-|>", color=RED, lw=1.1))
a1.axvline(24, color=GRAY, ls="--", lw=1)
a1.text(23.5, 2.45, "decision is made\nafter the last\nreading", ha="right", va="top",
        fontsize=8.5, color=GRAY)
a1.annotate("", xy=(24, -1.2), xytext=(16, -1.2),
            arrowprops=dict(arrowstyle="<->", color=GRAY, lw=1))
a1.text(20, -1.12, "lag = 8", ha="center", va="bottom", fontsize=9, color=GRAY)
a1.set_xlim(-1, 25.5); a1.set_ylim(-1.45, 2.6)
a1.set_xlabel("time step (reading)"); a1.set_ylabel("sensor value")
a1.set_title("One example stream: noise plus a single spike", fontsize=10.5)

a2.plot(lags, accs, color=PURPLE, lw=2, marker="o", ms=7)
a2.axhline(0.5, color=GRAY, ls=":", lw=1.2)
a2.text(11, 0.465, "chance (50%)", ha="center", fontsize=9, color=GRAY)
for L, A in zip(lags, accs):
    # the label just right of the cliff sits right of its point, clear of the falling line
    a2.text(L + (0.3 if L == 8 else 0), A + 0.035, f"{A:.3f}",
            ha="left" if L == 8 else "center", fontsize=8.5)
a2.set_xticks(lags)
a2.set_xlim(-1, 15.5); a2.set_ylim(0.4, 1.1)
a2.set_xlabel("lag: readings between the spike and the decision")
a2.set_ylabel("test accuracy")
a2.set_title("Plain RNN, 200 SGD epochs: a sharp cliff", fontsize=10.5)
plt.tight_layout()
plt.savefig("../figures/ch16_sensor_lag.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch16_sensor_lag.png")
