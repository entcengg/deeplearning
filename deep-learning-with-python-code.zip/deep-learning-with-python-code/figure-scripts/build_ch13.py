import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"

# ---------- 1. ch13_framework_comparison.png ----------
scratch_loss = np.load("ch10_xor_training.npz")["seed0"]
pytorch_loss = np.load("ch13_pytorch_xor_loss.npy")

fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(np.arange(1, len(scratch_loss)+1), scratch_loss, color="#7D8794", linewidth=2.0,
        label="Chapter 10: NumPy from scratch")
ax.plot(np.arange(1, len(pytorch_loss)+1), pytorch_loss, color=BLUE, linewidth=1.6,
        linestyle="--", label="This chapter: PyTorch")
ax.set_yscale("log")
ax.set_xlabel("epoch"); ax.set_ylabel("loss (log scale)")
ax.set_title("The same network, the same problem, two implementations")
ax.legend(fontsize=10)
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch13_framework_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch13_zero_grad_bug.png ----------
steps = [1, 2, 3]
buggy = [-6.0000, -10.8000, -13.4400]
correct = [-6.0000, -4.8000, -3.8400]

fig, ax = plt.subplots(figsize=(6.6, 4.6))
width = 0.35
xs = np.arange(len(steps))
ax.bar(xs - width/2, [abs(v) for v in buggy], width, color=ORANGE, label="without zero_grad()")
ax.bar(xs + width/2, [abs(v) for v in correct], width, color=BLUE, label="with zero_grad()")
ax.set_xticks(xs); ax.set_xticklabels([f"step {s}" for s in steps])
ax.set_ylabel("|gradient|")
ax.set_title("Forgetting zero_grad(): gradients accumulate instead of shrinking")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25, axis="y")
plt.tight_layout()
plt.savefig("../figures/ch13_zero_grad_bug.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch13_training_workflow.png ----------
# Self-contained re-run of Program 5's complete training workflow (same
# architecture, same seeds), but capturing every epoch's train/val loss
# -- rather than just the handful Program 5 prints -- for a continuous
# curve, with the best-checkpoint epoch marked.
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split

torch.manual_seed(0)


class BlobDataset(Dataset):
    def __init__(self, n_per_class=120, seed=0):
        g = torch.Generator().manual_seed(seed)
        class0 = torch.randn(n_per_class, 2, generator=g) * 0.9 + torch.tensor([-1.5, -1.5])
        class1 = torch.randn(n_per_class, 2, generator=g) * 0.9 + torch.tensor([1.5, 1.5])
        self.X = torch.cat([class0, class1], dim=0)
        self.y = torch.cat([torch.zeros(n_per_class), torch.ones(n_per_class)]).unsqueeze(1)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


class BlobNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Linear(2, 8)
        self.output = nn.Linear(8, 1)

    def forward(self, x):
        return self.output(torch.relu(self.hidden(x)))


def run_validation(model, loader, loss_fn):
    model.eval()
    total_loss, n = 0.0, 0
    with torch.no_grad():
        for xb, yb in loader:
            pred = model(xb)
            total_loss += loss_fn(pred, yb).item() * len(xb)
            n += len(xb)
    return total_loss / n


full_dataset = BlobDataset()
n_val = 48
n_train = len(full_dataset) - n_val
train_set, val_set = random_split(full_dataset, [n_train, n_val],
                                   generator=torch.Generator().manual_seed(0))
train_loader = DataLoader(train_set, batch_size=16, shuffle=True,
                           generator=torch.Generator().manual_seed(0))
val_loader = DataLoader(val_set, batch_size=16, shuffle=False)

model = BlobNet()
optimizer = torch.optim.Adam(model.parameters(), lr=0.05)
loss_fn = nn.BCEWithLogitsLoss()

train_losses, val_losses = [], []
best_val, best_epoch = float("inf"), None
for epoch in range(1, 31):
    model.train()
    train_loss_sum, n_seen = 0.0, 0
    for xb, yb in train_loader:
        optimizer.zero_grad()
        loss = loss_fn(model(xb), yb)
        loss.backward()
        optimizer.step()
        train_loss_sum += loss.item() * len(xb)
        n_seen += len(xb)
    train_losses.append(train_loss_sum / n_seen)
    val_loss = run_validation(model, val_loader, loss_fn)
    val_losses.append(val_loss)
    if val_loss < best_val:
        best_val, best_epoch = val_loss, epoch

np.savez("ch13_training_workflow.npz", train=train_losses, val=val_losses,
         best_epoch=best_epoch, best_val=best_val)

epochs = np.arange(1, 31)
fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(epochs, train_losses, color="#7D8794", linewidth=2.0, label="training loss")
ax.plot(epochs, val_losses, color=BLUE, linewidth=2.0, label="validation loss")
ax.axvline(best_epoch, color=ORANGE, linestyle="--", linewidth=1.6,
           label=f"checkpointed epoch ({best_epoch})")
ax.scatter([best_epoch], [best_val], color=ORANGE, zorder=5, s=45)
ax.set_yscale("log")
ax.set_xlabel("epoch"); ax.set_ylabel("loss (log scale)")
ax.set_title("A complete training workflow: batching, validation, and checkpointing")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch13_training_workflow.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 3 figures")
