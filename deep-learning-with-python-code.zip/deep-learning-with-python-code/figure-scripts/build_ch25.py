import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.datasets import load_digits
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 11

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))
    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    mask = np.zeros((CANVAS, CANVAS), dtype=np.int64)
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        foreground = sprite > 0.0
        patch = mask[y1:y2, x1:x2]
        patch[foreground] = label + 1
        mask[y1:y2, x1:x2] = patch
    return canvas, mask


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, masks = [], []
    for _ in range(n_images):
        c, m = make_one_image(rng)
        images.append(c); masks.append(m)
    return torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(masks))


def conv_block(in_ch, out_ch):
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.ReLU(),
        nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.ReLU(),
    )


class TinyUNet(nn.Module):
    def __init__(self, use_skip=True):
        super().__init__()
        self.use_skip = use_skip
        self.enc1 = conv_block(1, 16)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = conv_block(16, 32)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = conv_block(32, 64)
        self.up2 = nn.ConvTranspose2d(64, 32, kernel_size=2, stride=2)
        self.dec2 = conv_block(64 if use_skip else 32, 32)
        self.up1 = nn.ConvTranspose2d(32, 16, kernel_size=2, stride=2)
        self.dec1 = conv_block(32 if use_skip else 16, 16)
        self.final = nn.Conv2d(16, NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        s1 = self.enc1(x)
        p1 = self.pool1(s1)
        s2 = self.enc2(p1)
        p2 = self.pool2(s2)
        b = self.bottleneck(p2)
        u2 = self.up2(b)
        d2 = self.dec2(torch.cat([u2, s2], dim=1) if self.use_skip else u2)
        u1 = self.up1(d2)
        d1 = self.dec1(torch.cat([u1, s1], dim=1) if self.use_skip else u1)
        return self.final(d1)


def dice_loss(probs, target_onehot, eps=1e-6):
    dims = (0, 2, 3)
    inter = (probs * target_onehot).sum(dim=dims)
    union = probs.sum(dim=dims) + target_onehot.sum(dim=dims)
    return 1 - ((2 * inter + eps) / (union + eps)).mean()


def combined_loss(logits, target):
    ce = F.cross_entropy(logits, target)
    probs = F.softmax(logits, dim=1)
    target_onehot = F.one_hot(target, NUM_CLASSES).permute(0, 3, 1, 2).float()
    return ce + dice_loss(probs, target_onehot)


def metrics_from_preds(preds, masks):
    pixel_acc = (preds == masks).float().mean().item()
    ious, dices = [], []
    for c in range(NUM_CLASSES):
        pred_c = (preds == c); true_c = (masks == c)
        inter = (pred_c & true_c).sum().item()
        union = (pred_c | true_c).sum().item()
        if union == 0:
            continue
        ious.append(inter / union)
        denom = pred_c.sum().item() + true_c.sum().item()
        dices.append(2 * inter / denom if denom > 0 else 0.0)
    return pixel_acc, float(np.mean(ious)), float(np.mean(dices))


CMAP = plt.cm.tab20(np.linspace(0, 1, NUM_CLASSES))
CMAP[0] = [1, 1, 1, 1]   # background = white


def mask_to_rgb(mask):
    return CMAP[mask]


# ============================================================================
# Figure 1: dataset examples -- canvas + ground-truth mask pairs
# ============================================================================
ex_images, ex_masks = make_dataset(6, seed=42)
fig, axes = plt.subplots(2, 6, figsize=(13, 4.6))
for k in range(6):
    axes[0, k].imshow(ex_images[k].numpy(), cmap='gray_r', vmin=0, vmax=1)
    axes[0, k].set_title(f"scene {k}: image", fontsize=9)
    axes[0, k].set_xticks([]); axes[0, k].set_yticks([])
    axes[1, k].imshow(mask_to_rgb(ex_masks[k].numpy()))
    axes[1, k].set_title(f"scene {k}: mask", fontsize=9)
    axes[1, k].set_xticks([]); axes[1, k].set_yticks([])
fig.suptitle("Synthetic scenes (top) and their pixel-level ground truth (bottom) --\n"
             "each color is one digit class; masks trace the actual stroke shape, not a box", fontsize=10)
plt.tight_layout()
plt.savefig("../figures/ch25_dataset_masks.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch25_dataset_masks.png")

# ============================================================================
# Train both variants once; reuse for figures 2 and 3
# ============================================================================
torch.manual_seed(0)
train_images, train_masks = make_dataset(1200, seed=0)
test_images, test_masks = make_dataset(300, seed=1)

histories = {}
models = {}
for use_skip in [True, False]:
    torch.manual_seed(0)
    model = TinyUNet(use_skip=use_skip)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    history = []
    print(f"Training TinyUNet use_skip={use_skip} for figures...")
    batch_size, n_batches = 100, 1200 // 100
    for epoch in range(1, 101):
        perm = torch.randperm(len(train_images))
        epoch_loss = 0.0
        for b in range(n_batches):
            idx = perm[b * batch_size:(b + 1) * batch_size]
            logits = model(train_images[idx].unsqueeze(1))
            loss = combined_loss(logits, train_masks[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            epoch_loss += loss.item()
        history.append(epoch_loss / n_batches)
        if epoch % 25 == 0:
            print(f"  epoch {epoch}: loss={history[-1]:.4f}")
    model.eval()
    histories[use_skip] = history
    models[use_skip] = model

with torch.no_grad():
    preds_skip = models[True](test_images.unsqueeze(1)).argmax(dim=1)
    preds_noskip = models[False](test_images.unsqueeze(1)).argmax(dim=1)

# ============================================================================
# Figure 2: qualitative comparison -- image, ground truth, with-skip, no-skip
# ============================================================================
example_indices = [0, 3, 7, 12]
fig, axes = plt.subplots(4, 4, figsize=(9, 9))
col_titles = ["input", "ground truth", "WITH skip", "WITHOUT skip"]
for row, idx in enumerate(example_indices):
    axes[row, 0].imshow(test_images[idx].numpy(), cmap='gray_r', vmin=0, vmax=1)
    axes[row, 1].imshow(mask_to_rgb(test_masks[idx].numpy()))
    axes[row, 2].imshow(mask_to_rgb(preds_skip[idx].numpy()))
    axes[row, 3].imshow(mask_to_rgb(preds_noskip[idx].numpy()))
    for col in range(4):
        axes[row, col].set_xticks([]); axes[row, col].set_yticks([])
        if row == 0:
            axes[row, col].set_title(col_titles[col], fontsize=10)
fig.suptitle("Same test images: ground truth vs. predictions with and without skip connections\n"
             "(without skip connections, boundaries blur and small strokes are lost)", fontsize=10)
plt.tight_layout()
plt.savefig("../figures/ch25_skip_vs_noskip.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch25_skip_vs_noskip.png")

# ============================================================================
# Figure 3: training loss curves, with vs. without skip connections
# ============================================================================
fig, ax = plt.subplots(figsize=(7.5, 4.5))
ax.plot(range(1, 101), histories[True], color=BLUE, label="WITH skip connections", linewidth=1.5)
ax.plot(range(1, 101), histories[False], color=ORANGE, label="WITHOUT skip connections", linewidth=1.5)
ax.set_xlabel("epoch"); ax.set_ylabel("mean training loss (CE + Dice)")
ax.set_title("Training loss: skip connections converge lower, not just faster")
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("../figures/ch25_loss_curves.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch25_loss_curves.png")

# ============================================================================
# Figure 4: baseline vs. trained model, grouped bar chart
# ============================================================================
baseline_preds = torch.zeros_like(test_masks)
bl_acc, bl_miou, bl_dice = metrics_from_preds(baseline_preds, test_masks)
m_acc, m_miou, m_dice = metrics_from_preds(preds_skip, test_masks)

labels = ["pixel accuracy", "mean IoU", "mean Dice"]
baseline_vals = [bl_acc, bl_miou, bl_dice]
model_vals = [m_acc, m_miou, m_dice]
x = np.arange(len(labels))
width = 0.35
fig, ax = plt.subplots(figsize=(7.5, 4.8))
bars1 = ax.bar(x - width/2, baseline_vals, width, label="always-background baseline", color=GRAY)
bars2 = ax.bar(x + width/2, model_vals, width, label="trained TinyUNet", color=BLUE)
for bars in [bars1, bars2]:
    for bar in bars:
        h = bar.get_height()
        ax.annotate(f"{h:.3f}", (bar.get_x() + bar.get_width()/2, h), textcoords="offset points",
                    xytext=(0, 3), ha='center', fontsize=9)
ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylim(0, 1.08)
ax.set_title("Pixel accuracy nearly hides the gap that mIoU and Dice reveal clearly")
ax.legend()
plt.tight_layout()
plt.savefig("../figures/ch25_baseline_comparison.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch25_baseline_comparison.png")

# ============================================================================
# Figure 5: semantic vs. instance vs. panoptic segmentation, same scene
# ============================================================================
# Reuses the existing dataset generator, but a local variant additionally
# returns the per-object list (label, box, sprite) that make_one_image()
# already computes internally and normally discards once the combined
# canvas/mask are built. Test scene 0 (seed=1) is the same "two 4s" scene
# already shown in Figure 2 / discussed in the chapter text as an example
# where semantic segmentation cannot tell the two objects apart.

def make_one_image_with_objects(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))
    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    mask = np.zeros((CANVAS, CANVAS), dtype=np.int64)
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        foreground = sprite > 0.0
        patch = mask[y1:y2, x1:x2]
        patch[foreground] = label + 1
        mask[y1:y2, x1:x2] = patch
    return canvas, mask, placed


rng_scene0 = np.random.RandomState(1)
canvas0, mask0, placed0 = make_one_image_with_objects(rng_scene0)
# Confirm this regenerates test scene 0 exactly (make_dataset(300, seed=1)'s
# very first draw), so the figure is built from the same ground truth the
# chapter text already refers to, not a different random scene.
assert np.allclose(canvas0, test_images[0].numpy())
assert np.array_equal(mask0, test_masks[0].numpy())
labels_in_scene = [p[0] for p in placed0]
print(f"Scene 0 regenerated for Figure 5: {len(placed0)} object(s), labels={labels_in_scene}")

INSTANCE_COLORS = [BLUE, ORANGE, GREEN, PURPLE]
instance_shade = [1.0, 0.55, 0.78, 0.4]  # brightness multiplier per instance, for the panoptic panel

fig, axes = plt.subplots(1, 4, figsize=(13, 3.6))

axes[0].imshow(canvas0, cmap='gray_r', vmin=0, vmax=1)
axes[0].set_title("Input", fontsize=10)

axes[1].imshow(mask_to_rgb(mask0))
axes[1].set_title("Semantic\n(one merged region)", fontsize=10)

axes[2].imshow(canvas0, cmap='gray_r', vmin=0, vmax=1, alpha=0.35)
for i, (label, x1, y1, x2, y2, gi, gj, sprite) in enumerate(placed0):
    color = INSTANCE_COLORS[i % len(INSTANCE_COLORS)]
    rect = patches.Rectangle((x1 - 0.5, y1 - 0.5), x2 - x1, y2 - y1, linewidth=1.8,
                              edgecolor=color, facecolor='none')
    axes[2].add_patch(rect)
    fg = sprite > 0.0
    overlay = np.zeros((y2 - y1, x2 - x1, 4))
    rgb = np.array(matplotlib.colors.to_rgb(color))
    overlay[fg] = [*rgb, 0.55]
    # imshow puts pixel i at [i-0.5, i+0.5], so the overlay's extent is shifted by 0.5 too
    axes[2].imshow(overlay, extent=(x1 - 0.5, x2 - 0.5, y2 - 0.5, y1 - 0.5))
    axes[2].text((x1 + x2) / 2, y1 - 1.2, f"obj {i+1} (class {label})", color=color,
                 fontsize=8, fontweight='bold', ha='center')
axes[2].set_xlim(-0.5, CANVAS - 0.5); axes[2].set_ylim(CANVAS - 0.5, -0.5)
axes[2].set_title("Instance\n(separate box + mask each)", fontsize=10)

panoptic_rgb = mask_to_rgb(mask0).copy()
for i, (label, x1, y1, x2, y2, gi, gj, sprite) in enumerate(placed0):
    fg = sprite > 0.0
    shade = instance_shade[i % len(instance_shade)]
    region = panoptic_rgb[y1:y2, x1:x2].copy()
    region[fg, 0:3] = region[fg, 0:3] * shade
    panoptic_rgb[y1:y2, x1:x2] = region
axes[3].imshow(panoptic_rgb)
for i, (label, x1, y1, x2, y2, gi, gj, sprite) in enumerate(placed0):
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    axes[3].text(cx, y1 - 1.2, f"#{i+1}", color='black', fontsize=9, fontweight='bold', ha='center')
axes[3].set_title("Panoptic\n(class + instance ID)", fontsize=10)

for ax in axes:
    ax.set_xticks([]); ax.set_yticks([])
plt.tight_layout()
plt.savefig("../figures/ch25_segmentation_types.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch25_segmentation_types.png")

print("\nAll Chapter 25 figures built.")
