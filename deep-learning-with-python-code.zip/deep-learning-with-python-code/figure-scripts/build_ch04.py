import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"

# ---------- 1. ch04_secant_tangent.png ----------
def f(x): return x**2
x0 = 3.0
xs = np.linspace(1.2, 4.8, 300)

fig, ax = plt.subplots(figsize=(7.4, 5.0))
ax.plot(xs, f(xs), color="black", linewidth=2.2, label=r"$f(x)=x^2$", zorder=3)

for h, color, style in [(1.5, "#AAB7B8", ":"), (0.7, "#7FB3D5", "--"), (0.15, "#E67E22", "-")]:
    x1 = x0 + h
    slope = (f(x1) - f(x0)) / h
    xs_line = np.array([x0 - 0.5, x1 + 0.5])
    ys_line = f(x0) + slope * (xs_line - x0)
    ax.plot(xs_line, ys_line, color=color, linestyle=style, linewidth=1.8,
            label=f"secant, h={h}: slope={slope:.2g}")
    ax.scatter([x0, x1], [f(x0), f(x1)], color=color, zorder=4, s=28)

# the true tangent line, slope 6
xs_tan = np.array([1.6, 4.4])
ax.plot(xs_tan, f(x0) + 6*(xs_tan - x0), color=BLUE, linewidth=2.4,
        label="tangent line: slope = 6")
ax.scatter([x0], [f(x0)], color="black", zorder=5, s=45)
ax.annotate("(3, 9)", (x0, f(x0)), textcoords="offset points", xytext=(8, -18), fontsize=9)

ax.set_xlabel("$x$"); ax.set_ylabel("$f(x)$")
ax.set_title("Secant slopes converging to the tangent slope at $x=3$")
ax.legend(fontsize=8.5, loc="upper left")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch04_secant_tangent.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch04_gradient_contour.png ----------
def g(w, b): return w**2 + 3*w*b + b**2

W, B = np.meshgrid(np.linspace(-2, 5, 300), np.linspace(-3, 5, 300))
Z = g(W, B)

fig, ax = plt.subplots(figsize=(6.6, 5.6))
levels = np.linspace(0, 60, 13)
cs = ax.contour(W, B, Z, levels=levels, cmap="Blues", linewidths=1.1)
ax.clabel(cs, inline=True, fontsize=7, fmt="%.0f")

w0, b0 = 2.0, 1.0
grad = np.array([2*w0+3*b0, 3*w0+2*b0])          # (7, 8)
scale = 0.10                                      # shrink arrow to fit the axes
ax.scatter([w0], [b0], color="black", zorder=5, s=45)
ax.annotate("(2, 1)", (w0, b0), textcoords="offset points", xytext=(6, -14), fontsize=9)

ax.annotate("", xy=(w0 + scale*grad[0], b0 + scale*grad[1]), xytext=(w0, b0),
            arrowprops=dict(arrowstyle="-|>", color="#C0392B", lw=2.4))
ax.text(w0 + scale*grad[0] + 0.15, b0 + scale*grad[1], r"$\nabla g = (7, 8)$" "\nsteepest ascent",
        color="#C0392B", fontsize=9)

ax.annotate("", xy=(w0 - scale*grad[0], b0 - scale*grad[1]), xytext=(w0, b0),
            arrowprops=dict(arrowstyle="-|>", color=BLUE, lw=2.4))
ax.text(w0 - scale*grad[0] - 1.9, b0 - scale*grad[1] - 0.55, r"$-\nabla g$" "\nsteepest descent",
        color=BLUE, fontsize=9)

ax.set_xlabel("$w$"); ax.set_ylabel("$b$")
ax.set_title(r"Contours of $g(w,b)=w^2+3wb+b^2$ and its gradient at $(2,1)$")
plt.tight_layout()
plt.savefig("../figures/ch04_gradient_contour.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch04_chain_rule.png ----------
fig, ax = plt.subplots(figsize=(9.4, 3.6))
ax.set_xlim(0, 14.6); ax.set_ylim(-0.3, 4.6); ax.axis("off")

def box(x, y, w, h, text, fc="#D4E6F1"):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                 facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=10.5)

box(0.4, 1.6, 1.7, 1.2, "$x$", fc="#EAF2F8")
box(3.9, 1.6, 2.6, 1.2, "$g(x)=3x+1$")
box(8.6, 1.6, 2.6, 1.2, "$f(u)=u^2$")
box(12.2, 1.6, 2.0, 1.2, "$h(x)$", fc="#EAF2F8")

for (x1, x2) in [(2.1, 3.9), (6.5, 8.6), (11.2, 12.2)]:
    ax.annotate("", xy=(x2, 2.2), xytext=(x1, 2.2),
                arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))

ax.text(3.0, 3.15, "$x=2$", ha="center", fontsize=9)
ax.text(7.55, 3.15, "$u=g(2)=7$", ha="center", fontsize=9)
ax.text(11.7, 3.15, "$h(2)=49$", ha="center", fontsize=9)

ax.text(5.2, 0.95, "local slope $g'(x)=3$", ha="center", fontsize=9, style="italic", color="#7D8794")
ax.text(9.9, 0.95, "local slope $f'(u)=2u$", ha="center", fontsize=9, style="italic", color="#7D8794")

ax.text(7.3, 0.05,
        r"chain rule: $h'(x) = f'(g(x)) \cdot g'(x)$  =  local slope of $f$  $\times$  local slope of $g$  =  $2(7)\times 3 = 42$",
        ha="center", fontsize=9.5)

plt.tight_layout()
plt.savefig("../figures/ch04_chain_rule.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch04_computational_graph.png : forward values + backward local-derivative product ----------
fig, ax = plt.subplots(figsize=(10.4, 5.4))
ax.set_xlim(0, 15.6); ax.set_ylim(-1.6, 6.4); ax.axis("off")

def node(x, y, w, h, text, fc="#D4E6F1"):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                 facecolor=fc, edgecolor="black", lw=1.3, zorder=3))
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=10.5, zorder=4)

positions = [0.4, 4.3, 8.2, 12.1]
node(positions[0], 3.2, 1.7, 1.2, "$x=2$", fc="#EAF2F8")
node(positions[1], 3.2, 2.6, 1.2, "$u=3x$\n$u=6$")
node(positions[2], 3.2, 2.6, 1.2, "$v=u{+}1$\n$v=7$")
node(positions[3], 3.2, 2.1, 1.2, "$h=v^2$\n$h=49$", fc="#EAF2F8")

# forward pass arrows (above the spine)
fwd_pairs = [(positions[0]+1.7, positions[1]), (positions[1]+2.6, positions[2]),
             (positions[2]+2.6, positions[3])]
for x1, x2 in fwd_pairs:
    ax.annotate("", xy=(x2, 4.1), xytext=(x1, 4.1),
                arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
ax.text(7.8, 5.7, "forward pass: compute and remember every intermediate value",
        ha="center", fontsize=9.5, style="italic")

# backward pass arrows (below the spine), right to left, with local derivatives and running product
bwd_labels = [
    (positions[3]+0.5, positions[2]+1.8, r"local slope $\dfrac{dh}{dv}=2v=14$", r"running product: $14$"),
    (positions[2]+0.5, positions[1]+1.8, r"local slope $\dfrac{dv}{du}=1$", r"running product: $14\times 1=14$"),
    (positions[1]+0.5, positions[0]+1.3, r"local slope $\dfrac{du}{dx}=3$", r"running product: $14\times 3=42$"),
]
for x1, x2, local_lab, running_lab in bwd_labels:
    ax.annotate("", xy=(x2, 1.55), xytext=(x1, 1.55),
                arrowprops=dict(arrowstyle="-|>", color="#C0392B", lw=1.8,
                                 connectionstyle="arc3,rad=0.0"))
    xm = (x1 + x2) / 2
    ax.text(xm, 2.0, local_lab, ha="center", fontsize=9, color="#7D8794")
    ax.text(xm, 0.75, running_lab, ha="center", fontsize=9.3, color="#C0392B", fontweight="bold")

ax.text(7.8, -1.25,
        r"$h'(2) = \dfrac{dh}{dv}\cdot\dfrac{dv}{du}\cdot\dfrac{du}{dx} = 2v \times 1 \times 3 = 14\times 3 = 42$"
        "  --- the same 42 Program 3 verified two other ways",
        ha="center", fontsize=9.8)

plt.tight_layout()
plt.savefig("../figures/ch04_computational_graph.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 4 figures")
