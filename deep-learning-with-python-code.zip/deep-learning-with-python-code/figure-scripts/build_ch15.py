import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits

import os
os.makedirs("../figures", exist_ok=True)

BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
GRAY = "#7F8C8D"

# =================================================================
# 1. ch15_gradient_flow.png  --  plain vs residual, all 30 layers
# =================================================================
torch.manual_seed(0)
DEPTH, WIDTH = 30, 20


class PlainDeepNet(nn.Module):
    def __init__(self, depth=DEPTH, width=WIDTH):
        super().__init__()
        self.layers = nn.ModuleList([nn.Linear(width, width) for _ in range(depth)])
        self.act = nn.Sigmoid()

    def forward(self, x):
        for layer in self.layers:
            x = self.act(layer(x))
        return x


class ResidualDeepNet(nn.Module):
    def __init__(self, depth=DEPTH, width=WIDTH):
        super().__init__()
        self.layers = nn.ModuleList([nn.Linear(width, width) for _ in range(depth)])
        self.act = nn.Sigmoid()

    def forward(self, x):
        for layer in self.layers:
            x = self.act(layer(x)) + x
        return x


torch.manual_seed(0)
plain = PlainDeepNet()
torch.manual_seed(0)
resnet = ResidualDeepNet()
torch.manual_seed(1)
x = torch.randn(8, WIDTH)
y = torch.randn(8, WIDTH)


def grad_norms(model):
    model.zero_grad()
    loss = ((model(x) - y) ** 2).mean()
    loss.backward()
    return np.array([model.layers[i].weight.grad.norm().item() for i in range(DEPTH)])


plain_norms = grad_norms(plain)
res_norms = grad_norms(resnet)
np.savez("ch15_gradient_flow.npz", plain=plain_norms, res=res_norms)

FLOOR = 1e-20   # visualization floor only, for the exact-zero entries
plain_floored = np.clip(plain_norms, FLOOR, None)

fig, ax = plt.subplots(figsize=(7.6, 5.0))
layers = np.arange(DEPTH)
ax.plot(layers, plain_floored, "o-", color=ORANGE, label="plain network", ms=4)
ax.plot(layers, res_norms, "o-", color=GREEN, label="residual network", ms=4)
zero_mask = plain_norms == 0.0
ax.plot(layers[zero_mask], plain_floored[zero_mask], "x", color="black",
        ms=8, mew=2, label="underflowed to exact 0 (float32)")
ax.set_yscale("log")
ax.set_xlabel("layer index (0 = input side, 29 = output side)")
ax.set_ylabel("weight gradient norm (log scale)")
ax.set_title("Gradient flow: plain vs. residual, depth 30")
ax.legend(fontsize=9, loc="lower right")
ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig("../figures/ch15_gradient_flow.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch15_residual_block.png  --  labeled diagram
# =================================================================
fig, ax = plt.subplots(figsize=(7.8, 5.6))
ax.set_xlim(0, 9.6); ax.set_ylim(0, 10); ax.axis("off")


def block(cx, cy, w, h, text, fc):
    ax.add_patch(plt.Rectangle((cx - w / 2, cy - h / 2), w, h,
                                facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=10.5)


# main path, bottom to top
ax.text(2.5, 9.3, r"$x$", ha="center", fontsize=15, fontweight="bold")
ax.annotate("", xy=(2.5, 8.65), xytext=(2.5, 9.05),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
block(2.5, 7.9, 2.6, 0.9, "weight layer\n(conv / linear)", "#D4E6F1")
ax.annotate("", xy=(2.5, 6.95), xytext=(2.5, 7.45),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
block(2.5, 6.5, 1.8, 0.8, "ReLU", "#D5F5E3")
ax.annotate("", xy=(2.5, 5.55), xytext=(2.5, 6.1),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
block(2.5, 5.1, 2.6, 0.9, "weight layer\n(conv / linear)", "#D4E6F1")
ax.annotate("", xy=(2.5, 4.15), xytext=(2.5, 4.65),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
ax.text(2.5, 3.7, r"$F(x)$", ha="center", fontsize=13)

# sum junction
ax.add_patch(plt.Circle((4.0, 2.0), 0.42, facecolor="white", edgecolor="black", lw=1.6))
ax.text(4.0, 2.0, "+", ha="center", va="center", fontsize=18)
ax.annotate("", xy=(3.75, 2.35), xytext=(2.5, 3.35),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))

# output
ax.annotate("", xy=(4.0, 1.1), xytext=(4.0, 1.55),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))
ax.text(4.0, 0.7, r"$y = F(x) + x$", ha="center", fontsize=12.5, fontweight="bold")

# skip connection: clear of the weight-layer boxes (which span x in
# [1.2, 3.8]), running down at x=0.6 and into the sum junction.
ax.plot([0.6, 0.6], [9.3, 2.0], color=PURPLE, lw=2.2, solid_capstyle="round")
ax.plot([0.6, 2.5], [9.3, 9.3], color=PURPLE, lw=2.2, solid_capstyle="round")
ax.annotate("", xy=(3.62, 2.0), xytext=(0.6, 2.0),
            arrowprops=dict(arrowstyle="-|>", color=PURPLE, lw=2.2))
ax.text(0.6, 5.6, "identity\nskip\nconnection", ha="center", fontsize=9.3,
        color=PURPLE, bbox=dict(facecolor="white", edgecolor="none", pad=1.5))

# equation / explanation column, well clear of the main path
ax.text(7.3, 6.6, "Equation 15.1", ha="center", fontsize=10, style="italic", color=GRAY)
ax.text(7.3, 6.05, r"$y = F(x) + x$", fontsize=13, ha="center")
ax.text(7.3, 4.9, "Equation 15.2", ha="center", fontsize=10, style="italic", color=GRAY)
ax.text(7.3, 4.3, r"$\dfrac{\partial y}{\partial x} = \dfrac{\partial F}{\partial x} + 1$",
        fontsize=13, ha="center", color=PURPLE)
ax.text(7.3, 3.0,
        "the \"+1\" guarantees a\ngradient path that never\nvanishes, however small\n"
        + r"$\partial F/\partial x$" + " becomes",
        fontsize=8.8, ha="center", style="italic", color=PURPLE)

plt.tight_layout()
plt.savefig("../figures/ch15_residual_block.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch15_batchnorm.png  --  toy normalization + training curves
# =================================================================
digits = load_digits()
Xd = digits.data / 16.0
yd = digits.target
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(Xd, yd, test_size=0.2, random_state=0)
X_train_t = torch.tensor(X_train, dtype=torch.float32)
y_train_t = torch.tensor(y_train, dtype=torch.long)


class DeepMLP(nn.Module):
    def __init__(self, use_bn=False, width=30, in_dim=64, out_dim=10, depth=8):
        super().__init__()
        self.use_bn = use_bn
        dims = [in_dim] + [width] * (depth - 1) + [out_dim]
        self.linears = nn.ModuleList([nn.Linear(dims[i], dims[i + 1]) for i in range(depth)])
        if use_bn:
            self.bns = nn.ModuleList([nn.BatchNorm1d(width) for _ in range(depth - 1)])
        self.act = nn.ReLU()

    def forward(self, x):
        for i in range(len(self.linears) - 1):
            x = self.linears[i](x)
            if self.use_bn:
                x = self.bns[i](x)
            x = self.act(x)
        return self.linears[-1](x)


def full_loss_curve(model, epochs=100, lr=0.01):
    opt = optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    losses = []
    for _ in range(epochs):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(X_train_t), y_train_t)
        loss.backward()
        opt.step()
        losses.append(loss.item())
    return np.array(losses)


torch.manual_seed(0)
m_plain = DeepMLP(use_bn=False)
torch.manual_seed(0)
m_bn = DeepMLP(use_bn=True)
loss_plain = full_loss_curve(m_plain)
loss_bn = full_loss_curve(m_bn)
np.savez("ch15_batchnorm.npz", loss_plain=loss_plain, loss_bn=loss_bn)

toy = np.array([2.0, 4.0, 4.0, 6.0])
toy_hat = (toy - toy.mean()) / np.sqrt(((toy - toy.mean()) ** 2).mean() + 1e-5)

fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.6))
ax = axes[0]
xpos = np.arange(4)
w = 0.35
ax.bar(xpos - w / 2, toy, width=w, color=ORANGE, label="raw $x$")
ax.bar(xpos + w / 2, toy_hat, width=w, color=BLUE, label=r"normalized $\hat{x}$")
ax.axhline(0, color="black", lw=0.8)
ax.set_xticks(xpos); ax.set_xticklabels([f"$x_{{{i+1}}}$" for i in range(4)])
ax.set_title("Batch normalization on $x=(2,4,4,6)$")
ax.legend(fontsize=9)
ax.grid(alpha=0.3, axis="y")

ax = axes[1]
ax.plot(np.arange(1, 101), loss_plain, color=ORANGE, label="without batch norm")
ax.plot(np.arange(1, 101), loss_bn, color=GREEN, label="with batch norm")
ax.set_yscale("log")
ax.set_xlabel("epoch"); ax.set_ylabel("training loss (log scale)")
ax.set_title("8-layer MLP on digits")
ax.legend(fontsize=9)
ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig("../figures/ch15_batchnorm.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 4. ch15_transfer.png  --  transfer vs scratch, full 100-epoch curve
# =================================================================
torch.manual_seed(0)
np.random.seed(0)
X = digits.data.reshape(-1, 1, 8, 8) / 16.0
y = digits.target
idx = np.random.permutation(len(X))
pretrain_idx = idx[:1400]
scarce_idx = idx[1400:1430]
target_test_idx = idx[1430:]
X_pre = torch.tensor(X[pretrain_idx], dtype=torch.float32)
y_pre = torch.tensor(y[pretrain_idx], dtype=torch.long)
X_scarce = torch.tensor(X[scarce_idx], dtype=torch.float32)
y_scarce = torch.tensor(y[scarce_idx], dtype=torch.long)
X_ttest = torch.tensor(X[target_test_idx], dtype=torch.float32)
y_ttest = torch.tensor(y[target_test_idx], dtype=torch.long)


class FeatureCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.act = nn.ReLU()
        self.head = nn.Linear(16 * 2 * 2, 10)

    def features(self, x):
        x = self.pool(self.act(self.conv1(x)))
        x = self.pool(self.act(self.conv2(x)))
        return x.flatten(1)

    def forward(self, x):
        return self.head(self.features(x))


def acc(model, X_t, y_t):
    model.eval()
    with torch.no_grad():
        return (model(X_t).argmax(1) == y_t).float().mean().item()


loss_fn = nn.CrossEntropyLoss()
torch.manual_seed(0)
pretrained = FeatureCNN()
opt = optim.Adam(pretrained.parameters(), lr=0.01)
for _ in range(30):
    pretrained.train(); opt.zero_grad()
    loss_fn(pretrained(X_pre), y_pre).backward(); opt.step()

transfer_model = FeatureCNN()
transfer_model.load_state_dict(pretrained.state_dict())
for p in transfer_model.conv1.parameters():
    p.requires_grad = False
for p in transfer_model.conv2.parameters():
    p.requires_grad = False
torch.manual_seed(2)
transfer_model.head = nn.Linear(16 * 2 * 2, 10)
opt_t = optim.Adam(transfer_model.head.parameters(), lr=0.01)

torch.manual_seed(3)
scratch_model = FeatureCNN()
opt_s = optim.Adam(scratch_model.parameters(), lr=0.01)

transfer_curve, scratch_curve = [], []
for _ in range(100):
    transfer_model.train(); opt_t.zero_grad()
    loss_fn(transfer_model(X_scarce), y_scarce).backward(); opt_t.step()
    scratch_model.train(); opt_s.zero_grad()
    loss_fn(scratch_model(X_scarce), y_scarce).backward(); opt_s.step()
    transfer_curve.append(acc(transfer_model, X_ttest, y_ttest))
    scratch_curve.append(acc(scratch_model, X_ttest, y_ttest))

transfer_curve = np.array(transfer_curve)
scratch_curve = np.array(scratch_curve)
np.savez("ch15_transfer.npz", transfer=transfer_curve, scratch=scratch_curve)

fig, ax = plt.subplots(figsize=(7.6, 5.0))
epochs = np.arange(1, 101)
ax.plot(epochs, transfer_curve, color=GREEN, label="pretrained + frozen features (transfer)")
ax.plot(epochs, scratch_curve, color=ORANGE, label="trained from scratch")
ax.set_xlabel("epoch"); ax.set_ylabel("target-task test accuracy")
ax.set_title("Transfer learning with 30 scarce training examples")
ax.legend(fontsize=9, loc="lower right")
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("../figures/ch15_transfer.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 5. ch15_scratch_vs_transfer_datasize.png -- accuracy vs. target
#    training-set size, transfer vs. scratch (self-contained re-run of
#    Program 4, same pretrained backbone, same sizes).
# =================================================================
np.random.seed(0)
idx2 = np.random.permutation(len(X))
pretrain_idx2 = idx2[:1400]
remaining_idx2 = idx2[1400:]
target_test_idx2 = remaining_idx2[:100]
pool_idx2 = remaining_idx2[100:]

X_pre2 = torch.tensor(X[pretrain_idx2], dtype=torch.float32)
y_pre2 = torch.tensor(y[pretrain_idx2], dtype=torch.long)
X_ttest2 = torch.tensor(X[target_test_idx2], dtype=torch.float32)
y_ttest2 = torch.tensor(y[target_test_idx2], dtype=torch.long)

torch.manual_seed(0)
pretrained2 = FeatureCNN()
opt2 = optim.Adam(pretrained2.parameters(), lr=0.01)
for _ in range(30):
    pretrained2.train(); opt2.zero_grad()
    loss_fn(pretrained2(X_pre2), y_pre2).backward(); opt2.step()

TRAIN_SIZES = [10, 20, 30, 50, 100, 200, 297]
transfer_accs, scratch_accs = [], []
for size in TRAIN_SIZES:
    train_idx2 = pool_idx2[:size]
    X_tr = torch.tensor(X[train_idx2], dtype=torch.float32)
    y_tr = torch.tensor(y[train_idx2], dtype=torch.long)

    transfer_model2 = FeatureCNN()
    transfer_model2.load_state_dict(pretrained2.state_dict())
    for p in transfer_model2.conv1.parameters():
        p.requires_grad = False
    for p in transfer_model2.conv2.parameters():
        p.requires_grad = False
    torch.manual_seed(2)
    transfer_model2.head = nn.Linear(16 * 2 * 2, 10)
    opt_t2 = optim.Adam(transfer_model2.head.parameters(), lr=0.01)

    torch.manual_seed(3)
    scratch_model2 = FeatureCNN()
    opt_s2 = optim.Adam(scratch_model2.parameters(), lr=0.01)

    for _ in range(100):
        transfer_model2.train(); opt_t2.zero_grad()
        loss_fn(transfer_model2(X_tr), y_tr).backward(); opt_t2.step()
        scratch_model2.train(); opt_s2.zero_grad()
        loss_fn(scratch_model2(X_tr), y_tr).backward(); opt_s2.step()

    transfer_accs.append(acc(transfer_model2, X_ttest2, y_ttest2))
    scratch_accs.append(acc(scratch_model2, X_ttest2, y_ttest2))

np.savez("ch15_scratch_vs_transfer_datasize.npz", sizes=np.array(TRAIN_SIZES),
         transfer=np.array(transfer_accs), scratch=np.array(scratch_accs))

fig, ax = plt.subplots(figsize=(7.4, 4.9))
ax.plot(TRAIN_SIZES, transfer_accs, "o-", color=GREEN, linewidth=2,
        label="pretrained + frozen features (transfer)")
ax.plot(TRAIN_SIZES, scratch_accs, "o-", color=ORANGE, linewidth=2,
        label="trained from scratch")
ax.set_xscale("log")
ax.set_xticks(TRAIN_SIZES); ax.set_xticklabels([str(s) for s in TRAIN_SIZES])
ax.set_xlabel("target training-set size (log scale)")
ax.set_ylabel("target-task test accuracy (100 held-out examples)")
ax.set_title("Transfer's advantage shrinks as target training data grows")
ax.legend(fontsize=9.5, loc="lower right")
ax.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig("../figures/ch15_scratch_vs_transfer_datasize.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 5 figures written")
