import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

# =================================================================
# 1. ch18_attention_mechanism.png -- Q/K/V pipeline diagram
# =================================================================
fig, ax = plt.subplots(figsize=(9.6, 5.6))
ax.set_xlim(0, 12.0); ax.set_ylim(0, 7.4); ax.axis("off")


def box(cx, cy, w, h, text, fc, fontsize=10.5):
    ax.add_patch(plt.Rectangle((cx - w / 2, cy - h / 2), w, h,
                                facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fontsize)


def arrow(x0, y0, x1, y1, color="black", lw=1.6):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw))


box(1.6, 6.2, 1.8, 0.9, "Query\n$q$", "#FCF3CF")
box(1.6, 4.4, 1.8, 0.9, "Keys\n$k_1,\\dots,k_T$", "#D4E6F1")
box(1.6, 2.6, 1.8, 0.9, "Values\n$v_1,\\dots,v_T$", "#D5F5E3")

box(4.6, 5.3, 2.4, 1.0, "dot products\n$q\\cdot k_i$", "#EBDEF0")
arrow(2.5, 6.2, 3.4, 5.6)
arrow(2.5, 4.4, 3.4, 5.1)

box(7.2, 5.3, 2.2, 1.0, "scale by\n$1/\\sqrt{d_k}$", "#EBDEF0")
arrow(5.8, 5.3, 6.1, 5.3)

box(9.7, 5.3, 2.0, 1.0, "softmax\n$\\to \\alpha_i$", "#FADBD8")
arrow(8.3, 5.3, 8.7, 5.3)

box(7.2, 2.6, 2.8, 1.0, "weighted sum\n$\\sum_i \\alpha_i v_i$", "#FCF3CF")
arrow(9.7, 4.8, 8.2, 3.1)
arrow(2.5, 2.6, 5.8, 2.6)

box(10.3, 2.6, 1.6, 1.0, "context\nvector", "#D5F5E3")
arrow(8.6, 2.6, 9.5, 2.6)

ax.text(6.0, 0.9,
        r"$\alpha_i=\mathrm{softmax}_i\!\left(q\cdot k_i / \sqrt{d_k}\right)$, "
        r"one weight per key, all weights summing to 1",
        ha="center", fontsize=10, style="italic", color=GRAY)

ax.set_title("Scaled dot-product attention: one query, many keys and values",
             fontsize=12.5)
plt.tight_layout()
plt.savefig("../figures/ch18_attention_mechanism.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch18_self_attention.png -- Program 2's actual 3x3 weight matrix,
#    plus an all-pairs token diagram
# =================================================================
X = np.array([[1.0, 0.0, 1.0], [0.0, 1.0, 1.0], [1.0, 1.0, 0.0]])
W_Q = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
W_K = np.array([[0.0, 1.0], [1.0, 0.0], [1.0, 1.0]])
Q = X @ W_Q
K = X @ W_K
d_k = 2
scores = (Q @ K.T) / np.sqrt(d_k)
weights = np.exp(scores - scores.max(axis=1, keepdims=True))
weights = weights / weights.sum(axis=1, keepdims=True)

fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.6))

ax0 = axes[0]
ax0.set_xlim(0, 6); ax0.set_ylim(0, 6); ax0.axis("off")
positions = {1: (1.2, 4.6), 2: (4.8, 4.6), 3: (3.0, 1.4)}
for i in positions:
    for j in positions:
        if i == j:
            continue
        x0, y0 = positions[i]
        x1, y1 = positions[j]
        ax0.annotate("", xy=(x1, y1), xytext=(x0, y0),
                     arrowprops=dict(arrowstyle="-|>", color=GRAY, lw=1.0,
                                      alpha=0.6,
                                      connectionstyle=f"arc3,rad={0.15 if i<j else -0.15}"))
for i, (x, y) in positions.items():
    ax0.add_patch(plt.Circle((x, y), 0.55, facecolor="#D4E6F1", edgecolor="black", lw=1.4))
    ax0.text(x, y, f"$x_{i}$", ha="center", va="center", fontsize=13)
ax0.set_title("Self-attention: every token attends\nto every token, including itself", fontsize=11)

ax1 = axes[1]
im = ax1.imshow(weights, cmap="Blues", vmin=0, vmax=1)
ax1.set_xticks([0, 1, 2]); ax1.set_xticklabels(["$x_1$", "$x_2$", "$x_3$"])
ax1.set_yticks([0, 1, 2]); ax1.set_yticklabels(["$x_1$", "$x_2$", "$x_3$"])
ax1.set_xlabel("attending TO")
ax1.set_ylabel("attending FROM")
for i in range(3):
    for j in range(3):
        ax1.text(j, i, f"{weights[i, j]:.3f}", ha="center", va="center",
                  fontsize=10.5, color="white" if weights[i, j] > 0.5 else "black")
ax1.set_title("Program 2's actual attention weights", fontsize=11)
fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

plt.tight_layout()
plt.savefig("../figures/ch18_self_attention.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch18_retrieval_comparison.png -- MSE vs seq_len (attention vs RNN)
#    and the 5-example attention-weight heatmap from Program 3
# =================================================================
def make_batch(seq_len, n, rng):
    values = rng.standard_normal((n, seq_len)).astype(np.float32)
    positions = rng.integers(0, seq_len, size=n)
    markers = np.zeros((n, seq_len), dtype=np.float32)
    markers[np.arange(n), positions] = 1.0
    targets = values[np.arange(n), positions]
    Xb = np.stack([values, markers], axis=-1)
    return torch.tensor(Xb), torch.tensor(targets), positions


class AttentionRetriever(nn.Module):
    def __init__(self, d_model=16):
        super().__init__()
        self.key_proj = nn.Linear(2, d_model)
        self.val_proj = nn.Linear(2, d_model)
        self.query = nn.Parameter(torch.randn(d_model))
        self.head = nn.Linear(d_model, 1)
        self.d_model = d_model

    def forward(self, x):
        K = self.key_proj(x)
        V = self.val_proj(x)
        scores = (K @ self.query) / self.d_model ** 0.5
        w = torch.softmax(scores, dim=1)
        context = (w.unsqueeze(-1) * V).sum(dim=1)
        return self.head(context).squeeze(-1), w


class RNNRetriever(nn.Module):
    def __init__(self, hidden=16):
        super().__init__()
        self.rnn = nn.RNN(input_size=2, hidden_size=hidden, batch_first=True)
        self.head = nn.Linear(hidden, 1)

    def forward(self, x):
        _, h_n = self.rnn(x)
        return self.head(h_n.squeeze(0)).squeeze(-1)


def train_and_test(model_fn, seq_len, train_rng, test_rng, epochs=300):
    torch.manual_seed(0)
    model = model_fn()
    opt = optim.Adam(model.parameters(), lr=0.01)
    X_train, y_train, _ = make_batch(seq_len, 1000, train_rng)
    X_test, y_test, _ = make_batch(seq_len, 200, test_rng)
    for _ in range(epochs):
        opt.zero_grad()
        out = model(X_train)
        pred = out[0] if isinstance(out, tuple) else out
        loss = ((pred - y_train) ** 2).mean()
        loss.backward()
        opt.step()
    with torch.no_grad():
        out = model(X_test)
        pred = out[0] if isinstance(out, tuple) else out
        return ((pred - y_test) ** 2).mean().item()


seq_lens = [10, 20, 50, 100]
att_mses, rnn_mses = [], []
for seq_len in seq_lens:
    att_mses.append(train_and_test(AttentionRetriever, seq_len,
                                    np.random.default_rng(seq_len),
                                    np.random.default_rng(seq_len + 1000)))
    rnn_mses.append(train_and_test(RNNRetriever, seq_len,
                                    np.random.default_rng(seq_len),
                                    np.random.default_rng(seq_len + 1000)))
np.savez("ch18_retrieval_mse.npz", seq_lens=np.array(seq_lens),
         att=np.array(att_mses), rnn=np.array(rnn_mses))

# Retrain one attention model at seq_len=50 and inspect its weights on
# 5 fresh examples -- the same computation as Program 3 Part B, kept
# self-contained here so this script does not depend on programs/.
torch.manual_seed(0)
insp_model = AttentionRetriever()
opt = optim.Adam(insp_model.parameters(), lr=0.01)
X_train, y_train, _ = make_batch(50, 1000, np.random.default_rng(50))
for _ in range(300):
    opt.zero_grad()
    pred, _ = insp_model(X_train)
    loss = ((pred - y_train) ** 2).mean()
    loss.backward()
    opt.step()
X_inspect, y_inspect, true_positions = make_batch(50, 5, np.random.default_rng(123))
with torch.no_grad():
    _, weights_t = insp_model(X_inspect)
weight_matrix = weights_t.numpy()

fig, axes = plt.subplots(1, 2, figsize=(12.6, 4.8))

ax0 = axes[0]
ax0.plot(seq_lens, att_mses, "o-", color=BLUE, lw=2, ms=6, label="attention retriever")
ax0.plot(seq_lens, rnn_mses, "o-", color=ORANGE, lw=2, ms=6, label="plain RNN")
ax0.set_yscale("log")
ax0.set_xlabel("sequence length $T$")
ax0.set_ylabel("test MSE (log scale)")
ax0.set_title("Recovering the value at a random marked position")
ax0.legend(fontsize=9.5)
ax0.grid(alpha=0.3, which="both")

ax1 = axes[1]
im = ax1.imshow(weight_matrix, cmap="viridis", aspect="auto")
for i, p in enumerate(true_positions):
    ax1.plot(p, i, "o", mfc="none", mec="red", mew=2.0, ms=11)
ax1.set_xlabel("sequence position")
ax1.set_ylabel("test example")
ax1.set_yticks(range(len(true_positions)))
ax1.set_title("Learned attention weights, $T=50$\n(red circle = true marked position)")
fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04, label="attention weight")

plt.tight_layout()
plt.savefig("../figures/ch18_retrieval_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 4. ch18_sentence_attention.png -- self-attention heatmap for a real
#    short sentence (Program 4), with word tick labels. "dog" and "it"
#    carry a shared embedding feature standing in for coreference; every
#    weight below is computed with the chapter's own Equation 18.6, not
#    hand-drawn.
# =================================================================
sentence4 = ["the", "dog", "barked", "because", "it", "was", "scared"]
T4 = len(sentence4)
a4, b4 = 2.0, 3.0
d_model4 = 7
identity_dim4 = {"the": 0, "dog": 1, "barked": 2, "because": 3, "was": 4, "scared": 5}
E4 = np.zeros((T4, d_model4))
for word, dim in identity_dim4.items():
    E4[sentence4.index(word), dim] = a4
E4[sentence4.index("dog"), 6] = b4
E4[sentence4.index("it"), 6] = b4

scores4 = (E4 @ E4.T) / np.sqrt(d_model4)
weights4 = np.exp(scores4 - scores4.max(axis=1, keepdims=True))
weights4 = weights4 / weights4.sum(axis=1, keepdims=True)

fig, ax = plt.subplots(figsize=(7.6, 6.6))
im = ax.imshow(weights4, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(T4)); ax.set_xticklabels(sentence4, rotation=40, ha="right", fontsize=10.5)
ax.set_yticks(range(T4)); ax.set_yticklabels(sentence4, fontsize=10.5)
ax.set_xlabel("attending TO", fontsize=10.5)
ax.set_ylabel("attending FROM", fontsize=10.5)
for i in range(T4):
    for j in range(T4):
        ax.text(j, i, f"{weights4[i, j]:.2f}", ha="center", va="center", fontsize=8.0,
                color="white" if weights4[i, j] > 0.5 else "black")
ax.set_title("Self-attention weights for a real sentence\n"
              "(\"dog\" and \"it\" share a coreference feature in their embeddings)",
              fontsize=11.5)
fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="attention weight")
plt.tight_layout()
plt.savefig("../figures/ch18_sentence_attention.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 4 figures written")
