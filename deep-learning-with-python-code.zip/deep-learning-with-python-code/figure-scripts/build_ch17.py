import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

# =================================================================
# 1. ch17_lstm_cell.png -- labeled LSTM cell diagram
# =================================================================
fig, ax = plt.subplots(figsize=(9.2, 6.4))
ax.set_xlim(0, 12.4); ax.set_ylim(0, 8.6); ax.axis("off")


def gate(cx, cy, text, fc, w=1.5, h=0.95):
    ax.add_patch(plt.Rectangle((cx - w / 2, cy - h / 2), w, h,
                                facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=10)


def dot(cx, cy, text=r"$\times$", r=0.32):
    ax.add_patch(plt.Circle((cx, cy), r, facecolor="white", edgecolor="black", lw=1.4))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=13)


def arrow(x0, y0, x1, y1, color="black", lw=1.5):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw))


# cell-state highway, running straight across the top
ax.annotate("", xy=(11.9, 7.4), xytext=(0.5, 7.4),
            arrowprops=dict(arrowstyle="-|>", color=RED, lw=2.6))
ax.text(0.5, 7.85, r"$c_{t-1}$", fontsize=13, color=RED, ha="left")
ax.text(11.9, 7.85, r"$c_t$", fontsize=13, color=RED, ha="right")
ax.text(6.2, 8.25, "cell state: the gradient highway (mostly linear, elementwise)",
        ha="center", fontsize=9.5, style="italic", color=RED)

# forget gate multiply onto the highway
dot(2.6, 7.4)
arrow(2.6, 6.55, 2.6, 7.08)
gate(2.6, 5.9, "forget gate\n$f_t=\\sigma(\\cdot)$", "#FADBD8")

# new-info addition onto the highway
ax.add_patch(plt.Circle((6.2, 7.4), 0.32, facecolor="white", edgecolor="black", lw=1.4))
ax.text(6.2, 7.4, "+", ha="center", va="center", fontsize=15)
dot(6.2, 6.35, r"$\times$")
arrow(6.2, 6.67, 6.2, 7.08)
gate(5.0, 5.4, "input gate\n$i_t=\\sigma(\\cdot)$", "#D5F5E3", w=1.6)
gate(7.4, 5.4, "candidate\n$g_t=\\tanh(\\cdot)$", "#D4E6F1", w=1.6)
arrow(5.0, 5.9, 5.7, 6.15)
arrow(7.4, 5.9, 6.7, 6.15)

# output gate and hidden state: c_t -> tanh -> (times o_t) -> h_t, in that
# order -- the tanh is applied to the cell state BEFORE the output gate
# multiplies it; h_t = o_t * tanh(c_t), never tanh(o_t * c_t).
arrow(9.4, 7.05, 9.4, 6.85, color=RED, lw=2.0)
ax.text(9.4, 6.5, r"$\tanh$", ha="center", va="center", fontsize=10,
        bbox=dict(boxstyle="round", fc="#EAECEE", ec="black"))
dot(9.4, 5.4, r"$\times$")
arrow(9.4, 6.25, 9.4, 5.73)
gate(10.7, 4.4, "output gate\n$o_t=\\sigma(\\cdot)$", "#FCF3CF", w=1.6)
arrow(10.45, 4.9, 9.72, 5.22)
arrow(9.4, 5.08, 9.4, 4.35)
ax.text(9.4, 3.95, r"$h_t$", fontsize=13, ha="center", fontweight="bold")

# shared input at the bottom
ax.text(6.0, 0.6, r"$x_t,\ h_{t-1}$  feed every gate and the candidate above",
        ha="center", fontsize=10, style="italic", color=GRAY)
for cx, cy in [(2.6, 5.42), (5.0, 4.9), (7.4, 4.9), (10.7, 3.9)]:
    arrow(6.0, 1.0, cx, cy, color=GRAY, lw=1.1)

ax.set_title("The LSTM cell: gates around an (almost) linear cell-state highway",
             fontsize=12)
plt.tight_layout()
plt.savefig("../figures/ch17_lstm_cell.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch17_gru_cell.png -- labeled GRU cell diagram
#
# h_t = z_t * h_{t-1} + (1 - z_t) * n_t is a BLEND of two branches
# that must merge at a single "+" junction -- it is not a running sum
# that then gets rescaled. So the highway carries z_t*h_{t-1} up to
# one "+" junction, the (1-z_t)*n_t branch joins it there from below,
# and h_t leaves on the far side of that same junction.
# =================================================================
fig, ax = plt.subplots(figsize=(9.6, 6.4))
ax.set_xlim(0, 12.5); ax.set_ylim(0, 8.2); ax.axis("off")

HWY_Y = 7.0
ax.annotate("", xy=(11.9, HWY_Y), xytext=(0.5, HWY_Y),
            arrowprops=dict(arrowstyle="-|>", color=RED, lw=2.6))
ax.text(0.5, HWY_Y + 0.4, r"$h_{t-1}$", fontsize=13, color=RED, ha="left")
ax.text(11.9, HWY_Y + 0.4, r"$h_t$", fontsize=13, color=RED, ha="right")
ax.text(6.2, HWY_Y + 0.85,
        "hidden state does double duty: memory and output, no separate cell state",
        ha="center", fontsize=9.5, style="italic", color=RED)

# branch 1, on the highway itself: z_t * h_{t-1}
dot(4.0, HWY_Y, r"$\times$")
gate(4.0, 5.5, "update gate\n$z_t=\\sigma(\\cdot)$", "#D5F5E3", w=1.7)
arrow(4.0, 5.98, 4.0, HWY_Y - 0.35)

# single merge junction: the ONLY place the two branches combine
ax.add_patch(plt.Circle((8.8, HWY_Y), 0.34, facecolor="white", edgecolor="black", lw=1.6))
ax.text(8.8, HWY_Y, "+", ha="center", va="center", fontsize=15)

# branch 2, off the highway, merging in from below: (1 - z_t) * n_t
dot(8.8, 5.3, r"$\times$")
ax.text(7.55, 5.3, r"$1-z_t$", fontsize=10, ha="center")
arrow(8.8, 5.65, 8.8, HWY_Y - 0.37)
gate(8.8, 3.9, "candidate\n$n_t=\\tanh(\\cdot)$", "#D4E6F1", w=1.8)
arrow(8.8, 4.38, 8.8, 4.8)

dot(5.6, 2.7, r"$\times$")
gate(5.6, 1.3, "reset gate\n$r_t=\\sigma(\\cdot)$", "#FADBD8", w=1.7)
arrow(5.6, 1.8, 5.6, 2.35)
ax.text(5.6, 3.55, r"$W_{hn}h_{t-1}$", fontsize=9.5, ha="center")
arrow(5.6, 3.02, 7.9, 3.75)
ax.text(3.6, 2.7, "resets how much\nof the past feeds\nthe candidate", fontsize=8.3,
        ha="center", style="italic", color=GRAY)

ax.text(6.4, 0.15, r"$x_t,\ h_{t-1}$  feed every gate and the candidate above",
        ha="center", fontsize=10, style="italic", color=GRAY)
arrow(4.0, 4.55, 4.0, 5.02, color=GRAY, lw=1.1)   # up into update gate
arrow(5.6, 0.5, 5.6, 0.82, color=GRAY, lw=1.1)    # up into reset gate
arrow(8.8, 2.55, 8.8, 3.42, color=GRAY, lw=1.1)   # up into candidate

ax.set_title("The GRU cell: two gates, one merged memory/output state",
             fontsize=12)
plt.tight_layout()
plt.savefig("../figures/ch17_gru_cell.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch17_gradient_comparison.png -- RNN vs LSTM vs GRU, default vs
#    biased initialization (two panels, log scale)
# =================================================================
T, HIDDEN = 50, 20
CHECKPOINTS_FULL = np.arange(1, T + 1)


def gradient_norms_full(cell_type, gate_bias=0.0):
    torch.manual_seed(0)
    if cell_type == "RNN":
        cell = nn.RNNCell(1, HIDDEN)
    elif cell_type == "GRU":
        cell = nn.GRUCell(1, HIDDEN)
        with torch.no_grad():
            cell.bias_ih[HIDDEN:2 * HIDDEN] += gate_bias
    else:
        cell = nn.LSTMCell(1, HIDDEN)
        with torch.no_grad():
            cell.bias_ih[HIDDEN:2 * HIDDEN] += gate_bias

    torch.manual_seed(0)
    xs = [torch.randn(1, 1) for _ in range(T)]

    h = torch.zeros(1, HIDDEN)
    c = torch.zeros(1, HIDDEN) if cell_type == "LSTM" else None
    states = []
    for x in xs:
        if cell_type == "LSTM":
            h, c = cell(x, (h, c))
            c.retain_grad()
            states.append(c)
        else:
            h = cell(x, h)
            h.retain_grad()
            states.append(h)

    target = torch.randn(1, HIDDEN)
    loss = ((states[-1] - target) ** 2).mean()
    loss.backward()
    return np.array([s.grad.norm().item() for s in states])


default_norms = {ct: gradient_norms_full(ct, 0.0) for ct in ["RNN", "LSTM", "GRU"]}
biased_norms = {
    "RNN": gradient_norms_full("RNN", 0.0),
    "LSTM": gradient_norms_full("LSTM", 2.0),
    "GRU": gradient_norms_full("GRU", 2.0),
}
np.savez("ch17_gradient_comparison.npz",
         **{f"default_{k}": v for k, v in default_norms.items()},
         **{f"biased_{k}": v for k, v in biased_norms.items()})

fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.9), sharey=True)
colors = {"RNN": ORANGE, "LSTM": BLUE, "GRU": GREEN}

for ax, norms, title in [
    (axes[0], default_norms, "Default initialization\n(forget/update gate bias = 0)"),
    (axes[1], biased_norms, "Forget/update gate bias = +2.0\n(standard initialization trick)"),
]:
    for ct in ["RNN", "LSTM", "GRU"]:
        ax.plot(CHECKPOINTS_FULL, norms[ct], "-", color=colors[ct], lw=2.0, label=ct)
    ax.set_yscale("log")
    ax.set_xlabel("timestep $t$")
    ax.set_title(title, fontsize=11)
    ax.grid(alpha=0.3, which="both")

axes[0].set_ylabel("gradient norm reaching the state\nat timestep $t$ (log scale)")
axes[0].legend(fontsize=9.5, loc="lower right")
plt.tight_layout()
plt.savefig("../figures/ch17_gradient_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 3 figures written")

# =================================================================
# 4. ch17_same_task.png -- Program 5: RNN vs GRU vs LSTM trained on
#    Chapter 16's recall-the-first-input task (Part A: SGD; Part B: Adam)
# =================================================================
# Values exactly as printed by programs/ch17_program5.py (a ~10-minute
# run: 5 models x 4 lengths with SGD, then 5 models x 3 lengths x 3 seeds
# with Adam). Rerun that program to regenerate them.
LENGTHS_A = [5, 10, 20, 40]
PART_A = {
    "RNN, default":  [1.000, 1.000, 0.450, 0.465],
    "GRU, default":  [1.000, 0.475, 0.475, 0.480],
    "LSTM, default": [0.740, 0.465, 0.440, 0.480],
    "GRU, bias +2":  [0.680, 0.595, 0.555, 0.480],
    "LSTM, bias +2": [1.000, 1.000, 0.440, 0.480],
}
LENGTHS_B = [20, 80, 160]
PART_B = {   # (mean accuracy over seeds 0-2, number of runs with accuracy >= 0.95)
    "RNN, default":  [(1.000, 3), (0.820, 2), (0.493, 0)],
    "GRU, default":  [(1.000, 3), (0.492, 0), (0.473, 0)],
    "LSTM, default": [(0.917, 2), (0.483, 0), (0.488, 0)],
    "GRU, bias +2":  [(1.000, 3), (1.000, 3), (0.723, 1)],
    "LSTM, bias +2": [(1.000, 3), (0.835, 0), (0.823, 2)],
}
STYLE = {   # colour by cell; hollow/dashed = default init, solid = gate bias +2
    "RNN, default":  dict(color=ORANGE, ls="-", marker="o", fill=True),
    "GRU, default":  dict(color=GREEN, ls="--", marker="s", fill=False),
    "LSTM, default": dict(color=BLUE, ls="--", marker="^", fill=False),
    "GRU, bias +2":  dict(color=GREEN, ls="-", marker="s", fill=True),
    "LSTM, bias +2": dict(color=BLUE, ls="-", marker="^", fill=True),
}

fig, axes = plt.subplots(1, 2, figsize=(12.6, 4.9), gridspec_kw={"width_ratios": [1, 1.25]})
ax = axes[0]
offsets = np.linspace(-0.06, 0.06, len(PART_A))       # tiny x-jitter so tied points stay visible
for (name, accs), dx in zip(PART_A.items(), offsets):
    s = STYLE[name]
    xs = np.arange(len(LENGTHS_A)) + dx
    ax.plot(xs, accs, ls=s["ls"], color=s["color"], marker=s["marker"], ms=7, lw=1.8,
            mfc=s["color"] if s["fill"] else "white", mec=s["color"], label=name)
ax.axhline(0.5, color=GRAY, lw=1.0, ls=":")
ax.text(3.35, 0.515, "chance", color=GRAY, fontsize=9, ha="right", va="bottom")
ax.set_xticks(range(len(LENGTHS_A)))
ax.set_xticklabels([f"T = {L}" for L in LENGTHS_A])
ax.set_xlim(-0.3, 3.4)
ax.set_ylim(0.38, 1.06)
ax.set_ylabel("test accuracy")
ax.set_title("Part A: Chapter 16's recipe (plain SGD, lr = 0.5)", fontsize=11)
ax.grid(alpha=0.3)
ax.legend(fontsize=8.8, loc="upper right")

ax = axes[1]
n_models, width = len(PART_B), 0.15
for i, (name, cells) in enumerate(PART_B.items()):
    s = STYLE[name]
    xs = np.arange(len(LENGTHS_B)) + (i - (n_models - 1) / 2) * width
    means = [m for m, _ in cells]
    ax.bar(xs, means, width=width * 0.92, color=s["color"] if s["fill"] else "white",
           edgecolor=s["color"], hatch=None if s["fill"] else "///", lw=1.4, label=name)
    for x, (m, solved) in zip(xs, cells):
        ax.text(x, m + 0.012, f"{solved}/3", ha="center", va="bottom", fontsize=8.2)
ax.axhline(0.5, color=GRAY, lw=1.0, ls=":")
ax.set_xticks(range(len(LENGTHS_B)))
ax.set_xticklabels([f"T = {L}" for L in LENGTHS_B])
ax.set_ylim(0.38, 1.12)
ax.set_ylabel("mean test accuracy over 3 seeds")
ax.set_title("Part B: Adam (lr = 0.01); label = runs reaching 0.95", fontsize=11)
ax.grid(alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("../figures/ch17_same_task.png", dpi=200, bbox_inches="tight")
plt.close()
