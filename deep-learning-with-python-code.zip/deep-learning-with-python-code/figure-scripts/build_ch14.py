import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"

# ---------- 1. ch14_convolution_slide.png ----------
image = np.array([
    [1,2,3,0,1],[0,1,2,3,1],[1,0,1,2,0],[2,1,0,1,2],[0,2,1,0,1]
])
kernel = np.array([[1,0,-1],[1,0,-1],[1,0,-1]])
output = np.array([[-4,-2,4],[0,-4,0],[1,0,-1]])

fig, axes = plt.subplots(1, 3, figsize=(12.5, 4.6))
ax = axes[0]
ax.set_xlim(0,5); ax.set_ylim(0,5); ax.set_aspect("equal"); ax.invert_yaxis()
for i in range(5):
    for j in range(5):
        fc = "#FDEBD0" if (i<3 and j<3) else "#EAF2F8"
        ax.add_patch(plt.Rectangle((j,i),1,1, facecolor=fc, edgecolor="black", lw=0.8))
        ax.text(j+0.5,i+0.5,str(image[i,j]), ha="center", va="center", fontsize=11)
ax.add_patch(plt.Rectangle((0,0),3,3, facecolor="none", edgecolor=ORANGE, lw=3))
ax.set_title("Input (5$\\times$5)\nkernel positioned at top-left", fontsize=10.5)
ax.axis("off")

ax = axes[1]
ax.set_xlim(0,3); ax.set_ylim(0,3); ax.set_aspect("equal"); ax.invert_yaxis()
for i in range(3):
    for j in range(3):
        ax.add_patch(plt.Rectangle((j,i),1,1, facecolor="#D4E6F1", edgecolor="black", lw=0.8))
        ax.text(j+0.5,i+0.5,str(kernel[i,j]), ha="center", va="center", fontsize=12)
ax.set_title("Kernel (3$\\times$3)", fontsize=10.5)
ax.axis("off")

ax = axes[2]
ax.set_xlim(0,3); ax.set_ylim(0,3); ax.set_aspect("equal"); ax.invert_yaxis()
for i in range(3):
    for j in range(3):
        fc = "#D5F5E3" if (i==0 and j==0) else "#EAF2F8"
        ax.add_patch(plt.Rectangle((j,i),1,1, facecolor=fc, edgecolor="black", lw=0.8))
        ax.text(j+0.5,i+0.5,str(int(output[i,j])), ha="center", va="center", fontsize=12)
ax.set_title("Output (3$\\times$3)\ntop-left cell shown", fontsize=10.5)
ax.axis("off")

fig.suptitle("Sliding a 3$\\times$3 kernel over a 5$\\times$5 input: one position computed", fontsize=12, y=1.03)
plt.tight_layout()
plt.savefig("../figures/ch14_convolution_slide.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch14_param_efficiency.png ----------
sizes = [8, 16, 32, 64, 128, 256]
fc_counts = [(s*s)*10 + 10 for s in sizes]
conv_count = (3*3*1+1)*10

fig, ax = plt.subplots(figsize=(7.2, 4.8))
ax.plot(sizes, fc_counts, "o-", color=ORANGE, linewidth=2, label="fully connected (to 10 units)")
ax.axhline(conv_count, color=BLUE, linewidth=2, linestyle="--", label=f"convolution (3$\\times$3, 10 filters) = {conv_count}")
ax.set_yscale("log")
ax.set_xlabel("image side length (pixels)"); ax.set_ylabel("parameters (log scale)")
ax.set_title("Weight sharing: convolution's parameter count never grows with image size")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch14_param_efficiency.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch14_cnn_architecture.png ----------
fig, ax = plt.subplots(figsize=(11.5, 3.8))
ax.set_xlim(0, 15.5); ax.set_ylim(0, 5); ax.axis("off")

def block(x, y, w, h, text, fc, fontsize=9):
    ax.add_patch(mpatches.FancyBboxPatch((x,y),w,h, boxstyle="round,pad=0.05",
                 facecolor=fc, edgecolor="black", lw=1.2))
    ax.text(x+w/2, y+h/2, text, ha="center", va="center", fontsize=fontsize)

stages = [
    ("input\n8$\\times$8$\\times$1", "#EAF2F8", 1.4),
    ("conv1\n8 filters\n8$\\times$8$\\times$8", "#D4E6F1", 1.7),
    ("ReLU", "#D4E6F1", 1.1),
    ("max pool\n4$\\times$4$\\times$8", "#A9CCE3", 1.5),
    ("conv2\n16 filters\n4$\\times$4$\\times$16", "#D4E6F1", 1.7),
    ("ReLU", "#D4E6F1", 1.1),
    ("max pool\n2$\\times$2$\\times$16", "#A9CCE3", 1.5),
    ("flatten\n64", "#FDEBD0", 1.2),
    ("FC\n10 classes", "#FADBD8", 1.4),
]
x = 0.3
for text, fc, w in stages:
    block(x, 1.6, w, 1.8, text, fc)
    if x > 0.3:
        ax.annotate("", xy=(x,2.5), xytext=(x-0.25,2.5),
                    arrowprops=dict(arrowstyle="-|>", color="black", lw=1.3))
    x += w + 0.25

plt.tight_layout()
plt.savefig("../figures/ch14_cnn_architecture.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch14_cnn_vs_mlp.png ----------
data = np.load("ch14_cnn_vs_mlp.npz")
cnn_accs, mlp_accs = data["cnn"], data["mlp"]
epochs = np.arange(1, len(cnn_accs)+1)

fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(epochs, cnn_accs, color=BLUE, linewidth=2, label="CNN (1,898 parameters)")
ax.plot(epochs, mlp_accs, color=ORANGE, linewidth=2, label="MLP (2,110 parameters)")
ax.set_xlabel("epoch"); ax.set_ylabel("test accuracy")
ax.set_title("CNN versus MLP on the digits dataset, roughly parameter-matched")
ax.legend(fontsize=10, loc="lower right")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch14_cnn_vs_mlp.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 5. ch14_feature_maps.png ----------
# Self-contained re-run of Program 5: train the identical SmallCNN (same
# seed, same 50 epochs), then show one test digit alongside its 8 conv1
# feature maps.
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
Xd = digits.images.astype(np.float32) / 16.0
yd = digits.target
Xd_train, Xd_test, yd_train, yd_test = train_test_split(Xd, yd, test_size=0.2, random_state=0)
Xd_train_img = torch.from_numpy(Xd_train).unsqueeze(1)
Xd_test_img = torch.from_numpy(Xd_test).unsqueeze(1)
yd_train_t = torch.from_numpy(yd_train).long()


class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.fc = nn.Linear(16 * 2 * 2, 10)

    def forward(self, x):
        f1 = torch.relu(self.conv1(x))
        x = self.pool(f1)
        x = self.pool(torch.relu(self.conv2(x)))
        return self.fc(x.view(x.size(0), -1))

    def conv1_features(self, x):
        return torch.relu(self.conv1(x))


torch.manual_seed(0)
cnn = SmallCNN()
opt = torch.optim.Adam(cnn.parameters(), lr=0.01)
loss_fn = nn.CrossEntropyLoss()
for _ in range(50):
    cnn.train(); opt.zero_grad()
    loss_fn(cnn(Xd_train_img), yd_train_t).backward()
    opt.step()

sample_image = Xd_test_img[0:1]
sample_label = int(yd_test[0])
with torch.no_grad():
    fmaps = cnn.conv1_features(sample_image).squeeze(0).numpy()   # (8, 8, 8)

fig, axes = plt.subplots(3, 3, figsize=(7.5, 7.8))
axes[0, 0].imshow(sample_image.squeeze().numpy(), cmap="gray")
axes[0, 0].set_title(f"input (digit {sample_label})", fontsize=10)
for f in range(8):
    r, c = divmod(f + 1, 3)
    ax = axes[r, c]
    im = ax.imshow(fmaps[f], cmap="viridis")
    ax.set_title(f"filter {f}", fontsize=10)
for ax in axes.flat:
    ax.set_xticks([]); ax.set_yticks([])
fig.suptitle("conv1's 8 learned feature maps, one trained test digit", fontsize=12.5, y=0.99)
plt.tight_layout(rect=[0, 0, 1, 0.97])
plt.savefig("../figures/ch14_feature_maps.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 6. ch14_real_image_conv.png ----------
# Self-contained re-run of Program 6: hand-designed kernels applied to
# an actual photograph instead of a synthetic 5x5 grid.
import matplotlib.cbook as cbook
import torch.nn.functional as Fnn

rgb = plt.imread(cbook.get_sample_data("grace_hopper.jpg", asfileobj=False)).astype(np.float32) / 255.0
gray = rgb @ np.array([0.299, 0.587, 0.114], dtype=np.float32)
gray = gray[::4, ::4]
img_t = torch.from_numpy(gray).unsqueeze(0).unsqueeze(0)

vertical_edges = torch.tensor([[1., 0., -1.], [1., 0., -1.], [1., 0., -1.]]).unsqueeze(0).unsqueeze(0)
horizontal_edges = vertical_edges.transpose(2, 3).contiguous()
blur = (torch.ones(3, 3) / 9.0).unsqueeze(0).unsqueeze(0)

v_out = Fnn.conv2d(img_t, vertical_edges, padding=1).squeeze().numpy()
h_out = Fnn.conv2d(img_t, horizontal_edges, padding=1).squeeze().numpy()
b_out = Fnn.conv2d(img_t, blur, padding=1).squeeze().numpy()

fig, axes = plt.subplots(2, 2, figsize=(8.2, 8.6))
axes[0, 0].imshow(gray, cmap="gray")
axes[0, 0].set_title("original (grayscale, downsampled)", fontsize=10.5)
axes[0, 1].imshow(v_out, cmap="gray")
axes[0, 1].set_title("vertical-edge kernel", fontsize=10.5)
axes[1, 0].imshow(h_out, cmap="gray")
axes[1, 0].set_title("horizontal-edge kernel", fontsize=10.5)
axes[1, 1].imshow(b_out, cmap="gray")
axes[1, 1].set_title("3$\\times$3 blur kernel", fontsize=10.5)
for ax in axes.flat:
    ax.set_xticks([]); ax.set_yticks([])
fig.suptitle("The same hand-designed kernels, applied to a real photograph", fontsize=12.5, y=0.995)
plt.tight_layout(rect=[0, 0, 1, 0.97])
plt.savefig("../figures/ch14_real_image_conv.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 6 figures")
