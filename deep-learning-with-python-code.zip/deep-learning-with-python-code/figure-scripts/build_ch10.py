import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
RED = "#C0392B"

# ---------- 1. ch10_backward_flow.png ----------
fig, ax = plt.subplots(figsize=(9.0, 5.6))
ax.set_xlim(0, 11); ax.set_ylim(0, 7.4); ax.axis("off")

# forward structure (faint)
ax.add_patch(plt.Circle((1.2, 5.0), 0.4, facecolor="#EAF2F8", edgecolor="black", lw=1.2, zorder=3))
ax.text(1.2, 5.0, "$x_1$", ha="center", va="center", fontsize=10)
ax.add_patch(plt.Circle((1.2, 2.0), 0.4, facecolor="#EAF2F8", edgecolor="black", lw=1.2, zorder=3))
ax.text(1.2, 2.0, "$x_2$", ha="center", va="center", fontsize=10)

ax.add_patch(plt.Circle((5.0, 5.5), 0.5, facecolor="#D4E6F1", edgecolor="black", lw=1.2, zorder=3))
ax.text(5.0, 5.5, "$a^{[1]}_1$", ha="center", va="center", fontsize=9.5)
ax.add_patch(plt.Circle((5.0, 1.5), 0.5, facecolor="#D4E6F1", edgecolor="black", lw=1.2, zorder=3))
ax.text(5.0, 1.5, "$a^{[1]}_2$", ha="center", va="center", fontsize=9.5)

ax.add_patch(plt.Circle((8.8, 3.5), 0.5, facecolor="#FDEBD0", edgecolor="black", lw=1.2, zorder=3))
ax.text(8.8, 3.5, "$a^{[2]}$", ha="center", va="center", fontsize=9.5)

# forward arrows (light gray)
for (x1,y1),(x2,y2) in [((1.55,5.0),(4.55,5.5)), ((1.55,5.0),(4.55,1.5)),
                         ((1.55,2.0),(4.55,5.5)), ((1.55,2.0),(4.55,1.5)),
                         ((5.45,5.5),(8.35,3.5)), ((5.45,1.5),(8.35,3.5))]:
    ax.annotate("", xy=(x2,y2), xytext=(x1,y1),
                arrowprops=dict(arrowstyle="-|>", color="#BFC9CA", lw=1.3), zorder=1)

# backward delta arrows (red, above the forward path)
ax.annotate("", xy=(5.5, 6.3), xytext=(8.6, 4.05),
            arrowprops=dict(arrowstyle="-|>", color=RED, lw=2.2, connectionstyle="arc3,rad=0.25"), zorder=4)
ax.text(7.3, 6.35, r"$\delta^{[2]} = a^{[2]}-y$", color=RED, fontsize=10.5, ha="center")

ax.annotate("", xy=(1.9, 6.3), xytext=(4.7, 6.15),
            arrowprops=dict(arrowstyle="-|>", color=RED, lw=2.0, connectionstyle="arc3,rad=0.2"), zorder=4)
ax.text(3.2, 6.9, r"$\delta^{[1]}=(W^{[2]T}\delta^{[2]})\odot\varphi'(z^{[1]})$",
        color=RED, fontsize=9.5, ha="center")

ax.annotate("", xy=(0.6, 0.55), xytext=(4.6, 0.85),
            arrowprops=dict(arrowstyle="-|>", color=RED, lw=2.0, connectionstyle="arc3,rad=-0.15"), zorder=4)
ax.text(2.6, 0.15, r"$\dfrac{\partial L}{\partial W^{[1]}}=\delta^{[1]}\otimes x$", color=RED, fontsize=9.5, ha="center")

ax.text(5.5, 7.1, "backward pass: the error signal $\\delta$ flows right to left",
        ha="center", fontsize=10.5, style="italic", color=RED)
ax.text(5.0, 0.55, r"$\dfrac{\partial L}{\partial W^{[2]}}=\delta^{[2]}\otimes a^{[1]}$", ha="center", fontsize=9.5, color=RED)

plt.tight_layout()
plt.savefig("../figures/ch10_backward_flow.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch10_xor_loss.png ----------
data = np.load("ch10_xor_training.npz")
loss0 = data["seed0"]
epochs = np.arange(1, len(loss0)+1)

fig, ax = plt.subplots(figsize=(7.2, 4.6))
ax.plot(epochs, loss0, color=BLUE, linewidth=1.8)
ax.set_yscale("log")
ax.set_xlabel("epoch"); ax.set_ylabel("loss (log scale)")
ax.set_title("Learning XOR from scratch: loss during training")
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch10_xor_loss.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch10_stuck_comparison.png ----------
loss4 = data["seed4"]

fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(epochs, loss0, color=BLUE, linewidth=1.8, label="seed 0: converges")
ax.plot(epochs, loss4, color=ORANGE, linewidth=1.8, label="seed 4: gets stuck")
ax.axhline(np.log(2), color="gray", linestyle=":", linewidth=1.2, label=r"$\log 2$ (random guessing)")
ax.set_yscale("log")
ax.set_xlabel("epoch"); ax.set_ylabel("loss (log scale)")
ax.set_title("Same network, same algorithm, different initialization")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch10_stuck_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch10_computational_graph.png ----------
# Recompute the worked example's output-layer chain from scratch (same
# numbers as the chapter text) and render it as an operation-level graph:
# every node is one elementary operation, not one neuron.
def sigmoid(zz): return 1/(1+np.exp(-zz))

x = np.array([0.5, 0.2]); y = 1.0
W1 = np.array([[0.3, -0.1], [0.2, 0.4]]); b1 = np.array([0.1, -0.2])
W2 = np.array([0.5, -0.3]); b2 = 0.2

z1 = W1 @ x + b1
a1 = sigmoid(z1)
p1, p2 = W2[0]*a1[0], W2[1]*a1[1]
z2 = p1 + p2 + b2
a2 = sigmoid(z2)
L = -np.log(a2)                      # BCE with y=1

dL_da2 = -1/a2
da2_dz2 = a2*(1-a2)
dL_dz2 = dL_da2 * da2_dz2            # == a2 - y, the Eq. 10.3 shortcut
dL_dp1 = dL_dz2; dL_dp2 = dL_dz2; dL_db2 = dL_dz2
dL_dW2_1 = dL_dp1 * a1[0]; dL_dW2_2 = dL_dp2 * a1[1]
dL_da1_1 = dL_dp1 * W2[0]; dL_da1_2 = dL_dp2 * W2[1]

fig, ax = plt.subplots(figsize=(12.6, 5.6))
ax.set_xlim(0, 13.4); ax.set_ylim(-0.3, 6.6); ax.axis("off")

def opbox(cx, cy, text, w=1.3, h=0.9, fc="#D4E6F1"):
    ax.add_patch(mpatches.FancyBboxPatch((cx-w/2, cy-h/2), w, h, boxstyle="round,pad=0.07",
                 facecolor=fc, edgecolor="black", lw=1.3, zorder=3))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=10.5, zorder=4)

positions = {
    "a1_1": (0.9, 4.6), "a1_2": (0.9, 1.4),
    "p1": (3.4, 4.6), "p2": (3.4, 1.4),
    "z2": (6.1, 3.0), "a2": (8.6, 3.0), "L": (11.1, 3.0),
}
labels = {
    "a1_1": f"$a^{{[1]}}_1$\n{a1[0]:.4f}", "a1_2": f"$a^{{[1]}}_2$\n{a1[1]:.4f}",
    "p1": f"$\\times W^{{[2]}}_1$\n{p1:.4f}", "p2": f"$\\times W^{{[2]}}_2$\n{p2:.4f}",
    "z2": f"$+\\,b^{{[2]}}$\n$z^{{[2]}}$={z2:.4f}", "a2": f"$\\sigma(\\cdot)$\n$a^{{[2]}}$={a2:.4f}",
    "L": f"BCE$(y{{=}}1)$\n$L$={L:.4f}",
}
for k, (cx, cy) in positions.items():
    fc = "#FDEBD0" if k == "L" else ("#EAF2F8" if k.startswith("a1") else "#D4E6F1")
    opbox(cx, cy, labels[k], fc=fc)

edges = [("a1_1","p1"), ("a1_2","p2"), ("p1","z2"), ("p2","z2"), ("z2","a2"), ("a2","L")]
for u, v in edges:
    x1, y1 = positions[u]; x2, y2 = positions[v]
    ax.annotate("", xy=(x2-0.68, y2), xytext=(x1+0.68, y1),
                arrowprops=dict(arrowstyle="-|>", color="#7D8794", lw=1.5), zorder=1)

back_labels = [
    (10.0, 4.0, f"$\\partial L/\\partial a^{{[2]}}={dL_da2:.4f}$"),
    (7.3, 4.2, f"$\\partial L/\\partial z^{{[2]}}={dL_dz2:.4f}$"),
    (5.55, 3.95, f"$\\partial L/\\partial p_1={dL_dp1:.4f}$"),
    (5.55, 1.75, f"$\\partial L/\\partial p_2={dL_dp2:.4f}$"),
    (1.9, 3.55, f"$\\partial L/\\partial a^{{[1]}}_1={dL_da1_1:.4f}$"),
    (1.9, 0.9, f"$\\partial L/\\partial a^{{[1]}}_2={dL_da1_2:.4f}$"),
]
for bx, by, text in back_labels:
    ax.text(bx, by, text, color=RED, fontsize=9.3, ha="center", zorder=5)

for (u, v) in edges:
    x1, y1 = positions[u]; x2, y2 = positions[v]
    ax.annotate("", xy=(x1+0.70, y1-0.35), xytext=(x2-0.70, y2-0.35),
                arrowprops=dict(arrowstyle="-|>", color=RED, lw=1.5,
                                 connectionstyle="arc3,rad=0.12"), zorder=2)

ax.text(6.0, 6.1, "forward pass (gray, left to right)  /  backward pass (red, right to left)",
        ha="center", fontsize=10.5, style="italic")
ax.text(3.4, 5.7, f"$dW^{{[2]}}_1={dL_dW2_1:.4f}$", color=RED, fontsize=9, ha="center")
ax.text(3.4, 0.05, f"$dW^{{[2]}}_2={dL_dW2_2:.4f}$", color=RED, fontsize=9, ha="center")
ax.text(6.1, 5.7, f"$db^{{[2]}}={dL_db2:.4f}$", color=RED, fontsize=9, ha="center")

plt.tight_layout()
plt.savefig("../figures/ch10_computational_graph.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 4 figures")
