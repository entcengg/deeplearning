import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)

# ---------- 1. ch02_stack.png : the software stack ----------
fig, ax = plt.subplots(figsize=(7.0, 4.6))
ax.set_xlim(0, 10); ax.set_ylim(0, 8.6); ax.axis("off")
layers = [
    ("Your Python code", "the experiments and models you write", "#EAF2F8"),
    ("Keras / PyTorch / scikit-learn", "layers, training loops, ready-made models", "#D4E6F1"),
    ("NumPy and tensor libraries", "fast arithmetic on whole arrays", "#A9CCE3"),
    ("Compiled math kernels (C / CUDA)", "the multiplications actually run here", "#FDEBD0"),
    ("Hardware: CPU or GPU", "silicon doing arithmetic in bulk", "#EAECEE"),
]
y = 7.0
for title, sub, fc in layers:
    ax.add_patch(mpatches.FancyBboxPatch((1.0, y), 8.0, 1.25,
                 boxstyle="round,pad=0.06", facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(5.0, y + 0.80, title, ha="center", fontsize=10.5, fontweight="bold")
    ax.text(5.0, y + 0.33, sub, ha="center", fontsize=8.5, style="italic")
    y -= 1.62
ax.annotate("", xy=(0.55, 1.2), xytext=(0.55, 7.9),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.5))
ax.text(0.28, 4.5, "each layer calls the one below", rotation=90,
        ha="center", va="center", fontsize=9)
plt.tight_layout(); plt.savefig("../figures/ch02_stack.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 2. ch02_cpu_gpu.png : few strong cores vs many simple cores ----------
fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.3))
for ax in axes:
    ax.set_xlim(0, 8); ax.set_ylim(0, 8.9); ax.set_aspect("equal"); ax.axis("off")

ax = axes[0]
ax.text(4.0, 8.55, "CPU: a few powerful cores", ha="center", fontsize=11, fontweight="bold")
ax.text(4.0, 8.05, "great at complicated, branching work,\na few tasks at a time",
        ha="center", fontsize=8.5, style="italic")
for i in range(2):
    for j in range(2):
        ax.add_patch(mpatches.FancyBboxPatch((0.7 + j*3.5, 0.9 + i*3.5), 3.0, 3.0,
                     boxstyle="round,pad=0.05", facecolor="#D4E6F1",
                     edgecolor="black", lw=1.4))
        ax.text(2.2 + j*3.5, 2.4 + i*3.5, "core", ha="center", va="center", fontsize=10)

ax = axes[1]
ax.text(4.0, 8.55, "GPU: thousands of simple cores", ha="center", fontsize=11, fontweight="bold")
ax.text(4.0, 8.05, "great at doing the same simple arithmetic\non huge arrays simultaneously",
        ha="center", fontsize=8.5, style="italic")
for i in range(12):
    for j in range(12):
        ax.add_patch(plt.Rectangle((0.7 + j*0.56, 0.8 + i*0.52), 0.46, 0.42,
                     facecolor="#A9CCE3", edgecolor="black", lw=0.5))
plt.tight_layout(); plt.savefig("../figures/ch02_cpu_gpu.png", dpi=200, bbox_inches="tight"); plt.close()

print("saved 2 figures")
