# Figure scripts

The scripts that draw the figures in *Deep Learning with Python: A Practical and Mathematical Introduction*, one script per chapter. They are included for the same reason the programs are: so that no figure in the book is a picture of a result you cannot reproduce yourself.

[All chapters](../README.md)

## Running a script

Run each script from inside this folder; it writes its figures (PNG, 200 dpi) to a `figures/` folder at the top of the repository:

```bash
cd figure-scripts
python build_ch05.py
```

The figures are not stored in the repository (`figures/` is listed in `.gitignore`); run a script to make them. Scripts for the later chapters retrain the chapter's models with the same seeds as its programs and can take several minutes.

| Script | Figures for |
|:--|:--|
| [`build_ch01.py`](build_ch01.py) | Chapter 1 · What Is Deep Learning? |
| [`build_ch02.py`](build_ch02.py) | Chapter 2 · Setting Up Python for Deep Learning |
| [`build_ch03.py`](build_ch03.py) | Chapter 3 · Vectors, Matrices, and Tensors |
| [`build_ch04.py`](build_ch04.py) | Chapter 4 · Derivatives, Gradients, and the Chain Rule |
| [`build_ch05.py`](build_ch05.py) | Chapter 5 · The Artificial Neuron |
| [`build_ch06.py`](build_ch06.py) | Chapter 6 · The Perceptron |
| [`build_ch07.py`](build_ch07.py) | Chapter 7 · Activation Functions |
| [`build_ch08.py`](build_ch08.py) | Chapter 8 · Loss Functions |
| [`build_ch09.py`](build_ch09.py) | Chapter 9 · Forward Propagation and Multilayer Networks |
| [`build_ch10.py`](build_ch10.py) | Chapter 10 · Backpropagation |
| [`build_ch11.py`](build_ch11.py) | Chapter 11 · Gradient Descent and Optimizers |
| [`build_ch12.py`](build_ch12.py) | Chapter 12 · Regularization and Generalization |
| [`build_ch13.py`](build_ch13.py) | Chapter 13 · Building Networks with PyTorch and Keras |
| [`build_ch14.py`](build_ch14.py) | Chapter 14 · Convolution and CNN Fundamentals |
| [`build_ch15.py`](build_ch15.py) | Chapter 15 · CNN Architectures and Transfer Learning |
| [`build_ch16.py`](build_ch16.py) | Chapter 16 · Recurrent Neural Networks |
| [`build_ch17.py`](build_ch17.py) | Chapter 17 · LSTM and GRU |
| [`build_ch18.py`](build_ch18.py) | Chapter 18 · Attention Mechanisms |
| [`build_ch19.py`](build_ch19.py) | Chapter 19 · Transformers |
| [`build_ch20.py`](build_ch20.py) | Chapter 20 · Deep Learning for NLP |
| [`build_ch21.py`](build_ch21.py) | Chapter 21 · Autoencoders and Variational Autoencoders |
| [`build_ch22.py`](build_ch22.py) | Chapter 22 · Generative Adversarial Networks |
| [`build_ch23.py`](build_ch23.py) | Chapter 23 · Diffusion Models |
| [`build_ch24.py`](build_ch24.py) | Chapter 24 · Object Detection |
| [`build_ch25.py`](build_ch25.py) | Chapter 25 · Image Segmentation |
| [`build_ch26.py`](build_ch26.py) | Chapter 26 · Deep Learning for Time Series |
| [`build_ch27.py`](build_ch27.py) | Chapter 27 · Explainability and Responsible AI |
| [`build_ch28.py`](build_ch28.py) | Chapter 28 · Deploying Deep Learning Models |

One figure has no script here, because a program draws it: Figure 2.2 is the plot that Chapter 2's Program 3 saves as `first_plot.png`.

## Saved training histories

A few scripts plot training histories recorded from the book's programs and read them from the files below, which are stored alongside the scripts. Some scripts save the numbers they compute in the same way.

- `ch05_cf_training.npz`
- `ch10_xor_training.npz`
- `ch11_optimizer_comparison.npz`
- `ch12_data.npz`
- `ch13_pytorch_xor_loss.npy`
- `ch13_training_workflow.npz`
- `ch14_cnn_vs_mlp.npz`
- `ch15_batchnorm.npz`
- `ch15_gradient_flow.npz`
- `ch15_scratch_vs_transfer_datasize.npz`
- `ch15_transfer.npz`
- `ch16_recall_task.npz`
- `ch16_vanishing_time.npz`
- `ch17_gradient_comparison.npz`
- `ch18_retrieval_mse.npz`
