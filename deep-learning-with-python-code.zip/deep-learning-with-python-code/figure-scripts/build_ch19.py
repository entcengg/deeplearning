import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

# =================================================================
# 1. ch19_multihead_attention.png -- split into heads, attend, concat
# =================================================================
fig, ax = plt.subplots(figsize=(9.8, 5.8))
ax.set_xlim(0, 12.4); ax.set_ylim(0, 7.6); ax.axis("off")


def box(cx, cy, w, h, text, fc, fontsize=10.5):
    ax.add_patch(plt.Rectangle((cx - w / 2, cy - h / 2), w, h,
                                facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fontsize)


def arrow(x0, y0, x1, y1, color="black", lw=1.6):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw))


box(1.5, 6.6, 2.0, 0.9, "$Q, K, V$\n$(T,\\ d_{model})$", "#FCF3CF")
arrow(1.5, 6.15, 1.5, 5.7)

box(1.5, 5.2, 2.2, 0.7, "split into $h$ heads", "#EBDEF0")
arrow(2.6, 5.0, 3.7, 4.2)
arrow(2.6, 5.0, 3.7, 2.2)

box(4.9, 4.2, 2.6, 1.1, "head 1\nscaled dot-product\nattention, $d_k=d_{model}/h$", "#D4E6F1")
box(4.9, 2.2, 2.6, 1.1, "head $h$\nscaled dot-product\nattention, $d_k=d_{model}/h$", "#D4E6F1")
ax.text(4.9, 3.2, "$\\vdots$", ha="center", fontsize=16)

arrow(6.2, 4.2, 7.5, 3.6)
arrow(6.2, 2.2, 7.5, 2.8)
box(8.4, 3.2, 2.0, 1.1, "concatenate\nhead outputs", "#FADBD8")

arrow(9.4, 3.2, 10.3, 3.2)
box(11.2, 3.2, 1.6, 1.1, "output\nprojection\n$W_O$", "#D5F5E3")

ax.text(6.2, 0.9,
        r"each head learns its own $W_Q^{(i)},W_K^{(i)},W_V^{(i)}$ and can specialize "
        "in a different kind of relationship",
        ha="center", fontsize=10, style="italic", color=GRAY)
ax.set_title("Multi-head attention: several smaller attentions run in parallel, then combined",
             fontsize=12.5)
plt.tight_layout()
plt.savefig("../figures/ch19_multihead_attention.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch19_positional_encoding.png -- PE heatmap + a few dimensions'
#    sine/cosine waves as a function of position
# =================================================================
def positional_encoding(seq_len, d_model):
    pe = np.zeros((seq_len, d_model))
    positions = np.arange(seq_len).reshape(-1, 1)
    i = np.arange(0, d_model, 2)
    div_term = 10000.0 ** (i / d_model)
    pe[:, 0::2] = np.sin(positions / div_term)
    pe[:, 1::2] = np.cos(positions / div_term)
    return pe


PE_big = positional_encoding(60, 32)

fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.6))

ax0 = axes[0]
im = ax0.imshow(PE_big.T, cmap="RdBu", aspect="auto", vmin=-1, vmax=1)
ax0.set_xlabel("position")
ax0.set_ylabel("encoding dimension")
ax0.set_title("Sinusoidal positional encoding\n($d_{model}=32$, 60 positions)")
fig.colorbar(im, ax=ax0, fraction=0.046, pad=0.04)

ax1 = axes[1]
positions = np.arange(60)
for dim, color in zip([0, 1, 8, 9], [BLUE, ORANGE, GREEN, PURPLE]):
    label = f"dim {dim} ({'sin' if dim % 2 == 0 else 'cos'}, $i={dim // 2}$)"
    ax1.plot(positions, PE_big[:, dim], color=color, lw=1.8, label=label)
ax1.set_xlabel("position")
ax1.set_ylabel("encoding value")
ax1.set_title("Low dimensions oscillate fast,\nhigh dimensions oscillate slowly")
ax1.legend(fontsize=8.5, loc="lower right")
ax1.grid(alpha=0.3)

plt.tight_layout()
plt.savefig("../figures/ch19_positional_encoding.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch19_order_task.png -- Program 3's accuracy-vs-length results and
#    the order-swapped-twin probabilities
# =================================================================
def make_batch(seq_len, n, rng):
    X = np.zeros((n, seq_len, 3), dtype=np.float32)
    targets = np.zeros(n, dtype=np.float32)
    for idx in range(n):
        pos_a, pos_b = rng.choice(seq_len, size=2, replace=False)
        X[idx, :, 2] = 1.0
        X[idx, pos_a] = [1, 0, 0]
        X[idx, pos_b] = [0, 1, 0]
        targets[idx] = 1.0 if pos_a < pos_b else 0.0
    return torch.tensor(X), torch.tensor(targets)


class OrderModel(nn.Module):
    def __init__(self, d_model=32, use_pe=False, max_len=200):
        super().__init__()
        self.embed = nn.Linear(3, d_model)
        self.use_pe = use_pe
        if use_pe:
            self.register_buffer("pe", torch.tensor(positional_encoding(max_len, d_model).astype(np.float32)))
        self.key_proj = nn.Linear(d_model, d_model)
        self.val_proj = nn.Linear(d_model, d_model)
        self.query = nn.Parameter(torch.randn(d_model))
        self.head = nn.Linear(d_model, 1)
        self.d_model = d_model

    def forward(self, x):
        T = x.shape[1]
        e = self.embed(x)
        if self.use_pe:
            e = e + self.pe[:T]
        K = self.key_proj(e)
        V = self.val_proj(e)
        scores = (K @ self.query) / self.d_model ** 0.5
        weights = torch.softmax(scores, dim=1)
        context = (weights.unsqueeze(-1) * V).sum(dim=1)
        return self.head(context).squeeze(-1)


def train_model(seq_len, use_pe, epochs=300):
    torch.manual_seed(0)
    model = OrderModel(use_pe=use_pe)
    opt = optim.Adam(model.parameters(), lr=0.02)
    rng = np.random.default_rng(seq_len)
    X_train, y_train = make_batch(seq_len, 1000, rng)
    loss_fn = nn.BCEWithLogitsLoss()
    for _ in range(epochs):
        opt.zero_grad()
        pred = model(X_train)
        loss = loss_fn(pred, y_train)
        loss.backward()
        opt.step()
    return model


def test_accuracy(model, seq_len, test_rng):
    X_test, y_test = make_batch(seq_len, 200, test_rng)
    with torch.no_grad():
        pred = torch.sigmoid(model(X_test))
        return ((pred > 0.5).float() == y_test).float().mean().item()


seq_lens = [10, 30, 50]
acc_no_pe, acc_with_pe = [], []
trained = {}
for seq_len in seq_lens:
    for use_pe in [False, True]:
        model = train_model(seq_len, use_pe)
        acc = test_accuracy(model, seq_len, np.random.default_rng(seq_len + 1000))
        (acc_no_pe if not use_pe else acc_with_pe).append(acc)
        trained[(seq_len, use_pe)] = model

seq_len = 30
pos_a, pos_b = 8, 19
twin1 = np.zeros((1, seq_len, 3), dtype=np.float32)
twin1[0, :, 2] = 1.0; twin1[0, pos_a] = [1, 0, 0]; twin1[0, pos_b] = [0, 1, 0]
twin2 = np.zeros((1, seq_len, 3), dtype=np.float32)
twin2[0, :, 2] = 1.0; twin2[0, pos_a] = [0, 1, 0]; twin2[0, pos_b] = [1, 0, 0]
twin1_t, twin2_t = torch.tensor(twin1), torch.tensor(twin2)

probs = {}
for use_pe in [False, True]:
    model = trained[(seq_len, use_pe)]
    with torch.no_grad():
        probs[use_pe] = (torch.sigmoid(model(twin1_t)).item(),
                          torch.sigmoid(model(twin2_t)).item())

fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.6))

ax0 = axes[0]
width = 0.35
xpos = np.arange(len(seq_lens))
ax0.bar(xpos - width / 2, acc_no_pe, width, color=GRAY, label="without positional encoding")
ax0.bar(xpos + width / 2, acc_with_pe, width, color=BLUE, label="with positional encoding")
ax0.axhline(0.5, color="black", lw=1.0, ls="--", alpha=0.6, label="chance")
ax0.set_xticks(xpos); ax0.set_xticklabels([str(s) for s in seq_lens])
ax0.set_xlabel("sequence length $T$")
ax0.set_ylabel("test accuracy")
ax0.set_title("'Does A come before B?'\ncontent alone cannot answer this")
ax0.legend(fontsize=9)
ax0.set_ylim(0, 1.08)
ax0.grid(alpha=0.3, axis="y")

ax1 = axes[1]
labels = ["twin 1\n(A before B)", "twin 2\n(B before A)"]
xpos2 = np.arange(2)
ax1.bar(xpos2 - width / 2, probs[False], width, color=GRAY, label="without positional encoding")
ax1.bar(xpos2 + width / 2, probs[True], width, color=BLUE, label="with positional encoding")
ax1.axhline(0.5, color="black", lw=1.0, ls="--", alpha=0.6)
ax1.set_xticks(xpos2); ax1.set_xticklabels(labels)
ax1.set_ylabel("predicted $P$(A before B)")
ax1.set_title("Same two positions, swapped labels\n(model output for each twin)")
ax1.legend(fontsize=9)
ax1.set_ylim(0, 1.0)
ax1.grid(alpha=0.3, axis="y")

plt.tight_layout()
plt.savefig("../figures/ch19_order_task.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 4. ch19_encoder_block.png -- the assembled Transformer encoder block
# =================================================================
fig, ax = plt.subplots(figsize=(6.4, 7.0))
ax.set_xlim(0, 8); ax.set_ylim(0, 11.6); ax.axis("off")

box(4, 1.0, 4.4, 0.9, "input embeddings\n+ positional encoding", "#FCF3CF")
arrow(4, 1.45, 4, 2.0)

box(4, 2.6, 4.4, 1.0, "multi-head\nself-attention", "#D4E6F1")
arrow(4, 3.1, 6.6, 3.1); arrow(6.6, 3.1, 6.6, 4.3); arrow(6.6, 4.3, 4.7, 4.3)
ax.text(6.85, 3.7, "residual", rotation=90, fontsize=8.5, color=GRAY, ha="center")

box(4, 4.6, 4.4, 0.9, "Add & LayerNorm", "#FADBD8")
arrow(4, 5.05, 4, 5.6)

box(4, 6.2, 4.4, 1.0, "feed-forward network\n(Linear $\\to$ ReLU $\\to$ Linear)", "#D5F5E3")
arrow(4, 6.7, 6.6, 6.7); arrow(6.6, 6.7, 6.6, 7.9); arrow(6.6, 7.9, 4.7, 7.9)
ax.text(6.85, 7.3, "residual", rotation=90, fontsize=8.5, color=GRAY, ha="center")

box(4, 8.2, 4.4, 0.9, "Add & LayerNorm", "#FADBD8")
arrow(4, 8.65, 4, 9.2)

box(4, 9.8, 4.4, 0.8, "encoder block output\n(same shape as input)", "#EBDEF0")
arrow(4, 10.2, 4, 10.8)
ax.text(4, 11.25, "$\\times N$ (stack several blocks)", ha="center", fontsize=10,
        style="italic", color=GRAY)

ax.set_title("One Transformer encoder block", fontsize=13, pad=10)
plt.tight_layout()
plt.savefig("../figures/ch19_encoder_block.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 4 figures written")
