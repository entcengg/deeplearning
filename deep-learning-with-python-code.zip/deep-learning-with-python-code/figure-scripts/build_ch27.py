# build_ch27.py -- generates all figures for Chapter 27 (Explainability and
# Responsible AI). Each section below mirrors the corresponding program's
# model/training code exactly (same architecture, same seeds, same call
# order) so the figures are consistent with the numbers printed in the
# chapter text.

import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

import os
FIG_DIR = "../figures"
os.makedirs(FIG_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Shared CNN pieces (Programs 1, 2, 3, 5 all use this exact architecture)
# ---------------------------------------------------------------------------

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        logits = self.fc(pooled)
        return logits, a2


def load_digit_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_cnn(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits, _ = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def vanilla_saliency(model, x_single, target_class):
    x = x_single.clone().requires_grad_(True)
    logits, _ = model(x)
    score = logits[0, target_class]
    model.zero_grad()
    if x.grad is not None:
        x.grad.zero_()
    score.backward()
    return x.grad[0, 0].abs().numpy()


def upsample_nearest(small_map, out_size):
    h, w = small_map.shape
    row_idx = (np.arange(out_size) * h // out_size)
    col_idx = (np.arange(out_size) * w // out_size)
    return small_map[np.ix_(row_idx, col_idx)]


def grad_cam(model, x_single, target_class):
    x = x_single.clone()
    logits, features = model(x)
    features.retain_grad()
    score = logits[0, target_class]
    model.zero_grad()
    score.backward()
    grads = features.grad[0]
    activations = features.detach()[0]
    alpha = grads.mean(dim=(1, 2))
    cam = torch.zeros(activations.shape[1:])
    for k in range(activations.shape[0]):
        cam += alpha[k] * activations[k]
    cam = torch.relu(cam).numpy()
    return upsample_nearest(cam, 8)


def cosine_similarity(a, b):
    a_flat, b_flat = a.flatten(), b.flatten()
    denom = (np.linalg.norm(a_flat) * np.linalg.norm(b_flat))
    if denom < 1e-12:
        return 0.0
    return float(np.dot(a_flat, b_flat) / denom)


# ---------------------------------------------------------------------------
# Figure 1: vanilla saliency vs. Grad-CAM, same 4 test images (Programs 1-2)
# ---------------------------------------------------------------------------

def build_figure1():
    torch.manual_seed(0); np.random.seed(0)
    X_train, y_train, X_test, y_test = load_digit_data()
    model = SmallCNN()
    train_cnn(model, X_train, y_train, epochs=250)
    model.eval()
    test_logits, _ = model(X_test)
    test_pred = test_logits.argmax(dim=1)
    correct_idx = (test_pred == y_test).nonzero(as_tuple=True)[0][:4]

    fig, axes = plt.subplots(3, 4, figsize=(10, 7.5))
    for col, i in enumerate(correct_idx.tolist()):
        x_single = X_test[i:i + 1]
        true_class = int(y_test[i])
        img = x_single[0, 0].numpy()
        sal = vanilla_saliency(model, x_single, true_class)
        cam = grad_cam(model, x_single, true_class)

        axes[0, col].imshow(img, cmap="gray_r", vmin=0, vmax=1)
        axes[0, col].set_title(f"digit {true_class}", fontsize=10)
        axes[1, col].imshow(sal, cmap="hot")

        # Overlay Grad-CAM as a translucent heatmap whose OWN alpha channel
        # scales with the CAM value, so near-zero regions stay fully
        # transparent (showing the plain digit) and only high-CAM regions
        # are colored -- a constant blending alpha instead washes the whole
        # panel out to a uniform gray-red haze.
        hot = matplotlib.colormaps["hot"]
        cam_norm = cam / (cam.max() + 1e-8)
        overlay = hot(cam_norm)
        overlay[..., 3] = cam_norm * 0.85
        axes[2, col].imshow(img, cmap="gray_r", vmin=0, vmax=1)
        axes[2, col].imshow(overlay)
        for row in range(3):
            axes[row, col].set_xticks([]); axes[row, col].set_yticks([])

    axes[0, 0].set_ylabel("input", fontsize=10)
    axes[1, 0].set_ylabel("vanilla\nsaliency", fontsize=10)
    axes[2, 0].set_ylabel("Grad-CAM\noverlay", fontsize=10)
    fig.suptitle("Vanilla-gradient saliency vs. Grad-CAM on the same four predictions", fontsize=12)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch27_saliency_and_gradcam.png", dpi=200)
    plt.close(fig)
    print("Saved ch27_saliency_and_gradcam.png")


# ---------------------------------------------------------------------------
# Figure 2: sanity check -- trained-vs-random similarity distributions (Program 3)
# ---------------------------------------------------------------------------

def build_figure2():
    torch.manual_seed(0); np.random.seed(0)
    X_train, y_train, X_test, y_test = load_digit_data()

    trained_model = SmallCNN()
    train_cnn(trained_model, X_train, y_train, epochs=250)
    trained_model.eval()
    with torch.no_grad():
        test_logits, _ = trained_model(X_test)
        test_pred = test_logits.argmax(dim=1)

    torch.manual_seed(999)
    random_model = SmallCNN()
    random_model.eval()

    torch.manual_seed(12345)
    random_model_c = SmallCNN()
    random_model_c.eval()

    correct_idx = (test_pred == y_test).nonzero(as_tuple=True)[0][:20]
    sal_sims, cam_sims, floor_sims = [], [], []
    for i in correct_idx.tolist():
        x_single = X_test[i:i + 1]
        true_class = int(y_test[i])
        sal_sims.append(cosine_similarity(
            vanilla_saliency(trained_model, x_single, true_class),
            vanilla_saliency(random_model, x_single, true_class)))
        cam_trained = grad_cam(trained_model, x_single, true_class)
        cam_random = grad_cam(random_model, x_single, true_class)
        cam_sims.append(cosine_similarity(cam_trained, cam_random))
        cam_random_c = grad_cam(random_model_c, x_single, true_class)
        floor_sims.append(cosine_similarity(cam_random, cam_random_c))

    fig, ax = plt.subplots(figsize=(7, 5.5))
    data = [sal_sims, cam_sims, floor_sims]
    labels = ["Saliency\n(trained vs.\nrandom)", "Grad-CAM\n(trained vs.\nrandom)",
              "Grad-CAM\n(random vs.\nrandom, floor)"]
    bp = ax.boxplot(data, tick_labels=labels, patch_artist=True, showmeans=True)
    colors = ["#4C72B0", "#DD8452", "#999999"]
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color); patch.set_alpha(0.6)
    ax.axhline(1.0, color="green", linestyle=":", linewidth=1, label="identical maps (similarity = 1)")
    ax.set_ylabel("cosine similarity")
    ax.set_title("Sanity check: does the explanation depend on what the model learned?")
    ax.legend(loc="upper right", fontsize=9)
    ax.set_ylim(-0.05, 1.05)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch27_sanity_check.png", dpi=200)
    plt.close(fig)
    print("Saved ch27_sanity_check.png")


# ---------------------------------------------------------------------------
# Figure 3: fairness -- demographic parity / equalized-odds gaps (Program 4)
# ---------------------------------------------------------------------------

class LogisticClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        return self.linear(x).squeeze(-1)


def make_fairness_dataset(n_per_group=2000):
    Q0 = np.random.normal(0.0, 1.0, size=n_per_group)
    Q1 = np.random.normal(0.0, 1.0, size=n_per_group)
    Q = np.concatenate([Q0, Q1])
    S = np.concatenate([np.zeros(n_per_group), np.ones(n_per_group)]).astype(np.int64)
    Y = (Q > 0).astype(np.int64)
    noise0 = np.random.normal(0.0, 0.5, size=n_per_group)
    noise1 = np.random.normal(-0.6, 1.0, size=n_per_group)
    noise = np.concatenate([noise0, noise1])
    X = (Q + noise).astype(np.float32)
    perm = np.random.permutation(len(Q))
    return X[perm], Y[perm], S[perm], Q[perm]


def train_logistic(X_train, y_train, epochs=300, lr=0.1):
    model = LogisticClassifier()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()
    X_t = torch.from_numpy(X_train).unsqueeze(-1)
    y_t = torch.from_numpy(y_train.astype(np.float32))
    for epoch in range(epochs):
        logits = model(X_t)
        loss = loss_fn(logits, y_t)
        optimizer.zero_grad(); loss.backward(); optimizer.step()
    return model


def predict_logistic(model, X):
    with torch.no_grad():
        logits = model(torch.from_numpy(X).unsqueeze(-1))
        return (torch.sigmoid(logits) > 0.5).numpy().astype(np.int64)


def group_metrics(pred, y, s, group):
    mask = (s == group)
    y_g, pred_g = y[mask], pred[mask]
    pos_rate = pred_g.mean()
    pos_mask, neg_mask = (y_g == 1), (y_g == 0)
    tpr = pred_g[pos_mask].mean() if pos_mask.any() else float("nan")
    fpr = pred_g[neg_mask].mean() if neg_mask.any() else float("nan")
    return pos_rate, tpr, fpr


def build_figure3():
    np.random.seed(0); torch.manual_seed(0)
    X, Y, S, Q = make_fairness_dataset(n_per_group=2000)
    (X_train, X_test, y_train, y_test, s_train, s_test,
     Q_train, Q_test) = train_test_split(X, Y, S, Q, test_size=0.25, random_state=0, stratify=S)

    model = train_logistic(X_train, y_train, epochs=300)
    pred_test = predict_logistic(model, X_test)
    pos0, tpr0, fpr0 = group_metrics(pred_test, y_test, s_test, 0)
    pos1, tpr1, fpr1 = group_metrics(pred_test, y_test, s_test, 1)
    dp_gap = abs(pos0 - pos1)
    tpr_gap = abs(tpr0 - tpr1)

    oracle_model = train_logistic(Q_train.astype(np.float32), y_train, epochs=300)
    oracle_pred = predict_logistic(oracle_model, Q_test.astype(np.float32))
    o_pos0, o_tpr0, o_fpr0 = group_metrics(oracle_pred, y_test, s_test, 0)
    o_pos1, o_tpr1, o_fpr1 = group_metrics(oracle_pred, y_test, s_test, 1)
    o_dp_gap = abs(o_pos0 - o_pos1)
    o_tpr_gap = abs(o_tpr0 - o_tpr1)

    fig, axes = plt.subplots(1, 2, figsize=(10, 5))

    ax = axes[0]
    x = np.arange(2)
    width = 0.35
    ax.bar(x - width / 2, [tpr0, tpr1], width, label="TPR", color="#4C72B0")
    ax.bar(x + width / 2, [fpr0, fpr1], width, label="FPR", color="#DD8452")
    ax.set_xticks(x); ax.set_xticklabels(["Group 0", "Group 1"])
    ax.set_ylabel("rate")
    ax.set_title("Classifier trained on biased X\n(sensitive attribute withheld)")
    ax.legend()
    ax.set_ylim(0, 1.05)

    ax = axes[1]
    gap_labels = ["Demographic\nparity gap", "Equalized-odds\nTPR gap"]
    biased_vals = [dp_gap, tpr_gap]
    oracle_vals = [o_dp_gap, o_tpr_gap]
    xg = np.arange(2)
    ax.bar(xg - width / 2, biased_vals, width, label="trained on biased X", color="#C44E52")
    ax.bar(xg + width / 2, oracle_vals, width, label="trained on true Q (oracle)", color="#55A868")
    ax.set_xticks(xg); ax.set_xticklabels(gap_labels)
    ax.set_ylabel("gap between groups")
    ax.set_title("Withholding S does not close the gap")
    ax.legend()

    fig.suptitle("Fairness through unawareness: same true qualification, unequal outcomes", fontsize=12)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch27_fairness_gaps.png", dpi=200)
    plt.close(fig)
    print("Saved ch27_fairness_gaps.png")


# ---------------------------------------------------------------------------
# Figure 4: FGSM vs. random noise, accuracy across epsilon (Program 5)
# ---------------------------------------------------------------------------

def fgsm_attack(model, x, y_true, epsilon):
    x_adv_input = x.clone().requires_grad_(True)
    logits, _ = model(x_adv_input)
    loss = nn.functional.cross_entropy(logits, y_true)
    model.zero_grad()
    loss.backward()
    perturbation = epsilon * x_adv_input.grad.sign()
    return (x + perturbation).clamp(0.0, 1.0).detach()


def random_noise_attack(model, x, epsilon, generator):
    random_signs = torch.randint(0, 2, x.shape, generator=generator).float() * 2 - 1
    return (x + epsilon * random_signs).clamp(0.0, 1.0)


def build_figure4():
    torch.manual_seed(0); np.random.seed(0)
    X_train, y_train, X_test, y_test = load_digit_data()
    model = SmallCNN()
    train_cnn(model, X_train, y_train, epochs=250)
    model.eval()

    with torch.no_grad():
        clean_logits, _ = model(X_test)
        clean_acc = (clean_logits.argmax(dim=1) == y_test).float().mean().item()

    gen = torch.Generator().manual_seed(0)
    epsilons = [0.0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3]
    fgsm_accs, random_accs = [], []
    for eps in epsilons:
        if eps == 0.0:
            fgsm_accs.append(clean_acc); random_accs.append(clean_acc); continue
        x_fgsm = fgsm_attack(model, X_test, y_test, eps)
        with torch.no_grad():
            fgsm_logits, _ = model(x_fgsm)
            fgsm_accs.append((fgsm_logits.argmax(dim=1) == y_test).float().mean().item())
        x_rand = random_noise_attack(model, X_test, eps, gen)
        with torch.no_grad():
            rand_logits, _ = model(x_rand)
            random_accs.append((rand_logits.argmax(dim=1) == y_test).float().mean().item())

    fig, ax = plt.subplots(figsize=(7, 5.5))
    ax.plot(epsilons, fgsm_accs, marker="o", color="#C44E52", label="FGSM (gradient-directed)")
    ax.plot(epsilons, random_accs, marker="s", color="#4C72B0", label="random sign noise (same magnitude)")
    ax.set_xlabel(r"$\epsilon$ (maximum per-pixel change)")
    ax.set_ylabel("test accuracy")
    ax.set_title("Direction matters: FGSM vs. equal-magnitude random noise")
    ax.legend()
    ax.set_ylim(-0.02, 1.02)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch27_fgsm_sweep.png", dpi=200)
    plt.close(fig)
    print("Saved ch27_fgsm_sweep.png")


if __name__ == "__main__":
    build_figure1()
    build_figure2()
    build_figure3()
    build_figure4()
