# build_ch28.py -- generates all figures for Chapter 28 (Deploying Deep
# Learning Models). Each section mirrors the corresponding program's
# model/training code exactly (same architecture, same seeds, same call
# order) so the figures are consistent with the numbers printed in the
# chapter text.

import os
import warnings
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import ks_2samp
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

FIG_DIR = "../figures"
os.makedirs(FIG_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Shared pieces
# ---------------------------------------------------------------------------

class DigitClassifier(nn.Module):
    """Programs 1, 3, 4, 5's architecture."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_image_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


# ---------------------------------------------------------------------------
# Figure 1: Serialization formats (Program 1)
# ---------------------------------------------------------------------------

def build_figure1():
    # TorchScript's saved archive embeds debug source-location metadata (the
    # exporting script's file path and line numbers), so re-running the
    # export inside this figure script -- a different file, different line
    # numbers -- produces a harmlessly different byte count than Program 1's
    # own export, even with identical seeds and an identical architecture.
    # The three sizes below are therefore taken directly from Program 1's
    # verified captured output rather than re-derived here, so the figure
    # matches the chapter text exactly.
    sizes = [8.5, 15.4, 6.6]
    labels = ["state_dict\n(needs class def)", "TorchScript\n(source-free)", "ONNX\n(framework-agnostic)"]
    colors = ["#4C72B0", "#DD8452", "#55A868"]

    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(labels, sizes, color=colors, edgecolor="black", linewidth=0.8)
    for bar, size in zip(bars, sizes):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                f"{size:.1f} KB", ha="center", va="bottom", fontsize=10, fontweight="bold")
    ax.set_ylabel("On-disk size (KB)")
    ax.set_title("Three Export Formats, One Trained Model\n(all three reproduce identical predictions)")
    ax.set_ylim(0, max(sizes) * 1.25)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch28_serialization_formats.png", dpi=200)
    plt.close(fig)
    print("Figure 1 (serialization formats) saved.")


# ---------------------------------------------------------------------------
# Figure 2: Quantization trade-offs (Program 2)
# ---------------------------------------------------------------------------

def build_figure2():
    # Quantized-model pickle size and all latency numbers vary slightly by
    # run/environment (quantization's internal observer bookkeeping and
    # wall-clock timing are not exactly reproducible across separate script
    # invocations, as discussed in the chapter text). The six values below
    # are taken directly from Program 2's own verified captured output so
    # this figure matches the chapter text exactly.
    fp32_acc, quant_acc = 0.9689, 0.9667
    fp32_kb, quant_kb = 70.4, 22.7
    size_ratio = 3.11   # matches Program 2's own unrounded-KB ratio exactly
    fp32_ms, quant_ms = 0.0313, 0.0962

    fig, axes = plt.subplots(1, 3, figsize=(12, 4.2))

    axes[0].bar(["float32", "quantized"], [fp32_acc, quant_acc], color=["#4C72B0", "#C44E52"],
                edgecolor="black", linewidth=0.8)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_ylabel("Test accuracy")
    axes[0].set_title("Accuracy")
    for i, v in enumerate([fp32_acc, quant_acc]):
        axes[0].text(i, v + 0.02, f"{v:.4f}", ha="center", fontsize=9)

    axes[1].bar(["float32", "quantized"], [fp32_kb, quant_kb], color=["#4C72B0", "#C44E52"],
                edgecolor="black", linewidth=0.8)
    axes[1].set_ylabel("On-disk size (KB)")
    axes[1].set_title(f"Size ({size_ratio:.2f}x smaller)")
    for i, v in enumerate([fp32_kb, quant_kb]):
        axes[1].text(i, v + 1, f"{v:.1f} KB", ha="center", fontsize=9)

    axes[2].bar(["float32", "quantized"], [fp32_ms, quant_ms], color=["#4C72B0", "#C44E52"],
                edgecolor="black", linewidth=0.8)
    axes[2].set_ylabel("Latency, batch=1 (ms)")
    axes[2].set_title("Latency (quantized is SLOWER)")
    for i, v in enumerate([fp32_ms, quant_ms]):
        axes[2].text(i, v + max(fp32_ms, quant_ms) * 0.02, f"{v:.3f} ms", ha="center", fontsize=9)

    fig.suptitle("Dynamic Quantization on a Small MLP: a Real Win and a Real Cost", fontsize=12)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch28_quantization_tradeoffs.png", dpi=200)
    plt.close(fig)
    print("Figure 2 (quantization trade-offs) saved.")


# ---------------------------------------------------------------------------
# Figure 3: Throughput vs. batch size (Program 3)
# ---------------------------------------------------------------------------

def build_figure3():
    # Wall-clock throughput is not exactly reproducible across separate
    # script invocations (see the chapter text). These five values are
    # taken directly from Program 3's own verified captured output so this
    # figure matches the chapter text exactly.
    batch_sizes = [1, 4, 16, 64, 256]
    throughputs = [15039.0, 20441.4, 73674.8, 176900.4, 278239.1]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(batch_sizes, throughputs, marker="o", markersize=8, linewidth=2, color="#4C72B0")
    ax.set_xscale("log", base=2)
    ax.set_yscale("log")
    ax.set_xticks(batch_sizes)
    ax.set_xticklabels([str(b) for b in batch_sizes])
    ax.set_xlabel("Batch size (log scale)")
    ax.set_ylabel("Throughput, images/sec (log scale)")
    ax.set_title("Throughput vs. Batch Size\n(identical model, identical arithmetic per image)")
    ax.grid(True, which="both", alpha=0.3)
    for bs, t in zip(batch_sizes, throughputs):
        ax.annotate(f"{t:,.0f}/s", (bs, t), textcoords="offset points", xytext=(0, 10),
                    ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch28_throughput_vs_batch.png", dpi=200)
    plt.close(fig)
    print("Figure 3 (throughput vs. batch size) saved.")


# ---------------------------------------------------------------------------
# Figure 4: Client/server request flow (Program 4) -- schematic, no data
# ---------------------------------------------------------------------------

def build_figure4():
    fig, ax = plt.subplots(figsize=(9, 3.2))
    ax.set_xlim(0, 10)
    ax.set_ylim(0.8, 3.6)
    ax.axis("off")

    def box(x, y, w, h, text, color):
        rect = plt.Rectangle((x, y), w, h, facecolor=color, edgecolor="black", linewidth=1.2, zorder=2)
        ax.add_patch(rect)
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=10, zorder=3,
                wrap=True)

    box(0.3, 1.7, 2.2, 1.6, "Client\n(requests library)", "#DD8452")
    box(4.0, 1.7, 2.2, 1.6, "Flask server\n/predict endpoint", "#4C72B0")
    box(7.7, 1.7, 2.0, 1.6, "DigitClassifier\n(in-process model)", "#55A868")

    ax.annotate("", xy=(4.0, 2.9), xytext=(2.5, 2.9),
                arrowprops=dict(arrowstyle="->", lw=1.8))
    ax.text(3.25, 3.05, "POST /predict\n{\"pixels\": [...]}", ha="center", fontsize=8)

    ax.annotate("", xy=(7.7, 2.5), xytext=(6.2, 2.5),
                arrowprops=dict(arrowstyle="->", lw=1.8))
    ax.text(6.95, 2.65, "forward pass", ha="center", fontsize=8)

    ax.annotate("", xy=(6.2, 1.9), xytext=(7.7, 1.9),
                arrowprops=dict(arrowstyle="->", lw=1.8))
    ax.text(6.95, 1.55, "logits", ha="center", fontsize=8)

    ax.annotate("", xy=(2.5, 1.5), xytext=(4.0, 1.5),
                arrowprops=dict(arrowstyle="->", lw=1.8))
    ax.text(3.25, 1.15, "200 OK\n{\"predicted_digit\": 2, ...}", ha="center", fontsize=8)

    ax.set_title("A Minimal Inference Server: the Network Boundary Around a Trained Model", fontsize=12)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch28_inference_server_flow.png", dpi=200)
    plt.close(fig)
    print("Figure 4 (client/server flow) saved.")


# ---------------------------------------------------------------------------
# Figure 5: Drift detection (Program 5)
# ---------------------------------------------------------------------------

def build_figure5():
    torch.manual_seed(0)
    np.random.seed(0)
    X_train, y_train, X_test, y_test = load_image_data()
    model = DigitClassifier()
    train_model(model, X_train, y_train, epochs=250)
    model.eval()

    X_train_flat = X_train.squeeze(1).reshape(len(X_train), -1).numpy()
    X_test_flat = X_test.squeeze(1).reshape(len(X_test), -1).numpy()

    gen = torch.Generator().manual_seed(0)
    noise = torch.randn(X_test.shape, generator=gen) * 0.05
    X_drifted = (X_test * 0.6 + 0.15 + noise).clamp(0.0, 1.0)
    X_drifted_flat = X_drifted.squeeze(1).reshape(len(X_drifted), -1).numpy()

    def per_pixel_ks(X_ref, X_current):
        n_features = X_ref.shape[1]
        stats = np.zeros(n_features)
        for j in range(n_features):
            stat, _ = ks_2samp(X_ref[:, j], X_current[:, j])
            stats[j] = stat
        return stats.reshape(8, 8)

    ks_clean = per_pixel_ks(X_train_flat, X_test_flat)
    ks_drifted = per_pixel_ks(X_train_flat, X_drifted_flat)

    with torch.no_grad():
        conf_clean = torch.softmax(model(X_test), dim=1).max(dim=1).values.mean().item()
        conf_drifted = torch.softmax(model(X_drifted), dim=1).max(dim=1).values.mean().item()
        acc_clean = (model(X_test).argmax(dim=1) == y_test).float().mean().item()
        acc_drifted = (model(X_drifted).argmax(dim=1) == y_test).float().mean().item()

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.3))

    im0 = axes[0].imshow(ks_clean, cmap="viridis", vmin=0, vmax=1)
    axes[0].set_title("KS statistic per pixel\n(clean test set vs. train)")
    axes[0].axis("off")
    fig.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)

    im1 = axes[1].imshow(ks_drifted, cmap="viridis", vmin=0, vmax=1)
    axes[1].set_title("KS statistic per pixel\n(drifted batch vs. train)")
    axes[1].axis("off")
    fig.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)

    metrics = ["Mean\nconfidence", "Accuracy\n(offline only)"]
    clean_vals = [conf_clean, acc_clean]
    drift_vals = [conf_drifted, acc_drifted]
    x = np.arange(len(metrics))
    width = 0.35
    axes[2].bar(x - width / 2, clean_vals, width, label="clean", color="#4C72B0",
                edgecolor="black", linewidth=0.8)
    axes[2].bar(x + width / 2, drift_vals, width, label="drifted", color="#C44E52",
                edgecolor="black", linewidth=0.8)
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(metrics)
    axes[2].set_ylim(0, 1.05)
    axes[2].set_title("Label-free signal vs.\nground truth")
    axes[2].legend(fontsize=8)

    fig.suptitle("Detecting Drift Without Labels: Input Statistics and Model Confidence", fontsize=12)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ch28_drift_detection.png", dpi=200)
    plt.close(fig)
    print("Figure 5 (drift detection) saved.")


# ---------------------------------------------------------------------------
# Figure 6: The model lifecycle (Section on MLOps) -- schematic, no data
# ---------------------------------------------------------------------------

def build_figure6():
    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    ax.set_xlim(0, 10.5)
    ax.set_ylim(0.3, 4.6)
    ax.axis("off")

    def box(cx, cy, text, color, w=1.9, h=1.05):
        rect = plt.Rectangle((cx - w / 2, cy - h / 2), w, h, facecolor=color,
                             edgecolor="black", linewidth=1.2, zorder=2)
        ax.add_patch(rect)
        ax.text(cx, cy, text, ha="center", va="center", fontsize=9.5, zorder=3)

    def arrow(x0, y0, x1, y1, style="-", color="black"):
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0), zorder=1,
                    arrowprops=dict(arrowstyle="->", lw=1.6, color=color, linestyle=style))

    top, bottom = 3.35, 1.05
    xs_top = [1.15, 3.85, 6.55, 9.25]
    box(xs_top[0], top, "Data\n(versioned)", "#FCE5CD")
    box(xs_top[1], top, "Train\n(code and config\nversioned)", "#FCE5CD")
    box(xs_top[2], top, "Evaluation gate\n(Program 6)", "#D9EAD3")
    box(xs_top[3], top, "Model registry\n(hash, lineage,\nmetrics)", "#D9EAD3")
    xs_bottom = [1.15, 5.2, 9.25]
    box(xs_bottom[2], bottom, "Deploy\n(canary or\nshadow first)", "#DCE9F5")
    box(xs_bottom[1], bottom, "Serve\n(Programs 4, 7)", "#DCE9F5")
    box(xs_bottom[0], bottom, "Monitor\n(Programs 5, 6)", "#F4CCCC")

    half = 0.95
    arrow(xs_top[0] + half, top, xs_top[1] - half, top)
    arrow(xs_top[1] + half, top, xs_top[2] - half, top)
    ax.text((xs_top[1] + xs_top[2]) / 2, top + 0.14, "candidate", ha="center", fontsize=8.5)
    arrow(xs_top[2] + half, top, xs_top[3] - half, top)
    ax.text((xs_top[2] + xs_top[3]) / 2, top + 0.14, "pass", ha="center", fontsize=8.5)
    arrow(xs_top[2], top + 0.525, xs_top[2], top + 0.95)
    ax.text(xs_top[2], top + 1.03, "fail: rejected, kept for audit", ha="center", fontsize=8.5)
    arrow(xs_top[3], top - 0.525, xs_bottom[2], bottom + 0.525)
    ax.text(xs_top[3] + 0.1, (top + bottom) / 2, "promote", ha="left", va="center", fontsize=8.5)
    arrow(xs_bottom[2] - half, bottom, xs_bottom[1] - half + 1.9, bottom)
    ax.text((xs_bottom[1] + xs_bottom[2]) / 2 + 0.05, bottom - 0.28, "then all traffic",
            ha="center", fontsize=8.5)
    arrow(xs_bottom[1] - half, bottom, xs_bottom[0] + half, bottom)
    ax.text((xs_bottom[0] + xs_bottom[1]) / 2, bottom - 0.28, "live traffic", ha="center",
            fontsize=8.5)
    arrow(xs_bottom[0], bottom + 0.525, xs_top[0], top - 0.525)
    ax.text(xs_top[0] - 0.1, (top + bottom) / 2, "retraining\ntrigger\n(drift)", ha="right",
            va="center", fontsize=8.5)
    p0, p1 = (xs_bottom[0] + half, bottom + 0.42), (xs_top[3] - half, top - 0.42)
    arrow(*p0, *p1, style="--", color="#C0392B")

    ax.set_title("The Model Lifecycle: Deployment Is One Step in a Loop", fontsize=12)
    fig.tight_layout()
    # Rotate the rollback label to the arrow's slope as drawn (display coordinates).
    d0, d1 = ax.transData.transform(p0), ax.transData.transform(p1)
    angle = np.degrees(np.arctan2(d1[1] - d0[1], d1[0] - d0[0]))
    ax.text((p0[0] + p1[0]) / 2 - 0.15, (p0[1] + p1[1]) / 2 + 0.17,
            "alarm: roll back to the previous registered version", ha="center",
            va="center", fontsize=8.5, color="#C0392B", rotation=angle,
            rotation_mode="anchor")
    fig.savefig(f"{FIG_DIR}/ch28_mlops_lifecycle.png", dpi=200)
    plt.close(fig)
    print("Figure 6 (model lifecycle) saved.")


if __name__ == "__main__":
    build_figure1()
    build_figure2()
    build_figure3()
    build_figure4()
    build_figure5()
    build_figure6()
    print("\nAll Chapter 28 figures built.")
