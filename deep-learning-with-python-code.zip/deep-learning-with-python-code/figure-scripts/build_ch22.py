import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t, X_test_t = torch.from_numpy(X_train), torch.from_numpy(X_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()
X_t = torch.from_numpy(X)
N = len(X)
NOISE_DIM = 16

class Generator(nn.Module):
    def __init__(self, noise_dim=NOISE_DIM):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(noise_dim, 32), nn.ReLU(),
                                  nn.Linear(32, 64), nn.Sigmoid())
    def forward(self, z):
        return self.net(z)

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 1))
    def forward(self, x):
        return self.net(x)

class VAE(nn.Module):
    def __init__(self, latent_dim):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, latent_dim)
        self.logvar_head = nn.Linear(32, latent_dim)
        self.decoder = nn.Sequential(nn.Linear(latent_dim, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())
    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)
    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + torch.randn_like(std) * std
    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar

class Judge(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)
    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

def vae_loss(recon, x, mu, logvar):
    recon_loss = ((recon - x) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    return recon_loss, kl

# =================================================================
# Train the GAN exactly as Program 2 does, tracking loss curves and
# fixed-noise samples along the way. Program 2 reseeds the generator
# (torch.manual_seed(123)) at EVERY one of its eight checkpoints to draw
# the same six noise vectors; that reseeding changes the random stream for
# the rest of training, so it is reproduced here at the same eight epochs,
# and the figures show Program 2's own run (asserted below).
# =================================================================
torch.manual_seed(0)
G = Generator()
D = Discriminator()
g_opt = optim.Adam(G.parameters(), lr=0.001, betas=(0.5, 0.999))
d_opt = optim.Adam(D.parameters(), lr=0.001, betas=(0.5, 0.999))
bce = nn.BCEWithLogitsLoss()
real_labels, fake_labels = torch.ones(N, 1), torch.zeros(N, 1)

d_losses, g_losses, d_real_probs, d_fake_probs = [], [], [], []
program2_checkpoints = {1, 25, 50, 100, 150, 200, 250, 300}
checkpoint_epochs = [1, 50, 100, 200, 300]          # the rows shown in Figure 1
checkpoint_samples = {}
logged = {}

for epoch in range(1, 301):
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z).detach()
    d_opt.zero_grad()
    d_loss = bce(D(X_t), real_labels) + bce(D(fake_images), fake_labels)
    d_loss.backward(); d_opt.step()

    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z)
    g_opt.zero_grad()
    g_loss = bce(D(fake_images), real_labels)
    g_loss.backward(); g_opt.step()

    with torch.no_grad():
        d_losses.append(d_loss.item())
        g_losses.append(g_loss.item())
        d_real_probs.append(torch.sigmoid(D(X_t)).mean().item())
        d_fake_probs.append(torch.sigmoid(D(fake_images)).mean().item())

    if epoch in program2_checkpoints:
        logged[epoch] = (f"{d_loss.item():.4f}", f"{g_loss.item():.4f}",
                         f"{d_real_probs[-1]:.4f}", f"{d_fake_probs[-1]:.4f}")
        with torch.no_grad():
            torch.manual_seed(123)
            fixed_z = torch.randn(6, NOISE_DIM)
            checkpoint_samples[epoch] = G(fixed_z).numpy().copy()
G.eval()

# Program 2's printed checkpoint lines: (d_loss, g_loss, D(real), D(fake))
PROGRAM2_PRINTED = {
    1: ("1.3928", "0.7434", "0.4804", "0.4755"), 25: ("1.0769", "0.8611", "0.6013", "0.4228"),
    50: ("0.9172", "1.0117", "0.6445", "0.3676"), 100: ("1.1951", "0.9106", "0.5190", "0.4070"),
    150: ("1.2176", "0.8480", "0.5254", "0.4292"), 200: ("1.1948", "0.7987", "0.5605", "0.4508"),
    250: ("1.2437", "0.7003", "0.5848", "0.4980"), 300: ("1.1767", "0.7424", "0.6060", "0.4780"),
}
assert logged == PROGRAM2_PRINTED, logged
assert f"{checkpoint_samples[300].mean():.4f}" == "0.2438"
assert f"{checkpoint_samples[1].mean():.4f}" == "0.4957"

# =================================================================
# 1. ch22_gan_training_progress.png -- generated images at checkpoints,
#    same 6 noise vectors throughout, showing noise -> digit-like shapes
# =================================================================
fig, axes = plt.subplots(len(checkpoint_epochs), 6, figsize=(8.5, 7.2))
for i, ep in enumerate(checkpoint_epochs):
    imgs = checkpoint_samples[ep].reshape(-1, 8, 8)
    for j in range(6):
        axes[i, j].imshow(imgs[j], cmap="gray_r", vmin=0, vmax=1)
        axes[i, j].set_xticks([]); axes[i, j].set_yticks([])
    axes[i, 0].set_ylabel(f"epoch {ep}", fontsize=10, rotation=90, labelpad=8)
fig.suptitle("Same 6 noise vectors decoded by the generator at different points in training",
             fontsize=11)
plt.tight_layout(rect=[0, 0, 1, 0.97])
plt.savefig("../figures/ch22_gan_training_progress.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch22_gan_training_progress.png")

# =================================================================
# 2. ch22_loss_curves.png -- D loss / G loss, and D(real) / D(fake)
#    probabilities, over all 300 epochs
# =================================================================
fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.4))
epochs_axis = np.arange(1, 301)
axes[0].plot(epochs_axis, d_losses, color=BLUE, label="Discriminator loss", linewidth=1.3)
axes[0].plot(epochs_axis, g_losses, color=ORANGE, label="Generator loss", linewidth=1.3)
axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
axes[0].set_title("Adversarial loss curves")
axes[0].legend(); axes[0].grid(alpha=0.3)

axes[1].plot(epochs_axis, d_real_probs, color=GREEN, label="D(real)", linewidth=1.3)
axes[1].plot(epochs_axis, d_fake_probs, color=RED, label="D(fake)", linewidth=1.3)
axes[1].axhline(0.5, color=GRAY, linestyle="--", linewidth=1, label="equilibrium (0.5)")
axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("Mean discriminator output")
axes[1].set_title("Discriminator's confidence on real vs. fake batches")
axes[1].legend(); axes[1].grid(alpha=0.3)
axes[1].set_ylim(0, 1)
plt.tight_layout()
plt.savefig("../figures/ch22_loss_curves.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch22_loss_curves.png")

# =================================================================
# Program 3, exactly: its own GAN (Program 2's recipe, but WITHOUT the
# checkpoint reseeding, so a different run from the one above), the two
# VAEs (healthy latent=4, oversized latent=16) and the judge.
# =================================================================
torch.manual_seed(0)
G3 = Generator()
D3 = Discriminator()
g3_opt = optim.Adam(G3.parameters(), lr=0.001, betas=(0.5, 0.999))
d3_opt = optim.Adam(D3.parameters(), lr=0.001, betas=(0.5, 0.999))
for epoch in range(300):
    z = torch.randn(N, NOISE_DIM)
    fake_images = G3(z).detach()
    d3_opt.zero_grad()
    d_loss = bce(D3(X_t), real_labels) + bce(D3(fake_images), fake_labels)
    d_loss.backward(); d3_opt.step()

    z = torch.randn(N, NOISE_DIM)
    fake_images = G3(z)
    g3_opt.zero_grad()
    g_loss = bce(D3(fake_images), real_labels)
    g_loss.backward(); g3_opt.step()
G3.eval()

def train_vae(latent_dim, seed=0):
    torch.manual_seed(seed)
    vae = VAE(latent_dim)
    opt = optim.Adam(vae.parameters(), lr=0.01)
    for epoch in range(300):
        vae.train(); opt.zero_grad()
        recon, mu, logvar = vae(X_train_t)
        recon_loss, kl = vae_loss(recon, X_train_t, mu, logvar)
        (recon_loss + kl).backward(); opt.step()
    vae.eval()
    return vae

vae_healthy = train_vae(latent_dim=4, seed=0)
vae_oversized = train_vae(latent_dim=16, seed=0)

torch.manual_seed(1)
judge = Judge()
judge_opt = optim.Adam(judge.parameters(), lr=0.01)
judge_loss_fn = nn.CrossEntropyLoss()
for epoch in range(100):
    judge.train(); judge_opt.zero_grad()
    loss = judge_loss_fn(judge(X_train_t), y_train_t)
    loss.backward(); judge_opt.step()
judge.eval()

N_GEN = 300
torch.manual_seed(42)
with torch.no_grad():
    gan_images = G3(torch.randn(N_GEN, NOISE_DIM))
    vae_h_images = vae_healthy.decoder(torch.randn(N_GEN, 4))
    vae_o_images = vae_oversized.decoder(torch.randn(N_GEN, 16))

def class_counts(judge, images, n_classes=10):
    with torch.no_grad():
        preds = judge(images).argmax(dim=1).numpy()
    return np.bincount(preds, minlength=n_classes)

gan_counts = class_counts(judge, gan_images)
vae_h_counts = class_counts(judge, vae_h_images)
vae_o_counts = class_counts(judge, vae_o_images)
# Program 3's printed predicted-class histograms
assert gan_counts.tolist() == [1, 19, 12, 34, 35, 52, 1, 3, 120, 23], gan_counts
assert vae_h_counts.tolist() == [21, 33, 0, 42, 25, 0, 24, 1, 117, 37], vae_h_counts
assert vae_o_counts.tolist() == [0, 0, 0, 0, 0, 0, 0, 0, 300, 0], vae_o_counts

# =================================================================
# 3. ch22_gan_vs_vae_comparison.png -- top: 8 sample images from each
#    of the 3 models; bottom: predicted-class histograms showing the
#    diversity difference (and the latent=16 collapse) directly
# =================================================================
fig = plt.figure(figsize=(12.0, 8.2))

model_images = [
    ("GAN", gan_images, GREEN, 0.76),
    ("VAE\n(latent=4)", vae_h_images, BLUE, 0.565),
    ("VAE\n(latent=16)\ncollapsed", vae_o_images, RED, 0.37),
]
img_left, img_right = 0.15, 0.98
row_height = 0.155
n_cols = 8
col_width = (img_right - img_left) / n_cols
for label, imgs, color, row_bottom in model_images:
    imgs_np = imgs.numpy().reshape(-1, 8, 8)
    for col in range(n_cols):
        ax = fig.add_axes([img_left + col * col_width, row_bottom,
                            col_width * 0.92, row_height])
        ax.imshow(imgs_np[col], cmap="gray_r", vmin=0, vmax=1)
        ax.set_xticks([]); ax.set_yticks([])
    fig.text(0.06, row_bottom + row_height / 2, label, fontsize=10, color=color,
              rotation=90, ha="center", va="center", fontweight="bold")

ax_hist = fig.add_axes([0.09, 0.06, 0.88, 0.22])
x = np.arange(10)
width = 0.26
ax_hist.bar(x - width, gan_counts, width, label="GAN", color=GREEN)
ax_hist.bar(x, vae_h_counts, width, label="VAE (latent=4)", color=BLUE)
ax_hist.bar(x + width, vae_o_counts, width, label="VAE (latent=16)", color=RED)
ax_hist.set_xticks(x)
ax_hist.set_xlabel("Judge's predicted digit class")
ax_hist.set_ylabel(f"Count (out of {N_GEN})")
ax_hist.set_title("Predicted-class histogram of generated images -- diversity, measured directly")
ax_hist.legend()
ax_hist.grid(alpha=0.3, axis="y")

fig.suptitle("Generated samples and their diversity: GAN vs. two VAE latent sizes",
             fontsize=12, y=0.965)
plt.savefig("../figures/ch22_gan_vs_vae_comparison.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch22_gan_vs_vae_comparison.png")

# =================================================================
# 4. ch22_conditional_gan.png -- Program 4's conditional GAN, exactly:
#    left, samples for every requested class (each column reuses one
#    noise vector across all ten rows); right, how well the judge reads
#    the requested class as training proceeds.
# =================================================================
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
N_CLASSES = 10
y_t = torch.from_numpy(y).long()


def one_hot(labels):
    return nn.functional.one_hot(labels, N_CLASSES).float()


class CondGenerator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(NOISE_DIM + N_CLASSES, 32), nn.ReLU(),
                                 nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, z, labels):
        return self.net(torch.cat([z, one_hot(labels)], dim=1))


class CondDiscriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(64 + N_CLASSES, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x, labels):
        return self.net(torch.cat([x, one_hot(labels)], dim=1))


# Program 4 trains its judge first (seed 1) -- the same judge as above.
torch.manual_seed(1)
judge4 = Judge()
opt4 = optim.Adam(judge4.parameters(), lr=0.01)
for epoch in range(100):
    opt4.zero_grad()
    nn.functional.cross_entropy(judge4(X_train_t), y_train_t).backward()
    opt4.step()
judge4.eval()


def measure_control(G):
    noise = torch.Generator().manual_seed(42)
    hits, images = [], []
    with torch.no_grad():
        for c in range(N_CLASSES):
            imgs = G(torch.randn(200, NOISE_DIM, generator=noise), torch.full((200,), c))
            hits.append((judge4(imgs).argmax(1) == c).float().mean().item())
            images.append(imgs)
    return np.array(hits), images


torch.manual_seed(0)
Gc, Dc = CondGenerator(), CondDiscriminator()
gc_opt = optim.Adam(Gc.parameters(), lr=0.001, betas=(0.5, 0.999))
dc_opt = optim.Adam(Dc.parameters(), lr=0.001, betas=(0.5, 0.999))
ones, zeros = torch.ones(N, 1), torch.zeros(N, 1)
curve_epochs, curve_mean, curve_worst, printed4 = [], [], [], {}
for epoch in range(1, 2001):
    fake = Gc(torch.randn(N, NOISE_DIM), y_t).detach()
    dc_opt.zero_grad()
    d_loss = bce(Dc(X_t, y_t), ones) + bce(Dc(fake, y_t), zeros)
    d_loss.backward()
    dc_opt.step()
    gc_opt.zero_grad()
    g_loss = bce(Dc(Gc(torch.randn(N, NOISE_DIM), y_t), y_t), ones)
    g_loss.backward()
    gc_opt.step()
    if epoch % 50 == 0:              # measuring uses its own generator: training is unchanged
        hits, _ = measure_control(Gc)
        curve_epochs.append(epoch); curve_mean.append(hits.mean()); curve_worst.append(hits.min())
        if epoch in (300, 1000, 1500, 2000):
            printed4[epoch] = (f"{hits.mean():.3f}", f"{hits.min():.3f}")
# Program 4's printed checkpoint lines
assert printed4 == {300: ("0.093", "0.000"), 1000: ("0.246", "0.010"),
                    1500: ("0.896", "0.710"), 2000: ("0.921", "0.725")}, printed4
hits, _ = measure_control(Gc)
assert [f"{h:.3f}" for h in hits] == ["0.990", "0.725", "0.985", "0.930", "0.905",
                                      "0.950", "0.975", "0.945", "0.915", "0.885"], hits

with torch.no_grad():
    z8 = torch.randn(8, NOISE_DIM, generator=torch.Generator().manual_seed(7))
    grid = [Gc(z8, torch.full((8,), c)).numpy().reshape(8, 8, 8) for c in range(N_CLASSES)]

fig = plt.figure(figsize=(12.6, 6.0))
outer = GridSpec(1, 2, width_ratios=[1.0, 1.05], wspace=0.16, left=0.05, right=0.98,
                 top=0.90, bottom=0.10)
inner = GridSpecFromSubplotSpec(N_CLASSES, 8, subplot_spec=outer[0], wspace=0.06, hspace=0.06)
for c in range(N_CLASSES):
    for j in range(8):
        ax = fig.add_subplot(inner[c, j])
        ax.imshow(grid[c][j], cmap="gray_r", vmin=0, vmax=1)
        ax.set_xticks([]); ax.set_yticks([])
        if j == 0:
            ax.set_ylabel(f"{c}", rotation=0, fontsize=10, labelpad=10, va="center")
fig.text(0.012, 0.50, "requested class", rotation=90, va="center", fontsize=10)
fig.text(0.27, 0.935, "Each column: one noise vector, ten requested classes", ha="center",
         fontsize=11)

ax = fig.add_subplot(outer[1])
ax.plot(curve_epochs, curve_mean, "-", color=GREEN, lw=2.0, label="mean over the 10 classes")
ax.plot(curve_epochs, curve_worst, "--", color=RED, lw=1.6, label="worst class")
for e, (m, w) in printed4.items():
    ax.plot([e], [float(m)], "o", color=GREEN, ms=6)
    ax.plot([e], [float(w)], "o", color=RED, ms=5)
ax.axhline(0.1, color=GRAY, lw=1.0, ls=":")
ax.text(1990, 0.115, "chance (0.1)", color=GRAY, fontsize=9, ha="right", va="bottom")
ax.axvline(300, color=GRAY, lw=1.0, ls="--")
ax.text(330, 0.62, "Program 2's\nbudget\n(300 epochs)", color=GRAY, fontsize=9, va="center")
ax.set_xlim(0, 2050); ax.set_ylim(-0.02, 1.02)
ax.set_xlabel("epoch")
ax.set_ylabel("fraction judged as the requested class")
ax.set_title("Control has to be learned", fontsize=11)
ax.legend(fontsize=9, loc="upper left")
ax.grid(alpha=0.3)
plt.savefig("../figures/ch22_conditional_gan.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch22_conditional_gan.png")
