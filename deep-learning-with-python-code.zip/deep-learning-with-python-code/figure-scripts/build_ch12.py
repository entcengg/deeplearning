import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
GRAY = "#7D8794"

data = np.load("ch12_data.npz")
x, y, x_val, y_val = data["x"], data["y"], data["x_val"], data["y_val"]

def poly_features(xx, degree):
    return np.vstack([xx**d for d in range(degree+1)]).T

def fit_ols(degree):
    X = poly_features(x, degree)
    w = np.linalg.lstsq(X, y, rcond=None)[0]
    return w

def predict(w, xx):
    degree = len(w) - 1
    return poly_features(xx, degree) @ w

# ---------- 1. ch12_poly_fits.png ----------
fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.4), sharey=True)
xs_smooth = np.linspace(-3.3, 3.3, 400)
degrees = [1, 3, 12]
titles = ["Degree 1: underfits", "Degree 3: good fit", "Degree 12: overfits"]

for ax, degree, title in zip(axes, degrees, titles):
    w = fit_ols(degree)
    ax.plot(xs_smooth, np.sin(xs_smooth), color=GRAY, linewidth=1.6, linestyle="--", label="true sin(x)")
    ax.plot(xs_smooth, predict(w, xs_smooth), color=BLUE, linewidth=2.0, label=f"degree-{degree} fit")
    ax.scatter(x, y, color="black", s=30, zorder=5, label="training data")
    ax.set_title(title, fontsize=11)
    ax.set_xlabel("$x$")
    ax.set_ylim(-3, 3)
    ax.grid(alpha=0.25)
axes[0].set_ylabel("$y$")
axes[0].legend(fontsize=8.5, loc="upper left")
plt.tight_layout()
plt.savefig("../figures/ch12_poly_fits.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch12_degree_curve.png ----------
degrees_range = list(range(1, 13))
train_errs, val_errs = [], []
for d in degrees_range:
    w = fit_ols(d)
    train_errs.append(np.mean((y - predict(w, x))**2))
    val_errs.append(np.mean((y_val - predict(w, x_val))**2))

fig, ax = plt.subplots(figsize=(7.2, 4.8))
ax.plot(degrees_range, train_errs, "o-", color=BLUE, label="training error")
ax.plot(degrees_range, val_errs, "s-", color=ORANGE, label="validation error")
ax.set_yscale("log")
ax.set_xlabel("polynomial degree"); ax.set_ylabel("MSE (log scale)")
ax.set_title("Training error keeps falling; validation error does not")
ax.legend(fontsize=10)
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch12_degree_curve.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch12_l2_sweep.png ----------
degree = 12
X = poly_features(x, degree)
Xv = poly_features(x_val, degree)

def fit_ridge(lam):
    n = X.shape[1]
    reg = lam * np.eye(n)
    reg[0, 0] = 0
    return np.linalg.solve(X.T @ X + reg, X.T @ y)

lambdas = np.logspace(-8, 3, 60)
train_e, val_e = [], []
for lam in lambdas:
    w = fit_ridge(lam)
    train_e.append(np.mean((y - X @ w)**2))
    val_e.append(np.mean((y_val - Xv @ w)**2))

fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(lambdas, train_e, color=BLUE, linewidth=2, label="training error")
ax.plot(lambdas, val_e, color=ORANGE, linewidth=2, label="validation error")
best_i = int(np.argmin(val_e))
ax.scatter([lambdas[best_i]], [val_e[best_i]], color="black", zorder=5, s=50,
           label=f"best: $\\lambda$={lambdas[best_i]:.4f}")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("$\\lambda$ (log scale)"); ax.set_ylabel("MSE (log scale)")
ax.set_title("L2 regularization sweep on the degree-12 polynomial")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch12_l2_sweep.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch12_early_stopping.png ----------
Xraw = poly_features(x, degree)
scales = np.max(np.abs(Xraw[:, 1:]), axis=0)
Xn = Xraw.copy(); Xn[:, 1:] /= scales
Xv_raw = poly_features(x_val, degree)
Xvn = Xv_raw.copy(); Xvn[:, 1:] /= scales

n = Xn.shape[1]; w = np.zeros(n)
eta = 0.3
epochs = 25000
train_hist, val_hist = [], []
for epoch in range(1, epochs + 1):
    pred = Xn @ w
    grad = (2 / len(y)) * Xn.T @ (pred - y)
    w -= eta * grad
    if epoch % 20 == 0:
        train_hist.append(np.mean((y - Xn @ w)**2))
        val_hist.append(np.mean((y_val - Xvn @ w)**2))

epochs_axis = np.arange(20, epochs + 1, 20)
best_idx = int(np.argmin(val_hist))

fig, ax = plt.subplots(figsize=(7.4, 4.8))
ax.plot(epochs_axis, train_hist, color=BLUE, linewidth=1.8, label="training error")
ax.plot(epochs_axis, val_hist, color=ORANGE, linewidth=1.8, label="validation error")
ax.axvline(epochs_axis[best_idx], color="gray", linestyle=":", linewidth=1.5)
ax.scatter([epochs_axis[best_idx]], [val_hist[best_idx]], color="black", zorder=5, s=50,
           label=f"best epoch $\\approx${epochs_axis[best_idx]}")
ax.set_xlabel("epoch"); ax.set_ylabel("MSE")
ax.set_title("Early stopping: training keeps improving after validation stops")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch12_early_stopping.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 4 figures")

# ---------------------------------------------------------------------------
# Figure 5: training and validation curves for an underfit, a good and an
# overfit model (Section "Reading Training and Validation Curves").
# Recomputes Program 5's gradient-descent runs with identical code and data
# (ch12_program5.py), then checks the plotted numbers against its printed
# output before saving.
# ---------------------------------------------------------------------------
from numpy.polynomial import legendre

rng5 = np.random.default_rng(0)
x5 = np.sort(rng5.uniform(-3, 3, 15))
y5 = np.sin(x5) + rng5.normal(0, 0.2, 15)
rng5v = np.random.default_rng(1)
x5v = np.sort(rng5v.uniform(-3, 3, 15))
y5v = np.sin(x5v) + rng5v.normal(0, 0.2, 15)

def legendre_features(xx, degree):
    return legendre.legvander(xx / 3, degree)

CHECK5 = set(np.unique(np.round(np.logspace(0, 6, 121)).astype(int)).tolist())

def gd_curves(degree, iters=1_000_000):
    X, Xv = legendre_features(x5, degree), legendre_features(x5v, degree)
    eta = 1 / np.linalg.eigvalsh((2 / 15) * X.T @ X).max()
    w = np.zeros(degree + 1)
    hist = []
    for it in range(1, iters + 1):
        w -= eta * (2 / 15) * X.T @ (X @ w - y5)
        if it in CHECK5:
            hist.append((it, np.mean((y5 - X @ w) ** 2), np.mean((y5v - Xv @ w) ** 2)))
    return np.array(hist)

curves5 = {d: gd_curves(d) for d in (1, 5, 12)}
# Values printed by ch12_program5.py (iteration 10^6 row and the val minima)
assert abs(curves5[1][-1, 2] - 0.36534) < 5e-6 and abs(curves5[5][-1, 2] - 0.05565) < 5e-6
assert abs(curves5[12][-1, 1] - 0.00112) < 5e-6 and abs(curves5[12][-1, 2] - 58.36427) < 5e-5
assert abs(curves5[12][:, 2].min() - 0.06079) < 5e-6

titles = {1: "Underfitting: degree 1", 5: "Good fit: degree 5", 12: "Overfitting: degree 12"}
fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.9), sharey=True)
for ax, d in zip(axes, (1, 5, 12)):
    h = curves5[d]
    ax.loglog(h[:, 0], h[:, 1], color=BLUE, lw=2, label="training MSE")
    ax.loglog(h[:, 0], h[:, 2], color=ORANGE, lw=2, label="validation MSE")
    best = np.argmin(h[:, 2])
    ax.plot(h[best, 0], h[best, 2], "o", color=ORANGE, ms=6, zorder=5)
    ax.set_title(titles[d], fontsize=11)
    ax.set_xlabel("gradient-descent iteration")
    ax.grid(True, which="major", alpha=0.3)
axes[0].set_ylabel("mean squared error")
axes[0].legend(loc="lower left", fontsize=9, framealpha=0.95)
axes[0].text(30, 0.06, "both errors stall early;\ntraining error stays high", fontsize=9,
             color=GRAY, va="top")
axes[1].text(30, 0.016, "both errors low and flat", fontsize=9, color=GRAY)
axes[2].text(1.5, 8, "validation turns upward\nwhile training keeps falling", fontsize=9,
             color=GRAY)
axes[2].annotate("best validation\n(iteration 1413)", xy=(1413, 0.0608), xytext=(2.0e4, 0.012),
                 fontsize=9, color=ORANGE,
                 arrowprops=dict(arrowstyle="-|>", color=ORANGE, lw=1.2))
plt.tight_layout()
plt.savefig("../figures/ch12_train_val_curves.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch12_train_val_curves.png")
