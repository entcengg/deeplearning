import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from mpl_toolkits.mplot3d import Axes3D
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"

# ---------- 1. ch05_neuron_diagram.png ----------
fig, ax = plt.subplots(figsize=(8.4, 4.6))
ax.set_xlim(0, 12); ax.set_ylim(0, 7); ax.axis("off")

inputs_y = [5.6, 3.5, 1.4]
labels = ["$x_1$", "$x_2$", "$x_3$"]
wlabels = ["$w_1$", "$w_2$", "$w_3$"]
for y, lab, wlab in zip(inputs_y, labels, wlabels):
    ax.add_patch(plt.Circle((1.0, y), 0.42, facecolor="#EAF2F8", edgecolor="black", lw=1.3, zorder=3))
    ax.text(1.0, y, lab, ha="center", va="center", fontsize=11, zorder=4)
    ax.annotate("", xy=(4.1, 3.5), xytext=(1.42, y),
                arrowprops=dict(arrowstyle="-|>", color="black", lw=1.3), zorder=2)
    mx, my = (1.42+4.1)/2, (y+3.5)/2
    ax.text(mx, my + (0.28 if y > 3.5 else (-0.32 if y < 3.5 else 0.22)),
            wlab, fontsize=10, ha="center", color="#7D8794", style="italic")

# summing junction
ax.add_patch(plt.Circle((4.6, 3.5), 0.55, facecolor="#D4E6F1", edgecolor="black", lw=1.4, zorder=3))
ax.text(4.6, 3.5, r"$\Sigma$", ha="center", va="center", fontsize=15, zorder=4)

# bias arrow coming from below
ax.add_patch(plt.Circle((4.6, 0.9), 0.38, facecolor="#FDEBD0", edgecolor="black", lw=1.2, zorder=3))
ax.text(4.6, 0.9, "$b$", ha="center", va="center", fontsize=10.5, zorder=4)
ax.annotate("", xy=(4.6, 2.93), xytext=(4.6, 1.30),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.3))

# z arrow to activation box
ax.annotate("", xy=(6.4, 3.5), xytext=(5.17, 3.5),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.5))
ax.text(5.75, 3.9, "$z$", ha="center", fontsize=10.5)

ax.add_patch(mpatches.FancyBboxPatch((6.5, 2.85), 2.1, 1.3, boxstyle="round,pad=0.08",
             facecolor="#A9CCE3", edgecolor="black", lw=1.4, zorder=3))
ax.text(7.55, 3.5, r"$\varphi$", ha="center", va="center", fontsize=15, zorder=4)

ax.annotate("", xy=(10.6, 3.5), xytext=(8.65, 3.5),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.5))
ax.text(10.9, 3.5, "$a$", ha="center", va="center", fontsize=12)

ax.text(4.6, 6.3, r"$z = w_1x_1+w_2x_2+w_3x_3+b \;=\; \mathbf{w}\cdot\mathbf{x}+b$",
        ha="center", fontsize=11)
ax.text(7.55, 1.85, r"$a=\varphi(z)$" "\nactivation\n(Ch. 6-7)", ha="center", fontsize=8.5, style="italic")

plt.tight_layout()
plt.savefig("../figures/ch05_neuron_diagram.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch05_line_fit.png ----------
C = np.array([0.0, 10.0, 20.0, 30.0])
F = np.array([32.0, 50.0, 68.0, 86.0])
Cline = np.linspace(-2, 32, 100)

fig, ax = plt.subplots(figsize=(6.8, 4.6))
ax.scatter(C, F, color="black", zorder=5, s=55, label="training data")
ax.plot(Cline, 1.0*Cline + 0.0, "--", color="#E67E22", linewidth=2,
        label=r"naive guess: $w{=}1,\,b{=}0$")
ax.plot(Cline, 1.8*Cline + 32.0, "-", color=BLUE, linewidth=2.4,
        label=r"trained: $w{=}1.8,\,b{=}32$")
ax.set_xlabel("Celsius, $C$"); ax.set_ylabel("Fahrenheit, $F$")
ax.set_title("The Celsius-to-Fahrenheit neuron, before and after training")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch05_line_fit.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch05_training_curves.png ----------
data = np.load("ch05_cf_training.npz")
w_t, b_t, loss_t = data["w"], data["b"], data["loss"]
epochs = np.arange(1, len(loss_t)+1)

fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.2))
axes[0].plot(epochs, loss_t, color=BLUE, linewidth=1.8)
axes[0].set_yscale("log")
axes[0].set_xlabel("epoch"); axes[0].set_ylabel("loss (log scale)")
axes[0].set_title("Loss during training")
axes[0].grid(alpha=0.25, which="both")

axes[1].plot(epochs, w_t/1.8, color="#E67E22", linewidth=1.8, label=r"$w(t)/1.8$")
axes[1].plot(epochs, b_t/32.0, color=BLUE, linewidth=1.8, label=r"$b(t)/32$")
axes[1].axhline(1.0, color="gray", linestyle=":", linewidth=1.2)
axes[1].set_xlabel("epoch"); axes[1].set_ylabel("fraction of target reached")
axes[1].set_title(r"$w$ reaches its target long before $b$ does")
axes[1].legend(fontsize=9.5)
axes[1].grid(alpha=0.25)

plt.tight_layout()
plt.savefig("../figures/ch05_training_curves.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch05_hyperplane.png ----------
x1 = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])
x2 = np.array([3.0, 1.0, 4.0, 2.0, 5.0, 3.0])
y  = 2*x1 - x2 + 5

fig = plt.figure(figsize=(8.0, 6.6))
ax = fig.add_subplot(111, projection="3d")
fig.subplots_adjust(left=0.02, right=0.86, top=0.92, bottom=0.08)

X1g, X2g = np.meshgrid(np.linspace(0, 7, 20), np.linspace(0, 6, 20))
Yg = 2*X1g - X2g + 5
ax.plot_surface(X1g, X2g, Yg, alpha=0.45, color=BLUE, edgecolor="none",
                rstride=1, cstride=1, zorder=1)

ax.scatter(x1, x2, y, color="black", s=70, zorder=10, depthshade=False,
           edgecolor="white", linewidth=0.8, label="training data")

ax.set_xlabel("$x_1$", labelpad=10)
ax.set_ylabel("$x_2$", labelpad=10)
ax.set_zlabel("$y$", labelpad=14)
ax.set_title(r"A 2-input linear neuron fits a plane: $\hat{y}=2x_1-x_2+5$", pad=0)
ax.view_init(elev=22, azim=-50)
plt.savefig("../figures/ch05_hyperplane.png", dpi=200)
plt.close()

# ---------- 5. ch05_weight_bias_sensitivity.png : varying w vs varying b ----------
Cline = np.linspace(-2, 32, 100)
ORANGE = "#E67E22"
GREEN = "#1C783C"

fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.6))

ax = axes[0]
ax.scatter(C, F, color="black", zorder=5, s=50, label="training data")
for w_val, color, style in [(1.0, ORANGE, "--"), (1.8, BLUE, "-"), (2.6, GREEN, "--")]:
    ax.plot(Cline, w_val * Cline + 32.0, style, color=color, linewidth=2.0,
            label=rf"$w{{=}}{w_val}$, $b{{=}}32$ (fixed)")
ax.scatter([0], [32], color="black", zorder=6, marker="x", s=70)
ax.set_xlabel("Celsius, $C$"); ax.set_ylabel("Fahrenheit, $F$")
ax.set_title(r"Varying $w$, with $b$ held fixed")
ax.legend(fontsize=8.5, loc="upper left")
ax.grid(alpha=0.25)

ax = axes[1]
ax.scatter(C, F, color="black", zorder=5, s=50, label="training data")
for b_val, color, style in [(10.0, ORANGE, "--"), (32.0, BLUE, "-"), (54.0, GREEN, "--")]:
    ax.plot(Cline, 1.8 * Cline + b_val, style, color=color, linewidth=2.0,
            label=rf"$w{{=}}1.8$ (fixed), $b{{=}}{b_val:.0f}$")
ax.set_xlabel("Celsius, $C$"); ax.set_ylabel("Fahrenheit, $F$")
ax.set_title(r"Varying $b$, with $w$ held fixed")
ax.legend(fontsize=8.5, loc="upper left")
ax.grid(alpha=0.25)

fig.suptitle(r"$w$ tilts the line; $b$ slides the whole line up or down", fontsize=11.5, y=1.01)
plt.tight_layout()
plt.savefig("../figures/ch05_weight_bias_sensitivity.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 6. ch05_diabetes_fit.png : a real, noisy dataset -- bmi vs. disease progression ----------
from sklearn.datasets import load_diabetes
data = load_diabetes()
bmi = data.data[:, data.feature_names.index("bmi")]
y_diab = data.target

w_diab, b_diab = 0.0, 0.0
X_diab = bmi.reshape(-1, 1)
m_diab = len(y_diab)
for _ in range(2000):
    y_hat = X_diab[:, 0] * w_diab + b_diab
    grad_w = (2 / m_diab) * np.sum(X_diab[:, 0] * (y_hat - y_diab))
    grad_b = 2 * np.mean(y_hat - y_diab)
    w_diab -= 0.8 * grad_w
    b_diab -= 0.8 * grad_b

fig, ax = plt.subplots(figsize=(7.2, 4.8))
ax.scatter(bmi, y_diab, color="#7D8794", s=16, alpha=0.6, zorder=2, label="442 patients")
bmi_line = np.linspace(bmi.min(), bmi.max(), 100)
ax.plot(bmi_line, w_diab * bmi_line + b_diab, color=BLUE, linewidth=2.4, zorder=5,
        label=rf"trained: $w{{\approx}}{w_diab:.0f}$, $b{{\approx}}{b_diab:.0f}$")
ax.set_xlabel("BMI (centered/scaled by scikit-learn)")
ax.set_ylabel("disease progression after one year")
ax.set_title("A real dataset: the best line leaves most points scattered around it")
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch05_diabetes_fit.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 6 figures")
