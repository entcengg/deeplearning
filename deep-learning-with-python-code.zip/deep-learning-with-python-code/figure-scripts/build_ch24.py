import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

CANVAS, CELL = 32, 8
S = CANVAS // CELL
SIZES = [8, 16]
NUM_CLASSES = 10
LAMBDA_COORD, LAMBDA_NOOBJ = 5.0, 0.5

digits = load_digits()
DIGIT_IMAGES = digits.images.astype(np.float32) / 16.0
DIGIT_LABELS = digits.target.astype(np.int64)


def make_sprite(img8x8, size):
    factor = size // 8
    return img8x8 if size == 8 else np.kron(img8x8, np.ones((factor, factor), dtype=np.float32))


def boxes_overlap(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    return not (ax2 <= bx1 or bx2 <= ax1 or ay2 <= by1 or by2 <= ay1)


def make_one_image(rng):
    n_objects = rng.choice([1, 2])
    placed = []
    attempts = 0
    while len(placed) < n_objects and attempts < 200:
        attempts += 1
        size = int(rng.choice(SIZES))
        x1 = int(rng.randint(0, CANVAS - size + 1)); y1 = int(rng.randint(0, CANVAS - size + 1))
        x2, y2 = x1 + size, y1 + size
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        gi, gj = int(cy // CELL), int(cx // CELL)
        collision = False
        for (_, ox1, oy1, ox2, oy2, ogi, ogj, _) in placed:
            if boxes_overlap((x1, y1, x2, y2), (ox1, oy1, ox2, oy2)) or (gi, gj) == (ogi, ogj):
                collision = True; break
        if collision:
            continue
        idx = int(rng.randint(0, len(DIGIT_IMAGES)))
        sprite = make_sprite(DIGIT_IMAGES[idx], size)
        placed.append((int(DIGIT_LABELS[idx]), x1, y1, x2, y2, gi, gj, sprite))
    canvas = np.zeros((CANVAS, CANVAS), dtype=np.float32)
    objectness = np.zeros((S, S), dtype=np.float32)
    box_target = np.zeros((S, S, 4), dtype=np.float32)
    class_target = np.zeros((S, S), dtype=np.int64)
    gt_boxes = []
    for (label, x1, y1, x2, y2, gi, gj, sprite) in placed:
        canvas[y1:y2, x1:x2] = sprite
        cell_left, cell_top = gj * CELL, gi * CELL
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        box_target[gi, gj] = [(cx - cell_left) / CELL, (cy - cell_top) / CELL,
                               (x2 - x1) / CELL, (y2 - y1) / CELL]
        objectness[gi, gj] = 1.0
        class_target[gi, gj] = label
        gt_boxes.append((label, x1, y1, x2, y2))
    return canvas, objectness, box_target, class_target, gt_boxes


def make_dataset(n_images, seed):
    rng = np.random.RandomState(seed)
    images, obj_t, box_t, cls_t, gt_all = [], [], [], [], []
    for _ in range(n_images):
        c, o, b, k, g = make_one_image(rng)
        images.append(c); obj_t.append(o); box_t.append(b); cls_t.append(k); gt_all.append(g)
    return (torch.from_numpy(np.stack(images)), torch.from_numpy(np.stack(obj_t)),
            torch.from_numpy(np.stack(box_t)), torch.from_numpy(np.stack(cls_t)), gt_all)


def detection_loss_parts(pred, obj_target, box_target, cls_target):
    conf_logit = pred[..., 0]; box_pred = pred[..., 1:5]; class_logits = pred[..., 5:]
    obj_mask, noobj_mask = obj_target, 1.0 - obj_target
    bce = nn.BCEWithLogitsLoss(reduction='none')
    conf_loss_obj = (bce(conf_logit, obj_target) * obj_mask).sum()
    conf_loss_noobj = (bce(conf_logit, torch.zeros_like(conf_logit)) * noobj_mask).sum()
    box_sse = ((box_pred - box_target) ** 2).sum(dim=-1)
    box_loss = (box_sse * obj_mask).sum()
    ce = nn.CrossEntropyLoss(reduction='none')
    class_loss_flat = ce(class_logits.reshape(-1, NUM_CLASSES), cls_target.reshape(-1))
    class_loss = (class_loss_flat.reshape(obj_mask.shape) * obj_mask).sum()
    batch = pred.shape[0]
    total = (LAMBDA_COORD * box_loss + conf_loss_obj + LAMBDA_NOOBJ * conf_loss_noobj + class_loss) / batch
    return total, (LAMBDA_COORD * box_loss / batch).item(), (conf_loss_obj / batch).item(), \
           (LAMBDA_NOOBJ * conf_loss_noobj / batch).item(), (class_loss / batch).item()


class TinyDetector(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.head = nn.Conv2d(64, 5 + NUM_CLASSES, kernel_size=1)

    def forward(self, x):
        out = self.head(self.backbone(x))
        return out.permute(0, 2, 3, 1)


def decode_box(gi, gj, t_x, t_y, t_w, t_h):
    cx, cy = gj * CELL + t_x * CELL, gi * CELL + t_y * CELL
    w, h = t_w * CELL, t_h * CELL
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a; bx1, by1, bx2, by2 = box_b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    union = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1) + max(0.0, bx2 - bx1) * max(0.0, by2 - by1) - inter
    return inter / union if union > 0 else 0.0


def nms(detections, iou_threshold=0.5):
    kept = []
    by_class = {}
    for d in detections:
        by_class.setdefault(d['class_id'], []).append(d)
    for class_id, dets in by_class.items():
        remaining = sorted(dets, key=lambda d: -d['confidence'])
        while remaining:
            best = remaining.pop(0)
            kept.append(best)
            remaining = [d for d in remaining if iou(best['box'], d['box']) <= iou_threshold]
    return kept


def draw_box(ax, box, color, lw=1.6, ls='-', label=None):
    x1, y1, x2, y2 = box
    rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=lw,
                              edgecolor=color, facecolor='none', linestyle=ls)
    ax.add_patch(rect)
    if label:
        ax.text(x1, y1 - 0.8, label, color=color, fontsize=8, fontweight='bold', va='bottom')


# ============================================================================
# Figure 1: IoU concept -- two boxes sliding apart
# ============================================================================
fig, axes = plt.subplots(1, 4, figsize=(11, 3.0))
fixed = (0.5, 0.5, 4.5, 4.5)
for ax, shift in zip(axes, [0, 1, 2, 4]):
    sliding = (0.5 + shift, 0.5, 4.5 + shift, 4.5)
    val = iou(fixed, sliding)
    ax.set_xlim(-0.5, 8.5); ax.set_ylim(-0.5, 5.5); ax.set_aspect('equal')
    ix1, iy1 = max(fixed[0], sliding[0]), max(fixed[1], sliding[1])
    ix2, iy2 = min(fixed[2], sliding[2]), min(fixed[3], sliding[3])
    if ix2 > ix1 and iy2 > iy1:
        ax.add_patch(patches.Rectangle((ix1, iy1), ix2 - ix1, iy2 - iy1,
                                        facecolor=PURPLE, alpha=0.35, edgecolor='none'))
    draw_box(ax, fixed, BLUE, label='A')
    draw_box(ax, sliding, ORANGE, label='B')
    ax.set_title(f"shift={shift}\nIoU={val:.3f}", fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
fig.suptitle("Intersection over Union as two boxes slide apart (purple = overlap)", fontsize=11)
plt.tight_layout()
plt.savefig("../figures/ch24_iou_concept.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch24_iou_concept.png")

# ============================================================================
# Figure 2: example synthetic scenes with grid + ground-truth boxes
# ============================================================================
_, _, _, _, example_gt = None, None, None, None, None
ex_images, ex_obj, ex_box, ex_cls, ex_gt = make_dataset(6, seed=42)
fig, axes = plt.subplots(2, 3, figsize=(9.5, 6.4))
for k, ax in enumerate(axes.flat):
    ax.imshow(ex_images[k].numpy(), cmap='gray_r', vmin=0, vmax=1, extent=(0, CANVAS, CANVAS, 0))
    for g in range(1, S):
        ax.axhline(g * CELL, color=GRAY, linewidth=0.5, alpha=0.5)
        ax.axvline(g * CELL, color=GRAY, linewidth=0.5, alpha=0.5)
    for (label, x1, y1, x2, y2) in ex_gt[k]:
        draw_box(ax, (x1, y1, x2, y2), RED, label=str(label))
    ax.set_xticks([]); ax.set_yticks([])
    ax.set_title(f"scene {k}: {len(ex_gt[k])} object(s)", fontsize=9)
fig.suptitle("Synthetic detection scenes: 4x4 grid overlay, exact ground-truth boxes", fontsize=11)
plt.tight_layout()
plt.savefig("../figures/ch24_dataset_examples.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch24_dataset_examples.png")

# ============================================================================
# Train the detector once; reuse for the loss curve and the NMS figure
# ============================================================================
torch.manual_seed(0)
train_images, train_obj, train_box, train_cls, train_gt = make_dataset(1200, seed=0)
test_images, test_obj, test_box, test_cls, test_gt = make_dataset(300, seed=1)
train_x, test_x = train_images.unsqueeze(1), test_images.unsqueeze(1)

model = TinyDetector()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
batch_size, n_batches = 100, 1200 // 100
history = {'total': [], 'box': [], 'conf_obj': [], 'conf_noobj': [], 'class': []}
print("Training TinyDetector for figures (300 epochs)...")
for epoch in range(1, 301):
    perm = torch.randperm(len(train_x))
    tot_e = box_e = co_e = cn_e = cl_e = 0.0
    for b in range(n_batches):
        idx = perm[b * batch_size:(b + 1) * batch_size]
        pred = model(train_x[idx])
        loss, lb, lco, lcn, lcl = detection_loss_parts(pred, train_obj[idx], train_box[idx], train_cls[idx])
        optimizer.zero_grad(); loss.backward(); optimizer.step()
        tot_e += loss.item(); box_e += lb; co_e += lco; cn_e += lcn; cl_e += lcl
    history['total'].append(tot_e / n_batches)
    history['box'].append(box_e / n_batches)
    history['conf_obj'].append(co_e / n_batches)
    history['conf_noobj'].append(cn_e / n_batches)
    history['class'].append(cl_e / n_batches)
    if epoch % 50 == 0:
        print(f"  epoch {epoch}: loss={history['total'][-1]:.4f}")
model.eval()
with torch.no_grad():
    test_pred = model(test_x)
conf_all = torch.sigmoid(test_pred[..., 0])

# ============================================================================
# Figure 3: training loss curve, total + components
# ============================================================================
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.0))
epochs = np.arange(1, 301)
axes[0].plot(epochs, history['total'], color=BLUE, linewidth=1.5)
axes[0].set_yscale('log')
axes[0].set_xlabel('epoch'); axes[0].set_ylabel('mean training loss (log scale)')
axes[0].set_title('Total detection loss')
axes[0].grid(alpha=0.3)

axes[1].plot(epochs, history['box'], color=BLUE, label='box (x $\\lambda_{coord}$)', linewidth=1.3)
axes[1].plot(epochs, history['conf_obj'], color=GREEN, label='confidence (object)', linewidth=1.3)
axes[1].plot(epochs, history['conf_noobj'], color=ORANGE, label='confidence (no object, x $\\lambda_{noobj}$)', linewidth=1.3)
axes[1].plot(epochs, history['class'], color=PURPLE, label='classification', linewidth=1.3)
axes[1].set_yscale('log')
axes[1].set_xlabel('epoch'); axes[1].set_ylabel('loss component (log scale)')
axes[1].set_title('The four loss terms separately')
axes[1].legend(fontsize=8)
axes[1].grid(alpha=0.3)
plt.tight_layout()
plt.savefig("../figures/ch24_loss_curves.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch24_loss_curves.png")

# ============================================================================
# Figure 4: raw (pre-NMS) vs. after-NMS detections, 3 example test images
# ============================================================================
CONF_THRESH = 0.3
example_indices = [25, 158, 30]   # images with a confirmed duplicate raw detection
fig, axes = plt.subplots(3, 2, figsize=(7.5, 10.5))
for row, img_idx in enumerate(example_indices):
    raw_dets = []
    for gi in range(S):
        for gj in range(S):
            c = conf_all[img_idx, gi, gj].item()
            if c > CONF_THRESH:
                t_x, t_y, t_w, t_h = test_pred[img_idx, gi, gj, 1:5].tolist()
                box = decode_box(gi, gj, t_x, t_y, t_w, t_h)
                class_id = test_pred[img_idx, gi, gj, 5:].argmax().item()
                raw_dets.append({'box': box, 'confidence': c, 'class_id': class_id})
    after = nms(raw_dets, iou_threshold=0.5)

    for col, (dets, title) in enumerate([(raw_dets, f"raw ({len(raw_dets)} detections)"),
                                          (after, f"after NMS ({len(after)} detection)")]):
        ax = axes[row, col]
        ax.imshow(test_images[img_idx].numpy(), cmap='gray_r', vmin=0, vmax=1,
                  extent=(0, CANVAS, CANVAS, 0))
        for (label, x1, y1, x2, y2) in test_gt[img_idx]:
            draw_box(ax, (x1, y1, x2, y2), GREEN, lw=1.2, ls='--')
        for d in dets:
            draw_box(ax, d['box'], RED, label=f"{d['confidence']:.2f}")
        ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(f"image {img_idx}: {title}", fontsize=9)
fig.suptitle("Raw per-cell detections vs. after Non-Maximum Suppression\n"
             "(green dashed = ground truth, red solid = detection, labeled with confidence)",
             fontsize=10)
plt.tight_layout()
plt.savefig("../figures/ch24_nms_before_after.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch24_nms_before_after.png")

print("\nAll Chapter 24 figures built.")
