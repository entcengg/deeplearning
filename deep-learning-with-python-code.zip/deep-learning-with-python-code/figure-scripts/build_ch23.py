import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

digits = load_digits()
X01 = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X01_train, X01_test, y_train, y_test = train_test_split(X01, y, test_size=0.2, random_state=0)
X01_train_t, X01_test_t = torch.from_numpy(X01_train), torch.from_numpy(X01_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()
X01_t = torch.from_numpy(X01)
Xpm1 = (X01 * 2 - 1).astype(np.float32)
Xpm1_train_t = torch.from_numpy((X01_train * 2 - 1).astype(np.float32))
N = len(X01)

T = 200
betas = torch.linspace(1e-4, 0.04, T)
alphas = 1 - betas
alpha_bars = torch.cumprod(alphas, dim=0)

class Denoiser(nn.Module):
    def __init__(self, T=T, time_dim=32, hidden=256):
        super().__init__()
        self.time_embed = nn.Embedding(T, time_dim)
        self.net = nn.Sequential(
            nn.Linear(64 + time_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 64),
        )
    def forward(self, x_t, t):
        return self.net(torch.cat([x_t, self.time_embed(t)], dim=1))

# =================================================================
# 1. ch23_forward_diffusion.png -- progressive corruption of one real
#    image at several timesteps (Program 1)
# =================================================================
torch.manual_seed(1)
x0 = torch.from_numpy(Xpm1[0])
checkpoints = [0, 1, 25, 50, 100, 150, 200]
imgs = []
for t in checkpoints:
    if t == 0:
        imgs.append(x0.clone())
    else:
        ab = alpha_bars[t - 1]
        eps = torch.randn(64)
        imgs.append(torch.sqrt(ab) * x0 + torch.sqrt(1 - ab) * eps)

fig, axes = plt.subplots(1, len(checkpoints), figsize=(12.5, 2.1))
for i, (t, img) in enumerate(zip(checkpoints, imgs)):
    axes[i].imshow(img.numpy().reshape(8, 8), cmap="gray_r", vmin=-1, vmax=1)
    axes[i].set_xticks([]); axes[i].set_yticks([])
    label = "$x_0$ (original)" if t == 0 else f"$x_{{{t}}}$"
    axes[i].set_title(label, fontsize=10)
fig.suptitle("Forward diffusion: the same image at increasing corruption steps $t$", fontsize=11, y=1.08)
plt.tight_layout()
plt.savefig("../figures/ch23_forward_diffusion.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch23_forward_diffusion.png")

# =================================================================
# Train the denoiser (matches Program 2) for the reverse-process figure
# =================================================================
torch.manual_seed(0)
denoiser = Denoiser()
opt = optim.Adam(denoiser.parameters(), lr=0.001)
losses = []
for epoch in range(4000):
    denoiser.train(); opt.zero_grad()
    t_idx = torch.randint(0, T, (len(Xpm1_train_t),))
    eps = torch.randn(len(Xpm1_train_t), 64)
    sqrt_ab = torch.sqrt(alpha_bars[t_idx]).unsqueeze(1)
    sqrt_1mab = torch.sqrt(1 - alpha_bars[t_idx]).unsqueeze(1)
    x_t = sqrt_ab * Xpm1_train_t + sqrt_1mab * eps
    loss = nn.functional.mse_loss(denoiser(x_t, t_idx), eps)
    loss.backward(); opt.step()
    losses.append(loss.item())
denoiser.eval()

@torch.no_grad()
def sample(n, record_steps=None, seed=None):
    if seed is not None:
        torch.manual_seed(seed)
    x = torch.randn(n, 64)
    trajectory = {}
    for t in reversed(range(T)):
        t_batch = torch.full((n,), t, dtype=torch.long)
        eps_pred = denoiser(x, t_batch)
        alpha_t, alpha_bar_t, beta_t = alphas[t], alpha_bars[t], betas[t]
        mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
        x = mean + torch.sqrt(beta_t) * torch.randn(n, 64) if t > 0 else mean
        if record_steps and t in record_steps:
            trajectory[t] = x.clone()
    return x, trajectory

# =================================================================
# 2. ch23_reverse_sampling.png -- training loss curve + the reverse
#    sampling trajectory from pure noise to a digit-like image
# =================================================================
_, traj = sample(6, record_steps={199, 150, 100, 50, 20, 0}, seed=123)

fig = plt.figure(figsize=(12.0, 5.2))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1.7], wspace=0.25)

ax_loss = fig.add_subplot(gs[0, 0])
ax_loss.plot(losses, color=BLUE, linewidth=0.8)
ax_loss.set_xlabel("Epoch"); ax_loss.set_ylabel("Noise-prediction MSE")
ax_loss.set_title("Denoiser training loss")
ax_loss.grid(alpha=0.3)

steps_order = [199, 150, 100, 50, 20, 0]
gs_right = gs[0, 1].subgridspec(len(steps_order), 6, hspace=0.15, wspace=0.1)
for i, t in enumerate(steps_order):
    imgs_t = traj[t].numpy().reshape(-1, 8, 8)
    for j in range(6):
        ax = fig.add_subplot(gs_right[i, j])
        ax.imshow(imgs_t[j], cmap="gray_r", vmin=-1, vmax=1)
        ax.set_xticks([]); ax.set_yticks([])
        if j == 0:
            ax.set_ylabel(f"t={t}", fontsize=8, rotation=0, ha="right", va="center")
fig.text(0.71, 0.94, "Same 6 noise vectors, denoised step by step (t=199 to t=0)", fontsize=10, ha="center")
plt.savefig("../figures/ch23_reverse_sampling.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch23_reverse_sampling.png")

# =================================================================
# Train GAN and VAE (Chapters 22/21 designs) for the 3-way comparison
# =================================================================
NOISE_DIM = 16
class Generator(nn.Module):
    def __init__(self, noise_dim=NOISE_DIM):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(noise_dim, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())
    def forward(self, z):
        return self.net(z)

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 1))
    def forward(self, x):
        return self.net(x)

class VAE(nn.Module):
    def __init__(self, latent_dim=4):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, latent_dim)
        self.logvar_head = nn.Linear(32, latent_dim)
        self.decoder = nn.Sequential(nn.Linear(latent_dim, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())
    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)
    def reparameterize(self, mu, logvar):
        return mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)
    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar

def vae_loss(recon, x, mu, logvar):
    recon_loss = ((recon - x) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    return recon_loss, kl

class Judge(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)
    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

torch.manual_seed(0)
G, D = Generator(), Discriminator()
g_opt = optim.Adam(G.parameters(), lr=0.001, betas=(0.5, 0.999))
d_opt = optim.Adam(D.parameters(), lr=0.001, betas=(0.5, 0.999))
bce = nn.BCEWithLogitsLoss()
real_labels, fake_labels = torch.ones(N, 1), torch.zeros(N, 1)
for epoch in range(300):
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z).detach()
    d_opt.zero_grad()
    (bce(D(X01_t), real_labels) + bce(D(fake_images), fake_labels)).backward()
    d_opt.step()
    z = torch.randn(N, NOISE_DIM)
    fake_images = G(z)
    g_opt.zero_grad()
    bce(D(fake_images), real_labels).backward()
    g_opt.step()
G.eval()

torch.manual_seed(0)
vae = VAE(latent_dim=4)
vae_opt = optim.Adam(vae.parameters(), lr=0.01)
for epoch in range(300):
    vae.train(); vae_opt.zero_grad()
    recon, mu, logvar = vae(X01_train_t)
    recon_loss, kl = vae_loss(recon, X01_train_t, mu, logvar)
    (recon_loss + kl).backward(); vae_opt.step()
vae.eval()

torch.manual_seed(1)
judge = Judge()
judge_opt = optim.Adam(judge.parameters(), lr=0.01)
for epoch in range(100):
    judge.train(); judge_opt.zero_grad()
    nn.functional.cross_entropy(judge(X01_train_t), y_train_t).backward()
    judge_opt.step()
judge.eval()

N_GEN = 300
torch.manual_seed(42)
with torch.no_grad():
    gan_images = G(torch.randn(N_GEN, NOISE_DIM))
    vae_images = vae.decoder(torch.randn(N_GEN, 4))
diffusion_raw, _ = sample(N_GEN, seed=42)
diffusion_images = ((diffusion_raw.clamp(-1, 1) + 1) / 2)

def class_counts(judge, images, n_classes=10):
    with torch.no_grad():
        preds = judge(images).argmax(dim=1).numpy()
    return np.bincount(preds, minlength=n_classes)

gan_counts = class_counts(judge, gan_images)
vae_counts = class_counts(judge, vae_images)
diff_counts = class_counts(judge, diffusion_images)

# =================================================================
# 3. ch23_three_way_comparison.png -- 8 samples each from GAN, VAE,
#    diffusion, plus the predicted-class histogram for all three
# =================================================================
fig = plt.figure(figsize=(12.0, 8.2))
model_images = [
    ("GAN", gan_images, GREEN, 0.76),
    ("VAE", vae_images, BLUE, 0.565),
    ("Diffusion", diffusion_images, PURPLE, 0.37),
]
img_left, img_right = 0.15, 0.98
row_height = 0.155
n_cols = 8
col_width = (img_right - img_left) / n_cols
for label, imgs_set, color, row_bottom in model_images:
    imgs_np = imgs_set.numpy().reshape(-1, 8, 8)
    for col in range(n_cols):
        ax = fig.add_axes([img_left + col * col_width, row_bottom,
                            col_width * 0.92, row_height])
        ax.imshow(imgs_np[col], cmap="gray_r", vmin=0, vmax=1)
        ax.set_xticks([]); ax.set_yticks([])
    fig.text(0.06, row_bottom + row_height / 2, label, fontsize=11, color=color,
              rotation=90, ha="center", va="center", fontweight="bold")

ax_hist = fig.add_axes([0.09, 0.06, 0.88, 0.22])
x = np.arange(10)
width = 0.26
ax_hist.bar(x - width, gan_counts, width, label="GAN", color=GREEN)
ax_hist.bar(x, vae_counts, width, label="VAE", color=BLUE)
ax_hist.bar(x + width, diff_counts, width, label="Diffusion", color=PURPLE)
ax_hist.set_xticks(x)
ax_hist.set_xlabel("Judge's predicted digit class")
ax_hist.set_ylabel(f"Count (out of {N_GEN})")
ax_hist.set_title("Predicted-class histogram of generated images")
ax_hist.legend()
ax_hist.grid(alpha=0.3, axis="y")

fig.suptitle("Three generative models, same judge classifier: GAN vs.\\ VAE vs.\\ diffusion",
             fontsize=12, y=0.965)
plt.savefig("../figures/ch23_three_way_comparison.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch23_three_way_comparison.png")
