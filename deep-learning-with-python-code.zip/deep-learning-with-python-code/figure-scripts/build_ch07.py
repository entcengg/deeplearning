import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"

# ---------- 1. ch07_linear_collapse.png ----------
fig, ax = plt.subplots(figsize=(9.2, 3.4))
ax.set_xlim(0, 14.6); ax.set_ylim(-0.3, 4.4); ax.axis("off")

def box(x, y, w, h, text, fc="#D4E6F1"):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                 facecolor=fc, edgecolor="black", lw=1.3))
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=10.5)

box(0.3, 1.5, 1.6, 1.2, "$x$", fc="#EAF2F8")
box(3.6, 1.5, 3.2, 1.2, r"$W_1 x + b_1$")
box(9.0, 1.5, 3.2, 1.2, r"$W_2(\cdot) + b_2$")

for (x1, x2) in [(1.9, 3.6), (6.8, 9.0)]:
    ax.annotate("", xy=(x2, 2.1), xytext=(x1, 2.1),
                arrowprops=dict(arrowstyle="-|>", color="black", lw=1.6))

ax.text(7.9, 3.15, "no activation in between", ha="center", fontsize=9, style="italic", color="#7D8794")
ax.text(7.0, 0.55,
        r"collapses to:  $y = (W_2 W_1)x + (W_2 b_1 + b_2) \;=\; W_{\mathrm{combined}}\,x + b_{\mathrm{combined}}$",
        ha="center", fontsize=10.5)
ax.text(7.0, -0.05, "-- a single linear layer, however many were stacked",
        ha="center", fontsize=9, style="italic", color="#7D8794")

plt.tight_layout()
plt.savefig("../figures/ch07_linear_collapse.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch07_activations_grid.png ----------
def sigmoid(z): return 1/(1+np.exp(-z))
def sigmoid_prime(z):
    s = sigmoid(z); return s*(1-s)
def tanh(z): return np.tanh(z)
def tanh_prime(z): return 1-np.tanh(z)**2
def relu(z): return np.maximum(0, z)
def relu_prime(z): return (z > 0).astype(float)
def leaky_relu(z, alpha=0.01): return np.where(z > 0, z, alpha*z)
def leaky_relu_prime(z, alpha=0.01): return np.where(z > 0, 1.0, alpha)

z = np.linspace(-5, 5, 400)
funcs = [
    ("Sigmoid", sigmoid, sigmoid_prime, (-0.1, 1.1)),
    ("Tanh", tanh, tanh_prime, (-1.2, 1.2)),
    ("ReLU", relu, relu_prime, (-1, 5.2)),
    ("Leaky ReLU", leaky_relu, leaky_relu_prime, (-1, 5.2)),
]

fig, axes = plt.subplots(2, 4, figsize=(13.5, 6.0))
for j, (name, f, fp, ylim) in enumerate(funcs):
    axes[0, j].plot(z, f(z), color=BLUE, linewidth=2.1)
    axes[0, j].set_title(name, fontsize=11)
    axes[0, j].set_ylim(*ylim)
    axes[0, j].grid(alpha=0.25)
    axes[0, j].axhline(0, color="gray", linewidth=0.6)

    axes[1, j].plot(z, fp(z), color=ORANGE, linewidth=2.1)
    axes[1, j].set_xlabel("$z$")
    axes[1, j].set_ylim(-0.1, 1.15)
    axes[1, j].grid(alpha=0.25)
    axes[1, j].axhline(0, color="gray", linewidth=0.6)

axes[0, 0].set_ylabel(r"$\varphi(z)$")
axes[1, 0].set_ylabel(r"$\varphi'(z)$")
plt.tight_layout()
plt.savefig("../figures/ch07_activations_grid.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch07_vanishing_gradient.png ----------
zs = [3.0, -4.0, 5.0, -3.0, 4.0]
slopes = [sigmoid_prime(z) for z in zs]
cumulative = np.cumprod(slopes)

fig, ax1 = plt.subplots(figsize=(7.6, 4.6))
layers = np.arange(1, 6)
ax1.bar(layers, slopes, color=BLUE, alpha=0.75, label="local slope at this layer")
ax1.set_xlabel("layer"); ax1.set_ylabel("local slope $\\sigma'(z)$", color=BLUE)
ax1.set_xticks(layers)
ax1.tick_params(axis="y", labelcolor=BLUE)

ax2 = ax1.twinx()
ax2.plot(layers, cumulative, "o-", color=ORANGE, linewidth=2.2, label="cumulative product")
ax2.set_yscale("log")
ax2.set_ylabel("cumulative product (log scale)", color=ORANGE)
ax2.tick_params(axis="y", labelcolor=ORANGE)

ax1.set_title("The chain rule across 5 saturated sigmoid layers")
fig.tight_layout()
plt.savefig("../figures/ch07_vanishing_gradient.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch07_softmax.png ----------
logits = np.array([2.0, 1.0, 0.1])
def softmax(z):
    z = z - np.max(z)
    e = np.exp(z)
    return e / np.sum(e)
probs = softmax(logits)

fig, axes = plt.subplots(1, 2, figsize=(9.4, 4.2))
axes[0].bar(["class A", "class B", "class C"], logits, color="#7D8794")
axes[0].set_title("Logits (raw $z$ values)")
axes[0].set_ylabel("$z$")
axes[0].grid(alpha=0.25, axis="y")

axes[1].bar(["class A", "class B", "class C"], probs, color=BLUE)
for i, p in enumerate(probs):
    axes[1].text(i, p + 0.02, f"{p:.3f}", ha="center", fontsize=9.5)
axes[1].set_title("Softmax output (sums to 1)")
axes[1].set_ylabel("probability")
axes[1].set_ylim(0, 0.8)
axes[1].grid(alpha=0.25, axis="y")

plt.tight_layout()
plt.savefig("../figures/ch07_softmax.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 5. ch07_gelu_silu.png ----------
from math import erf
_erf_vec = np.vectorize(erf)

def gelu_exact(zz):
    return zz * 0.5 * (1 + _erf_vec(zz / np.sqrt(2)))

def silu(zz):
    return zz * sigmoid(zz)

def gelu_prime_numeric(zz, h=1e-4):
    return (gelu_exact(zz + h) - gelu_exact(zz - h)) / (2 * h)

def silu_prime_numeric(zz, h=1e-4):
    return (silu(zz + h) - silu(zz - h)) / (2 * h)

GREEN = "#16A085"
z = np.linspace(-5, 5, 400)

fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.6))

axes[0].plot(z, relu(z), color="#7D8794", linewidth=1.6, linestyle="--", label="ReLU (reference)")
axes[0].plot(z, gelu_exact(z), color=BLUE, linewidth=2.1, label="GELU")
axes[0].plot(z, silu(z), color=ORANGE, linewidth=2.1, label="SiLU (Swish)")
axes[0].axhline(0, color="gray", linewidth=0.6)
axes[0].set_xlabel("$z$"); axes[0].set_ylabel(r"$\varphi(z)$")
axes[0].set_title("GELU and SiLU versus ReLU")
axes[0].legend(fontsize=9)
axes[0].grid(alpha=0.25)

axes[1].plot(z, relu_prime(z), color="#7D8794", linewidth=1.6, linestyle="--", label="ReLU$'$ (reference)")
axes[1].plot(z, gelu_prime_numeric(z), color=BLUE, linewidth=2.1, label="GELU$'$")
axes[1].plot(z, silu_prime_numeric(z), color=ORANGE, linewidth=2.1, label="SiLU$'$")
axes[1].axhline(0, color="gray", linewidth=0.6)
axes[1].set_xlabel("$z$"); axes[1].set_ylabel(r"$\varphi'(z)$")
axes[1].set_title("Derivatives: both dip negative, then approach 1")
axes[1].legend(fontsize=9)
axes[1].grid(alpha=0.25)

plt.tight_layout()
plt.savefig("../figures/ch07_gelu_silu.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 5 figures")
