import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
PURPLE = "#8E44AD"

# ---------- 1. ch09_network_diagram.png ----------
fig, ax = plt.subplots(figsize=(8.6, 5.6))
ax.set_xlim(0, 10); ax.set_ylim(0, 8); ax.axis("off")

layer_x = [1.2, 4.2, 7.2, 9.6]
layer_counts = [3, 4, 4, 2]
layer_names = ["input\n$\\mathbf{a}^{[0]}=\\mathbf{x}$", "hidden 1\n$\\mathbf{a}^{[1]}$",
               "hidden 2\n$\\mathbf{a}^{[2]}$", "output\n$\\mathbf{a}^{[3]}$"]
node_ys = []
for n in layer_counts:
    ys = np.linspace(6.5, 1.5, n) if n > 1 else [4.0]
    node_ys.append(ys)

for li in range(len(layer_x) - 1):
    for y1 in node_ys[li]:
        for y2 in node_ys[li+1]:
            ax.plot([layer_x[li]+0.28, layer_x[li+1]-0.28], [y1, y2],
                    color="#BFC9CA", linewidth=0.7, zorder=1)

colors = ["#EAF2F8", "#D4E6F1", "#D4E6F1", "#FDEBD0"]
for li, (x, ys, name, fc) in enumerate(zip(layer_x, node_ys, layer_names, colors)):
    for y in ys:
        ax.add_patch(plt.Circle((x, y), 0.28, facecolor=fc, edgecolor="black", lw=1.2, zorder=3))
    ax.text(x, 7.35, name, ha="center", fontsize=10)

ax.text(2.7, 0.6, r"$\mathbf{z}^{[1]}=W^{[1]}\mathbf{a}^{[0]}+\mathbf{b}^{[1]},\;\; \mathbf{a}^{[1]}=\varphi^{[1]}(\mathbf{z}^{[1]})$",
        ha="center", fontsize=9.5)
ax.text(5.7, 0.6, r"$\mathbf{z}^{[2]}=W^{[2]}\mathbf{a}^{[1]}+\mathbf{b}^{[2]},\;\; \mathbf{a}^{[2]}=\varphi^{[2]}(\mathbf{z}^{[2]})$",
        ha="center", fontsize=9.5)
ax.text(8.4, 0.6, r"$\mathbf{a}^{[3]}=$" "\noutput", ha="center", fontsize=9.5)

plt.tight_layout()
plt.savefig("../figures/ch09_network_diagram.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch09_xor_network.png ----------
fig, ax = plt.subplots(figsize=(8.2, 5.4))
ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")

# input nodes
ax.add_patch(plt.Circle((1.0, 5.0), 0.4, facecolor="#EAF2F8", edgecolor="black", lw=1.3, zorder=3))
ax.text(1.0, 5.0, "$x_1$", ha="center", va="center", fontsize=11)
ax.add_patch(plt.Circle((1.0, 2.0), 0.4, facecolor="#EAF2F8", edgecolor="black", lw=1.3, zorder=3))
ax.text(1.0, 2.0, "$x_2$", ha="center", va="center", fontsize=11)

# hidden nodes
ax.add_patch(plt.Circle((4.6, 5.5), 0.5, facecolor="#D4E6F1", edgecolor="black", lw=1.3, zorder=3))
ax.text(4.6, 5.5, "$h_A$\n(OR)", ha="center", va="center", fontsize=9.5)
ax.add_patch(plt.Circle((4.6, 1.5), 0.5, facecolor="#D4E6F1", edgecolor="black", lw=1.3, zorder=3))
ax.text(4.6, 1.5, "$h_B$\n(NAND)", ha="center", va="center", fontsize=9.5)

# output node
ax.add_patch(plt.Circle((8.4, 3.5), 0.5, facecolor="#FDEBD0", edgecolor="black", lw=1.3, zorder=3))
ax.text(8.4, 3.5, "$y$\n(AND)", ha="center", va="center", fontsize=9.5)

edges = [
    ((1.0,5.0),(4.6,5.5), "1"), ((1.0,2.0),(4.6,5.5), "1"),
    ((1.0,5.0),(4.6,1.5), "-1"), ((1.0,2.0),(4.6,1.5), "-1"),
    ((4.6,5.5),(8.4,3.5), "1"), ((4.6,1.5),(8.4,3.5), "1"),
]
for (x1,y1),(x2,y2),w in edges:
    ax.annotate("", xy=(x2,y2), xytext=(x1,y1),
                arrowprops=dict(arrowstyle="-|>", color="black", lw=1.3), zorder=2)
    # Place the label 70% of the way along the edge (not at the midpoint):
    # the two diagonal edges (x1->hB and x2->hA) cross each other near the
    # midpoint, so a midpoint label sits right where the lines intersect.
    # At t=0.7 the edges have already fanned apart, clear of the crossing.
    t = 0.7
    mx, my = x1 + t*(x2-x1), y1 + t*(y2-y1)
    # Nudge perpendicular to the edge (not just straight up) so the label
    # clears steep edges too, instead of sitting on top of the line itself.
    dx, dy = x2-x1, y2-y1
    length = (dx**2 + dy**2) ** 0.5
    px, py = -dy/length, dx/length
    if py < 0:
        px, py = -px, -py
    off = 0.22
    ax.text(mx + off*px, my + off*py, f"$w={w}$", fontsize=8, color="#7D8794")

ax.text(4.6, 6.5, "$b=-0.5$", ha="center", fontsize=9, color=PURPLE)
ax.text(4.6, 0.6, "$b=1.5$", ha="center", fontsize=9, color=PURPLE)
ax.text(8.4, 4.5, "$b=-1.5$", ha="center", fontsize=9, color=PURPLE)

ax.text(5.0, 6.9, "hidden layer (step activation)", ha="center", fontsize=10, style="italic")

plt.tight_layout()
plt.savefig("../figures/ch09_xor_network.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch09_xor_geometry.png ----------
X = np.array([[0,0],[0,1],[1,0],[1,1]])
y_xor = np.array([0,1,1,0])

fig, ax = plt.subplots(figsize=(6.4, 5.8))
for xi, yi in zip(X, y_xor):
    color = BLUE if yi == 1 else ORANGE
    marker = "o" if yi == 1 else "s"
    ax.scatter(*xi, color=color, s=220, zorder=5, marker=marker, edgecolor="black")
    ax.annotate(f"({xi[0]},{xi[1]})", xi, textcoords="offset points", xytext=(12,8), fontsize=9)

x1_line = np.linspace(-0.6, 1.6, 50)
ax.plot(x1_line, 0.5 - x1_line, color=PURPLE, linewidth=2, label=r"$h_A$: $x_1+x_2=0.5$ (OR boundary)")
ax.plot(x1_line, 1.5 - x1_line, color="#16A085", linewidth=2, label=r"$h_B$: $x_1+x_2=1.5$ (NAND boundary)")
ax.fill_between(x1_line, np.maximum(0.5-x1_line, -1), np.minimum(1.5-x1_line, 2.2),
                color=BLUE, alpha=0.12, label="between the lines $\\to$ output 1")

ax.set_xlim(-0.6, 1.6); ax.set_ylim(-0.6, 2.0)
ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
ax.set_title("Two hidden boundaries together carve out the XOR region")
ax.legend(fontsize=8.5, loc="upper right")
ax.set_aspect("equal")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch09_xor_geometry.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch09_forward_flow_numeric.png ----------
# Re-run Program 1's exact 3 -> 4 (ReLU) -> 2 (softmax) example and draw
# the real computed numbers flowing through the network, node by node.
def relu(zz): return np.maximum(0, zz)
def softmax_(zz):
    zz = zz - np.max(zz)
    e = np.exp(zz)
    return e / np.sum(e)

x_in = np.array([1.0, -2.0, 0.5])
W1p = np.array([[0.2, -0.1, 0.4], [0.5, 0.3, -0.2], [-0.3, 0.8, 0.1], [0.1, 0.1, 0.1]])
b1p = np.array([0.1, -0.2, 0.05, 0.0])
W2p = np.array([[0.3, -0.2, 0.5, 0.1], [-0.1, 0.4, 0.2, -0.3]])
b2p = np.array([0.0, 0.1])

z1p = W1p @ x_in + b1p
a1p = relu(z1p)
z2p = W2p @ a1p + b2p
a2p = softmax_(z2p)

fig, ax = plt.subplots(figsize=(9.6, 5.8))
ax.set_xlim(0, 10); ax.set_ylim(0, 7.6); ax.axis("off")

layer_x = [1.3, 4.8, 8.4]
in_ys = np.linspace(6.2, 1.4, 3)
hid_ys = np.linspace(6.6, 1.0, 4)
out_ys = np.linspace(5.0, 2.6, 2)

for y1 in in_ys:
    for y2 in hid_ys:
        ax.plot([layer_x[0]+0.35, layer_x[1]-0.35], [y1, y2], color="#BFC9CA", linewidth=0.6, zorder=1)
for y1 in hid_ys:
    for y2 in out_ys:
        ax.plot([layer_x[1]+0.35, layer_x[2]-0.35], [y1, y2], color="#BFC9CA", linewidth=0.6, zorder=1)

for y, val in zip(in_ys, x_in):
    ax.add_patch(plt.Circle((layer_x[0], y), 0.35, facecolor="#EAF2F8", edgecolor="black", lw=1.2, zorder=3))
    ax.text(layer_x[0], y, f"{val:.1f}", ha="center", va="center", fontsize=10, zorder=4)

for y, z, a in zip(hid_ys, z1p, a1p):
    ax.add_patch(plt.Circle((layer_x[1], y), 0.42, facecolor="#D4E6F1", edgecolor="black", lw=1.2, zorder=3))
    ax.text(layer_x[1], y+0.1, f"$z$={z:.2f}", ha="center", va="center", fontsize=8.5, zorder=4)
    ax.text(layer_x[1], y-0.15, f"$a$={a:.2f}", ha="center", va="center", fontsize=8.5, zorder=4, weight="bold")

for y, z, a in zip(out_ys, z2p, a2p):
    ax.add_patch(plt.Circle((layer_x[2], y), 0.42, facecolor="#FDEBD0", edgecolor="black", lw=1.2, zorder=3))
    ax.text(layer_x[2], y+0.1, f"$z$={z:.2f}", ha="center", va="center", fontsize=8.5, zorder=4)
    ax.text(layer_x[2], y-0.15, f"$p$={a:.2f}", ha="center", va="center", fontsize=8.5, zorder=4, weight="bold")

ax.text(layer_x[0], 7.2, "input $\\mathbf{x}$", ha="center", fontsize=11)
ax.text(layer_x[1], 7.2, "hidden (ReLU)\n$z^{[1]},\\,a^{[1]}$", ha="center", fontsize=11)
ax.text(layer_x[2], 7.2, "output (softmax)\n$z^{[2]},\\,a^{[2]}$", ha="center", fontsize=11)
ax.text(5.0, 0.35, "Program 1's exact numbers, flowing left to right through the network", ha="center", fontsize=9.5, style="italic", color="#7D8794")

plt.tight_layout()
plt.savefig("../figures/ch09_forward_flow_numeric.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 5. ch09_diamond_region.png ----------
def step_(zz): return np.where(zz > 0, 1.0, 0.0)
W1d = np.array([[-1.0,-1.0],[-1.0,1.0],[1.0,-1.0],[1.0,1.0]])
b1d = np.array([1.0,1.0,1.0,1.0])
W2d = np.array([[1.0,1.0,1.0,1.0]])
b2d = np.array([-3.5])

gx, gy = np.meshgrid(np.linspace(-2.2, 2.2, 300), np.linspace(-2.2, 2.2, 300))
pts = np.stack([gx.ravel(), gy.ravel()], axis=1)
H = step_(pts @ W1d.T + b1d)
pred = step_(H @ W2d.T + b2d).reshape(gx.shape)

fig, ax = plt.subplots(figsize=(6.6, 6.0))
ax.contourf(gx, gy, pred, levels=[-0.5, 0.5, 1.5], colors=["#FDEBD0", "#D4E6F1"])
diamond_x = [1, 0, -1, 0, 1]
diamond_y = [0, 1, 0, -1, 0]
ax.plot(diamond_x, diamond_y, color=PURPLE, linewidth=2.2, label="$|x_1|+|x_2|=1$ (the four hidden boundaries)")

test_points = np.array([[0.0,0.0],[0.5,0.2],[-0.3,-0.4],[0.4,-0.4],
                         [1.0,1.0],[-1.0,1.0],[0.9,0.9],[2.0,0.0],[0.0,-2.0]])
truth = (np.abs(test_points[:,0]) + np.abs(test_points[:,1]) <= 1.0)
ax.scatter(test_points[truth,0], test_points[truth,1], color=BLUE, s=90, zorder=5, edgecolor="black", label="inside (tested)")
ax.scatter(test_points[~truth,0], test_points[~truth,1], color=ORANGE, s=90, marker="s", zorder=5, edgecolor="black", label="outside (tested)")

ax.set_xlim(-2.2, 2.2); ax.set_ylim(-2.2, 2.2)
ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
ax.set_title("Four hidden half-planes carve out a bounded diamond")
ax.legend(fontsize=8, loc="lower right")
ax.set_aspect("equal")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch09_diamond_region.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 6. ch09_width_depth.png ----------
def tent(xx): return 2*np.maximum(0,xx) - 4*np.maximum(0, xx-0.5)
def deep_narrow(xx, depth):
    y = xx.copy()
    for _ in range(depth):
        y = tent(y)
    return y
def shallow_wide(xx, n_neurons, rng):
    breakpoints = rng.uniform(0.0, 1.0, n_neurons)
    signs = rng.choice([-1.0, 1.0], n_neurons)
    weights_out = rng.normal(0, 1, n_neurons)
    y = np.zeros_like(xx)
    for bp, s, v in zip(breakpoints, signs, weights_out):
        y += v * np.maximum(0, s*(xx - bp))
    return y

xs = np.linspace(0, 1, 2001)
rng = np.random.default_rng(0)
deep_y = deep_narrow(xs, depth=4)            # 8 neurons -> 16 pieces
shallow_y = shallow_wide(xs, 8, rng)         # 8 neurons -> measured 2 pieces

fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.6))
axes[0].plot(xs, deep_y, color=BLUE, linewidth=1.6)
axes[0].set_title("Depth: 4 layers $\\times$ 2 ReLUs (8 neurons) $\\to$ 16 pieces")
axes[0].set_xlabel("$x$"); axes[0].set_ylabel("$f(x)$")
axes[0].grid(alpha=0.25)

axes[1].plot(xs, shallow_y, color=ORANGE, linewidth=1.6)
axes[1].set_title("Width: 1 layer $\\times$ 8 ReLUs (8 neurons) $\\to$ 2 pieces")
axes[1].set_xlabel("$x$"); axes[1].set_ylabel("$f(x)$")
axes[1].grid(alpha=0.25)

plt.tight_layout()
plt.savefig("../figures/ch09_width_depth.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 6 figures")
