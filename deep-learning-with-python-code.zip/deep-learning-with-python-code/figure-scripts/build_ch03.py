import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"

# ---------- 1. ch03_tensor_ranks.png ----------
fig, ax = plt.subplots(figsize=(9.6, 3.4))
ax.set_xlim(0, 16); ax.set_ylim(0, 5.6); ax.axis("off")

def cell(x, y, s=0.62, fc="#D4E6F1", txt=None, fs=8.5):
    ax.add_patch(plt.Rectangle((x, y), s, s, facecolor=fc, edgecolor="black", lw=0.9))
    if txt is not None:
        ax.text(x + s/2, y + s/2, txt, ha="center", va="center", fontsize=fs)

# scalar
cell(0.9, 2.6, txt="7")
ax.text(1.21, 4.4, "scalar", ha="center", fontsize=10, fontweight="bold")
ax.text(1.21, 1.7, "rank 0\nshape ( )", ha="center", fontsize=8.5)

# vector
for i, v in enumerate([2, -1, 3]):
    cell(3.4, 3.3 - i*0.62, txt=str(v))
ax.text(3.71, 4.4, "vector", ha="center", fontsize=10, fontweight="bold")
ax.text(3.71, 1.2, "rank 1\nshape (3,)", ha="center", fontsize=8.5)

# matrix
Mv = [[1, 0, 2], [-1, 3, 1]]
for i in range(2):
    for j in range(3):
        cell(5.9 + j*0.62, 3.0 - i*0.62, txt=str(Mv[i][j]))
ax.text(6.83, 4.4, "matrix", ha="center", fontsize=10, fontweight="bold")
ax.text(6.83, 1.55, "rank 2\nshape (2, 3)", ha="center", fontsize=8.5)

# rank-3 tensor: stacked sheets (back sheets plain, front sheet gridded)
for k in range(2):
    off = (2 - k) * 0.30
    ax.add_patch(plt.Rectangle((9.6 + off, 2.3 - 2*0.62 + off), 3*0.62, 3*0.62,
                 facecolor=["#EAF2F8", "#D4E6F1"][k], edgecolor="black", lw=0.9))
for i in range(3):
    for j in range(3):
        cell(9.6 + j*0.62, 2.3 - i*0.62, fc="#A9CCE3")
ax.text(10.9, 4.4, "rank-3 tensor", ha="center", fontsize=10, fontweight="bold")
ax.text(10.9, 0.35, "rank 3\nshape (3, 3, 3)", ha="center", fontsize=8.5)

# rank-4 tensor: a batch of two rank-3 tensors (e.g. two small colour images)
s4 = 0.36
for n, x0 in enumerate([12.6, 14.4]):
    for k in range(2):
        off = (2 - k) * 0.18
        ax.add_patch(plt.Rectangle((x0 + off, 2.62 - 2*s4 + off), 3*s4, 3*s4,
                     facecolor=["#EAF2F8", "#D4E6F1"][k], edgecolor="black", lw=0.8))
    for i in range(3):
        for j in range(3):
            cell(x0 + j*s4, 2.62 - i*s4, s=s4, fc="#A9CCE3")
    ax.text(x0 + 0.72, 1.55, f"item {n + 1}", ha="center", fontsize=8)
ax.text(14.22, 4.4, "rank-4 tensor", ha="center", fontsize=10, fontweight="bold")
ax.text(14.22, 0.35, "rank 4\nshape (2, 3, 3, 3)", ha="center", fontsize=8.5)
plt.tight_layout(); plt.savefig("../figures/ch03_tensor_ranks.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 2. ch03_matmul.png ----------
fig, ax = plt.subplots(figsize=(8.6, 4.2))
ax.set_xlim(0, 14); ax.set_ylim(0, 7); ax.axis("off")
s = 0.85
A = [[1, 2], [3, 4]]
B = [[5, 6], [7, 0]]
C = [[19, 6], [43, 18]]

def grid(x0, y0, Mv, hl=None, fc="#EAF2F8"):
    for i in range(len(Mv)):
        for j in range(len(Mv[0])):
            face = fc
            if hl and (i, j) in hl: face = "#FDEBD0"
            ax.add_patch(plt.Rectangle((x0 + j*s, y0 - i*s), s, s,
                         facecolor=face, edgecolor="black", lw=1.1))
            ax.text(x0 + j*s + s/2, y0 - i*s + s/2, str(Mv[i][j]),
                    ha="center", va="center", fontsize=11)

grid(1.0, 4.6, A, hl=[(0, 0), (0, 1)])                 # row 1 of A
ax.text(1.85, 5.9, "A  (2$\\times$2)", ha="center", fontsize=10)
ax.text(3.25, 4.15, "@", fontsize=14)
grid(4.0, 4.6, B, hl=[(0, 1), (1, 1)])                 # column 2 of B
ax.text(4.85, 5.9, "B  (2$\\times$2)", ha="center", fontsize=10)
ax.text(6.25, 4.15, "=", fontsize=14)
grid(7.0, 4.6, C, hl=[(0, 1)])
ax.text(7.85, 5.9, "A @ B", ha="center", fontsize=10)

ax.text(7.0, 1.9, "highlighted cell = (row 1 of A) $\\cdot$ (column 2 of B)"
        "\n$= 1\\times 6 + 2\\times 0 = 6$",
        ha="center", fontsize=10.5)
ax.text(7.0, 0.6, "shape rule:  $(m\\times n)\\;@\\;(n\\times p)\\;\\rightarrow\\;(m\\times p)$"
        " --- the inner sizes must match",
        ha="center", fontsize=10.5)
plt.tight_layout(); plt.savefig("../figures/ch03_matmul.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 3. ch03_digit_tensor.png ----------
from sklearn.datasets import load_digits
digits = load_digits()
img = digits.images[0]
fig, axes = plt.subplots(1, 2, figsize=(8.6, 4.0))
axes[0].imshow(img, cmap="gray_r")
axes[0].set_title("what you see: a handwritten 0")
axes[0].set_xticks(range(8)); axes[0].set_yticks(range(8))
axes[1].imshow(np.ones_like(img), cmap="gray", vmin=0, vmax=1)
for i in range(8):
    for j in range(8):
        axes[1].text(j, i, int(img[i, j]), ha="center", va="center", fontsize=8)
axes[1].set_title("what the computer sees: an 8$\\times$8 grid of numbers")
axes[1].set_xticks(range(8)); axes[1].set_yticks(range(8))
for a in axes:
    a.tick_params(labelsize=7)
plt.tight_layout(); plt.savefig("../figures/ch03_digit_tensor.png", dpi=200, bbox_inches="tight"); plt.close()

# ---------- 4. ch03_broadcasting.png ----------
fig, ax = plt.subplots(figsize=(8.8, 3.6))
ax.set_xlim(0, 15); ax.set_ylim(0, 5.6); ax.axis("off")
s = 0.9
Mv = [[1, 2, 3], [4, 5, 6]]
bv = [10, 20, 30]
Rv = [[11, 22, 33], [14, 25, 36]]

def g(x0, y0, rows, fc="#EAF2F8", dashed=False):
    for i in range(len(rows)):
        for j in range(len(rows[0])):
            ax.add_patch(plt.Rectangle((x0 + j*s, y0 - i*s), s, s, facecolor=fc,
                         edgecolor="black", lw=1.0, linestyle=":" if dashed else "-"))
            ax.text(x0 + j*s + s/2, y0 - i*s + s/2, str(rows[i][j]),
                    ha="center", va="center", fontsize=10.5)

g(0.7, 3.9, Mv)
ax.text(2.05, 5.0, "M  shape (2, 3)", ha="center", fontsize=9.5)
ax.text(4.0, 3.4, "+", fontsize=15)
g(4.8, 3.9, [bv], fc="#FDEBD0")
g(4.8, 3.9 - s, [bv], fc="#FDEBD0", dashed=True)     # broadcast copy
ax.text(6.15, 5.0, "b  shape (3,)", ha="center", fontsize=9.5)
ax.text(6.15, 1.35, "b is treated as if copied\ndown to every row", ha="center",
        fontsize=8.5, style="italic")
ax.text(8.35, 3.4, "=", fontsize=15)
g(9.2, 3.9, Rv, fc="#D4E6F1")
ax.text(10.55, 5.0, "M + b  shape (2, 3)", ha="center", fontsize=9.5)
ax.text(13.3, 3.2, "no copy is actually\nmade in memory --\nbroadcasting is\na set of rules,\nnot a data copy",
        ha="center", fontsize=8.5, style="italic")
plt.tight_layout(); plt.savefig("../figures/ch03_broadcasting.png", dpi=200, bbox_inches="tight"); plt.close()

print("saved 4 figures")
