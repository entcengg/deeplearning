import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from scipy.spatial.distance import cdist
import os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"
RED = "#C0392B"
GRAY = "#7F8C8D"

digits = load_digits()
X = digits.images.reshape(-1, 64).astype(np.float32) / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
X_train_t, X_test_t = torch.from_numpy(X_train), torch.from_numpy(X_test)
y_train_t, y_test_t = torch.from_numpy(y_train).long(), torch.from_numpy(y_test).long()

# =================================================================
# 1. ch21_autoencoder_reconstruction.png -- Program 1's loss curve +
#    original vs reconstructed digit images
# =================================================================
class Autoencoder(nn.Module):
    def __init__(self, latent_dim=8):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, latent_dim))
        self.decoder = nn.Sequential(nn.Linear(latent_dim, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z

torch.manual_seed(0)
ae8 = Autoencoder(latent_dim=8)
opt = optim.Adam(ae8.parameters(), lr=0.01)
loss_fn = nn.MSELoss()
train_curve, test_curve = [], []
for epoch in range(1, 101):
    ae8.train(); opt.zero_grad()
    recon, _ = ae8(X_train_t)
    loss = loss_fn(recon, X_train_t)
    loss.backward(); opt.step()
    ae8.eval()
    with torch.no_grad():
        test_loss = loss_fn(ae8(X_test_t)[0], X_test_t)
    train_curve.append(loss.item())
    test_curve.append(test_loss.item())

fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.6), gridspec_kw={"width_ratios": [1, 1.3]})

ax0 = axes[0]
ax0.plot(range(1, 101), train_curve, color=BLUE, label="train MSE")
ax0.plot(range(1, 101), test_curve, color=ORANGE, label="test MSE", ls="--")
ax0.set_xlabel("epoch"); ax0.set_ylabel("reconstruction MSE (per pixel)")
ax0.set_title("Training a plain autoencoder\n(64 " + r"$\to$" + " 32 " + r"$\to$" + " 8 " + r"$\to$" + " 32 " + r"$\to$" + " 64)")
ax0.legend(fontsize=9); ax0.grid(alpha=0.3)

ax1 = axes[1]
ax1.axis("off")
n_show = 6
ae8.eval()
with torch.no_grad():
    sample = X_test_t[:n_show]
    recon, _ = ae8(sample)
sample_np = sample.numpy().reshape(-1, 8, 8)
recon_np = recon.numpy().reshape(-1, 8, 8)
gs = fig.add_gridspec(2, n_show, left=0.535, right=0.98, top=0.82, bottom=0.08, wspace=0.15, hspace=0.15)
for i in range(n_show):
    ax_o = fig.add_subplot(gs[0, i]); ax_o.imshow(sample_np[i], cmap="gray_r", vmin=0, vmax=1); ax_o.axis("off")
    ax_r = fig.add_subplot(gs[1, i]); ax_r.imshow(recon_np[i], cmap="gray_r", vmin=0, vmax=1); ax_r.axis("off")
    if i == 0:
        ax_o.set_ylabel("original", fontsize=9); ax_o.axis("on")
        ax_o.set_xticks([]); ax_o.set_yticks([])
        for spine in ax_o.spines.values(): spine.set_visible(False)
        ax_r.set_ylabel("reconstructed", fontsize=9); ax_r.axis("on")
        ax_r.set_xticks([]); ax_r.set_yticks([])
        for spine in ax_r.spines.values(): spine.set_visible(False)
fig.text(0.76, 0.87, "Six held-out test digits: original vs.\nreconstructed (8-D latent code)", ha="center", fontsize=10.5)

plt.savefig("../figures/ch21_autoencoder_reconstruction.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 2. ch21_latent_space_holes.png -- 2D latent scatter colored by digit,
#    plus a grid of decoded random bounding-box points
# =================================================================
class Autoencoder2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 2))
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z

torch.manual_seed(0)
ae2 = Autoencoder2D()
opt = optim.Adam(ae2.parameters(), lr=0.01)
for epoch in range(200):
    ae2.train(); opt.zero_grad()
    recon, _ = ae2(X_train_t)
    loss = nn.functional.mse_loss(recon, X_train_t)
    loss.backward(); opt.step()
ae2.eval()
with torch.no_grad():
    _, z_all = ae2(torch.from_numpy(X))
z_all = z_all.numpy()

rng = np.random.default_rng(42)
n_probe = 300
x_lo, x_hi = z_all[:, 0].min(), z_all[:, 0].max()
y_lo, y_hi = z_all[:, 1].min(), z_all[:, 1].max()
random_points = np.column_stack([rng.uniform(x_lo, x_hi, n_probe), rng.uniform(y_lo, y_hi, n_probe)])
with torch.no_grad():
    decoded_random = ae2.decoder(torch.tensor(random_points, dtype=torch.float32)).numpy().reshape(-1, 8, 8)

fig = plt.figure(figsize=(12.0, 4.8))
gs_main = fig.add_gridspec(1, 2, width_ratios=[1.15, 1], wspace=0.28)

ax0 = fig.add_subplot(gs_main[0])
scatter = ax0.scatter(z_all[:, 0], z_all[:, 1], c=y, cmap="tab10", s=10, alpha=0.75)
ax0.scatter(random_points[:24, 0], random_points[:24, 1], marker="x", color="black", s=35,
            label="random bounding-box\nsample points", zorder=5)
legend1 = ax0.legend(*scatter.legend_elements(), title="digit", loc="upper left",
                      bbox_to_anchor=(1.01, 1.0), fontsize=8, title_fontsize=9)
ax0.add_artist(legend1)
ax0.legend(loc="lower left", fontsize=8)
ax0.set_xlabel("latent dim 1"); ax0.set_ylabel("latent dim 2")
ax0.set_title("2-D latent space: real digits (colored)\nvs. random probe points (×)")
ax0.grid(alpha=0.3)

gs_grid = gs_main[1].subgridspec(4, 6, wspace=0.1, hspace=0.1)
for i in range(24):
    ax = fig.add_subplot(gs_grid[i // 6, i % 6])
    ax.imshow(decoded_random[i], cmap="gray_r", vmin=0, vmax=1)
    ax.axis("off")
fig.text(0.795, 0.90, "24 random bounding-box points, decoded\n(some look digit-like, many do not)",
          ha="center", fontsize=10)

plt.savefig("../figures/ch21_latent_space_holes.png", dpi=200, bbox_inches="tight")
plt.close()

# =================================================================
# 3. ch21_vae_comparison.png -- latent containment scatter (plain AE vs
#    VAE, both with the [-2,2] box) + judge-confidence bar chart
# =================================================================
class VAE2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, 2)
        self.logvar_head = nn.Linear(32, 2)
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + torch.randn_like(std) * std

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar

def vae_loss(recon, x, mu, logvar):
    recon_loss = ((recon - x) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    return recon_loss, kl

class Judge(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

def mean_confidence(judge, images):
    with torch.no_grad():
        probs = torch.softmax(judge(images), dim=1)
        return probs.max(dim=1).values.mean().item()

# re-train the plain 2D AE (same protocol as Program 3, 300 epochs)
torch.manual_seed(0)
ae_p3 = Autoencoder2D()
opt = optim.Adam(ae_p3.parameters(), lr=0.01)
for epoch in range(300):
    ae_p3.train(); opt.zero_grad()
    recon, _ = ae_p3(X_train_t)
    loss = nn.functional.mse_loss(recon, X_train_t)
    loss.backward(); opt.step()
ae_p3.eval()
with torch.no_grad():
    _, z_ae_all = ae_p3(torch.from_numpy(X))
    z_ae_all = z_ae_all.numpy()

torch.manual_seed(0)
vae = VAE2D()
opt = optim.Adam(vae.parameters(), lr=0.01)
for epoch in range(300):
    vae.train(); opt.zero_grad()
    recon, mu, logvar = vae(X_train_t)
    recon_loss, kl = vae_loss(recon, X_train_t, mu, logvar)
    (recon_loss + kl).backward(); opt.step()
vae.eval()
with torch.no_grad():
    mu_all, logvar_all = vae.encode(torch.from_numpy(X))
    z_vae_all = mu_all.numpy()

rng = np.random.default_rng(42)
n_probe = 300
x_lo, x_hi = z_ae_all[:, 0].min(), z_ae_all[:, 0].max()
y_lo, y_hi = z_ae_all[:, 1].min(), z_ae_all[:, 1].max()
ae_random_points = np.column_stack([rng.uniform(x_lo, x_hi, n_probe), rng.uniform(y_lo, y_hi, n_probe)])
vae_random_points = rng.normal(0.0, 1.0, size=(n_probe, 2))

with torch.no_grad():
    ae_decoded = ae_p3.decoder(torch.tensor(ae_random_points, dtype=torch.float32))
    vae_decoded = vae.decoder(torch.tensor(vae_random_points, dtype=torch.float32))

torch.manual_seed(1)
judge = Judge()
opt = optim.Adam(judge.parameters(), lr=0.01)
loss_fn = nn.CrossEntropyLoss()
for epoch in range(100):
    judge.train(); opt.zero_grad()
    loss = loss_fn(judge(X_train_t), y_train_t)
    loss.backward(); opt.step()
judge.eval()

real_conf = mean_confidence(judge, X_test_t)
ae_conf = mean_confidence(judge, ae_decoded)
vae_conf = mean_confidence(judge, vae_decoded)

fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.8))

ax0 = axes[0]
box = 2.0
ax0.add_patch(plt.Rectangle((-box, -box), 2 * box, 2 * box, fill=False, ec="black", lw=1.5, ls="--",
                              label="N(0,1) 2-sigma box [-2,2]" + r"$\times$" + "[-2,2]"))
ax0.scatter(z_ae_all[:, 0], z_ae_all[:, 1], s=8, alpha=0.5, color=GRAY, label="plain AE (real digits)")
ax0.scatter(z_vae_all[:, 0], z_vae_all[:, 1], s=8, alpha=0.5, color=BLUE, label="VAE (real digits)")
ax0.set_xlim(-14, 10); ax0.set_ylim(-14, 4)
ax0.set_xlabel("latent dim 1"); ax0.set_ylabel("latent dim 2")
ax0.set_title("Where real data actually lands:\nplain AE (19.9% inside box) vs. VAE (100% inside box)", fontsize=10.5)
ax0.legend(fontsize=8, loc="lower left")
ax0.grid(alpha=0.3)

ax1 = axes[1]
bars = ax1.bar(["real test\nimages", "plain-AE\nrandom decodes", "VAE\nrandom decodes"],
               [real_conf, ae_conf, vae_conf], color=[GREEN, GRAY, BLUE], width=0.55)
ax1.set_ylabel("mean judge confidence")
ax1.set_title("Independent judge classifier's confidence\non decoded random latent points", fontsize=10.5)
ax1.set_ylim(0, 1.05)
for bar, v in zip(bars, [real_conf, ae_conf, vae_conf]):
    ax1.text(bar.get_x() + bar.get_width() / 2, v + 0.02, f"{v:.3f}", ha="center", fontsize=10)
ax1.grid(alpha=0.3, axis="y")

plt.tight_layout()
plt.savefig("../figures/ch21_vae_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

print("all 3 figures written")
print(f"ae8 final train/test mse: {train_curve[-1]:.4f} {test_curve[-1]:.4f}")
print(f"ae2 (fig2) latent bbox: x[{x_lo:.3f},{x_hi:.3f}] y[{y_lo:.3f},{y_hi:.3f}]")
print(f"real_conf={real_conf:.4f} ae_conf={ae_conf:.4f} vae_conf={vae_conf:.4f}")

# =================================================================
# 4. ch21_latent_interpolation.png -- Program 4, Part A: walk in a
#    straight line from the first real 0's code to the first real 1's
#    code and decode every point, for the plain 2-D AE and the 2-D VAE.
#    The three networks are trained with ch21_program4.py's exact code
#    and seeds, and the judge labels are checked against its output.
# =================================================================
class P4AE(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 2))
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z


class P4VAE(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(64, 32), nn.ReLU())
        self.mu_head = nn.Linear(32, 2)
        self.logvar_head = nn.Linear(32, 2)
        self.decoder = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 64), nn.Sigmoid())

    def encode(self, x):
        h = self.hidden(x)
        return self.mu_head(h), self.logvar_head(h)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)
        return self.decoder(z), mu, logvar


class P4Judge(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 28)
        self.fc2 = nn.Linear(28, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))


torch.manual_seed(0)
p4_ae = P4AE()
opt = optim.Adam(p4_ae.parameters(), lr=0.01)
for epoch in range(300):
    opt.zero_grad()
    nn.functional.mse_loss(p4_ae(X_train_t)[0], X_train_t).backward()
    opt.step()
p4_ae.eval()

torch.manual_seed(0)
p4_vae = P4VAE()
opt = optim.Adam(p4_vae.parameters(), lr=0.01)
for epoch in range(300):
    opt.zero_grad()
    recon, mu, logvar = p4_vae(X_train_t)
    recon_loss = ((recon - X_train_t) ** 2).sum(dim=1).mean()
    kl = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1)).mean()
    (recon_loss + kl).backward()
    opt.step()
p4_vae.eval()

torch.manual_seed(1)
p4_judge = P4Judge()
opt = optim.Adam(p4_judge.parameters(), lr=0.01)
for epoch in range(100):
    opt.zero_grad()
    nn.functional.cross_entropy(p4_judge(X_train_t), y_train_t).backward()
    opt.step()
p4_judge.eval()

idx0, idx1 = int(np.where(y == 0)[0][0]), int(np.where(y == 1)[0][0])
alphas = np.linspace(0.0, 1.0, 7)
paths = {}
with torch.no_grad():
    for name in ("ae", "vae"):
        x01 = torch.from_numpy(X[[idx0, idx1]])
        c = p4_ae.encoder(x01) if name == "ae" else p4_vae.encode(x01)[0]
        dec = p4_ae.decoder if name == "ae" else p4_vae.decoder
        zs = torch.stack([(1 - a) * c[0] + a * c[1] for a in alphas])
        imgs = dec(zs)
        probs = torch.softmax(p4_judge(imgs), dim=1)
        paths[name] = (imgs.numpy().reshape(-1, 8, 8), probs.argmax(1).tolist(),
                       probs.max(1).values.tolist())
# judge labels printed by ch21_program4.py, Part A
assert paths["ae"][1] == [0, 0, 5, 8, 8, 1, 1], paths["ae"][1]
assert paths["vae"][1] == [0, 8, 8, 8, 8, 8, 1], paths["vae"][1]

fig, axes = plt.subplots(2, 7, figsize=(12.0, 4.4))
for r, (name, label) in enumerate([("ae", "plain AE"), ("vae", "VAE")]):
    imgs, preds, confs = paths[name]
    for col in range(7):
        ax = axes[r, col]
        ax.imshow(imgs[col], cmap="gray_r", vmin=0, vmax=1)
        ax.set_xticks([]); ax.set_yticks([])
        color = GREEN if preds[col] in (0, 1) else RED
        ax.set_title(f"judge: {preds[col]} ({confs[col]:.2f})", fontsize=9, color=color, pad=3)
        if r == 1:
            ax.set_xlabel(rf"$\alpha$ = {alphas[col]:.2f}", fontsize=9.5)
    axes[r, 0].set_ylabel(label, fontsize=11)
fig.suptitle("Decoding the straight line from a real 0 (left) to a real 1 (right) in latent space\n"
             "green: judged 0 or 1; red: judged some other digit", fontsize=11)
plt.tight_layout()
plt.savefig("../figures/ch21_latent_interpolation.png", dpi=200, bbox_inches="tight")
plt.close()
print("Saved ch21_latent_interpolation.png")
