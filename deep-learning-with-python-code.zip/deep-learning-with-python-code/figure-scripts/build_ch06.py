import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"

# ---------- 1. ch06_step_function.png ----------
fig, ax = plt.subplots(figsize=(5.6, 4.2))
z = np.linspace(-4, 4, 800)
a = (z > 0).astype(float)
ax.plot(z, a, color=BLUE, linewidth=2.2)
ax.scatter([0], [0], facecolors="white", edgecolors=BLUE, s=50, zorder=5, linewidth=1.8)
ax.scatter([0], [1], facecolors=BLUE, edgecolors=BLUE, s=50, zorder=5)
ax.set_xlabel("$z$"); ax.set_ylabel(r"$\varphi(z)$")
ax.set_title("The step activation function")
ax.set_yticks([0, 1])
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch06_step_function.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch06_and_boundary.png ----------
X = np.array([[0,0],[0,1],[1,0],[1,1]])
y = np.array([0,0,0,1])
w = np.array([2.0, 1.0]); b = -2.0

fig, ax = plt.subplots(figsize=(5.8, 5.2))
for xi, yi in zip(X, y):
    color = BLUE if yi == 1 else ORANGE
    marker = "o" if yi == 1 else "s"
    ax.scatter(*xi, color=color, s=180, zorder=5, marker=marker,
               edgecolor="black", linewidth=1.2)
    ax.annotate(f"({xi[0]},{xi[1]}) $\\to$ {yi}", xi, textcoords="offset points",
                xytext=(12, 8), fontsize=9.5)

# decision boundary: w1 x1 + w2 x2 + b = 0  ->  x2 = -(w1 x1 + b)/w2
x1_line = np.linspace(-0.6, 1.6, 50)
x2_line = -(w[0]*x1_line + b) / w[1]
ax.plot(x1_line, x2_line, color="black", linewidth=2, label="decision boundary")
ax.fill_between(x1_line, x2_line, 2.2, color=BLUE, alpha=0.08)
ax.fill_between(x1_line, -0.8, x2_line, color=ORANGE, alpha=0.08)

# weight vector, drawn from a point on the line, perpendicular to it
origin = np.array([0.5, -(w[0]*0.5+b)/w[1]])
wn = w / np.linalg.norm(w) * 0.6
ax.annotate("", xy=origin+wn, xytext=origin,
            arrowprops=dict(arrowstyle="-|>", color="#8E44AD", lw=2.2))
ax.text(*(origin+wn+np.array([0.05,0.05])), r"$\mathbf{w}=(2,1)$", color="#8E44AD", fontsize=10)

ax.set_xlim(-0.6, 1.6); ax.set_ylim(-0.8, 2.0)
ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
ax.set_title("The trained AND perceptron: decision boundary and weight vector")
ax.legend(loc="lower left", fontsize=9)
ax.set_aspect("equal")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch06_and_boundary.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch06_separability.png ----------
# Top row: AND vs XOR on the four corner points. Bottom row: the same contrast
# on clouds of data points, with a perceptron trained by Equation 6.2's rule.
from sklearn.datasets import make_blobs, make_circles
fig, axes = plt.subplots(2, 2, figsize=(10.2, 9.4))

# AND -- separable
y_and = np.array([0,0,0,1])
ax = axes[0, 0]
for xi, yi in zip(X, y_and):
    color = BLUE if yi == 1 else ORANGE
    marker = "o" if yi == 1 else "s"
    ax.scatter(*xi, color=color, s=200, zorder=5, marker=marker, edgecolor="black")
x1_line = np.linspace(-0.6, 1.6, 50)
ax.plot(x1_line, 1.5 - x1_line, color="black", linewidth=2)
ax.set_title("AND: linearly separable")
ax.set_xlim(-0.6,1.6); ax.set_ylim(-0.6,1.6); ax.set_aspect("equal")
ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
ax.grid(alpha=0.25)

# XOR -- not separable
y_xor = np.array([0,1,1,0])
ax = axes[0, 1]
for xi, yi in zip(X, y_xor):
    color = BLUE if yi == 1 else ORANGE
    marker = "o" if yi == 1 else "s"
    ax.scatter(*xi, color=color, s=200, zorder=5, marker=marker, edgecolor="black")
for (m, c) in [(1.0, 0.5), (-1.0, 1.5), (0.3, 0.35)]:
    xs = np.linspace(-0.6, 1.6, 50)
    ax.plot(xs, m*xs + c, color="gray", linewidth=1.4, linestyle="--", alpha=0.8)
ax.set_title("XOR: no line works")
ax.set_xlim(-0.6,1.6); ax.set_ylim(-0.6,1.6); ax.set_aspect("equal")
ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
ax.grid(alpha=0.25)


def train_perceptron(Xd, yd, epochs=100, eta=1.0):
    """Equation 6.2's rule with Equation 6.1's step, from zero weights."""
    w_p, b_p = np.zeros(2), 0.0
    for _ in range(epochs):
        for xi, yi in zip(Xd, yd):
            y_hat = 1 if xi @ w_p + b_p > 0 else 0
            w_p += eta * (yi - y_hat) * xi
            b_p += eta * (yi - y_hat)
    acc = np.mean(((Xd @ w_p + b_p) > 0).astype(int) == yd)
    return w_p, b_p, acc


blobs_X, blobs_y = make_blobs(n_samples=200, centers=[(-1.5, -1.0), (1.5, 1.0)],
                              cluster_std=0.7, random_state=0)
rings_X, rings_y = make_circles(n_samples=200, factor=0.35, noise=0.08, random_state=0)
rings_X = rings_X * 2.6
for ax, (Xd, yd, title) in zip(axes[1], [(blobs_X, blobs_y, "two clusters: separable"),
                                         (rings_X, rings_y, "a ring around a core: not separable")]):
    w_p, b_p, acc = train_perceptron(Xd, yd)
    for cls, color, marker in [(0, ORANGE, "s"), (1, BLUE, "o")]:
        pts = Xd[yd == cls]
        ax.scatter(pts[:, 0], pts[:, 1], color=color, marker=marker, s=26,
                   edgecolor="black", linewidth=0.5, zorder=5)
    xs = np.linspace(-4, 4, 50)
    if abs(w_p[1]) > 1e-12:
        ax.plot(xs, -(w_p[0] * xs + b_p) / w_p[1], color="black", linewidth=2)
    ax.set_title(f"{title}\n(perceptron training accuracy {acc:.0%})")
    ax.set_xlim(-4, 4); ax.set_ylim(-4, 4); ax.set_aspect("equal")
    ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
    ax.grid(alpha=0.25)
    print(f"separability figure, {title}: perceptron training accuracy {acc:.4f}")

from matplotlib.lines import Line2D
legend_handles = [
    Line2D([0], [0], marker="s", color="none", markerfacecolor=ORANGE,
           markeredgecolor="black", markersize=11, label="class 0 (square)"),
    Line2D([0], [0], marker="o", color="none", markerfacecolor=BLUE,
           markeredgecolor="black", markersize=11, label="class 1 (circle)"),
]
fig.legend(handles=legend_handles, loc="upper center",
           bbox_to_anchor=(0.5, 1.02), ncol=2, fontsize=9.5, frameon=False)
plt.tight_layout()
plt.savefig("../figures/ch06_separability.png", dpi=200, bbox_inches="tight")
plt.close()


# ---------- 4. ch06_convergence.png ----------
and_counts = [1, 3, 3, 2, 1, 0, 0, 0, 0, 0]
xor_counts = [2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]

fig, ax = plt.subplots(figsize=(7.2, 4.6))
ax.plot(range(1, len(and_counts)+1), and_counts, "o-", color=BLUE, label="AND (separable)")
ax.plot(range(1, len(xor_counts)+1), xor_counts, "s-", color=ORANGE, label="XOR (not separable)")
ax.set_xlabel("epoch"); ax.set_ylabel("misclassified examples that epoch")
ax.set_title("Perceptron training: convergence versus perpetual cycling")
ax.set_yticks(range(0, 5))
ax.legend(fontsize=10)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch06_convergence.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 5. ch06_stacking_xor.png : two perceptrons feeding a third, solving XOR ----------
fig, ax = plt.subplots(figsize=(9.6, 5.6))
ax.set_xlim(0, 13.2); ax.set_ylim(0, 8.0); ax.axis("off")

def circ(x, y, r, text, fc="#EAF2F8", fs=11):
    ax.add_patch(plt.Circle((x, y), r, facecolor=fc, edgecolor="black", lw=1.3, zorder=3))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, zorder=4)

def nbox(x, y, w, h, title, sub, fc):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                 facecolor=fc, edgecolor="black", lw=1.4, zorder=3))
    ax.text(x + w/2, y + h*0.66, title, ha="center", va="center", fontsize=11.5,
            fontweight="bold", zorder=4)
    ax.text(x + w/2, y + h*0.28, sub, ha="center", va="center", fontsize=8.3, zorder=4)

# inputs
circ(1.0, 6.0, 0.5, "$x_1$")
circ(1.0, 2.0, 0.5, "$x_2$")

# hidden layer: OR and NAND perceptrons
nbox(4.3, 5.1, 3.0, 1.7, "OR", r"$\mathbf{w}{=}(1,1)$, $b{=}{-}0.5$", "#D4E6F1")
nbox(4.3, 1.2, 3.0, 1.7, "NAND", r"$\mathbf{w}{=}({-}1,{-}1)$, $b{=}1.5$", "#D4E6F1")

for (ix, iy) in [(1.0, 6.0), (1.0, 2.0)]:
    for (ox, oy) in [(4.3, 5.95), (4.3, 2.05)]:
        ax.annotate("", xy=(ox, oy), xytext=(ix+0.5, iy),
                    arrowprops=dict(arrowstyle="-|>", color="black", lw=1.1), zorder=2)

# output perceptron: AND of the two hidden outputs
nbox(9.0, 3.15, 3.0, 1.7, "AND", r"$\mathbf{w}{=}(1,1)$, $b{=}{-}1.5$", "#FDEBD0")
ax.annotate("", xy=(9.0, 4.55), xytext=(7.3, 5.95),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.4), zorder=2)
ax.annotate("", xy=(9.0, 3.65), xytext=(7.3, 2.05),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.4), zorder=2)
ax.text(7.55, 6.05, "$h_1$", fontsize=10.5, fontweight="bold")
ax.text(7.55, 1.75, "$h_2$", fontsize=10.5, fontweight="bold")

# final output
circ(12.4, 4.0, 0.55, "out")
ax.annotate("", xy=(11.85, 4.0), xytext=(12.0, 4.0),
            arrowprops=dict(arrowstyle="-", color="none"))
ax.annotate("", xy=(12.4-0.55, 4.0), xytext=(10.0, 4.0),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=1.4), zorder=2)

ax.text(6.6, 7.4, "One line cannot separate XOR, but two lines (OR and NAND) can --\n"
                   "a third perceptron then combines those two decisions into the right answer.",
        ha="center", fontsize=9.8)

plt.tight_layout()
plt.savefig("../figures/ch06_stacking_xor.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 5 figures")
