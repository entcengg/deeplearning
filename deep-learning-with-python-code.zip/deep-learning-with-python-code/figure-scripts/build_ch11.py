import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"
GREEN = "#16A085"
PURPLE = "#8E44AD"

# ---------- 1. ch11_batch_sgd_minibatch.png ----------
# Program 1's three loops, recording the full-dataset loss after every epoch.
rng = np.random.default_rng(0)
m = 60
X = rng.uniform(0, 10, m)
Y = 3 * X + 2 + rng.normal(0, 1.5, m)
def loss(w, b):
    return np.mean((Y - (w * X + b)) ** 2)
def grad_on(w, b, X_batch, Y_batch):
    y_hat = w * X_batch + b
    return 2 * np.mean(X_batch * (y_hat - Y_batch)), 2 * np.mean(y_hat - Y_batch)
eta, n_epochs = 0.01, 200
w, b, batch = 0.0, 0.0, []
for _ in range(n_epochs):
    dw, db = grad_on(w, b, X, Y); w -= eta * dw; b -= eta * db
    batch.append(loss(w, b))
rng_s, w, b, sgd = np.random.default_rng(1), 0.0, 0.0, []
for _ in range(n_epochs):
    for i in rng_s.permutation(m):
        dw, db = grad_on(w, b, X[i:i+1], Y[i:i+1]); w -= eta * dw; b -= eta * db
    sgd.append(loss(w, b))
rng_m, w, b, mb = np.random.default_rng(2), 0.0, 0.0, []
for _ in range(n_epochs):
    idx = rng_m.permutation(m)
    for start in range(0, m, 10):
        bt = idx[start:start + 10]
        dw, db = grad_on(w, b, X[bt], Y[bt]); w -= eta * dw; b -= eta * db
    mb.append(loss(w, b))
batch, sgd, mb = np.array(batch), np.array(sgd), np.array(mb)
epochs = np.arange(1, len(batch) + 1)

fig, ax = plt.subplots(figsize=(7.6, 4.8))
ax.plot(epochs, sgd, color=ORANGE, linewidth=0.9, alpha=0.85, label="stochastic (1 example)")
ax.plot(epochs, mb, color=GREEN, linewidth=1.3, label="mini-batch (10 examples)")
ax.plot(epochs, batch, color=BLUE, linewidth=1.8, label="batch (all 60 examples)")
ax.set_xlabel("epoch"); ax.set_ylabel("loss")
ax.set_title("Batch, mini-batch, and stochastic gradient descent")
ax.set_ylim(0, 20)
ax.legend(fontsize=9.5)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch11_batch_sgd_minibatch.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch11_optimizer_comparison.png ----------
opt_data = np.load("ch11_optimizer_comparison.npz")
loss_gd, loss_mom, loss_rms, loss_adam = (opt_data[k] for k in ["gd", "momentum", "rmsprop", "adam"])

fig, ax = plt.subplots(figsize=(7.8, 5.2))
ax.plot(np.arange(1, len(loss_gd)+1), loss_gd, color="#7D8794", linewidth=1.8, label="plain GD (needs 20000 epochs)")
ax.plot(np.arange(1, len(loss_mom)+1), loss_mom, color=PURPLE, linewidth=1.8, label="momentum (needs ~10000 epochs)")
ax.plot(np.arange(1, len(loss_rms)+1), loss_rms, color=ORANGE, linewidth=1.8, label="RMSProp (500 epochs, plateaus)")
ax.plot(np.arange(1, len(loss_adam)+1), loss_adam, color=BLUE, linewidth=1.8, label="Adam (converges by ~1500 epochs)")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("epoch (log scale)"); ax.set_ylabel("loss (log scale)")
ax.set_title("Four optimizers on the same Celsius-to-Fahrenheit ravine")
ax.legend(fontsize=9, loc="lower left")
ax.grid(alpha=0.25, which="both")
plt.tight_layout()
plt.savefig("../figures/ch11_optimizer_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch11_lr_schedules.png ----------
def step_decay(epoch, eta0, drop=0.5, step_size=100):
    return eta0 * (drop ** (epoch // step_size))
def cosine_decay(epoch, eta0, eta_min, T):
    return eta_min + 0.5*(eta0-eta_min)*(1+np.cos(np.pi*epoch/T))
def warmup_cosine(epoch, eta0, eta_min, warmup_epochs, T):
    if epoch < warmup_epochs:
        return eta0 * epoch / warmup_epochs
    t = epoch - warmup_epochs
    return eta_min + 0.5*(eta0-eta_min)*(1+np.cos(np.pi*t/(T-warmup_epochs)))
def hold_then_cosine_decay(epoch, eta0, eta_min, decay_start, T):
    if epoch < decay_start:
        return eta0
    t = epoch - decay_start
    return eta_min + 0.5*(eta0-eta_min)*(1+np.cos(np.pi*t/(T-decay_start)))

epochs_axis = np.arange(0, 500)
sd = [step_decay(e, 0.1) for e in epochs_axis]
cd = [cosine_decay(e, 0.1, 0.0, 500) for e in epochs_axis]
wc = [warmup_cosine(e, 0.1, 0.0, 20, 500) for e in epochs_axis]

fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.8))
axes[0].plot(epochs_axis, sd, color=ORANGE, linewidth=1.8, label="step decay")
axes[0].plot(epochs_axis, cd, color=BLUE, linewidth=1.8, label="cosine decay")
axes[0].plot(epochs_axis, wc, color=GREEN, linewidth=1.8, label="warmup + cosine decay")
axes[0].set_xlabel("epoch"); axes[0].set_ylabel("learning rate $\\eta$")
axes[0].set_title("Three learning-rate schedules")
axes[0].legend(fontsize=9.5)
axes[0].grid(alpha=0.25)

# --- RMSProp on the ravine: fixed eta vs. well-timed decay vs. early decay ---
C = np.array([0.0, 10.0, 20.0, 30.0])
F = np.array([32.0, 50.0, 68.0, 86.0])
def grad(w, b):
    F_hat = w*C + b
    return 2*np.mean(C*(F_hat-F)), 2*np.mean(F_hat-F)
def loss(w, b):
    return np.mean((F - (w*C+b))**2)

def run(schedule, epochs=500, beta=0.9, eps=1e-8):
    w, b, sw, sb = 0., 0., 0., 0.
    hist = []
    for epoch in range(1, epochs+1):
        eta = schedule(epoch)
        dw, db = grad(w, b)
        sw = beta*sw + (1-beta)*dw**2
        sb = beta*sb + (1-beta)*db**2
        w -= eta*dw/(np.sqrt(sw)+eps)
        b -= eta*db/(np.sqrt(sb)+eps)
        hist.append(loss(w, b))
    return np.array(hist)

fixed = run(lambda e: 0.1)
good = run(lambda e: hold_then_cosine_decay(e, 0.1, 0.001, 400, 500))
early = run(lambda e: hold_then_cosine_decay(e, 0.1, 0.001, 100, 500))

ep = np.arange(1, 501)
axes[1].plot(ep, fixed, color="#7D8794", linewidth=1.6, label="fixed $\\eta=0.1$ (plateaus)")
axes[1].plot(ep, early, color=ORANGE, linewidth=1.6, label="decay starts too early (epoch 100)")
axes[1].plot(ep, good, color=BLUE, linewidth=1.8, label="decay starts late (epoch 400)")
axes[1].set_yscale("log")
axes[1].set_xlabel("epoch"); axes[1].set_ylabel("loss (log scale)")
axes[1].set_title("Same ravine: timing the decay matters")
axes[1].legend(fontsize=8.5)
axes[1].grid(alpha=0.25, which="both")

plt.tight_layout()
plt.savefig("../figures/ch11_lr_schedules.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 3 figures")
