import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, os

os.makedirs("../figures", exist_ok=True)
BLUE = "#2E86C1"
ORANGE = "#E67E22"

def sigmoid(z): return 1/(1+np.exp(-z))

# ---------- 1. ch08_bce_shape.png ----------
p = np.linspace(0.001, 0.999, 400)
loss_y1 = -np.log(p)        # cost when true label is 1
loss_y0 = -np.log(1-p)      # cost when true label is 0

fig, ax = plt.subplots(figsize=(6.6, 4.6))
ax.plot(p, loss_y1, color=BLUE, linewidth=2.2, label="$y=1$: cost $=-\\log(\\hat{y})$")
ax.plot(p, loss_y0, color=ORANGE, linewidth=2.2, label="$y=0$: cost $=-\\log(1-\\hat{y})$")
ax.set_xlabel(r"predicted probability $\hat{y}$")
ax.set_ylabel("cost")
ax.set_title("Binary cross-entropy: the cost of being wrong")
ax.set_ylim(0, 6)
ax.legend(fontsize=10)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch08_bce_shape.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 2. ch08_gradient_comparison.png ----------
z = np.linspace(-8, 8, 400)
yhat = sigmoid(z)
y = 1.0   # true label is 1; look at the gradient dL/dz across all z

grad_mse = -2*(y-yhat)*yhat*(1-yhat)
grad_bce = yhat - y

fig, ax = plt.subplots(figsize=(7.2, 4.8))
ax.plot(z, grad_mse, color=ORANGE, linewidth=2.2, label="MSE + sigmoid: $-2(y-\\hat{y})\\hat{y}(1-\\hat{y})$")
ax.plot(z, grad_bce, color=BLUE, linewidth=2.2, label="BCE + sigmoid: $\\hat{y}-y$")
ax.axhline(0, color="gray", linewidth=0.7)
ax.set_xlabel("$z$ (true label $y=1$)")
ax.set_ylabel(r"$\partial L/\partial z$")
ax.set_title("Gradient reaching the neuron: MSE vanishes when confidently wrong")
ax.legend(fontsize=9.5, loc="upper right")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch08_gradient_comparison.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 3. ch08_mse_vs_mae.png ----------
e = np.linspace(-6, 6, 400)
sq = e**2
ab = np.abs(e)

fig, ax = plt.subplots(figsize=(6.6, 4.6))
ax.plot(e, sq, color=ORANGE, linewidth=2.2, label="squared error $e^2$ (MSE)")
ax.plot(e, ab, color=BLUE, linewidth=2.2, label="absolute error $|e|$ (MAE)")
ax.set_xlabel("error $e = y-\\hat{y}$")
ax.set_ylabel("per-example penalty")
ax.set_title("MSE penalizes large errors far more heavily than MAE")
ax.legend(fontsize=10)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("../figures/ch08_mse_vs_mae.png", dpi=200, bbox_inches="tight")
plt.close()

# ---------- 4. ch08_focal_loss.png ----------
GREEN = "#16A085"
GRAY = "#7D8794"

p_t = np.linspace(0.01, 0.99, 400)

fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.6))

for gamma, color in [(0.0, GRAY), (1.0, ORANGE), (2.0, BLUE), (5.0, GREEN)]:
    axes[0].plot(p_t, (1 - p_t) ** gamma, color=color, linewidth=2.1,
                 label=f"$\\gamma={gamma:g}$")
axes[0].set_xlabel(r"$p_t$ (probability assigned to the true class)")
axes[0].set_ylabel(r"modulating factor $(1-p_t)^\gamma$")
axes[0].set_title("Focal loss's focusing factor")
axes[0].legend(fontsize=9.5)
axes[0].grid(alpha=0.25)

for gamma, color in [(0.0, GRAY), (1.0, ORANGE), (2.0, BLUE), (5.0, GREEN)]:
    loss = -(1 - p_t) ** gamma * np.log(p_t)
    axes[1].plot(p_t, loss, color=color, linewidth=2.1, label=f"$\\gamma={gamma:g}$")
axes[1].set_xlabel(r"$p_t$ (probability assigned to the true class)")
axes[1].set_ylabel(r"focal loss $-(1-p_t)^\gamma\log(p_t)$")
axes[1].set_title("Larger $\\gamma$ suppresses easy examples more")
axes[1].set_ylim(0, 4.6)
axes[1].legend(fontsize=9.5)
axes[1].grid(alpha=0.25)

plt.tight_layout()
plt.savefig("../figures/ch08_focal_loss.png", dpi=200, bbox_inches="tight")
plt.close()

print("saved 4 figures")
