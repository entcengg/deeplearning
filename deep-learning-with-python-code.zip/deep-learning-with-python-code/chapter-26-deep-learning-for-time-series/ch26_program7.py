# ch26_program7.py
# Rolling-origin validation. Programs 2-3 judged every forecaster on ONE
# chronological split (train on t < 800, test on t >= 800). A single split is
# a single draw: it cannot say whether its error is typical. Here the
# train/test boundary -- the "origin" -- rolls forward through four successive
# 100-step test blocks, and a fresh differenced LSTM (Program 3, Part B) is
# trained at every origin. Two training schemes are compared:
#   EXPANDING: train on every window from the start of the series to the origin
#   ROLLING:   train only on the latest 540 windows before the origin
# Each test block is forecast one step at a time from the real past, and no
# test window ever informs the model that scores it, its scaling included.

import numpy as np
import torch
import torch.nn as nn
from sklearn.model_selection import TimeSeriesSplit

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60        # input window length L
N_FOLDS, FOLD_SIZE = 4, 100
ROLLING_TARGETS = 540      # the rolling scheme keeps the latest 540 training windows


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y


def make_windows(y, window=WINDOW, t_start=0, t_end=None):
    if t_end is None:
        t_end = len(y)
    X, targets, target_t = [], [], []
    for t in range(max(t_start, window), t_end):
        X.append(y[t - window:t])
        targets.append(y[t])
        target_t.append(t)
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32), np.array(target_t)


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


class LSTMForecaster(nn.Module):
    def __init__(self, hidden_size=8):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.head(h_n[-1]).squeeze(-1)


def train_forecaster(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(epochs):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            loss = loss_fn(model(X_train[idx]), y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def fit_predict(X_tr, y_tr, X_te):
    """Program 3, Part B: difference the input windows and the target, scale
    with THIS fold's training windows only, train a fresh model (seed 0), and
    return level forecasts last_observed_value + predicted_change."""
    Xd_tr, Xd_te = np.diff(X_tr, axis=1), np.diff(X_te, axis=1)
    delta_tr = y_tr - X_tr[:, -1]
    mu_x, sd_x = Xd_tr.mean(), Xd_tr.std()
    mu_d, sd_d = delta_tr.mean(), delta_tr.std()
    torch.manual_seed(0)
    model = LSTMForecaster(hidden_size=8)
    train_forecaster(model, torch.from_numpy((Xd_tr - mu_x) / sd_x).unsqueeze(-1),
                     torch.from_numpy((delta_tr - mu_d) / sd_d))
    model.eval()
    with torch.no_grad():
        pred = model(torch.from_numpy((Xd_te - mu_x) / sd_x).unsqueeze(-1)).numpy()
    return X_te[:, -1] + pred * sd_d + mu_d


t, y = make_series()
X_all, y_all, t_all = make_windows(y)          # 940 windows, targets t = 60..999

# Fold boundaries come from scikit-learn's TimeSeriesSplit: n_splits test blocks
# of test_size windows each, always the LATEST ones, in chronological order.
expanding = list(TimeSeriesSplit(n_splits=N_FOLDS, test_size=FOLD_SIZE).split(X_all))
rolling = list(TimeSeriesSplit(n_splits=N_FOLDS, test_size=FOLD_SIZE,
                               max_train_size=ROLLING_TARGETS).split(X_all))

print(f"Rolling-origin validation: {N_FOLDS} folds x {FOLD_SIZE}-step test blocks, "
      f"window L={WINDOW}, differenced LSTM")
print("Fold layout (training target range, number of windows):")
for k, ((tr_e, te), (tr_r, _)) in enumerate(zip(expanding, rolling), start=1):
    print(f"  fold {k}: test t={t_all[te][0]}..{t_all[te][-1]} | expanding train "
          f"t={t_all[tr_e][0]}..{t_all[tr_e][-1]} ({len(tr_e)}) | rolling train "
          f"t={t_all[tr_r][0]}..{t_all[tr_r][-1]} ({len(tr_r)})")
by_hand = [(60, s - 1, s, s + FOLD_SIZE - 1) for s in (600, 700, 800, 900)]
split_t = [(t_all[tr[0]], t_all[tr[-1]], t_all[te[0]], t_all[te[-1]]) for tr, te in expanding]
print(f"  matches the hand-written boundaries (test blocks start at 600, 700, 800, 900): "
      f"{by_hand == split_t}")

rows = []
for k, ((tr_e, te), (tr_r, _)) in enumerate(zip(expanding, rolling), start=1):
    # Forecast the test block and everything after it from this origin, so that
    # fold 3 can be compared with Program 3; each fold is scored on its own block.
    after = np.arange(te[0], len(X_all))
    pred_e = fit_predict(X_all[tr_e], y_all[tr_e], X_all[after])
    pred_r = fit_predict(X_all[tr_r], y_all[tr_r], X_all[after])
    block = slice(0, FOLD_SIZE)
    y_true = y_all[te]
    row = {"fold": k, "range": f"{t_all[te][0]}-{t_all[te][-1]}",
           "persist": mae(y_true, X_all[te][:, -1]),
           "seasonal": mae(y_true, X_all[te][:, -PERIOD]),
           "expanding": mae(y_true, pred_e[block]),
           "rolling": mae(y_true, pred_r[block])}
    rows.append(row)
    print(f"Fold {k} (test t={row['range']}, train windows: expanding={len(tr_e)}, "
          f"rolling={len(tr_r)}):")
    print(f"  MAE  persistence={row['persist']:.4f}  seasonal-naive={row['seasonal']:.4f}  "
          f"expanding={row['expanding']:.4f}  rolling={row['rolling']:.4f}")
    if k == 3:
        check = mae(y_all[after], pred_e)
print(f"\n{'fold':>4s} {'test block':>11s} {'persist':>9s} {'seasonal':>9s} "
      f"{'expanding':>10s} {'rolling':>9s}")
for r in rows:
    print(f"{r['fold']:4d} {r['range']:>11s} {r['persist']:9.4f} {r['seasonal']:9.4f} "
          f"{r['expanding']:10.4f} {r['rolling']:9.4f}")
print(f"{'mean':>4s} {'':>11s} " + " ".join(
    f"{np.mean([r[key] for r in rows]):{w}.4f}"
    for key, w in [("persist", 9), ("seasonal", 9), ("expanding", 10), ("rolling", 9)]))
print(f"{'std':>4s} {'':>11s} " + " ".join(
    f"{np.std([r[key] for r in rows]):{w}.4f}"
    for key, w in [("persist", 9), ("seasonal", 9), ("expanding", 10), ("rolling", 9)]))

best = min(range(N_FOLDS), key=lambda i: rows[i]["expanding"] / rows[i]["persist"])
worst = max(range(N_FOLDS), key=lambda i: rows[i]["expanding"] / rows[i]["persist"])
print(f"\nExpanding LSTM / persistence, fold by fold: "
      + "  ".join(f"{r['expanding'] / r['persist']:.3f}" for r in rows)
      + f"  (best fold {best + 1}, worst fold {worst + 1})")
print(f"Fold 1: expanding and rolling see the same 540 windows, so their MAE is identical "
      f"({rows[0]['expanding']:.4f} vs {rows[0]['rolling']:.4f}).")
print(f"Check against Program 3: fold 3 trains on exactly Program 3's windows (t=60..799);")
print(f"  scored on all of t=800..999 the expanding model gives MAE={check:.4f} "
      f"(Program 3, Part B: 0.6709).")
print(f"Program 3's single split reported {check:.4f}; the four folds range from "
      f"{min(r['expanding'] for r in rows):.4f} to {max(r['expanding'] for r in rows):.4f}.")
