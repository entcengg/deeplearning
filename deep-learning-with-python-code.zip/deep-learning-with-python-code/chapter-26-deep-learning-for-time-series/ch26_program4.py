# ch26_program4.py
# Multi-step forecasting: predicting H future values, not just one. Two
# strategies, built on the differenced representation that fixed Program 3's
# Part A: recursive (feed each prediction back in as if it were observed, then
# forecast one more step) and direct (one model predicts every horizon at
# once, relative to the same anchor point, so no predicted value is ever used
# as another prediction's input). Both are compared at two hidden sizes,
# because -- as the results show -- which strategy wins depends on it.

import numpy as np
import torch
import torch.nn as nn

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60        # input window length L
SPLIT_T = 800      # first SPLIT_T steps -> train targets, rest -> test targets
HORIZON = 10


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def make_multistep_windows(y, window=WINDOW, horizon=HORIZON, t_start=0, t_end=None):
    """For every anchor time a = t-1 with t in [max(t_start,window), t_end-horizon+1):
    X = y[t-window:t] (the window ending right at the anchor), targets = y[t:t+horizon]
    (the next `horizon` future values). Returns X, targets (n, horizon), anchor_t (= t)."""
    if t_end is None:
        t_end = len(y)
    X, targets, anchor_t = [], [], []
    for t in range(max(t_start, window), t_end - horizon + 1):
        X.append(y[t - window:t])
        targets.append(y[t:t + horizon])
        anchor_t.append(t)
    return (np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32),
            np.array(anchor_t))


class LSTMForecaster(nn.Module):
    """Same one-step cell as Program 3, operating on a window of DELTAS;
    out_dim=1 for the recursive strategy's one-step model, out_dim=HORIZON
    for the direct strategy's one-shot multi-horizon model."""
    def __init__(self, hidden_size=8, out_dim=1):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, out_dim)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.head(h_n[-1])   # (batch, out_dim)


def train_model(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            pred = model(X_train[idx])
            loss = loss_fn(pred, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def run_comparison(y, hidden_size):
    """Trains and evaluates both strategies at a given hidden size; returns
    per-horizon MAE arrays and overall MAE/RMSE for each."""
    X_ms, targets_ms, anchor_t = make_multistep_windows(y, t_start=SPLIT_T - 1)

    # One-step delta model (recursive strategy's building block).
    X_all_1, y_all_1 = [], []
    for tt in range(WINDOW, SPLIT_T):
        X_all_1.append(y[tt - WINDOW:tt]); y_all_1.append(y[tt])
    X_all_1 = np.array(X_all_1, dtype=np.float32); y_all_1 = np.array(y_all_1, dtype=np.float32)
    Xd_train_raw = np.diff(X_all_1, axis=1)
    last_train = X_all_1[:, -1]
    delta_train_raw = y_all_1 - last_train
    mu_x, sigma_x = Xd_train_raw.mean(), Xd_train_raw.std()
    mu_d, sigma_d = delta_train_raw.mean(), delta_train_raw.std()
    Xd_train = torch.from_numpy((Xd_train_raw - mu_x) / sigma_x).unsqueeze(-1)
    yd_train = torch.from_numpy((delta_train_raw - mu_d) / sigma_d).unsqueeze(-1)

    torch.manual_seed(0)
    onestep_model = LSTMForecaster(hidden_size=hidden_size, out_dim=1)
    train_model(onestep_model, Xd_train, yd_train, epochs=100)
    onestep_model.eval()

    def normalize_x(a):
        return (a - mu_x) / sigma_x

    def denorm_d(a):
        return a * sigma_d + mu_d

    recursive_preds = np.zeros((len(X_ms), HORIZON), dtype=np.float32)
    with torch.no_grad():
        for i in range(len(X_ms)):
            window = X_ms[i].copy()
            for h in range(HORIZON):
                xd = normalize_x(np.diff(window)).astype(np.float32)
                xd_t = torch.from_numpy(xd).view(1, WINDOW - 1, 1)
                pred_delta = denorm_d(onestep_model(xd_t).item())
                next_val = window[-1] + pred_delta
                recursive_preds[i, h] = next_val
                window = np.append(window[1:], next_val)

    # Direct multi-horizon model.
    X_ms_train, targets_ms_train, _ = make_multistep_windows(y, t_start=WINDOW, t_end=SPLIT_T)
    Xd_direct_train_raw = np.diff(X_ms_train, axis=1)
    anchor_train = X_ms_train[:, -1:]
    delta_targets_train_raw = targets_ms_train - anchor_train
    mu_xD, sigma_xD = Xd_direct_train_raw.mean(), Xd_direct_train_raw.std()
    mu_dD, sigma_dD = delta_targets_train_raw.mean(), delta_targets_train_raw.std()
    Xd_direct_train = torch.from_numpy((Xd_direct_train_raw - mu_xD) / sigma_xD).unsqueeze(-1)
    yd_direct_train = torch.from_numpy((delta_targets_train_raw - mu_dD) / sigma_dD)

    torch.manual_seed(0)
    direct_model = LSTMForecaster(hidden_size=hidden_size, out_dim=HORIZON)
    train_model(direct_model, Xd_direct_train, yd_direct_train, epochs=100)
    direct_model.eval()

    Xd_ms_test_raw = np.diff(X_ms, axis=1)
    anchor_test = X_ms[:, -1:]
    Xd_ms_test = torch.from_numpy((Xd_ms_test_raw - mu_xD) / sigma_xD).unsqueeze(-1)
    with torch.no_grad():
        pred_delta_direct_norm = direct_model(Xd_ms_test).numpy()
    direct_preds = anchor_test + pred_delta_direct_norm * sigma_dD + mu_dD

    rec_mae_by_h = np.array([mae(targets_ms[:, h], recursive_preds[:, h]) for h in range(HORIZON)])
    dir_mae_by_h = np.array([mae(targets_ms[:, h], direct_preds[:, h]) for h in range(HORIZON)])
    return targets_ms, recursive_preds, direct_preds, rec_mae_by_h, dir_mae_by_h


if __name__ == "__main__":
    t, y, trend, seasonal, noise = make_series()
    X_ms, targets_ms, anchor_t = make_multistep_windows(y, t_start=SPLIT_T - 1)
    print(f"Multi-step test set: {len(X_ms)} anchors, horizon H={HORIZON}, "
          f"anchors t-1={anchor_t.min()-1}..{anchor_t.max()-1}")

    for hidden_size in [8, 32]:
        n_params_1 = sum(p.numel() for p in LSTMForecaster(hidden_size, 1).parameters())
        n_params_H = sum(p.numel() for p in LSTMForecaster(hidden_size, HORIZON).parameters())
        print(f"\n{'='*74}\nHidden size = {hidden_size}  "
              f"(one-step model: {n_params_1:,} params; direct model: {n_params_H:,} params)\n{'='*74}")
        targets_ms, recursive_preds, direct_preds, rec_mae_by_h, dir_mae_by_h = \
            run_comparison(y, hidden_size)

        print(f"Per-horizon-step MAE (averaged over all {len(X_ms)} test anchors):")
        print(f"  h  | recursive | direct")
        print(f"  ---+-----------+--------")
        for h in range(HORIZON):
            print(f"  {h+1:2d} |   {rec_mae_by_h[h]:.4f}  | {dir_mae_by_h[h]:.4f}")

        rec_mae = mae(targets_ms, recursive_preds); rec_rmse = rmse(targets_ms, recursive_preds)
        dir_mae = mae(targets_ms, direct_preds); dir_rmse = rmse(targets_ms, direct_preds)
        print(f"\n  overall: recursive MAE={rec_mae:.4f} RMSE={rec_rmse:.4f}  |  "
              f"direct MAE={dir_mae:.4f} RMSE={dir_rmse:.4f}")
        print(f"  error growth h=1 to h={HORIZON}: recursive {rec_mae_by_h[-1]/rec_mae_by_h[0]:.3f}x, "
              f"direct {dir_mae_by_h[-1]/dir_mae_by_h[0]:.3f}x")
        print(f"  winner (lower overall MAE): {'recursive' if rec_mae < dir_mae else 'direct'}")

    print(f"\n{'='*74}\nWhat changed between the two hidden sizes")
    print(f"{'='*74}")
    print(f"At hidden_size=8, recursive wins overall, and direct's error is worse even at h=1 --")
    print(f"its small hidden state must support {HORIZON} separate output heads at once, and with")
    print(f"only 740 training anchors that shared capacity costs more than recursive's compounding")
    print(f"does at this horizon. At hidden_size=32, direct pulls ahead and shows the behavior the")
    print(f"strategy is supposed to have: essentially flat error from h=1 to h={HORIZON}, because every")
    print(f"horizon is predicted from the same real, observed anchor window. Recursive still grows")
    print(f"with horizon at hidden_size=32 too, just more slowly than it does at hidden_size=8.")
    print(f"The lesson: 'recursive compounds error, so direct is better' is only half the story --")
    print(f"direct also has to learn a harder, higher-variance target at every horizon with the same")
    print(f"data, and needs enough model capacity to actually do that before its advantage shows up.")
