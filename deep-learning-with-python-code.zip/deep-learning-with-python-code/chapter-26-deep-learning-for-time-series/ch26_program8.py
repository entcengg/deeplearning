# ch26_program8.py
# Distribution shift in a deployed forecaster. Part A measures a COVARIATE
# shift that Program 3 already suffered (the input levels move, the rule that
# generates the series does not). Parts B-C create a genuine CONCEPT DRIFT:
# at t = 600 the seasonal cycle speeds up from period 50 to period 30 (same
# trend, amplitude and noise draws), so the rule that maps a window to the
# next value changes. A differenced LSTM is deployed at t = 500 and then
# either left alone ("frozen") or retrained at the start of every later
# 100-step block on all history ("expanding") or on the latest 300 targets
# ("rolling"). Part C watches the frozen model's error against persistence.

import numpy as np
import torch
import torch.nn as nn

N = 1000          # total time steps
PERIOD = 50       # seasonal period before the drift, in steps
NEW_PERIOD = 30   # seasonal period after the drift
SHIFT_T = 600     # the drift happens here
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60        # input window length L
DEPLOY_T = 500     # the frozen model is trained on targets t < 500
ROLLING_TARGETS = 300
MONITOR_STEPS = 25


def make_series(n=N, seed=0, drift=False):
    """The chapter's series. With drift=True the seasonal term switches to
    period NEW_PERIOD at SHIFT_T (both sine waves are 0 there, so the value
    is continuous). Trend, amplitude and noise draws are identical either way."""
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    if drift:
        seasonal = np.where(t < SHIFT_T, seasonal,
                            SEASONAL_AMP * np.sin(2 * np.pi * (t - SHIFT_T) / NEW_PERIOD))
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    return t, trend + seasonal + noise


def windows(y, lo, hi):
    """Raw-level windows and targets for target times t = lo .. hi-1."""
    X = np.stack([y[t - WINDOW:t] for t in range(lo, hi)]).astype(np.float32)
    return X, y[lo:hi].astype(np.float32)


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


class LSTMForecaster(nn.Module):
    def __init__(self, hidden_size=8):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.head(h_n[-1]).squeeze(-1)


def train_forecaster(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(epochs):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            loss = loss_fn(model(X_train[idx]), y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def fit_model(y, lo, hi):
    """Train a fresh differenced LSTM (Program 3, Part B recipe, seed 0) on the
    windows whose targets are t = lo .. hi-1, scaled with those windows only.
    Returns a function from raw-level windows to level forecasts."""
    X, target = windows(y, max(lo, WINDOW), hi)
    Xd, delta = np.diff(X, axis=1), target - X[:, -1]
    mu_x, sd_x, mu_d, sd_d = Xd.mean(), Xd.std(), delta.mean(), delta.std()
    torch.manual_seed(0)
    model = LSTMForecaster(hidden_size=8)
    train_forecaster(model, torch.from_numpy((Xd - mu_x) / sd_x).unsqueeze(-1),
                     torch.from_numpy((delta - mu_d) / sd_d))
    model.eval()

    def predict(X_new):
        with torch.no_grad():
            p = model(torch.from_numpy((np.diff(X_new, axis=1) - mu_x) / sd_x).unsqueeze(-1)).numpy()
        return X_new[:, -1] + p * sd_d + mu_d
    return predict


_, y_calm = make_series(drift=False)      # the chapter's series (control)
_, y_drift = make_series(drift=True)

# ==============================================================================
# Part A: covariate shift = the input distribution moves, the rule does not
# ==============================================================================
print("Part A: Program 3's split (train targets t<800, test t>=800) on the calm series")
X_c, _ = windows(y_calm, WINDOW, N)
tt = np.arange(WINDOW, N)
X_train, X_test = X_c[tt < 800], X_c[tt >= 800]
above = float(np.mean(X_test > X_train.max()))
print(f"  raw levels: training windows span [{X_train.min():.2f}, {X_train.max():.2f}]; "
      f"{100 * above:.1f}% of test entries are above it")
Xd_train, Xd_test = np.diff(X_train, axis=1), np.diff(X_test, axis=1)
outside = float(np.mean((Xd_test < Xd_train.min()) | (Xd_test > Xd_train.max())))
print(f"  differenced: training range [{Xd_train.min():.2f}, {Xd_train.max():.2f}]; "
      f"{100 * outside:.1f}% of test entries are outside it")

# ==============================================================================
# Part B: concept drift -- frozen vs. retrained forecasters
# ==============================================================================
print(f"\nPart B: the seasonal period changes from {PERIOD} to {NEW_PERIOD} at t={SHIFT_T}")
print(f"  persistence MAE, t=500..599 (before the drift): {mae(y_drift[500:600], y_drift[499:599]):.4f}")
print(f"  persistence MAE, t=600..999 (after the drift):  {mae(y_drift[600:], y_drift[599:-1]):.4f}")
print(f"  (the same steps without the drift:              {mae(y_calm[600:], y_calm[599:-1]):.4f})")

frozen = fit_model(y_drift, WINDOW, DEPLOY_T)
print(f"\n  frozen model trained once on targets t=60..{DEPLOY_T - 1} "
      f"({DEPLOY_T - WINDOW} windows); retraining at the start of each block:")
blocks = [(500, 600), (600, 700), (700, 800), (800, 900), (900, 1000)]
names = ["persistence", "frozen, calm series", "frozen", "expanding retrain", "rolling retrain"]
table = {n: [] for n in names}
for lo, hi in blocks:
    X_b, y_b = windows(y_drift, lo, hi)
    Xc_b, yc_b = windows(y_calm, lo, hi)
    table["persistence"].append(mae(y_b, X_b[:, -1]))
    table["frozen, calm series"].append(mae(yc_b, frozen(Xc_b)))
    table["frozen"].append(mae(y_b, frozen(X_b)))
    if lo == DEPLOY_T:                     # block 1 is scored by the model just deployed
        table["expanding retrain"].append(table["frozen"][-1])
        table["rolling retrain"].append(table["frozen"][-1])
        continue
    expanding = fit_model(y_drift, WINDOW, lo)
    rolling = fit_model(y_drift, lo - ROLLING_TARGETS, lo)
    table["expanding retrain"].append(mae(y_b, expanding(X_b)))
    table["rolling retrain"].append(mae(y_b, rolling(X_b)))
print(f"  {'test block MAE':<22s}" + "".join(f"{f'{lo}-{hi - 1}':<10s}" for lo, hi in blocks))
for n in names:
    print(f"  {n:<22s}" + "".join(f"{v:<10.4f}" for v in table[n]))
post = slice(1, None)
print(f"  mean over the four post-drift blocks: "
      + ", ".join(f"{n} {np.mean(table[n][post]):.4f}" for n in names if n != "frozen, calm series"))

# ==============================================================================
# Part C: watching the error against the trivial baseline
# ==============================================================================
X_m, y_m = windows(y_drift, DEPLOY_T, N)
err_model = np.abs(y_m - frozen(X_m))
err_pers = np.abs(y_m - X_m[:, -1])
Xk_m, yk_m = windows(y_calm, DEPLOY_T, N)
err_model_calm = np.abs(yk_m - frozen(Xk_m))
err_pers_calm = np.abs(yk_m - Xk_m[:, -1])


def skill_ratio(err_a, err_b, w=MONITOR_STEPS):
    """Trailing w-step mean error of the model divided by that of persistence."""
    ka = np.convolve(err_a, np.ones(w) / w, mode="valid")
    kb = np.convolve(err_b, np.ones(w) / w, mode="valid")
    return ka / kb                      # entry i is for the window ending at t = DEPLOY_T + w - 1 + i


ratio_drift = skill_ratio(err_model, err_pers)
ratio_calm = skill_ratio(err_model_calm, err_pers_calm)
t_end = DEPLOY_T + MONITOR_STEPS - 1 + np.arange(len(ratio_drift))
print(f"\nPart C: trailing {MONITOR_STEPS}-step MAE of the frozen model / MAE of persistence "
      f"(alarm when > 1)")
pre = ratio_drift[t_end < SHIFT_T]
print(f"  before the drift (windows ending t<{SHIFT_T}): ratio between {pre.min():.2f} and "
      f"{pre.max():.2f}, alarm steps: {int(np.sum(pre > 1))}")
alarm = t_end[(t_end >= SHIFT_T) & (ratio_drift > 1.0)]
print(f"  after the drift: first alarm at t={alarm[0]}, {alarm[0] - SHIFT_T} steps after the change; "
      f"ratio at t=999: {ratio_drift[-1]:.2f}")
print(f"  calm control series, same model, same rule: ratio between {ratio_calm.min():.2f} and "
      f"{ratio_calm.max():.2f}, alarm steps: {int(np.sum(ratio_calm > 1))}")
