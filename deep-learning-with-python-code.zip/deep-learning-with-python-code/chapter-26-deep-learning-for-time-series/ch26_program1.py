# ch26_program1.py
# Turning one long time series into a supervised-learning dataset. A forecaster
# is trained the same way any regressor is -- on (input, target) pairs -- but a
# time series is one long sequence, not a table of independent rows. A sliding
# window manufactures those pairs: each input is the last L values, each target
# is the value that comes right after. The synthetic series here is built from
# a known trend + known seasonal component + noise, so "did the model recover
# the real signal" can be checked against ground truth, not just against noisy
# data.

import numpy as np

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60        # input window length L
SPLIT_T = 800      # first SPLIT_T steps -> train targets, rest -> test targets


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def make_windows(y, window=WINDOW, t_start=0, t_end=None):
    """Build (X, target, target_t) triples for every target index t in
    [max(t_start, window), t_end) : X = y[t-window:t], target = y[t]."""
    if t_end is None:
        t_end = len(y)
    X, targets, target_t = [], [], []
    for t in range(max(t_start, window), t_end):
        X.append(y[t - window:t])
        targets.append(y[t])
        target_t.append(t)
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32), np.array(target_t)


if __name__ == "__main__":
    t, y, trend, seasonal, noise = make_series()

    print("Synthetic series: y(t) = trend(t) + seasonal(t) + noise(t)")
    print(f"  trend(t)    = {TREND_A} + {TREND_B}*t")
    print(f"  seasonal(t) = {SEASONAL_AMP}*sin(2*pi*t/{PERIOD})")
    print(f"  noise(t)    ~ N(0, {NOISE_STD}^2), seed=0")
    print(f"  n = {N} steps, window length L = {WINDOW}, chronological split at t = {SPLIT_T}")

    print(f"\nWorked example -- decomposition at a few time steps:")
    for tt in [0, 25, 50, 799]:
        print(f"  t={tt:4d}: trend={trend[tt]:.4f}  seasonal={seasonal[tt]:.4f}  "
              f"noise={noise[tt]:.4f}  y={y[tt]:.4f}  "
              f"(check: {trend[tt]:.4f}+{seasonal[tt]:.4f}+{noise[tt]:.4f}="
              f"{trend[tt]+seasonal[tt]+noise[tt]:.4f})")

    # Exact seasonality check: seasonal(t) must equal seasonal(t+PERIOD) exactly,
    # since sin(2*pi*(t+PERIOD)/PERIOD) = sin(2*pi*t/PERIOD + 2*pi) = sin(2*pi*t/PERIOD).
    diff = seasonal[500] - seasonal[500 + PERIOD]
    print(f"\nSeasonal exactness check: seasonal(500) - seasonal(550) = {diff:.10f} (should be 0)")
    trend_drift = trend[500 + PERIOD] - trend[500]
    print(f"Trend drift over one period: trend(550)-trend(500) = {trend_drift:.4f} "
          f"(= {TREND_B}*{PERIOD} exactly)")

    X_all, y_all, t_all = make_windows(y, window=WINDOW)
    print(f"\nTotal windowed examples (targets t={WINDOW}..{N-1}): {len(X_all)}")

    train_mask = t_all < SPLIT_T
    X_train, y_train, t_train = X_all[train_mask], y_all[train_mask], t_all[train_mask]
    X_test, y_test, t_test = X_all[~train_mask], y_all[~train_mask], t_all[~train_mask]
    print(f"Train windows: {len(X_train)} (targets t={t_train.min()}..{t_train.max()})")
    print(f"Test windows:  {len(X_test)} (targets t={t_test.min()}..{t_test.max()})")

    # One fully worked window, shown numerically.
    example_t = 700
    idx = np.where(t_all == example_t)[0][0]
    print(f"\nOne worked window, target t={example_t}:")
    print(f"  X (last {WINDOW} values, first 5 and last 5 shown):")
    print(f"    first 5: {np.round(X_all[idx][:5], 4)}")
    print(f"    last 5:  {np.round(X_all[idx][-5:], 4)}")
    print(f"  target y[{example_t}] = {y_all[idx]:.4f}")
    print(f"  confirms X[-1] = y[{example_t-1}]: {X_all[idx][-1]:.4f} == {y[example_t-1]:.4f} "
          f"-> {np.isclose(X_all[idx][-1], y[example_t - 1])}")
    print(f"  confirms X[0]  = y[{example_t-WINDOW}]: {X_all[idx][0]:.4f} == {y[example_t-WINDOW]:.4f} "
          f"-> {np.isclose(X_all[idx][0], y[example_t - WINDOW])}")
