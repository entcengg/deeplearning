# Chapter 26 · Deep Learning for Time Series

Code for Chapter 26 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 25](../chapter-25-image-segmentation/README.md) · [Chapter 27 →](../chapter-27-explainability-and-responsible-ai/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 26.1.1 Program 1: Building the Windowed Dataset | Building a windowed time-series dataset from a known trend + seasonal + noise decomposition | [`ch26_program1.py`](ch26_program1.py) | [ch26_program1.txt](expected_output/ch26_program1.txt) | < 1 s |
| 2 | 26.2.1 Program 2: Computing and Explaining the Baselines | Persistence and seasonal-naive baselines, with their errors decomposed by hand | [`ch26_program2.py`](ch26_program2.py) | [ch26_program2.txt](expected_output/ch26_program2.txt) | < 1 s |
| 3 | 26.3.1 Program 3: Raw Levels (Part A) and Differenced Changes (Part B) | An LSTM forecaster trained on raw levels (Part A), diagnosed, and fixed by differencing both input and target (Part B) | [`ch26_program3.py`](ch26_program3.py) | [ch26_program3.txt](expected_output/ch26_program3.txt) | 11 s |
| 4 | 26.4.1 Program 4: Comparing Both Strategies at Two Hidden Sizes | Recursive vs. direct multi-step forecasting, compared at hidden sizes 8 and 32 | [`ch26_program4.py`](ch26_program4.py) | [ch26_program4.txt](expected_output/ch26_program4.txt) | 24 s |
| 5 | 26.5.1 Program 5: A Fair, Matched Comparison | LSTM vs. Transformer forecasters, trained identically on the same differenced windows at two window lengths | [`ch26_program5.py`](ch26_program5.py) | [ch26_program5.txt](expected_output/ch26_program5.txt) | 2 min |
| 6 | 26.6.1 Program 6: Three Leaks and an Honest Reference | Three ways to leak the future into a forecasting evaluation, each measured against an honest reference and the noise floor | [`ch26_program6.py`](ch26_program6.py) | [ch26_program6.txt](expected_output/ch26_program6.txt) | 47 s |
| 7 | 26.7.1 Program 7: Four Origins, Expanding and Rolling | Rolling-origin validation of the differenced LSTM with expanding and rolling training windows | [`ch26_program7.py`](ch26_program7.py) | [ch26_program7.txt](expected_output/ch26_program7.txt) | 29 s |
| 8 | 26.8.1 Program 8: A Deployed Model Meets a Changed Process | Covariate shift, concept drift, retraining and a simple drift alarm | [`ch26_program8.py`](ch26_program8.py) | [ch26_program8.txt](expected_output/ch26_program8.txt) | 25 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-26-deep-learning-for-time-series
python ch26_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch26_notebook.ipynb`](ch26_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, PyTorch.
