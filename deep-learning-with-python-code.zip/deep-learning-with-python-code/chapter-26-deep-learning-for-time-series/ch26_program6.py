# ch26_program6.py
# Data leakage in forecasting, measured. Sections 1-3 said a forecast may use
# only the past. This program breaks that rule on purpose, three different
# ways, on the chapter's own series, and measures what each leak does to the
# reported test error -- against an honest reference and against a floor that
# no honest forecaster can beat: the noise itself, which is unpredictable.
#   Leak 1: standardise with statistics from ALL windows, test period included.
#   Leak 2: shuffle the overlapping windows before splitting.
#   Leak 3: feed the model a "centered" moving average, which peeks ahead.

import numpy as np
import torch
import torch.nn as nn

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60        # input window length L
SPLIT_T = 800      # first SPLIT_T steps -> train targets, rest -> test targets


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def make_windows(y, window=WINDOW, t_start=0, t_end=None):
    if t_end is None:
        t_end = len(y)
    X, targets, target_t = [], [], []
    for t in range(max(t_start, window), t_end):
        X.append(y[t - window:t])
        targets.append(y[t])
        target_t.append(t)
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32), np.array(target_t)


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


class LSTMForecaster(nn.Module):
    """Program 3's forecaster; input_size > 1 lets Leak 3 add a second channel."""
    def __init__(self, hidden_size=8, input_size=1):
        super().__init__()
        self.lstm = nn.LSTM(input_size=input_size, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.head(h_n[-1]).squeeze(-1)


def train_forecaster(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(epochs):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            loss = loss_fn(model(X_train[idx]), y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def fit_predict(X_tr, y_tr, X_te, representation, stats=None):
    """Train a fresh LSTMForecaster (seed 0, 100 epochs) on raw-level windows
    (X_tr, y_tr) and return level forecasts for the windows X_te.
    representation 'raw' = Program 3 Part A, 'diff' = Part B.
    Normalization statistics come from `stats` = (X, y) -- by default the
    training windows themselves, the honest choice. Passing other windows
    here is exactly how Leak 1 is introduced."""
    X_s, y_s = (X_tr, y_tr) if stats is None else stats
    if representation == "raw":
        mu, sd = X_s.mean(), X_s.std()
        X_in, y_in = (X_tr - mu) / sd, (y_tr - mu) / sd
        X_out = (X_te - mu) / sd
    else:
        mu_x, sd_x = np.diff(X_s, axis=1).mean(), np.diff(X_s, axis=1).std()
        d_s = y_s - X_s[:, -1]
        mu_d, sd_d = d_s.mean(), d_s.std()
        X_in, y_in = (np.diff(X_tr, axis=1) - mu_x) / sd_x, (y_tr - X_tr[:, -1] - mu_d) / sd_d
        X_out = (np.diff(X_te, axis=1) - mu_x) / sd_x
    torch.manual_seed(0)
    model = LSTMForecaster(hidden_size=8)
    train_forecaster(model, torch.from_numpy(X_in).unsqueeze(-1), torch.from_numpy(y_in))
    model.eval()
    with torch.no_grad():
        pred = model(torch.from_numpy(X_out).unsqueeze(-1)).numpy()
    return pred * sd + mu if representation == "raw" else X_te[:, -1] + pred * sd_d + mu_d


def moving_average(y, k, centered):
    """k-point moving average. Trailing: s(t) = mean(y[t-k+1..t]), past only.
    Centered: s(t) = mean(y[t-k//2..t+k//2]), which peeks k//2 steps ahead."""
    s = np.full(len(y), np.nan)
    half = k // 2
    for t in range(len(y)):
        lo, hi = (t - half, t + half) if centered else (t - k + 1, t)
        if lo >= 0 and hi < len(y):
            s[t] = y[lo:hi + 1].mean()
    return s


t, y, trend, seasonal, noise = make_series()
X_all, y_all, t_all = make_windows(y)
train = t_all < SPLIT_T
X_tr, y_tr, X_te, y_te = X_all[train], y_all[train], X_all[~train], y_all[~train]

# ==============================================================================
# Part A: the honest reference, and the floor no honest forecaster can beat
# ==============================================================================
print("Part A: reference and floor (chronological split at t=800, as in Programs 1-3)")
honest_diff = fit_predict(X_tr, y_tr, X_te, "diff")
floor_mae = float(np.mean(np.abs(noise[SPLIT_T:])))
floor_rmse = float(np.sqrt(np.mean(noise[SPLIT_T:] ** 2)))
print(f"  honest differenced LSTM (Program 3, Part B): MAE={mae(y_te, honest_diff):.4f}  "
      f"RMSE={rmse(y_te, honest_diff):.4f}")
print(f"  noise floor on t=800..999: MAE={floor_mae:.4f}  RMSE={floor_rmse:.4f}")
print(f"  (an oracle that knows trend+seasonal exactly still misses by the noise; for")
print(f"   sigma={NOISE_STD} the long-run values are MAE={NOISE_STD * np.sqrt(2 / np.pi):.4f}, "
      f"RMSE={NOISE_STD:.4f})")

# ==============================================================================
# Leak 1: normalization statistics from ALL windows, test period included
# ==============================================================================
print("\nLeak 1: standardising with statistics from all windows (test period included)")
rows = {}
for rep, label in [("diff", "differenced"), ("raw", "raw-level")]:
    honest = honest_diff if rep == "diff" else fit_predict(X_tr, y_tr, X_te, "raw")
    leaky = fit_predict(X_tr, y_tr, X_te, rep, stats=(X_all, y_all))
    arr_tr = np.diff(X_tr, axis=1) if rep == "diff" else X_tr
    arr_all = np.diff(X_all, axis=1) if rep == "diff" else X_all
    print(f"  {label} inputs, mean/std: training {arr_tr.mean():.4f}/{arr_tr.std():.4f}, "
          f"all windows {arr_all.mean():.4f}/{arr_all.std():.4f}")
    print(f"    training statistics only (honest): MAE={mae(y_te, honest):.4f}  RMSE={rmse(y_te, honest):.4f}")
    print(f"    all-window statistics (leaky):     MAE={mae(y_te, leaky):.4f}  RMSE={rmse(y_te, leaky):.4f}")
    rows[f"scale-{rep}"] = (mae(y_te, honest), mae(y_te, leaky))

# ==============================================================================
# Leak 2: shuffle the overlapping windows, then split
# ==============================================================================
# Targets 60..899 form the pool, split 80/20 at random. Targets 900..999 are
# the true future: no protocol is allowed to touch them. Each model is trained
# once and scored two ways -- on its randomly held-out windows (what the leaky
# protocol reports) and on the true future (what deployment would deliver).
print("\nLeak 2: random 80/20 split of the 840 windows with targets t=60..899")
pool, future = t_all < 900, t_all >= 900
X_pool, y_pool, X_fut, y_fut = X_all[pool], y_all[pool], X_all[future], y_all[future]
print("  seed  representation   random-split MAE   true-future MAE   future/random")
shuffle_mae = {"raw": [], "diff": []}
for seed in range(3):
    order = np.random.RandomState(seed).permutation(len(X_pool))
    tr_idx, te_idx = order[:672], order[672:]
    for rep, label in [("raw", "raw level"), ("diff", "differenced")]:
        pred = fit_predict(X_pool[tr_idx], y_pool[tr_idx], np.concatenate([X_pool[te_idx], X_fut]), rep)
        m_random, m_future = mae(y_pool[te_idx], pred[:168]), mae(y_fut, pred[168:])
        shuffle_mae[rep].append((m_random, m_future))
        print(f"  {seed:4d}  {label:<14s}   {m_random:14.4f}   {m_future:15.4f}   {m_future / m_random:11.2f}x")
for rep, label in [("raw", "raw level"), ("diff", "differenced")]:
    a = np.array(shuffle_mae[rep])
    rows[f"shuffle-{rep}"] = (a[:, 1].mean(), a[:, 0].mean())
    print(f"  mean of 3 seeds, {label}: random-split {a[:, 0].mean():.4f}, "
          f"true future {a[:, 1].mean():.4f}")

# ==============================================================================
# Leak 3: a "centered" moving average as an input feature peeks into the future
# ==============================================================================
print("\nLeak 3: a 3-point moving average as an extra input channel")
print("  hand check: y(t-2)=39, y(t-1)=42, y(t)=48. A centered mean at t-1 is")
print("  s(t-1) = (39+42+48)/3 = 43, and 3*43 - 42 - 39 = 48 = y(t): the target itself.")
leak_results = {}
for centered in (False, True):
    s = moving_average(y, 3, centered)
    name = "centered" if centered else "trailing"
    lo = WINDOW + 3                      # skip the start, where s is undefined
    ts = np.arange(lo, N)
    # least squares on [y(t-2), y(t-1), s(t-1), 1] -> y(t)
    F = np.column_stack([y[ts - 2], y[ts - 1], s[ts - 1], np.ones(len(ts))])
    fit = ts < SPLIT_T
    w, *_ = np.linalg.lstsq(F[fit], y[ts][fit], rcond=None)
    err_ols = y[ts][~fit] - F[~fit] @ w
    # differenced LSTM reading two channels: changes in y and changes in s
    def channels(t_lo, t_hi):
        idx = np.arange(t_lo, t_hi)
        raw = np.stack([y[i - WINDOW:i] for i in idx])
        sm = np.stack([s[i - WINDOW:i] for i in idx])
        return np.stack([np.diff(raw, axis=1), np.diff(sm, axis=1)], axis=-1), y[idx], y[idx - 1]
    C_tr, y_t, last_tr = channels(lo, SPLIT_T)
    C_te, y_e, last_te = channels(SPLIT_T, N)
    mu_c, sd_c = C_tr.reshape(-1, 2).mean(0), C_tr.reshape(-1, 2).std(0)
    d_tr = y_t - last_tr
    mu_d, sd_d = d_tr.mean(), d_tr.std()
    torch.manual_seed(0)
    model = LSTMForecaster(hidden_size=8, input_size=2)
    train_forecaster(model, torch.from_numpy(((C_tr - mu_c) / sd_c).astype(np.float32)),
                     torch.from_numpy(((d_tr - mu_d) / sd_d).astype(np.float32)))
    model.eval()
    with torch.no_grad():
        pred = model(torch.from_numpy(((C_te - mu_c) / sd_c).astype(np.float32))).numpy()
    yhat = last_te + pred * sd_d + mu_d
    leak_results[name] = (mae(y_e, yhat), rmse(y_e, yhat))
    print(f"  {name} mean:")
    print(f"    least squares weights on [y(t-2), y(t-1), s(t-1), 1] = {np.round(w, 3) + 0.0}")
    print(f"    least squares test MAE={np.mean(np.abs(err_ols)):.4f}")
    print(f"    two-channel LSTM test MAE={leak_results[name][0]:.4f}  RMSE={leak_results[name][1]:.4f}")
rows["lookahead"] = (leak_results["trailing"][0], leak_results["centered"][0])
print(f"  noise floor for comparison: MAE={floor_mae:.4f}  RMSE={floor_rmse:.4f}")

# ==============================================================================
# Summary
# ==============================================================================
print("\nSummary: test MAE (honest = what deployment sees; leaky = what the protocol reports)")
print(f"  {'leak':<34s} {'honest':>7s} {'leaky':>7s} {'leaky/honest':>13s}")
for key, label in [("scale-diff", "full-series scaling, differenced"),
                   ("scale-raw", "full-series scaling, raw level"),
                   ("shuffle-raw", "shuffled split, raw level"),
                   ("shuffle-diff", "shuffled split, differenced"),
                   ("lookahead", "centered smoothing feature")]:
    h, l = rows[key]
    print(f"  {label:<34s} {h:7.4f} {l:7.4f} {l / h:12.2f}x")
print(f"  noise floor (no honest forecaster beats it): MAE={floor_mae:.4f}")
