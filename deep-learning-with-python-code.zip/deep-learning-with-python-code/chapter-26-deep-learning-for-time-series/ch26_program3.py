# ch26_program3.py
# A one-step-ahead LSTM forecaster (Chapter 17's cell, applied to a regression
# target instead of a classification one). Part A predicts the raw next value
# directly and is measured against Program 2's baselines -- not against an
# abstract notion of "good," but against the specific numbers a lookup-only
# forecast already achieves on this exact test set. Part B diagnoses why Part
# A falls short and fixes it.

import numpy as np
import torch
import torch.nn as nn

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
WINDOW = 60        # input window length L
SPLIT_T = 800      # first SPLIT_T steps -> train targets, rest -> test targets


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def make_windows(y, window=WINDOW, t_start=0, t_end=None):
    """Build (X, target, target_t) triples for every target index t in
    [max(t_start, window), t_end) : X = y[t-window:t], target = y[t]."""
    if t_end is None:
        t_end = len(y)
    X, targets, target_t = [], [], []
    for t in range(max(t_start, window), t_end):
        X.append(y[t - window:t])
        targets.append(y[t])
        target_t.append(t)
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32), np.array(target_t)


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def mape(y_true, y_pred):
    return float(100.0 * np.mean(np.abs((y_true - y_pred) / y_true)))


def persistence_forecast(y, t_start, t_end):
    """yhat[t] = y[t-1], for t in [t_start, t_end)."""
    return np.array([y[t - 1] for t in range(t_start, t_end)])


def seasonal_naive_forecast(y, t_start, t_end, period=PERIOD):
    """yhat[t] = y[t-period], for t in [t_start, t_end)."""
    return np.array([y[t - period] for t in range(t_start, t_end)])


class LSTMForecaster(nn.Module):
    def __init__(self, hidden_size=8):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (batch, seq_len, 1)
        _, (h_n, _) = self.lstm(x)   # h_n: (1, batch, hidden_size), final hidden state
        return self.head(h_n[-1]).squeeze(-1)   # (batch,)


def train_forecaster(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3, checkpoints=()):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        epoch_loss, n_batches = 0.0, 0
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            pred = model(X_train[idx])
            loss = loss_fn(pred, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            epoch_loss += loss.item(); n_batches += 1
        if epoch in checkpoints:
            print(f"  epoch {epoch:3d}: mean training MSE (normalized units) = {epoch_loss / n_batches:.5f}")


if __name__ == "__main__":
    t, y, trend, seasonal, noise = make_series()
    X_all, y_all, t_all = make_windows(y, window=WINDOW)
    train_mask = t_all < SPLIT_T
    X_train_raw, y_train_raw = X_all[train_mask], y_all[train_mask]
    X_test_raw, y_test_raw = X_all[~train_mask], y_all[~train_mask]
    yhat_persist = persistence_forecast(y, SPLIT_T, N)
    yhat_seasonal = seasonal_naive_forecast(y, SPLIT_T, N)
    checkpoints = {1, 10, 25, 50, 75, 100}

    # =========================================================================
    # Part A: predict the raw next LEVEL
    # =========================================================================
    print("Part A: LSTM trained to predict the raw next value y[t]")
    # Normalize using TRAINING-set statistics only -- using the full series'
    # mean/std (test included) would leak information about the future into
    # training, exactly the kind of leak this chapter's Common Mistakes warns about.
    mu, sigma = X_train_raw.mean(), X_train_raw.std()
    print(f"  normalization stats (training windows only): mean={mu:.4f}, std={sigma:.4f}")

    X_train = torch.from_numpy((X_train_raw - mu) / sigma).unsqueeze(-1)
    y_train = torch.from_numpy((y_train_raw - mu) / sigma)
    X_test = torch.from_numpy((X_test_raw - mu) / sigma).unsqueeze(-1)

    torch.manual_seed(0)
    model_a = LSTMForecaster(hidden_size=8)
    print(f"  LSTMForecaster parameters: {sum(p.numel() for p in model_a.parameters()):,}")
    print(f"  training for 100 epochs, batch_size=64...")
    train_forecaster(model_a, X_train, y_train, epochs=100, checkpoints=checkpoints)

    model_a.eval()
    with torch.no_grad():
        pred_a_norm = model_a(X_test)
    yhat_a = pred_a_norm.numpy() * sigma + mu
    y_true = y_test_raw

    print(f"\n  test set (t={SPLIT_T}..{N-1}):")
    print(f"    first 5 targets:     {np.round(y_true[:5], 4)}")
    print(f"    first 5 predictions: {np.round(yhat_a[:5], 4)}")
    print(f"    MAE  = {mae(y_true, yhat_a):.4f}")
    print(f"    RMSE = {rmse(y_true, yhat_a):.4f}")
    print(f"    MAPE = {mape(y_true, yhat_a):.2f}%")
    print(f"\n  Compare to persistence (MAE={mae(y_true, yhat_persist):.4f}) -- Part A's raw-level")
    print(f"  LSTM loses. Its predictions trail the rising series (first 5 predictions")
    print(f"  {np.round(yhat_a[:5], 2)} vs. targets {np.round(y_true[:5], 2)}), a sign that a network")
    print(f"  regressing an absolute level is being asked to extrapolate past the range of")
    print(f"  values it saw in training, rather than to track the series' local behavior.")

    # =========================================================================
    # Part B: predict the one-step CHANGE, from a window of CHANGES
    # =========================================================================
    print(f"\n{'='*74}")
    print("Part B: difference both the input window and the target -- predict")
    print("the next CHANGE from a window of recent CHANGES, not levels from levels")
    print(f"{'='*74}")

    Xd_train_raw = np.diff(X_train_raw, axis=1)     # (n, WINDOW-1): each window's own deltas
    Xd_test_raw = np.diff(X_test_raw, axis=1)
    last_train = X_train_raw[:, -1]                  # y[t-1] for every training window
    last_test = X_test_raw[:, -1]                     # y[t-1] for every test window
    delta_train_raw = y_train_raw - last_train         # target delta y[t]-y[t-1]
    delta_test_raw = y_test_raw - last_test

    mu_x, sigma_x = Xd_train_raw.mean(), Xd_train_raw.std()
    mu_d, sigma_d = delta_train_raw.mean(), delta_train_raw.std()
    print(f"  input deltas (within-window):  mean={mu_x:.4f}, std={sigma_x:.4f}")
    print(f"  target deltas y[t]-y[t-1]:      mean={mu_d:.4f}, std={sigma_d:.4f}")
    print(f"  (both are level-independent -- their scale does not grow as the series climbs,")
    print(f"  unlike Part A's raw-level statistics, which describe wherever the series happened")
    print(f"  to be during the {len(X_train_raw)} training windows.)")

    Xd_train = torch.from_numpy((Xd_train_raw - mu_x) / sigma_x).unsqueeze(-1)
    Xd_test = torch.from_numpy((Xd_test_raw - mu_x) / sigma_x).unsqueeze(-1)
    yd_train = torch.from_numpy((delta_train_raw - mu_d) / sigma_d)

    torch.manual_seed(0)
    model_b = LSTMForecaster(hidden_size=8)
    print(f"\n  training for 100 epochs, batch_size=64...")
    train_forecaster(model_b, Xd_train, yd_train, epochs=100, checkpoints=checkpoints)

    model_b.eval()
    with torch.no_grad():
        pred_b_norm = model_b(Xd_test)
    delta_pred = pred_b_norm.numpy() * sigma_d + mu_d
    yhat_b = last_test + delta_pred   # forecast = last observed value + predicted change

    print(f"\n  test set (t={SPLIT_T}..{N-1}):")
    print(f"    first 5 targets:     {np.round(y_true[:5], 4)}")
    print(f"    first 5 predictions: {np.round(yhat_b[:5], 4)}")
    print(f"    MAE  = {mae(y_true, yhat_b):.4f}")
    print(f"    RMSE = {rmse(y_true, yhat_b):.4f}")
    print(f"    MAPE = {mape(y_true, yhat_b):.2f}%")

    print(f"\nFull comparison (MAE / RMSE / MAPE):")
    print(f"  persistence:              {mae(y_true, yhat_persist):.4f} / {rmse(y_true, yhat_persist):.4f} / "
          f"{mape(y_true, yhat_persist):.2f}%")
    print(f"  seasonal-naive:           {mae(y_true, yhat_seasonal):.4f} / {rmse(y_true, yhat_seasonal):.4f} / "
          f"{mape(y_true, yhat_seasonal):.2f}%")
    print(f"  LSTM Part A (raw level):  {mae(y_true, yhat_a):.4f} / {rmse(y_true, yhat_a):.4f} / "
          f"{mape(y_true, yhat_a):.2f}%")
    print(f"  LSTM Part B (differenced):{mae(y_true, yhat_b):.4f} / {rmse(y_true, yhat_b):.4f} / "
          f"{mape(y_true, yhat_b):.2f}%")
    improvement = 100 * (1 - mae(y_true, yhat_b) / mae(y_true, yhat_persist))
    print(f"\n  Differencing both the input and the target turns a losing model into one that beats")
    print(f"  persistence's MAE by {improvement:.1f}% -- same architecture and hidden size, only the")
    print(f"  representation changed from absolute levels to level-independent changes.")
