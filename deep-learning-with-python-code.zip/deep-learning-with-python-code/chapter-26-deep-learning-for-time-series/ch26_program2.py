# ch26_program2.py
# Baseline forecasts: persistence (predict tomorrow = today) and seasonal-naive
# (predict this period = same point last period). Neither one learns anything
# -- both are pure lookups into the series itself -- but any trained model that
# cannot beat the stronger of the two has not actually learned the signal, only
# added complexity. Reported on three metrics: MAE, RMSE (both in the series'
# own units), and MAPE (scale-free, as a percentage).

import numpy as np

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
SPLIT_T = 800      # first SPLIT_T steps -> train targets, rest -> test targets


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def mape(y_true, y_pred):
    return float(100.0 * np.mean(np.abs((y_true - y_pred) / y_true)))


def persistence_forecast(y, t_start, t_end):
    """yhat[t] = y[t-1], for t in [t_start, t_end)."""
    return np.array([y[t - 1] for t in range(t_start, t_end)])


def seasonal_naive_forecast(y, t_start, t_end, period=PERIOD):
    """yhat[t] = y[t-period], for t in [t_start, t_end)."""
    return np.array([y[t - period] for t in range(t_start, t_end)])


if __name__ == "__main__":
    t, y, trend, seasonal, noise = make_series()
    y_true = y[SPLIT_T:N]
    t_range = (SPLIT_T, N)
    t_idx = np.arange(*t_range)

    print(f"Evaluating on the test period t={SPLIT_T}..{N-1} ({len(y_true)} points)")

    # --- Persistence baseline ---------------------------------------------
    yhat_persist = persistence_forecast(y, *t_range)
    print(f"\nPersistence (yhat[t] = y[t-1]):")
    print(f"  first 5 targets:     {np.round(y_true[:5], 4)}")
    print(f"  first 5 predictions: {np.round(yhat_persist[:5], 4)}")
    print(f"  MAE  = {mae(y_true, yhat_persist):.4f}")
    print(f"  RMSE = {rmse(y_true, yhat_persist):.4f}")
    print(f"  MAPE = {mape(y_true, yhat_persist):.2f}%")

    # --- Seasonal-naive baseline --------------------------------------------
    yhat_seasonal = seasonal_naive_forecast(y, *t_range)
    print(f"\nSeasonal-naive (yhat[t] = y[t-{PERIOD}]):")
    print(f"  first 5 targets:     {np.round(y_true[:5], 4)}")
    print(f"  first 5 predictions: {np.round(yhat_seasonal[:5], 4)}")
    print(f"  MAE  = {mae(y_true, yhat_seasonal):.4f}")
    print(f"  RMSE = {rmse(y_true, yhat_seasonal):.4f}")
    print(f"  MAPE = {mape(y_true, yhat_seasonal):.2f}%")

    # --- Why persistence wins here: decompose both errors by hand ----------
    # y[t]-y[t-k] = (trend[t]-trend[t-k]) + (seasonal[t]-seasonal[t-k]) + (noise[t]-noise[t-k])
    d1_trend = trend[t_idx] - trend[t_idx - 1]
    d1_seasonal = seasonal[t_idx] - seasonal[t_idx - 1]
    d1_noise = noise[t_idx] - noise[t_idx - 1]
    d50_trend = trend[t_idx] - trend[t_idx - PERIOD]
    d50_seasonal = seasonal[t_idx] - seasonal[t_idx - PERIOD]
    d50_noise = noise[t_idx] - noise[t_idx - PERIOD]

    print(f"\nWhy persistence beats seasonal-naive here -- decomposing both errors:")
    print(f"  persistence error = dtrend(1 step) + dseasonal(1 step) + dnoise(1 step)")
    print(f"    dtrend(1 step):    constant {d1_trend[0]:.4f} (= 0.03*1)")
    print(f"    dseasonal(1 step): mean={d1_seasonal.mean():.4f}  std={d1_seasonal.std():.4f}  "
          f"(small -- one step covers only 1/{PERIOD} of a cycle)")
    print(f"    dnoise(1 step):    mean={d1_noise.mean():.4f}  std={d1_noise.std():.4f}")
    print(f"    reconstructed MAE: "
          f"{mae(np.zeros_like(d1_trend), d1_trend + d1_seasonal + d1_noise):.4f} "
          f"(matches persistence MAE {mae(y_true, yhat_persist):.4f})")
    print(f"  seasonal-naive error = dtrend({PERIOD} steps) + dseasonal({PERIOD} steps) + dnoise({PERIOD} steps)")
    print(f"    dtrend({PERIOD} steps):    constant {d50_trend[0]:.4f} (= 0.03*{PERIOD} -- a real, unavoidable bias)")
    print(f"    dseasonal({PERIOD} steps): {d50_seasonal.min():.10f} .. {d50_seasonal.max():.10f} (cancels exactly)")
    print(f"    dnoise({PERIOD} steps):    mean={d50_noise.mean():.4f}  std={d50_noise.std():.4f}  "
          f"(same scale as 1-step noise -- these noise draws are independent either way)")
    print(f"    reconstructed MAE: "
          f"{mae(np.zeros_like(d50_trend), d50_trend + d50_seasonal + d50_noise):.4f} "
          f"(matches seasonal-naive MAE {mae(y_true, yhat_seasonal):.4f})")
    print(f"\n  Both forecasts get hit by noise of about the same size (this series' noise is i.i.d.,")
    print(f"  so no lag has an advantage there), and seasonal-naive's exact phase match cancels the")
    print(f"  seasonal term perfectly -- but it pays a constant {d50_trend[0]:.4f} trend-drift bias that")
    print(f"  persistence barely pays ({d1_trend[0]:.4f}), because persistence's reference point is only")
    print(f"  1 step stale instead of {PERIOD}. The lesson: seasonality alone does not make seasonal-naive")
    print(f"  the better baseline -- it depends on trend strength, noise structure, and how the period")
    print(f"  compares to the step size. Always compare candidate baselines on real data; never assume.")

    print(f"\nSummary: the bar a real model must clear is the BETTER of the two baselines -- "
          f"persistence, MAE={mae(y_true, yhat_persist):.4f}, RMSE={rmse(y_true, yhat_persist):.4f}.")
