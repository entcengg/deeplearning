# ch26_program5.py
# Does attention help forecasting? A small Transformer encoder (Chapter 19's
# block: positional encoding + self-attention + feedforward) against Program
# 3's LSTM, both reading the SAME differenced window and predicting the SAME
# next delta. Chapter 20's text classifier pooled its Transformer output by
# averaging over every position, because every word could matter to a topic.
# A forecast is different: the one position that matters most is the last
# one, the step immediately before the value being predicted, so this
# Transformer pools by reading its output AT that last position instead of
# averaging over the whole window. Compared at two window lengths, because
# Chapters 18-19 already found attention's edge over a recurrent reader shows
# up mainly once the sequence is long enough to stress a single hidden
# state's memory -- this chapter checks whether that holds for forecasting
# too, rather than assuming it does.

import math
import numpy as np
import torch
import torch.nn as nn

N = 1000          # total time steps
PERIOD = 50       # seasonal period, in steps
TREND_A = 20.0    # trend intercept
TREND_B = 0.03    # trend slope (per step)
SEASONAL_AMP = 6.0
NOISE_STD = 0.8
SPLIT_T = 800      # first SPLIT_T steps -> train targets, rest -> test targets


def make_series(n=N, seed=0):
    t = np.arange(n)
    trend = TREND_A + TREND_B * t
    seasonal = SEASONAL_AMP * np.sin(2 * np.pi * t / PERIOD)
    rng = np.random.RandomState(seed)
    noise = rng.normal(0.0, NOISE_STD, size=n)
    y = trend + seasonal + noise
    return t, y, trend, seasonal, noise


def mae(y_true, y_pred):
    return float(np.mean(np.abs(y_true - y_pred)))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


class LSTMForecaster(nn.Module):
    def __init__(self, hidden_size=8):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (batch, seq_len, 1)
        _, (h_n, _) = self.lstm(x)   # h_n: (1, batch, hidden_size), final hidden state
        return self.head(h_n[-1]).squeeze(-1)   # (batch,)


def train_forecaster(model, X_train, y_train, epochs=100, batch_size=64, lr=1e-3, checkpoints=()):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        epoch_loss, n_batches = 0.0, 0
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            pred = model(X_train[idx])
            loss = loss_fn(pred, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            epoch_loss += loss.item(); n_batches += 1
        if epoch in checkpoints:
            print(f"  epoch {epoch:3d}: mean training MSE (normalized units) = {epoch_loss / n_batches:.5f}")


def positional_encoding(seq_len, d_model):
    pe = torch.zeros(seq_len, d_model)
    position = torch.arange(seq_len).unsqueeze(1).float()
    div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
    pe[:, 0::2] = torch.sin(position * div_term)
    pe[:, 1::2] = torch.cos(position * div_term)
    return pe


class TransformerForecaster(nn.Module):
    def __init__(self, d_model=8, nhead=2, dim_feedforward=16, num_layers=1, max_len=200):
        super().__init__()
        self.input_proj = nn.Linear(1, d_model)
        self.register_buffer("pe", positional_encoding(max_len, d_model))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead,
                                            dim_feedforward=dim_feedforward,
                                            batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_layers)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        # x: (batch, seq_len, 1)
        seq_len = x.shape[1]
        h = self.input_proj(x) + self.pe[:seq_len].unsqueeze(0)
        h = self.encoder(h)              # (batch, seq_len, d_model)
        pooled = h[:, -1, :]              # the position aligned with the forecast anchor
        return self.head(pooled).squeeze(-1)


def build_onestep_dataset(y, window, t_start, t_end):
    X, targets = [], []
    for t in range(t_start, t_end):
        X.append(y[t - window:t]); targets.append(y[t])
    return np.array(X, dtype=np.float32), np.array(targets, dtype=np.float32)


def run_at_window(y, window, hidden_lstm=8, epochs=100):
    X_train_raw, y_train_raw = build_onestep_dataset(y, window, window, SPLIT_T)
    X_test_raw, y_test_raw = build_onestep_dataset(y, window, SPLIT_T, N)

    Xd_train_raw = np.diff(X_train_raw, axis=1)
    Xd_test_raw = np.diff(X_test_raw, axis=1)
    last_train, last_test = X_train_raw[:, -1], X_test_raw[:, -1]
    delta_train_raw = y_train_raw - last_train
    delta_test_raw = y_test_raw - last_test
    mu_x, sigma_x = Xd_train_raw.mean(), Xd_train_raw.std()
    mu_d, sigma_d = delta_train_raw.mean(), delta_train_raw.std()

    Xd_train = torch.from_numpy((Xd_train_raw - mu_x) / sigma_x).unsqueeze(-1)
    Xd_test = torch.from_numpy((Xd_test_raw - mu_x) / sigma_x).unsqueeze(-1)
    yd_train = torch.from_numpy((delta_train_raw - mu_d) / sigma_d)

    torch.manual_seed(0)
    lstm_model = LSTMForecaster(hidden_size=hidden_lstm)
    train_forecaster(lstm_model, Xd_train, yd_train, epochs=epochs)
    lstm_model.eval()
    with torch.no_grad():
        lstm_pred_norm = lstm_model(Xd_test)
    yhat_lstm = last_test + lstm_pred_norm.numpy() * sigma_d + mu_d

    torch.manual_seed(0)
    tfm_model = TransformerForecaster(max_len=window)
    train_forecaster(tfm_model, Xd_train, yd_train, epochs=epochs)
    tfm_model.eval()
    with torch.no_grad():
        tfm_pred_norm = tfm_model(Xd_test)
    yhat_tfm = last_test + tfm_pred_norm.numpy() * sigma_d + mu_d

    n_lstm = sum(p.numel() for p in lstm_model.parameters())
    n_tfm = sum(p.numel() for p in tfm_model.parameters())
    return y_test_raw, yhat_lstm, yhat_tfm, n_lstm, n_tfm


if __name__ == "__main__":
    t, y, trend, seasonal, noise = make_series()

    for window in [60, 150]:
        n_periods = window / PERIOD
        print(f"\n{'='*74}\nWindow length = {window} ({n_periods:.1f} seasonal periods of {PERIOD} steps)\n{'='*74}")
        y_true, yhat_lstm, yhat_tfm, n_lstm, n_tfm = run_at_window(y, window)
        print(f"LSTM:        {n_lstm:,} params  MAE={mae(y_true, yhat_lstm):.4f}  "
              f"RMSE={rmse(y_true, yhat_lstm):.4f}")
        print(f"Transformer: {n_tfm:,} params  MAE={mae(y_true, yhat_tfm):.4f}  "
              f"RMSE={rmse(y_true, yhat_tfm):.4f}")
        better = "LSTM" if mae(y_true, yhat_lstm) < mae(y_true, yhat_tfm) else "Transformer"
        print(f"Better on this test set: {better}")

    print(f"\n{'='*74}\nSummary across both window lengths\n{'='*74}")
    print(f"Both models read the exact same differenced windows and are trained the same way;")
    print(f"only the sequence-reading mechanism differs (a recurrent hidden state vs. self-attention")
    print(f"read out at the last position). Whatever the numbers above show, the comparison is a fair,")
    print(f"matched one -- the result is reported as measured, not assumed from Chapters 18-19's")
    print(f"retrieval-task finding.")
