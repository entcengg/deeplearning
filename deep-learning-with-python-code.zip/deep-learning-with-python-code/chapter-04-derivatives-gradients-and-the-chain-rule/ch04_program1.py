# ch04_program1.py
# The derivative as a limit: secant slopes converging to the tangent slope,
# then the same idea applied to a cubic, plus a product-rule check.

import numpy as np

# --- Part 1: f(x) = x^2 at x = 3. Analytical derivative: f'(x) = 2x, so f'(3) = 6. ---
def f(x):
    return x ** 2

x0 = 3.0
print("f(x) = x^2 at x = 3  (analytical f'(3) = 6)")
print(f"{'h':>8} {'forward diff':>14} {'central diff':>14}")
for h in [1.0, 0.1, 0.01, 0.001]:
    forward = (f(x0 + h) - f(x0)) / h
    central = (f(x0 + h) - f(x0 - h)) / (2 * h)
    print(f"{h:>8} {forward:>14.6f} {central:>14.6f}")

# --- Part 2: a cubic, where central differences are close but not exact. ---
def g(x):
    return x ** 3 - 2 * x ** 2 + 5     # analytical: g'(x) = 3x^2 - 4x

x0 = 2.0
print(f"\ng(x) = x^3 - 2x^2 + 5 at x = 2  (analytical g'(2) = {3*x0**2 - 4*x0:.0f})")
for h in [0.1, 0.001]:
    central = (g(x0 + h) - g(x0 - h)) / (2 * h)
    print(f"h={h:<6} central diff = {central:.6f}")

# --- Part 3: product rule check. h(x) = x^2 (x + 3) at x = 2. ---
def h_func(x):
    return x ** 2 * (x + 3)

x0 = 2.0
u, up = x0 ** 2, 2 * x0            # u = x^2,      u' = 2x
v, vp = x0 + 3, 1.0                # v = x + 3,    v' = 1
product_rule = up * v + u * vp
central = (h_func(x0 + 0.001) - h_func(x0 - 0.001)) / 0.002
print(f"\nh(x) = x^2(x+3) at x = 2:  h(2) = {h_func(x0):.1f}")
print(f"product rule: u'v + uv' = {up:.0f}*{v:.0f} + {u:.0f}*{vp:.0f} = {product_rule:.1f}")
print(f"central diff (h=0.001)                  = {central:.6f}")
