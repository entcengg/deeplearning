# ch04_program3.py
# The chain rule: differentiating a composed function two ways and checking
# they agree, then confirming with a numerical derivative.

def g(x):
    return 3 * x + 1          # the inner function

def f(u):
    return u ** 2             # the outer function

def h(x):
    return f(g(x))            # the composition: h(x) = (3x + 1)^2

x0 = 2.0
print("g(x) = 3x + 1,  f(u) = u^2,  h(x) = f(g(x)) = (3x+1)^2")
print(f"g({x0:.0f}) = {g(x0):.0f}")
print(f"h({x0:.0f}) = f(g({x0:.0f})) = {h(x0):.0f}")

# Chain rule: h'(x) = f'(g(x)) * g'(x) = 2*g(x) * 3 = 6*g(x)
h_prime_chain_rule = 2 * g(x0) * 3
print(f"\nchain rule: h'(x) = f'(g(x)) * g'(x) = 2*g(x)*3")
print(f"h'({x0:.0f}) = 2*{g(x0):.0f}*3 = {h_prime_chain_rule:.0f}")

# Numerical check on the WHOLE composed function, ignoring how it is built:
hstep = 0.001
h_prime_numeric = (h(x0 + hstep) - h(x0 - hstep)) / (2 * hstep)
print(f"numerical h'({x0:.0f})           = {h_prime_numeric:.6f}")
