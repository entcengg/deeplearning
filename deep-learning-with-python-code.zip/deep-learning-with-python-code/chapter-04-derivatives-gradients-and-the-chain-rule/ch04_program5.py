# ch04_program5.py
# What an incorrect gradient does to real training: the correct dL/dw
# from Program 4, against a buggy version that forgets the chain rule's
# inner slope (the C_i factor) -- run side by side on the same data.

import numpy as np

C = np.array([0.0, 10.0, 20.0, 30.0])
F = np.array([32.0, 50.0, 68.0, 86.0])
m = len(C)

def correct_gradients(w, b):
    F_hat = w * C + b
    L = np.mean((F - F_hat) ** 2)
    dL_dw = 2 * np.mean(C * (F_hat - F))    # derived via the chain rule, weighted by C_i
    dL_db = 2 * np.mean(F_hat - F)          # derived via the chain rule
    return L, dL_dw, dL_db

def buggy_gradients(w, b):
    # BUG: Common Mistake 1 -- forgets the chain rule's inner slope for w.
    # dL/dw should be weighted by C_i; this version uses the SAME formula as dL/db.
    F_hat = w * C + b
    L = np.mean((F - F_hat) ** 2)
    dL_dw_wrong = 2 * np.mean(F_hat - F)    # missing the C_i factor entirely
    dL_db = 2 * np.mean(F_hat - F)
    return L, dL_dw_wrong, dL_db

def train(gradient_fn, epochs, eta, report_at):
    w, b = 1.0, 0.0
    for epoch in range(1, epochs + 1):
        L, dw, db = gradient_fn(w, b)
        w -= eta * dw
        b -= eta * db
        if epoch in report_at:
            print(f"  epoch {epoch:>6}: w={w:.5f}  b={b:.5f}  loss={L:.6f}")
    return w, b

eta = 0.0005
epochs = 20000
checkpoints = {1, 10, 100, 1000, 5000, 10000, 20000}

print("Correct gradient (dL/dw properly weighted by C_i):")
w_correct, b_correct = train(correct_gradients, epochs, eta, checkpoints)
print(f"  final: w={w_correct:.5f} (target 1.8)  b={b_correct:.5f} (target 32)")

print("\nBuggy gradient (dL/dw missing the C_i factor -- Common Mistake 1):")
w_buggy, b_buggy = train(buggy_gradients, epochs, eta, checkpoints)
print(f"  final: w={w_buggy:.5f}  b={b_buggy:.5f}  (did NOT reach w=1.8, b=32)")

print(f"\nw - b stayed constant under the buggy rule: w0-b0={1.0-0.0:.1f}, "
      f"final w-b={w_buggy - b_buggy:.5f}")
