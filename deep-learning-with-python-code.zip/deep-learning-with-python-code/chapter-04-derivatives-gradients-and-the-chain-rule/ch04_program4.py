# ch04_program4.py
# The big reveal: using the chain rule to derive dL/dw AND dL/db for the
# two-parameter model F_hat = w*C + b, matching Chapter 1's given formulas.

import numpy as np

# Celsius -> Fahrenheit data (F = 1.8*C + 32 exactly)
C = np.array([0.0, 10.0, 20.0, 30.0])
F = np.array([32.0, 50.0, 68.0, 86.0])
m = len(C)

def loss_and_gradients(w, b):
    F_hat = w * C + b
    L = np.mean((F - F_hat) ** 2)
    dL_dw = 2 * np.mean(C * (F_hat - F))   # derived via the chain rule
    dL_db = 2 * np.mean(F_hat - F)         # derived via the chain rule
    return L, dL_dw, dL_db

# A naive first guess: "just multiply by 1, no offset."
w0, b0 = 1.0, 0.0
L, dL_dw, dL_db = loss_and_gradients(w0, b0)
print(f"At (w,b) = ({w0:.0f},{b0:.0f}):")
print("predictions F_hat        :", w0 * C + b0)
print("overshoots (F_hat - F)   :", w0 * C + b0 - F)
print(f"loss L                   = {L:.1f}")
print(f"dL/dw (analytical)       = {dL_dw:.1f}")
print(f"dL/db (analytical)       = {dL_db:.1f}")

# Confirm both partials numerically, exactly as Program 2 did.
h = 1e-4
Lp, _, _ = loss_and_gradients(w0 + h, b0); Lm, _, _ = loss_and_gradients(w0 - h, b0)
print(f"dL/dw (numerical)        = {(Lp - Lm) / (2*h):.4f}")
Lp, _, _ = loss_and_gradients(w0, b0 + h); Lm, _, _ = loss_and_gradients(w0, b0 - h)
print(f"dL/db (numerical)        = {(Lp - Lm) / (2*h):.4f}")

# One gradient descent step on BOTH parameters at once.
eta = 0.0005
w1 = w0 - eta * dL_dw
b1 = b0 - eta * dL_db
L1, _, _ = loss_and_gradients(w1, b1)
print(f"\nOne step with eta={eta}:")
print(f"w: {w0:.2f} -> {w1:.2f}   (target 1.8)")
print(f"b: {b0:.2f} -> {b1:.3f}   (target 32)")
print(f"loss: {L:.1f} -> {L1:.4f}")
