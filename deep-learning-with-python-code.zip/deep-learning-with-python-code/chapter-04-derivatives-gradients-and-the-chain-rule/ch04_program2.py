# ch04_program2.py
# Partial derivatives and the gradient for a two-variable function.

import numpy as np

def g(w, b):
    return w**2 + 3*w*b + b**2     # analytical: dg/dw = 2w+3b, dg/db = 3w+2b

w0, b0 = 2.0, 1.0
print(f"g(w,b) = w^2 + 3wb + b^2 at (w,b) = ({w0:.0f},{b0:.0f})")
print("g(2,1) =", g(w0, b0))

# Analytical partial derivatives
dg_dw_analytical = 2*w0 + 3*b0
dg_db_analytical = 3*w0 + 2*b0
print(f"\nanalytical dg/dw = 2w+3b = {dg_dw_analytical:.1f}")
print(f"analytical dg/db = 3w+2b = {dg_db_analytical:.1f}")

# Numerical partial derivatives: vary ONE input, hold the other fixed.
h = 0.001
dg_dw_numeric = (g(w0 + h, b0) - g(w0 - h, b0)) / (2 * h)
dg_db_numeric = (g(w0, b0 + h) - g(w0, b0 - h)) / (2 * h)
print(f"\nnumerical dg/dw  = {dg_dw_numeric:.6f}")
print(f"numerical dg/db  = {dg_db_numeric:.6f}")

gradient = np.array([dg_dw_analytical, dg_db_analytical])
print(f"\ngradient vector grad(g) = (dg/dw, dg/db) = ({gradient[0]:.0f}, {gradient[1]:.0f})")
print("length of gradient (steepest-ascent 'speed'):", np.linalg.norm(gradient).round(4))
