# Chapter 4 · Derivatives, Gradients, and the Chain Rule

Code for Chapter 4 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 3](../chapter-03-vectors-matrices-and-tensors/README.md) · [Chapter 5 →](../chapter-05-the-artificial-neuron/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 4.2 Program 1: Checking Derivatives Numerically | The derivative as a limit: secant slopes converging, then the same idea applied to a cubic and a product rule check | [`ch04_program1.py`](ch04_program1.py) | [ch04_program1.txt](expected_output/ch04_program1.txt) | < 1 s |
| 2 | 4.6 Program 2: Partial Derivatives and the Gradient | Partial derivatives and the gradient of a two-variable function | [`ch04_program2.py`](ch04_program2.py) | [ch04_program2.txt](expected_output/ch04_program2.txt) | < 1 s |
| 3 | 4.8 Program 3: Verifying the Chain Rule | The chain rule, checked against a numerical derivative of the whole composed function | [`ch04_program3.py`](ch04_program3.py) | [ch04_program3.txt](expected_output/ch04_program3.txt) | < 1 s |
| 4 | 4.10 Program 4: The Loss Gradient, Derived and Verified | Both partial derivatives of the two-parameter loss, checked numerically, and one training step | [`ch04_program4.py`](ch04_program4.py) | [ch04_program4.txt](expected_output/ch04_program4.txt) | < 1 s |
| 5 | 4.11 Program 5: Training With an Incorrect Gradient | Correct versus incorrect gradients, trained side by side on identical data | [`ch04_program5.py`](ch04_program5.py) | [ch04_program5.txt](expected_output/ch04_program5.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-04-derivatives-gradients-and-the-chain-rule
python ch04_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch04_notebook.ipynb`](ch04_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.
