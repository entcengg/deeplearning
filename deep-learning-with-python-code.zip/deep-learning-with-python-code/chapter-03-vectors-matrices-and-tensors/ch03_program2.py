# ch03_program2.py
# Matrices: shape, transpose, matrix-vector and matrix-matrix products.

import numpy as np

A = np.array([[1.0, 2.0],
              [3.0, 4.0]])
B = np.array([[5.0, 6.0],
              [7.0, 0.0]])

print("A shape:", A.shape, "  B shape:", B.shape)
print("A transposed:\n", A.T, sep="")

print("\nA @ B:\n", A @ B, sep="")
print("\nB @ A:\n", B @ A, sep="")   # different! order matters

W = np.array([[1.0, 0.0, 2.0],
              [-1.0, 3.0, 1.0]])     # shape (2, 3)
v = np.array([2.0, 1.0, 0.0])        # shape (3,)
print("\nW @ v:", W @ v)             # (2,3) @ (3,) -> (2,)

# Shapes that do not fit raise an error instead of guessing:
try:
    W @ np.array([1.0, 2.0])         # (2,3) @ (2,) -- inner sizes 3 and 2
except ValueError as err:
    print("\nValueError:", err)
