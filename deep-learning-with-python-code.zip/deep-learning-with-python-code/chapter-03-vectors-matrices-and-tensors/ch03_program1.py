# ch03_program1.py
# Vectors in NumPy: shape, arithmetic, length, and the dot product.

import numpy as np

x = np.array([2.0, -1.0, 3.0])
y = np.array([4.0,  0.0, 5.0])

print("x        :", x)
print("shape    :", x.shape, "   dimensions:", x.ndim)

print("\nx + y    :", x + y)          # element by element
print("2 * x    :", 2 * x)            # every element doubled
print("length   :", np.linalg.norm(x))  # sqrt(2^2 + (-1)^2 + 3^2)

print("\ndot(x, y):", np.dot(x, y))   # 2*4 + (-1)*0 + 3*5
print("x @ y    :", x @ y)            # @ is the same dot product
