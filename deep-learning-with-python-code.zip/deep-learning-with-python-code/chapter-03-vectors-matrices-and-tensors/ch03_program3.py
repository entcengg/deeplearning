# ch03_program3.py
# Real data as tensors: 1,797 handwritten digits, plus broadcasting.

import numpy as np
from sklearn.datasets import load_digits

digits = load_digits()
images = digits.images            # rank-3 tensor: (samples, height, width)
print("images tensor shape :", images.shape)
print("one image shape     :", images[0].shape)
print("top-left 4x4 corner of image 0:\n", images[0][:4, :4], sep="")
print("its label           :", digits.target[0])

# Flatten each 8x8 grid into a 64-number vector (row after row):
flat = images.reshape(1797, 64)
print("\nflattened shape     :", flat.shape)

# A batch is just a slice along axis 0:
batch = flat[0:32]
print("first batch shape   :", batch.shape)

# Broadcasting: one row vector is added to every row of a matrix.
M = np.array([[1.0, 2.0, 3.0],
              [4.0, 5.0, 6.0]])       # shape (2, 3)
b = np.array([10.0, 20.0, 30.0])      # shape (3,)
print("\nM + b:\n", M + b, sep="")

# The classic broadcasting trap: (4,) plus (4,1) quietly makes a matrix.
u = np.array([1.0, 2.0, 3.0, 4.0])            # shape (4,)
c = np.array([[1.0], [2.0], [3.0], [4.0]])    # shape (4, 1)
print("\nu + c has shape", (u + c).shape, "-- probably not what you wanted:")
print(u + c)
