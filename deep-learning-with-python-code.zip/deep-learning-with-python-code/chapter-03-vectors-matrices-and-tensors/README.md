# Chapter 3 · Vectors, Matrices, and Tensors

Code for Chapter 3 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 2](../chapter-02-setting-up-python-for-deep-learning/README.md) · [Chapter 4 →](../chapter-04-derivatives-gradients-and-the-chain-rule/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 3.4 Program 1: Vectors in NumPy | Vectors: shape, arithmetic, length, and the dot product | [`ch03_program1.py`](ch03_program1.py) | [ch03_program1.txt](expected_output/ch03_program1.txt) | < 1 s |
| 2 | 3.7 Program 2: Matrix Multiplication in NumPy | Matrices: transpose, products, and a shape error on purpose | [`ch03_program2.py`](ch03_program2.py) | [ch03_program2.txt](expected_output/ch03_program2.txt) | < 1 s |
| 3 | 3.10 Program 3: Real Data as Tensors | The digits dataset as a tensor, flattening, batches, and broadcasting — including the classic trap | [`ch03_program3.py`](ch03_program3.py) | [ch03_program3.txt](expected_output/ch03_program3.txt) | 1 s |
| 4 | 3.11 Program 4: A Gallery of Shape Errors | Three shape bugs that plague real deep learning code: one crash, two silent wrong answers | [`ch03_program4.py`](ch03_program4.py) | [ch03_program4.txt](expected_output/ch03_program4.txt) | 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-03-vectors-matrices-and-tensors
python ch03_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch03_notebook.ipynb`](ch03_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn.
