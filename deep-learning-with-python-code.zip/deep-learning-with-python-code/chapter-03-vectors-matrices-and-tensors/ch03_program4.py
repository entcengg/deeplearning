# ch03_program4.py
# A gallery of shape errors: one loud crash, and two silent ones that
# return a plausible-looking wrong answer instead of raising anything.

import numpy as np
from sklearn.datasets import load_digits

digits = load_digits()
flat = digits.images.reshape(1797, 64)   # (1797, 64), as Program 3 built it
y = digits.target

print("=== Error 1: mismatched batch sizes (a loud crash) ===")
X_batch = flat[0:32]          # 32 examples
y_batch = y[0:16]             # BUG: only 16 labels sliced -- forgot to match it
print("X_batch shape:", X_batch.shape, " y_batch shape:", y_batch.shape)
w = np.zeros(64)
predictions = X_batch @ w
try:
    errors = predictions - y_batch
except ValueError as err:
    print("ValueError:", err)

print("\n=== Error 2: a missing batch axis silently changes what mean() does ===")
one_example = flat[0]              # shape (64,) -- a SINGLE example, batch axis gone
print("one_example shape:", one_example.shape)
wrong_mean = one_example.mean(axis=0)     # intended: "average across the batch, per pixel"
print("one_example.mean(axis=0) ->", wrong_mean, " (a single number, not 64 of them)")
batch_of_one = flat[0:1]           # shape (1, 64) -- batch axis kept, size-1 batch
correct_mean = batch_of_one.mean(axis=0)
print("flat[0:1].mean(axis=0) shape:", correct_mean.shape,
      " (first 3 values:", correct_mean[:3], ")")

print("\n=== Error 3: channels-first vs. channels-last, mixed up silently ===")
batch = np.zeros((2, 3, 4, 4))     # (batch, channels, H, W) -- PyTorch convention
batch[:, 0, :, :] = 100            # fill channel 0 with 100s
batch[:, 1, :, :] = 200            # fill channel 1 with 200s
batch[:, 2, :, :] = 300            # fill channel 2 with 300s
true_channel0 = batch[:, 0, :, :]                 # correct: channels-first indexing
assumed_channel0 = batch[:, :, :, 0]              # BUG: treats the LAST axis as channel
print("true channel 0, unique values:       ", np.unique(true_channel0))
print("wrongly-assumed channel 0, unique values:", np.unique(assumed_channel0))
print("(the second line silently mixes all three channels -- no error, no warning)")
