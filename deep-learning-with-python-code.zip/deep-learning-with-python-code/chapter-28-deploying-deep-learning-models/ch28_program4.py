# ch28_program4.py
# Every earlier program in this chapter called the model directly, inside
# the same Python process that trained it. A real deployment puts the
# model behind a network boundary: some other process, possibly on another
# machine, sends data in and gets a prediction back over HTTP. This
# program starts an actual Flask server in a background thread, sends it
# real HTTP requests with the `requests` library, and inspects the real
# JSON responses -- nothing here is simulated or mocked.

import json
import threading
import time
import warnings

import numpy as np
import requests
import torch
import torch.nn as nn
from flask import Flask, jsonify, request
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

torch.manual_seed(0)
np.random.seed(0)

HOST = "127.0.0.1"
PORT = 8731


class DigitClassifier(nn.Module):
    """Same architecture as Program 1 and Program 3."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def build_app(model):
    """Wraps a trained model in a two-endpoint Flask app: /health for a
    liveness check, and /predict for a real prediction on posted pixels."""
    app = Flask(__name__)
    app.logger.disabled = True
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok"})

    @app.route("/predict", methods=["POST"])
    def predict():
        payload = request.get_json(force=True, silent=True)
        if payload is None or "pixels" not in payload:
            return jsonify({"error": "request body must be JSON with a 'pixels' field"}), 400

        pixels = np.array(payload["pixels"], dtype=np.float32)
        if pixels.shape != (8, 8):
            return jsonify({"error": f"'pixels' must be an 8x8 array, got shape {list(pixels.shape)}"}), 400

        x = torch.from_numpy(pixels).view(1, 1, 8, 8)
        with torch.no_grad():
            logits = model(x)
            probs = torch.softmax(logits, dim=1).squeeze(0)
            predicted = int(probs.argmax().item())
            confidence = float(probs[predicted].item())

        return jsonify({
            "predicted_digit": predicted,
            "confidence": round(confidence, 4),
            "probabilities": [round(p, 4) for p in probs.tolist()],
        })

    return app


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    model = DigitClassifier()
    print("Training DigitClassifier for 250 epochs (same setup as Programs 1 and 3)...")
    train_model(model, X_train, y_train, epochs=250)
    model.eval()

    with torch.no_grad():
        test_acc = (model(X_test).argmax(dim=1) == y_test).float().mean().item()
    print(f"Test accuracy: {test_acc:.4f}\n")

    app = build_app(model)
    import flask.cli
    flask.cli.show_server_banner = lambda *args, **kwargs: None   # suppress the startup banner
    server_thread = threading.Thread(
        target=lambda: app.run(host=HOST, port=PORT, debug=False, use_reloader=False),
        daemon=True)
    server_thread.start()
    time.sleep(1.0)   # give the server a moment to bind the port before the first request

    base_url = f"http://{HOST}:{PORT}"

    # --- Real HTTP request 1: health check ---
    health_response = requests.get(f"{base_url}/health", timeout=5)
    print(f"GET /health -> status {health_response.status_code}, body {health_response.json()}")

    # --- Real HTTP request 2: a well-formed prediction request ---
    sample_index = 0
    sample_pixels = X_test[sample_index, 0].numpy().tolist()
    true_label = int(y_test[sample_index].item())
    predict_response = requests.post(
        f"{base_url}/predict", json={"pixels": sample_pixels}, timeout=5)
    predict_body = predict_response.json()
    print(f"\nPOST /predict (true label {true_label}) -> status {predict_response.status_code}")
    print(f"  {json.dumps(predict_body)}")

    # --- Real HTTP request 3: every test image, checking the server's accuracy over HTTP ---
    correct = 0
    for i in range(len(X_test)):
        pixels = X_test[i, 0].numpy().tolist()
        r = requests.post(f"{base_url}/predict", json={"pixels": pixels}, timeout=5)
        predicted = r.json()["predicted_digit"]
        if predicted == int(y_test[i].item()):
            correct += 1
    server_acc = correct / len(X_test)
    print(f"\nAccuracy computed by calling the live server once per test image: {server_acc:.4f}")
    print(f"(matches the in-process test accuracy of {test_acc:.4f} exactly -- the server wraps the")
    print(f"same model, it does not run a second copy of the math)")

    # --- Real HTTP request 4: a deliberately malformed request, to check error handling ---
    bad_response = requests.post(f"{base_url}/predict", json={"pixels": [1, 2, 3]}, timeout=5)
    print(f"\nPOST /predict with a malformed payload -> status {bad_response.status_code}")
    print(f"  {json.dumps(bad_response.json())}")

    print(f"\nThis server is deliberately minimal -- a single unbatched request per call, no")
    print(f"authentication, no request queueing, no logging beyond what Flask does by default --")
    print(f"and that is the point: it shows the smallest possible boundary between 'a trained")
    print(f"PyTorch model' and 'a networked prediction'. Program 3's batching lesson still applies")
    print(f"here: calling /predict once per image, as the accuracy check above just did {len(X_test)} times,")
    print(f"pays the full per-request overhead every time. A production version of this same server")
    print(f"would accept a list of pixel arrays per request, or queue several incoming requests")
    print(f"together for a few milliseconds before running one batched forward pass, exactly as")
    print(f"Program 3 measured.")
