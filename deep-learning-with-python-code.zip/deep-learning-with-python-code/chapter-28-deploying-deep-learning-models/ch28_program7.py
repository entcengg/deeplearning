# ch28_program7.py
# Program 4's server, hardened for a hostile network. Every request must
# carry an API key; each key gets a fixed budget of requests per minute;
# bodies over a size limit are refused; and every input is validated --
# structure, shape, type, finiteness and range -- before the model sees
# it. Errors come back as a short JSON message, never a stack trace, and a
# successful response carries only the predicted digit and a rounded
# confidence, not the full probability vector. A client then sends the
# server well-formed, malformed and hostile requests over real HTTP.

import collections
import hmac
import json
import logging
import math
import secrets
import threading
import time
import warnings

import numpy as np
import requests
import torch
import torch.nn as nn
from flask import Flask, jsonify, request
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from werkzeug.exceptions import HTTPException
from werkzeug.serving import make_server

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

torch.manual_seed(0)
np.random.seed(0)

HOST = "127.0.0.1"
MAX_BODY_BYTES = 4096                 # an 8x8 image needs well under 2 KB of JSON
RATE_LIMIT, RATE_WINDOW = 10, 60.0    # at most 10 requests per key per 60 seconds
# In production the keys live in a secret store, never in source code.
API_KEYS = {"client-A": secrets.token_hex(16), "client-B": secrets.token_hex(16)}


class DigitClassifier(nn.Module):
    """Same architecture as Programs 1, 3, 4, 5 and 6."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def validate(payload):
    """Return (8x8 float32 array, None) for a valid body, else (None, reason)."""
    if not isinstance(payload, dict) or set(payload) != {"pixels"}:
        return None, "expected exactly one field, 'pixels'"
    rows = payload["pixels"]
    if (not isinstance(rows, list) or len(rows) != 8
            or any(not isinstance(r, list) or len(r) != 8 for r in rows)):
        return None, "'pixels' must be an 8x8 array"
    values = [v for r in rows for v in r]
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in values):
        return None, "'pixels' must contain only numbers"
    if any(not math.isfinite(v) for v in values):
        return None, "no NaN or infinite values allowed"
    if any(v < 0.0 or v > 1.0 for v in values):
        return None, "pixel values must lie in [0, 1]"
    return np.array(rows, dtype=np.float32), None


def build_app(model):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = MAX_BODY_BYTES
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    recent = collections.defaultdict(collections.deque)   # client -> request times
    lock = threading.Lock()
    audit = collections.Counter()                          # status code -> count

    def error(status, message):
        return jsonify({"error": message}), status

    @app.errorhandler(413)
    def too_large(e):
        return error(413, f"request body larger than {MAX_BODY_BYTES} bytes")

    @app.errorhandler(HTTPException)
    def http_error(e):                 # 404, 405, ...: a short message, nothing more
        return error(e.code, e.name.lower())

    @app.errorhandler(Exception)
    def unexpected(e):                 # a bug: report nothing about the internals
        return error(500, "internal error")

    @app.after_request
    def record(response):
        audit[response.status_code] += 1
        return response

    @app.route("/predict", methods=["POST"])
    def predict():
        # 1. Authentication: compare keys in constant time.
        key = request.headers.get("X-API-Key", "")
        client = next((name for name, k in API_KEYS.items()
                       if hmac.compare_digest(k.encode(), key.encode())), None)
        if client is None:
            return error(401, "missing or invalid API key")
        # 2. Rate limiting: a sliding window of request times per client.
        now = time.monotonic()
        with lock:
            times = recent[client]
            while times and now - times[0] > RATE_WINDOW:
                times.popleft()
            if len(times) >= RATE_LIMIT:
                body, status = error(429, "rate limit exceeded")
                body.headers["Retry-After"] = str(int(RATE_WINDOW))
                return body, status
            times.append(now)
        # 3. Size limit (MAX_CONTENT_LENGTH -> 413) and JSON parsing.
        payload = request.get_json(force=True, silent=True)
        if payload is None:
            return error(400, "body must be valid JSON")
        # 4. Validation, before the model ever sees the data.
        pixels, problem = validate(payload)
        if problem:
            return error(400, problem)
        with torch.no_grad():
            probs = torch.softmax(model(torch.from_numpy(pixels).view(1, 1, 8, 8)), dim=1)[0]
        return jsonify({"predicted_digit": int(probs.argmax()),
                        "confidence": round(float(probs.max()), 2)})

    return app, audit


X_train, y_train, X_test, y_test = load_data()
model = DigitClassifier()
print("Training DigitClassifier for 250 epochs (same setup as Programs 1 and 3-6)...")
train_model(model, X_train, y_train, epochs=250)
model.eval()

app, audit = build_app(model)
server = make_server(HOST, 0, app, threaded=True)      # port 0: any free port
threading.Thread(target=server.serve_forever, daemon=True).start()
url = f"http://{HOST}:{server.server_port}/predict"
key_a = {"X-API-Key": API_KEYS["client-A"]}
good = X_test[0, 0].numpy().tolist()                    # true label: 2
blank = [[0.0] * 8 for _ in range(8)]
# A well-behaved client library refuses to encode NaN; a hand-written body need not.
nan_body = json.dumps({"pixels": blank}).replace("0.0", "NaN", 1)

tests = [
    ("no API key", dict(json={"pixels": good})),
    ("wrong API key", dict(json={"pixels": good}, headers={"X-API-Key": "guess"})),
    ("valid request (true label 2)", dict(json={"pixels": good}, headers=key_a)),
    ("body is not JSON", dict(data="hello", headers=key_a)),
    ("wrong field name", dict(json={"image": good}, headers=key_a)),
    ("wrong shape (3 values)", dict(json={"pixels": [1, 2, 3]}, headers=key_a)),
    ("a string among the numbers", dict(json={"pixels": [["1"] * 8] + blank[1:]}, headers=key_a)),
    ("a NaN value", dict(data=nan_body, headers={**key_a, "Content-Type": "application/json"})),
    ("raw 0-16 pixel scale", dict(json={"pixels": (X_test[0, 0] * 16).tolist()}, headers=key_a)),
    ("20 KB body", dict(json={"pixels": good, "pad": "x" * 20000}, headers=key_a)),
]
print(f"\nserver listening on a free port; limits: {MAX_BODY_BYTES}-byte body, "
      f"{RATE_LIMIT} requests/key/{int(RATE_WINDOW)} s")
print(f"{'request':<28}{'status':>6}  response")
for name, kwargs in tests:
    r = requests.post(url, timeout=5, **kwargs)
    print(f"{name:<28}{r.status_code:>6}  {r.text.strip()}")
r = requests.get(url, timeout=5)
print(f"{'GET instead of POST':<28}{r.status_code:>6}  {r.text.strip()}")
with torch.no_grad():
    raw = torch.softmax(model(X_test[0:1] * 16), dim=1)[0]
print(f"without the range check, the model would have answered the raw-scale image:")
print(f"  digit {int(raw.argmax())} with confidence {float(raw.max()):.2f}")

statuses = []
for i in range(12):
    r = requests.post(url, json={"pixels": good}, headers={"X-API-Key": API_KEYS["client-B"]},
                      timeout=5)
    statuses.append(r.status_code)
print(f"\nclient-B sends 12 valid requests in a burst: "
      f"{statuses.count(200)} x 200, then {statuses.count(429)} x 429 "
      f"(Retry-After: {r.headers.get('Retry-After')} s)")
server.shutdown()
print(f"server audit log by status: {dict(sorted(audit.items()))}; server shut down")
