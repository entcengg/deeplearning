# Chapter 28 · Deploying Deep Learning Models

Code for Chapter 28 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 27](../chapter-27-explainability-and-responsible-ai/README.md) · [Appendix A →](../appendix-a-python-refresher/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 28.1.1 Program 1: Three Export Formats, One Verified Model | Exporting a trained classifier to state_dict, TorchScript, and ONNX, and verifying every reload against the original | [`ch28_program1.py`](ch28_program1.py) | [ch28_program1.txt](expected_output/ch28_program1.txt) | 25 s |
| 2 | 28.2.1 Program 2: Measuring Quantization's Real Trade-Off | Dynamic quantization on a small MLP, with accuracy, size, and latency all measured directly | [`ch28_program2.py`](ch28_program2.py) | [ch28_program2.txt](expected_output/ch28_program2.txt) | 14 s |
| 3 | 28.3.1 Program 3: Measuring the Batching Curve Directly | Throughput and per-image latency across a batch-size sweep | [`ch28_program3.py`](ch28_program3.py) | [ch28_program3.txt](expected_output/ch28_program3.txt) | 25 s |
| 4 | 28.4.1 Program 4: A Minimal Inference Server, Verified Live | A minimal Flask inference server, queried with real HTTP requests | [`ch28_program4.py`](ch28_program4.py) | [ch28_program4.txt](expected_output/ch28_program4.txt) | 26 s |
| 5 | 28.5.1 Program 5: A Label-Free Drift Monitor, Checked Against Ground Truth | Label-free drift detection via a per-pixel KS test and model confidence, checked against ground-truth accuracy | [`ch28_program5.py`](ch28_program5.py) | [ch28_program5.txt](expected_output/ch28_program5.txt) | 25 s |
| 6 | 28.6.1 Program 6: A Registry, a Gate, a Rollback and a Retraining Trigger | A model registry, evaluation gate, rollback and drift-triggered retraining | [`ch28_program6.py`](ch28_program6.py) | [ch28_program6.txt](expected_output/ch28_program6.txt) | 1 min |
| 7 | 28.7.1 Program 7: Hardening Program 4's Server | An inference endpoint with authentication, rate limiting, a size limit and input validation, tested with real HTTP requests | [`ch28_program7.py`](ch28_program7.py) | [ch28_program7.txt](expected_output/ch28_program7.txt) | 25 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-28-deploying-deep-learning-models
python ch28_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch28_notebook.ipynb`](ch28_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, SciPy, PyTorch, ONNX, ONNX Runtime, Flask, Requests.

## Notes

- Program 1 needs `onnx` and `onnxruntime` (both in `requirements.txt`) and writes the exported model files to a `ch28_artifacts` folder in your system's temporary directory. Its TorchScript file can come out a little larger or smaller than the book's 15.4 KB, because PyTorch stores the program's path inside the file (for its error messages), and that path depends on where you saved the repository.
- Program 2's accuracies and file sizes match the book; its latencies are measured on your computer and will differ. It writes to the same temporary `ch28_artifacts` folder as Program 1.
- Program 3 measures throughput and latency on your computer, so its numbers will differ from the book; the shape of the batching curve is what to compare.
- Programs 4 and 7 start a small web server on your own computer (address 127.0.0.1) and send it real HTTP requests; neither server can be reached from outside your computer. Program 4 uses port 8731 (if something else already uses that port, change `PORT` at the top of the program); Program 7 picks any free port and shuts its server down at the end.
- Program 6 keeps its model registry in a temporary folder that it deletes when it finishes.
