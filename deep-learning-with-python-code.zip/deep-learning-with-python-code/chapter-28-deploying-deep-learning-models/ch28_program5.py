# ch28_program5.py
# A deployed model almost never gets to see labels: nobody hand-labels
# every image a live system receives, so accuracy cannot be computed the
# way it was during training. What CAN be watched, with no labels at all,
# is whether the incoming data still looks like the data the model was
# trained on. This program builds a label-free drift monitor -- a
# per-feature two-sample Kolmogorov-Smirnov test comparing live input
# statistics against a reference window -- and then checks, using labels
# that only this offline demonstration happens to have, whether the
# accuracy actually did degrade when the monitor raised an alarm.

import warnings
import numpy as np
import torch
import torch.nn as nn
from scipy.stats import ks_2samp
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

torch.manual_seed(0)
np.random.seed(0)


class DigitClassifier(nn.Module):
    """Same architecture as Programs 1, 3, and 4."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def make_drifted_batch(X, generator, contrast=0.6, brightness=0.15, noise_std=0.05):
    """Simulates a plausible sensor/preprocessing change -- lower contrast,
    brighter background, more read noise -- the kind of shift a camera or
    scanner replacement could introduce without anyone updating the model."""
    noise = torch.randn(X.shape, generator=generator) * noise_std
    drifted = X * contrast + brightness + noise
    return drifted.clamp(0.0, 1.0)


def ks_drift_report(X_ref, X_current, alpha=0.05):
    """Runs an independent two-sample Kolmogorov-Smirnov test on each pixel
    feature, comparing the reference window to the current window. Returns
    the per-feature KS statistics/p-values and a summary: how many of the
    n_features independent tests were flagged at the alpha level, and what
    fraction that is of the total."""
    n_features = X_ref.shape[1]
    statistics = np.zeros(n_features)
    p_values = np.zeros(n_features)
    for j in range(n_features):
        stat, p = ks_2samp(X_ref[:, j], X_current[:, j])
        statistics[j] = stat
        p_values[j] = p
    flagged = p_values < alpha
    return {
        "statistics": statistics,
        "p_values": p_values,
        "n_flagged": int(flagged.sum()),
        "n_features": n_features,
        "fraction_flagged": float(flagged.sum()) / n_features,
        "mean_ks_statistic": float(statistics.mean()),
    }


def mean_confidence(model, X):
    """Mean top-1 softmax probability -- a label-free signal available at
    serving time, unlike accuracy."""
    with torch.no_grad():
        probs = torch.softmax(model(X), dim=1)
        top1 = probs.max(dim=1).values
    return top1.mean().item()


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    model = DigitClassifier()
    print("Training DigitClassifier for 250 epochs (same setup as Programs 1, 3, and 4)...")
    train_model(model, X_train, y_train, epochs=250)
    model.eval()

    with torch.no_grad():
        clean_acc = (model(X_test).argmax(dim=1) == y_test).float().mean().item()
    print(f"Test accuracy on clean, undrifted data: {clean_acc:.4f}\n")

    # Flatten to (n_samples, 64) pixel features for the per-feature KS test.
    X_train_flat = X_train.squeeze(1).reshape(len(X_train), -1).numpy()
    X_test_flat = X_test.squeeze(1).reshape(len(X_test), -1).numpy()

    gen = torch.Generator().manual_seed(0)
    X_drifted = make_drifted_batch(X_test, gen)
    X_drifted_flat = X_drifted.squeeze(1).reshape(len(X_drifted), -1).numpy()

    print("Monitoring window A: the ACTUAL held-out test set (same distribution as training data).")
    report_a = ks_drift_report(X_train_flat, X_test_flat)
    print(f"  KS test flagged {report_a['n_flagged']} / {report_a['n_features']} pixel features at "
          f"alpha=0.05 ({report_a['fraction_flagged']*100:.1f}%)")
    print(f"  mean KS statistic across all features: {report_a['mean_ks_statistic']:.4f}")
    print(f"  (with 64 independent tests at alpha=0.05, roughly 64*0.05 = 3.2 false positives are")
    print(f"  expected by chance alone, even with zero real drift -- this is the multiple-comparisons")
    print(f"  baseline the drifted window below should clearly exceed)")

    print("\nMonitoring window B: a SYNTHETICALLY DRIFTED copy of the same test set")
    print("(contrast x0.6, brightness +0.15, extra Gaussian noise -- a plausible sensor change):")
    report_b = ks_drift_report(X_train_flat, X_drifted_flat)
    print(f"  KS test flagged {report_b['n_flagged']} / {report_b['n_features']} pixel features at "
          f"alpha=0.05 ({report_b['fraction_flagged']*100:.1f}%)")
    print(f"  mean KS statistic across all features: {report_b['mean_ks_statistic']:.4f}")

    conf_clean = mean_confidence(model, X_test)
    conf_drifted = mean_confidence(model, X_drifted)
    print(f"\nLabel-free confidence signal (mean top-1 softmax probability):")
    print(f"  clean data:   {conf_clean:.4f}")
    print(f"  drifted data: {conf_drifted:.4f}")

    with torch.no_grad():
        drifted_acc = (model(X_drifted).argmax(dim=1) == y_test).float().mean().item()
    print(f"\nGround-truth accuracy on the drifted batch (only available here because this is an")
    print(f"offline demonstration with labels on hand -- a live system would not have this number):")
    print(f"  clean accuracy:   {clean_acc:.4f}")
    print(f"  drifted accuracy: {drifted_acc:.4f}")

    print(f"\nThe two label-free signals and the label-dependent ground truth all agree. The KS test")
    print(f"went from {report_a['n_flagged']} flagged features on undrifted data (comfortably within")
    print(f"the range chance alone produces against a {int(round(report_a['n_features']*0.05))}-feature "
          f"expectation) to {report_b['n_flagged']} on the")
    print(f"drifted batch; mean confidence fell from {conf_clean:.4f} to {conf_drifted:.4f};")
    print(f"and accuracy, which a live deployment could not have computed directly, fell from "
          f"{clean_acc:.4f} to")
    print(f"{drifted_acc:.4f}. In production, only the first two signals are ever available in real")
    print(f"time -- the input-distribution test and the model's own confidence -- and this is exactly")
    print(f"why both are monitored: neither alone is proof of a problem (a confidence drop can come")
    print(f"from genuinely harder examples; a KS flag can come from a benign, harmless change upstream),")
    print(f"but together, and especially when they move in the same direction, they are the closest")
    print(f"a deployed model gets to a warning light before its accuracy is ever directly measured again.")
