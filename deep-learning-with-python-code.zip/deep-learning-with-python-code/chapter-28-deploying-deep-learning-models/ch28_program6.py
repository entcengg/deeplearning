# ch28_program6.py
# After deployment: the model lifecycle in miniature. A file-based model
# registry stores every trained version under a hash of its weights,
# together with where it came from and how it scored. An evaluation gate
# decides whether a candidate may replace the production model. A monitor
# on live traffic can trigger a rollback, which restores the previous
# version exactly, and Program 5's label-free drift test serves as the
# trigger for retraining, which starts the next cycle.

import hashlib
import json
import os
import tempfile
import warnings

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import ks_2samp
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

torch.manual_seed(0)
np.random.seed(0)


class DigitClassifier(nn.Module):
    """Same architecture as Programs 1, 3, 4 and 5."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()
    model.eval()
    return model


def make_drifted_batch(X, generator, contrast=0.6, brightness=0.15, noise_std=0.05):
    """Program 5's simulated sensor change."""
    noise = torch.randn(X.shape, generator=generator) * noise_std
    return (X * contrast + brightness + noise).clamp(0.0, 1.0)


def accuracy(model, X, y):
    with torch.no_grad():
        return (model(X).argmax(dim=1) == y).float().mean().item()


def mean_confidence(model, X):
    with torch.no_grad():
        return torch.softmax(model(X), dim=1).max(dim=1).values.mean().item()


def weights_hash(model):
    """SHA-256 of the raw parameter bytes: the identity of a model version."""
    h = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        h.update(name.encode())
        h.update(tensor.numpy().tobytes())
    return h.hexdigest()[:12]


class Registry:
    """A minimal model registry: one weights file per version, plus a JSON
    index of metadata. Production registries add access control, lineage
    graphs and a user interface, but keep these same core records."""
    def __init__(self, root):
        self.root, self.index = root, []

    def register(self, model, version, parent, data, metrics):
        digest = weights_hash(model)
        torch.save(model.state_dict(), os.path.join(self.root, f"{digest}.pt"))
        self.index.append({"version": version, "sha256": digest, "parent": parent,
                           "data": data, "metrics": metrics, "status": "candidate"})
        self._save()

    def entry(self, version):
        return next(e for e in self.index if e["version"] == version)

    def set_status(self, version, status):
        self.entry(version)["status"] = status
        self._save()

    def load(self, version):
        e = self.entry(version)
        model = DigitClassifier()
        state = torch.load(os.path.join(self.root, f"{e['sha256']}.pt"), weights_only=True)
        model.load_state_dict(state)
        model.eval()
        assert weights_hash(model) == e["sha256"], "registry file does not match its hash"
        return model

    def _save(self):
        with open(os.path.join(self.root, "registry.json"), "w") as f:
            json.dump(self.index, f, indent=1)


def gate(candidate, production, min_accuracy=0.90, tolerance=0.01):
    """Promote only if the candidate reaches min_accuracy on every evaluation
    set, and is no worse than production by more than the tolerance."""
    for name, acc in candidate.items():
        if acc < min_accuracy:
            return False, f"{name} {acc:.4f} is below the {min_accuracy:.2f} minimum"
        if production is not None and acc < production.get(name, 0.0) - tolerance:
            return False, f"{name} {acc:.4f} is worse than production's {production[name]:.4f}"
    return True, "passes every check"


X_train, y_train, X_test, y_test = load_data()
gen = torch.Generator().manual_seed(0)
X_test_drifted = make_drifted_batch(X_test, gen)          # the "after the change" golden set
X_train_flat = X_train.reshape(len(X_train), -1).numpy()  # reference window for drift tests

workdir = tempfile.TemporaryDirectory()
registry = Registry(workdir.name)
production = None

# --- 1. v1: Program 5's model, the first production version ---------------
v1 = train_model(DigitClassifier(), X_train, y_train)
m1 = {"clean": accuracy(v1, X_test, y_test)}
registry.register(v1, "v1", None, "1347 clean images", m1)
ok, why = gate(m1, None)
registry.set_status("v1", "production" if ok else "rejected")
production = "v1"
print(f"v1  {registry.entry('v1')['sha256']}  clean {m1['clean']:.4f}  -> "
      f"{'PROMOTED' if ok else 'REJECTED'} ({why})")

# --- 2. v2: a data-pipeline bug shifts 30% of the labels by one ------------
torch.manual_seed(2)
y_buggy = y_train.clone()
rows = torch.randperm(len(y_buggy))[: int(0.3 * len(y_buggy))]
y_buggy[rows] = (y_buggy[rows] + 1) % 10
v2 = train_model(DigitClassifier(), X_train, y_buggy)
m2 = {"clean": accuracy(v2, X_test, y_test)}
registry.register(v2, "v2", "v1", "30% of labels shifted", m2)
ok, why = gate(m2, registry.entry(production)["metrics"])
registry.set_status("v2", "production" if ok else "rejected")
print(f"v2  {registry.entry('v2')['sha256']}  clean {m2['clean']:.4f}  -> "
      f"{'PROMOTED' if ok else 'REJECTED'} ({why})")

# --- 3. v3: training code stops dividing pixels by 16; serving code doesn't -
torch.manual_seed(3)
v3 = train_model(DigitClassifier(), X_train * 16.0, y_train)
m3 = {"clean": accuracy(v3, X_test * 16.0, y_test)}   # offline check reuses the training code
registry.register(v3, "v3", "v1", "pixels 0-16 in training", m3)
ok, why = gate(m3, registry.entry(production)["metrics"])
if ok:
    registry.set_status(production, "archived")
    registry.set_status("v3", "production")
    production = "v3"
print(f"v3  {registry.entry('v3')['sha256']}  clean {m3['clean']:.4f}  -> "
      f"{'PROMOTED' if ok else 'REJECTED'} ({why})")

# --- Live traffic arrives through the SERVING pipeline (pixels 0-1) --------
baseline_conf = mean_confidence(v1, X_test)          # v1's confidence when it was approved
live = registry.load(production)
window = X_test[:150]
conf = mean_confidence(live, window)
print(f"\nlive window 1 served by {production}: mean confidence {conf:.4f} "
      f"(v1's baseline {baseline_conf:.4f})")
print(f"  accuracy on that window, known only offline: {accuracy(live, window, y_test[:150]):.4f}")
if conf < baseline_conf - 0.15:
    registry.set_status(production, "rolled back")
    registry.set_status("v1", "production")
    production = "v1"
    restored = registry.load("v1")
    with torch.no_grad():
        same = torch.equal(restored(X_test), v1(X_test))
    print(f"  ALARM: confidence more than 0.15 below baseline -> ROLLBACK to v1")
    print(f"  v1 reloaded from the registry: hash verified; identical predictions: {same}")

# --- 4. A retraining trigger: drift in 2 consecutive windows ---------------
print("\nmonitoring v1 on six live windows of 75 images (windows 4-6 after a sensor change)")
print("window  KS-flagged features (of 64)  mean confidence  [accuracy, offline only]")
live = registry.load(production)
streak, triggered_at = 0, None
for w in range(6):
    sl = slice(75 * w, 75 * (w + 1))
    X_w = X_test_drifted[sl] if w >= 3 else X_test[sl]
    X_w_flat = X_w.reshape(len(X_w), -1).numpy()
    flagged = sum(ks_2samp(X_train_flat[:, j], X_w_flat[:, j]).pvalue < 0.05 for j in range(64))
    streak = streak + 1 if flagged > 16 else 0
    note = ""
    if streak == 2 and triggered_at is None:
        triggered_at = w + 1
        note = "  <- RETRAINING TRIGGERED"
    print(f"{w + 1:>6}  {flagged:>27d}  {mean_confidence(live, X_w):>15.4f}"
          f"  [{accuracy(live, X_w, y_test[sl]):.4f}]{note}")

# --- 5. v4: retrained with newly labeled images from the new sensor --------
torch.manual_seed(4)
new_rows = torch.randperm(len(X_train))[:600]                 # 600 images get labeled
X_new = make_drifted_batch(X_train[new_rows], torch.Generator().manual_seed(1))
v4 = DigitClassifier()
v4.load_state_dict(registry.load("v1").state_dict())          # warm start from v1
v4.train()
v4 = train_model(v4, torch.cat([X_train, X_new]), torch.cat([y_train, y_train[new_rows]]),
                 epochs=60)
m4 = {"clean": accuracy(v4, X_test, y_test), "drifted": accuracy(v4, X_test_drifted, y_test)}
registry.entry("v1")["metrics"]["drifted"] = accuracy(v1, X_test_drifted, y_test)
registry.register(v4, "v4", "v1", "clean + 600 new-sensor", m4)
ok, why = gate(m4, registry.entry(production)["metrics"])
if ok:
    registry.set_status(production, "archived")
    registry.set_status("v4", "production")
    production = "v4"
print(f"\nv4  {registry.entry('v4')['sha256']}  clean {m4['clean']:.4f}, drifted "
      f"{m4['drifted']:.4f}  -> {'PROMOTED' if ok else 'REJECTED'} ({why})")

print("\nregistry.json at the end:")
print(f"{'version':<8}{'sha256':<14}{'parent':<8}{'status':<13}"
      f"{'clean':>7}{'drifted':>9}  data")
for e in registry.index:
    d = e["metrics"].get("drifted")
    print(f"{e['version']:<8}{e['sha256']:<14}{str(e['parent']):<8}{e['status']:<13}"
          f"{e['metrics']['clean']:>7.4f}{(f'{d:.4f}' if d is not None else '-'):>9}  {e['data']}")
workdir.cleanup()
