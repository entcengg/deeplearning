# ch28_program2.py
# Dynamic quantization stores a layer's WEIGHTS at int8 precision instead of
# float32, and quantizes each incoming ACTIVATION on the fly, at inference
# time, based on the range actually observed in that batch (hence
# "dynamic" -- nothing about activations is fixed in advance the way
# static/QAT quantization requires). PyTorch's quantize_dynamic targets
# nn.Linear (and recurrent layers); a plain multilayer perceptron, almost
# entirely Linear layers, is exactly the architecture this technique is
# built for, so it is used here instead of Chapter 27's convolutional
# SmallCNN. This program measures the real size, latency, and accuracy
# trade-off rather than assuming what quantization buys.

import os
import tempfile
import time
import warnings
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

torch.manual_seed(0)
np.random.seed(0)

ARTIFACT_DIR = os.path.join(tempfile.gettempdir(), "ch28_artifacts")
os.makedirs(ARTIFACT_DIR, exist_ok=True)


class DigitMLP(nn.Module):
    """64 -> 128 -> 64 -> 10, all Linear+ReLU -- almost entirely the layer
    type dynamic quantization actually targets."""
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(64, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, 10),
        )

    def forward(self, x):
        return self.net(x)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32).reshape(-1, 64)   # flattened, unlike Ch27's (1,8,8)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train), torch.from_numpy(y_train),
            torch.from_numpy(X_test), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=200, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def accuracy(model, X, y):
    with torch.no_grad():
        pred = model(X).argmax(dim=1)
    return (pred == y).float().mean().item()


def file_size_kb(path):
    return os.path.getsize(path) / 1024.0


def time_inference(model, X, batch_size, n_warmup=10, n_trials=7, n_repeats_per_trial=100):
    """Mean per-call latency (ms), estimated as the BEST (minimum) of
    n_trials independent trial blocks, each averaging n_repeats_per_trial
    consecutive forward passes. Averaging within a trial smooths out
    per-call jitter; taking the minimum across trials discards whichever
    trials were slowed by outside interference (a scheduler pre-emption, a
    garbage-collection pause) instead of letting those outliers drag a
    single grand average upward -- the same best-of-N-trials principle
    used for the batching benchmark in Program 3."""
    n = len(X)
    with torch.no_grad():
        for _ in range(n_warmup):                # warm-up, not timed
            model(X[:batch_size])
        best_ms = None
        for _ in range(n_trials):
            start = time.perf_counter()
            for i in range(n_repeats_per_trial):
                batch = X[(i * batch_size) % n:(i * batch_size) % n + batch_size]
                if len(batch) < batch_size:
                    batch = X[:batch_size]
                model(batch)
            elapsed = time.perf_counter() - start
            mean_ms = (elapsed / n_repeats_per_trial) * 1000.0
            if best_ms is None or mean_ms < best_ms:
                best_ms = mean_ms
    return best_ms


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    model = DigitMLP()
    n_params = sum(p.numel() for p in model.parameters())
    print(f"DigitMLP parameters: {n_params} (all in nn.Linear layers)")
    print("Training for 200 epochs, batch_size=32...")
    train_model(model, X_train, y_train, epochs=200)
    model.eval()

    fp32_acc = accuracy(model, X_test, y_test)
    print(f"\nFull-precision (float32) test accuracy: {fp32_acc:.4f}")

    fp32_path = f"{ARTIFACT_DIR}/mlp_fp32_state_dict.pt"
    torch.save(model.state_dict(), fp32_path)

    quantized_model = torch.quantization.quantize_dynamic(
        model, {nn.Linear}, dtype=torch.qint8)
    quantized_model.eval()

    quant_acc = accuracy(quantized_model, X_test, y_test)
    print(f"Dynamically-quantized (int8 weights) test accuracy: {quant_acc:.4f}")

    quant_path = f"{ARTIFACT_DIR}/mlp_quantized_state_dict.pt"
    torch.save(quantized_model.state_dict(), quant_path)

    fp32_kb = file_size_kb(fp32_path)
    quant_kb = file_size_kb(quant_path)
    print(f"\nOn-disk state_dict size: {fp32_kb:.1f} KB (float32) vs. {quant_kb:.1f} KB (quantized)")
    print(f"  size ratio: {fp32_kb / quant_kb:.2f}x smaller")

    print(f"\nMean latency per forward pass (best of 7 trials of 100 calls each, after warm-up):")
    for batch_size in (1, 32):
        fp32_ms = time_inference(model, X_test, batch_size=batch_size)
        quant_ms = time_inference(quantized_model, X_test, batch_size=batch_size)
        speedup = fp32_ms / quant_ms if quant_ms > 0 else float("inf")
        print(f"  batch_size={batch_size:3d}: float32={fp32_ms:.4f} ms  quantized={quant_ms:.4f} ms  "
              f"({speedup:.2f}x)")

    print(f"\nQuantization traded a small, measured amount of accuracy ({fp32_acc:.4f} to {quant_acc:.4f})")
    print(f"for a {fp32_kb / quant_kb:.2f}x smaller on-disk model -- a real, unconditional win, since it")
    print(f"depends only on how many bytes each weight occupies. The latency result is the more honest,")
    print(f"more surprising finding: the quantized model was actually SLOWER here, at both batch sizes")
    print(f"tested, not faster. This is a real, reproducible property of this model and this hardware,")
    print(f"not a bug -- dynamic quantization wraps every Linear layer's matrix multiply in a quantize")
    print(f"step and a dequantize step, and that overhead is only worth paying when the int8 multiply")
    print(f"itself is fast enough, and the matrices large enough, to make up for it. DigitMLP's largest")
    print(f"weight matrix is only 128x64 -- tiny by production standards -- so the fixed per-call")
    print(f"overhead of quantizing and dequantizing dominates over anything gained in the multiply.")
    print(f"Dynamic quantization is documented to help most on larger Linear layers, LSTMs, and")
    print(f"Transformer feedforward blocks on hardware with well-optimized int8 kernels; it is not a")
    print(f"technique to apply and assume a speedup, which is exactly why this program measured actual")
    print(f"latency instead of citing one.")
