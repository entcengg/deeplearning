# ch28_program3.py
# A model that scores one example at a time and a model that scores a
# batch of examples run the exact same arithmetic per example, but rarely
# take the same total time: every forward pass carries a roughly fixed,
# batch-size-independent overhead (Python-to-C++ dispatch, kernel launch,
# memory allocation) on top of the genuinely per-example work. This
# program measures throughput and per-image latency across a sweep of
# batch sizes to find out how much that fixed overhead actually costs when
# it is paid once per image instead of once per batch.

import time
import warnings
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

torch.manual_seed(0)
np.random.seed(0)


class DigitClassifier(nn.Module):
    """Same architecture as Program 1 (and Chapter 27's SmallCNN)."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def benchmark_batch_size(model, X, batch_size, n_warmup_batches=5, n_trials=7):
    """Processes every example in X using the given batch size (the last,
    possibly smaller, batch is included), after a short warm-up. Repeats
    the full pass n_trials times and keeps the MINIMUM elapsed time rather
    than the mean: on a shared machine, measurement noise (a scheduler
    pre-emption, a garbage-collection pause, another process briefly
    grabbing the CPU) can only ever make a trial slower than the model's
    true unloaded cost, never faster, so the minimum across several trials
    is a far more stable estimate of that true cost than any single trial
    or an average that lets the slow outliers pull it upward. Returns
    (best_elapsed_seconds, images_processed)."""
    n = len(X)
    with torch.no_grad():
        for _ in range(n_warmup_batches):          # warm-up, not timed
            model(X[:batch_size])
        best_elapsed = None
        processed = 0
        for _ in range(n_trials):
            start = time.perf_counter()
            processed = 0
            for start_idx in range(0, n, batch_size):
                batch = X[start_idx:start_idx + batch_size]
                model(batch)
                processed += len(batch)
            elapsed = time.perf_counter() - start
            if best_elapsed is None or elapsed < best_elapsed:
                best_elapsed = elapsed
    return best_elapsed, processed


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    model = DigitClassifier()
    print("Training DigitClassifier for 250 epochs (same setup as Program 1)...")
    train_model(model, X_train, y_train, epochs=250)
    model.eval()

    with torch.no_grad():
        test_acc = (model(X_test).argmax(dim=1) == y_test).float().mean().item()
    print(f"Test accuracy: {test_acc:.4f}\n")

    print(f"Scoring all {len(X_test)} test images at each batch size")
    print(f"(5-batch warm-up, then the BEST of 7 timed trials is kept):")
    print(f"{'batch size':>10} {'total time (ms)':>17} {'images/sec':>12} {'ms/image':>10}")

    batch_sizes = [1, 4, 16, 64, 256]
    results = []
    for bs in batch_sizes:
        elapsed, processed = benchmark_batch_size(model, X_test, bs)
        throughput = processed / elapsed
        ms_per_image = (elapsed / processed) * 1000.0
        results.append((bs, elapsed, throughput, ms_per_image))
        print(f"{bs:10d} {elapsed*1000:17.2f} {throughput:12.1f} {ms_per_image:10.4f}")

    single_throughput = results[0][2]
    best_bs, _, best_throughput, _ = max(results, key=lambda r: r[2])
    speedup = best_throughput / single_throughput

    print(f"\nGoing from batch_size=1 (the naive 'score requests one at a time' loop, {single_throughput:.1f}")
    print(f"images/sec) to batch_size={best_bs} ({best_throughput:.1f} images/sec) is a {speedup:.1f}x")
    print(f"throughput gain, on the IDENTICAL model doing the IDENTICAL arithmetic per image -- nothing")
    print(f"about the network changed, only how many images shared one forward-pass call. This is the")
    print(f"single most common mistake in a first deployment script: a loop that calls the model once")
    print(f"per incoming request is paying that fixed per-call overhead every single time, even though")
    print(f"the underlying computation is easily batchable whenever several requests can be grouped")
    print(f"before scoring. A production server almost always trades a small amount of added latency")
    print(f"(waiting briefly to collect a batch) for a large amount of added throughput this way.")
