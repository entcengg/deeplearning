# ch28_program1.py
# A trained nn.Module living inside a Python process is not, by itself, a
# deployment artifact -- it disappears the moment that process exits. This
# program takes a trained classifier through three real, portable export
# formats -- a state_dict checkpoint, TorchScript, and ONNX -- reloads each
# one in a fresh process-like state, and verifies its predictions still
# match the original model's before trusting any of them.

import os
import tempfile
import time
import warnings
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

# torch.jit.trace/load and the legacy torch.onnx.export path print routine
# FutureWarnings about upcoming API changes; harmless here, silenced so the
# printed output below reflects this program's own results.
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

torch.manual_seed(0)
np.random.seed(0)

ARTIFACT_DIR = os.path.join(tempfile.gettempdir(), "ch28_artifacts")
os.makedirs(ARTIFACT_DIR, exist_ok=True)


class DigitClassifier(nn.Module):
    """Same architecture as Chapter 27's SmallCNN, with forward() returning
    only the logits a deployed endpoint actually needs (no feature map)."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc = nn.Linear(16, 10)

    def forward(self, x):
        a1 = self.pool(torch.relu(self.conv1(x)))
        a2 = torch.relu(self.conv2(a1))
        pooled = a2.mean(dim=(2, 3))
        return self.fc(pooled)


def load_data():
    digits = load_digits()
    X = (digits.images / 16.0).astype(np.float32)
    y = digits.target.astype(np.int64)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0, stratify=y)
    return (torch.from_numpy(X_train).unsqueeze(1), torch.from_numpy(y_train),
            torch.from_numpy(X_test).unsqueeze(1), torch.from_numpy(y_test))


def train_model(model, X_train, y_train, epochs=250, batch_size=32, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n_train = len(X_train)
    for epoch in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        for b in range(0, n_train, batch_size):
            idx = perm[b:b + batch_size]
            logits = model(X_train[idx])
            loss = loss_fn(logits, y_train[idx])
            optimizer.zero_grad(); loss.backward(); optimizer.step()


def file_size_kb(path):
    return os.path.getsize(path) / 1024.0


if __name__ == "__main__":
    X_train, y_train, X_test, y_test = load_data()

    model = DigitClassifier()
    print("Training DigitClassifier for 250 epochs (same architecture and data as Chapter 27)...")
    train_model(model, X_train, y_train, epochs=250)
    model.eval()

    with torch.no_grad():
        original_logits = model(X_test)
        original_pred = original_logits.argmax(dim=1)
        original_acc = (original_pred == y_test).float().mean().item()
    print(f"Trained model test accuracy: {original_acc:.4f}\n")

    # --- Format 1: state_dict checkpoint (the recommended default) ---
    state_dict_path = f"{ARTIFACT_DIR}/model_state_dict.pt"
    torch.save(model.state_dict(), state_dict_path)

    reloaded = DigitClassifier()           # a fresh instance, as a new process would create
    reloaded.load_state_dict(torch.load(state_dict_path, weights_only=True))
    reloaded.eval()
    with torch.no_grad():
        reloaded_logits = reloaded(X_test)
    state_dict_max_diff = (reloaded_logits - original_logits).abs().max().item()
    state_dict_pred_match = torch.equal(reloaded_logits.argmax(dim=1), original_pred)
    print(f"Format 1 -- state_dict checkpoint ({file_size_kb(state_dict_path):.1f} KB):")
    print(f"  max logit difference after reload: {state_dict_max_diff:.2e}")
    print(f"  predictions identical to original:  {state_dict_pred_match}")

    # --- Format 2: TorchScript (source-free -- no DigitClassifier class needed to load it) ---
    torchscript_path = f"{ARTIFACT_DIR}/model_torchscript.pt"
    example_input = X_test[0:1]
    traced = torch.jit.trace(model, example_input)
    traced.save(torchscript_path)

    loaded_script = torch.jit.load(torchscript_path)   # loads WITHOUT importing DigitClassifier
    with torch.no_grad():
        script_logits = loaded_script(X_test)
    script_max_diff = (script_logits - original_logits).abs().max().item()
    script_pred_match = torch.equal(script_logits.argmax(dim=1), original_pred)
    print(f"\nFormat 2 -- TorchScript ({file_size_kb(torchscript_path):.1f} KB):")
    print(f"  max logit difference after reload: {script_max_diff:.2e}")
    print(f"  predictions identical to original:  {script_pred_match}")

    # --- Format 3: ONNX (framework-agnostic -- runs outside PyTorch entirely) ---
    onnx_path = f"{ARTIFACT_DIR}/model.onnx"
    torch.onnx.export(
        model, example_input, onnx_path, dynamo=False,
        input_names=["pixels"], output_names=["logits"],
        dynamic_axes={"pixels": {0: "batch"}, "logits": {0: "batch"}},
        opset_version=17,
    )

    import onnxruntime as ort
    session = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
    onnx_logits_np = session.run(["logits"], {"pixels": X_test.numpy()})[0]
    onnx_max_diff = np.abs(onnx_logits_np - original_logits.numpy()).max()
    onnx_pred_match = bool((onnx_logits_np.argmax(axis=1) == original_pred.numpy()).all())
    print(f"\nFormat 3 -- ONNX, run through onnxruntime, NOT PyTorch ({file_size_kb(onnx_path):.1f} KB):")
    print(f"  max logit difference vs. original: {onnx_max_diff:.2e}")
    print(f"  predictions identical to original:  {onnx_pred_match}")

    print(f"\nAll three formats reproduce the original model's predictions exactly, but they solve")
    print(f"different problems. The state_dict checkpoint is the smallest and the standard choice")
    print(f"for continued training or evaluation inside this same PyTorch codebase, but loading it")
    print(f"still requires the DigitClassifier class definition to exist wherever it is loaded.")
    print(f"TorchScript packages the computation graph itself, so `torch.jit.load` above never")
    print(f"imported DigitClassifier at all -- useful for shipping to a C++ or mobile runtime with")
    print(f"no Python class available. ONNX goes one step further: onnxruntime above never imported")
    print(f"torch itself, only onnxruntime, making it the right choice when the serving environment")
    print(f"may not run PyTorch at all (a different framework, a specialized inference accelerator).")
    print(f"The tiny nonzero logit differences above ({state_dict_max_diff:.1e}, {script_max_diff:.1e},")
    print(f"{onnx_max_diff:.1e}) are ordinary floating-point rounding from re-running the same")
    print(f"arithmetic through different code paths, not a sign that anything is actually wrong --")
    print(f"every one of the three predicted classes matches the original exactly.")
