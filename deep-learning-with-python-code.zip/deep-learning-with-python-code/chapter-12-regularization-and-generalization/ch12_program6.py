# ch12_program6.py
# Data augmentation, in three experiments on Program 1's data (15 noisy points
# from sin(x), fitted by a degree-12 polynomial).
#   Part A: for a LINEAR model, averaging the squared error over small Gaussian
#           jitters of the input is exactly an L2 penalty on the weight.
#   Part B: jitter-augmenting the 15 points (labels simply copied) tames the
#           degree-12 fit; too much jitter spoils it.
#   Part C: a mirror image x -> -x is a legitimate augmentation only if the
#           label is transformed the way the task demands (sin is odd, so
#           y -> -y); copying y unchanged teaches the model a false rule.

import numpy as np

rng = np.random.default_rng(0)
m = 15
x = np.sort(rng.uniform(-3, 3, m))
y = np.sin(x) + rng.normal(0, 0.2, m)
rng_val = np.random.default_rng(1)
x_val = np.sort(rng_val.uniform(-3, 3, 15))
y_val = np.sin(x_val) + rng_val.normal(0, 0.2, 15)

# ---- Part A: jitter on a linear model is an L2 penalty ----------------------
w, x0, y0, s = 2.0, 1.0, 1.5, 0.1
loss_plain = (y0 - w * x0) ** 2
penalty = s ** 2 * w ** 2
delta = np.random.default_rng(5).normal(0, s, 1_000_000)
loss_jitter = np.mean((y0 - w * (x0 + delta)) ** 2)
print("Part A: x=1, y=1.5, model w*x with w=2, jitter std s=0.1")
print(f"  loss without jitter              : {loss_plain:.4f}")
print(f"  penalty s^2 * w^2                : {penalty:.4f}")
print(f"  hand total                       : {loss_plain + penalty:.4f}")
print(f"  mean over 1,000,000 jittered x's : {loss_jitter:.4f}")

# ---- Part B: jitter augmentation of the degree-12 polynomial ----------------
def poly_features(xx, degree):
    return np.vstack([xx ** d for d in range(degree + 1)]).T

def fit(xx, yy, degree=12):
    return np.linalg.lstsq(poly_features(xx, degree), yy, rcond=None)[0]

def mse(w, xx, yy):
    return np.mean((yy - poly_features(xx, len(w) - 1) @ w) ** 2)

def jitter_augment(k, s, seed):
    """The 15 originals plus k jittered copies of each; labels are copied."""
    r = np.random.default_rng(seed)
    xs = [x] + [x + r.normal(0, s, m) for _ in range(k)]
    return np.concatenate(xs), np.tile(y, k + 1)

def jitter_summary(k, s, n_seeds=30):
    rows = []
    for seed in range(n_seeds):
        w = fit(*jitter_augment(k, s, seed))
        rows.append((mse(w, x, y), mse(w, x_val, y_val), np.abs(w).max()))
    rows = np.array(rows)
    med = np.median(rows, axis=0)
    return med[0], med[1], rows[:, 1].max(), med[2]

def show(label, train, val, worst, wmax):
    print(f"{label:>12}{train:>11.5f}{val:>11.5f}{worst:>11.5f}{wmax:>11.3f}")

head = f"{'':>12}{'train MSE':>11}{'val MSE':>11}{'worst val':>11}{'max|w|':>11}"
w0 = fit(x, y)
print("\nPart B: medians over 30 jitter seeds (train MSE: the original 15 points)")
print("jitter s = 0.1, k copies of each point:")
print(head)
show("no augment.", mse(w0, x, y), mse(w0, x_val, y_val), mse(w0, x_val, y_val),
     np.abs(w0).max())
for k in [1, 5, 20, 100]:
    show(f"k = {k}", *jitter_summary(k, 0.1))
print("k = 100 copies, jitter std s varies:")
print(head)
for s in [0.05, 0.1, 0.2, 0.5, 1.0, 2.0]:
    show(f"s = {s}", *jitter_summary(100, s))
print(f"(predicting y = 0 everywhere has val MSE {np.mean(y_val ** 2):.5f})")

# ---- Part C: mirror augmentation, with the right and the wrong label --------
print("\nPart C: add the mirror image of every point, x -> -x")
print(f"{'':>26} {'n':>3} {'train MSE':>10} {'val MSE':>10} {'max|w|':>9}")
x_mirror = np.concatenate([x, -x])
cases = [("no augmentation", x, y),
         ("mirror, y -> -y (right)", x_mirror, np.concatenate([y, -y])),
         ("mirror, y kept (wrong)", x_mirror, np.concatenate([y, y]))]
for name, xa, ya in cases:
    w = fit(xa, ya)
    tr, va = mse(w, x, y), mse(w, x_val, y_val)
    print(f"{name:>26} {len(xa):>3} {tr:>10.5f} {va:>10.5f} {np.abs(w).max():>9.3f}")
