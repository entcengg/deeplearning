# ch12_program1.py
# Fitting polynomials of increasing degree to a small noisy dataset:
# underfitting, a good fit, and dramatic overfitting.

import numpy as np

rng = np.random.default_rng(0)
m = 15
x = np.sort(rng.uniform(-3, 3, m))
y = np.sin(x) + rng.normal(0, 0.2, m)          # true relationship: sin(x) + noise

rng_val = np.random.default_rng(1)
m_val = 15
x_val = np.sort(rng_val.uniform(-3, 3, m_val))
y_val = np.sin(x_val) + rng_val.normal(0, 0.2, m_val)

def poly_features(xx, degree):
    return np.vstack([xx ** d for d in range(degree + 1)]).T

def fit(degree):
    X = poly_features(x, degree)
    return np.linalg.lstsq(X, y, rcond=None)[0]     # ordinary least squares

def mse(w, xx, yy):
    degree = len(w) - 1
    pred = poly_features(xx, degree) @ w
    return np.mean((yy - pred) ** 2)

print(f"{'degree':>6} {'train MSE':>12} {'val MSE':>12} {'max|weight|':>12}")
for degree in [1, 2, 3, 5, 7, 9, 12]:
    w = fit(degree)
    train_e = mse(w, x, y)
    val_e = mse(w, x_val, y_val)
    print(f"{degree:>6} {train_e:>12.5f} {val_e:>12.5f} {np.max(np.abs(w)):>12.2f}")
