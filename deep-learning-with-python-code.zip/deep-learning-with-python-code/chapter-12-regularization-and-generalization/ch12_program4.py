# ch12_program4.py
# Inverted dropout: randomly zero out units during training, scale the
# survivors up so the expected activation is unchanged.

import numpy as np

rng = np.random.default_rng(0)
a = np.array([1.0, 2.0, 3.0, 4.0, 5.0])     # a layer's activations
p_drop = 0.4                                 # drop 40% of units

mask = (rng.uniform(size=a.shape) > p_drop).astype(float)
a_dropped = a * mask / (1 - p_drop)          # inverted dropout: scale UP survivors
print("original activations :", a)
print("dropout mask (this draw):", mask)
print("after inverted dropout:", np.round(a_dropped, 4))

# Confirm the scaling makes dropout unbiased: average many independent draws.
totals = []
for _ in range(200_000):
    mask = (rng.uniform(size=a.shape) > p_drop).astype(float)
    totals.append(a * mask / (1 - p_drop))
average = np.mean(totals, axis=0)
print("\naverage activation over 200,000 draws:", np.round(average, 3))
print("(should match the original activations closely -- this is why no")
print("rescaling is needed at test time, when dropout is simply turned off)")
