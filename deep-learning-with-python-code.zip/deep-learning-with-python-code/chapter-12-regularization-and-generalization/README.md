# Chapter 12 · Regularization and Generalization

Code for Chapter 12 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 11](../chapter-11-gradient-descent-and-optimizers/README.md) · [Chapter 13 →](../chapter-13-building-networks-with-pytorch-and-keras/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 12.1 Underfitting and Overfitting | Polynomials of increasing degree, fit to the same small dataset | [`ch12_program1.py`](ch12_program1.py) | [ch12_program1.txt](expected_output/ch12_program1.txt) | < 1 s |
| 2 | 12.3.1 Program 2: Weight Decay, Verified, Then Applied | The L2 gradient and its weight-decay form, then a regularization sweep on the degree-12 polynomial | [`ch12_program2.py`](ch12_program2.py) | [ch12_program2.txt](expected_output/ch12_program2.txt) | < 1 s |
| 3 | 12.4.1 Program 3: Sparsity, Directly Observed | L1 versus L2 on the same polynomial features | [`ch12_program3.py`](ch12_program3.py) | [ch12_program3.txt](expected_output/ch12_program3.txt) | < 1 s |
| 4 | 12.5.1 Program 4: Inverted Dropout | Inverted dropout and a check that it is unbiased | [`ch12_program4.py`](ch12_program4.py) | [ch12_program4.txt](expected_output/ch12_program4.txt) | 1 s |
| 5 | 12.7.1 Program 5: Learning Curves for Three Capacities | Training and validation error during gradient descent for an underfit, a well-fit and an overfit polynomial | [`ch12_program5.py`](ch12_program5.py) | [ch12_program5.txt](expected_output/ch12_program5.txt) | 14 s |
| 6 | 12.8.1 Program 6: Augmentation That Helps, and Augmentation That Lies | Jitter and mirror augmentation of Program 1's fifteen points, with the label handled correctly and incorrectly | [`ch12_program6.py`](ch12_program6.py) | [ch12_program6.txt](expected_output/ch12_program6.txt) | < 1 s |
| 7 | 12.9.1 Program 7: The Decomposition, Measured | Bias, variance and noise measured over 2000 training sets, across polynomial degree and L2 strength | [`ch12_program7.py`](ch12_program7.py) | [ch12_program7.txt](expected_output/ch12_program7.txt) | 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-12-regularization-and-generalization
python ch12_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch12_notebook.ipynb`](ch12_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.
