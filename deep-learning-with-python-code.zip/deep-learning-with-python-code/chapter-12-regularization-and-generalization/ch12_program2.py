# ch12_program2.py
# L2 regularization: the gradient, its weight-decay interpretation, and
# a sweep of lambda taming the degree-12 polynomial's overfitting.

import numpy as np

# --- Part 1: verify the L2 gradient and the weight-decay update by hand ---
X = np.array([[1.0, 2.0], [2.0, 1.0], [3.0, 4.0]])
y_small = np.array([5.0, 4.0, 11.0])
w = np.array([0.5, -0.3])
lam = 0.1
eta = 0.1

pred = X @ w
grad_mse = (2 / len(y_small)) * X.T @ (pred - y_small)
grad_l2 = grad_mse + 2 * lam * w             # d/dw[lambda * sum(w^2)] = 2*lambda*w
print("grad of MSE alone      :", grad_mse)
print("grad of MSE + L2 penalty:", grad_l2)

w_direct = w - eta * grad_l2
w_decay = w * (1 - 2 * eta * lam) - eta * grad_mse    # the "weight decay" form
print("update (direct)  :", w_direct)
print("update (decay form):", w_decay, " -- identical")

# --- Part 2: ridge regression on the degree-12 polynomial ---
rng = np.random.default_rng(0)
m = 15
x = np.sort(rng.uniform(-3, 3, m))
y = np.sin(x) + rng.normal(0, 0.2, m)
rng_val = np.random.default_rng(1)
x_val = np.sort(rng_val.uniform(-3, 3, 15))
y_val = np.sin(x_val) + rng_val.normal(0, 0.2, 15)

def poly_features(xx, degree):
    return np.vstack([xx ** d for d in range(degree + 1)]).T

degree = 12
Xp = poly_features(x, degree)
Xvp = poly_features(x_val, degree)

def fit_ridge(lam):
    n = Xp.shape[1]
    reg = lam * np.eye(n)
    reg[0, 0] = 0                             # never regularize the bias term
    return np.linalg.solve(Xp.T @ Xp + reg, Xp.T @ y)

print(f"\n{'lambda':>10} {'train MSE':>12} {'val MSE':>12} {'max|weight|':>12}")
for lam in [0, 1e-6, 1e-4, 0.01, 1, 100]:
    w = fit_ridge(lam)
    train_e = np.mean((y - Xp @ w) ** 2)
    val_e = np.mean((y_val - Xvp @ w) ** 2)
    print(f"{lam:>10} {train_e:>12.5f} {val_e:>12.5f} {np.max(np.abs(w)):>12.3f}")
