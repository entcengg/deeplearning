# ch12_program5.py
# Training and validation curves, iteration by iteration, for three model
# capacities fit to Program 1's data by plain gradient descent: a line
# (underfits), a degree-5 polynomial (fits well) and a degree-12 polynomial
# (overfits). Each polynomial is written in the Legendre basis, which spans
# exactly the same functions as 1, x, ..., x^d but is far better conditioned,
# so gradient descent is fast enough to watch the whole story unfold.

import numpy as np
from numpy.polynomial import legendre

rng = np.random.default_rng(0)
m = 15
x = np.sort(rng.uniform(-3, 3, m))
y = np.sin(x) + rng.normal(0, 0.2, m)

rng_val = np.random.default_rng(1)
x_val = np.sort(rng_val.uniform(-3, 3, 15))
y_val = np.sin(x_val) + rng_val.normal(0, 0.2, 15)

def features(xx, degree):
    # columns P_0(x/3), ..., P_degree(x/3): Legendre polynomials of x/3
    return legendre.legvander(xx / 3, degree)

def mse(X, w, target):
    return np.mean((target - X @ w) ** 2)

CHECKPOINTS = set(np.unique(np.round(np.logspace(0, 6, 121)).astype(int)).tolist())

def gradient_descent(degree, iters=1_000_000):
    X, Xv = features(x, degree), features(x_val, degree)
    L = np.linalg.eigvalsh((2 / m) * X.T @ X).max()   # curvature of the training MSE
    eta = 1 / L                                       # any step below 2/L is stable
    w = np.zeros(degree + 1)
    history = []                                      # rows: iteration, train, val
    for it in range(1, iters + 1):
        w -= eta * (2 / m) * X.T @ (X @ w - y)
        if it in CHECKPOINTS:
            history.append((it, mse(X, w, y), mse(Xv, w, y_val)))
    return np.array(history), eta

curves = {d: gradient_descent(d) for d in (1, 5, 12)}

print("training and validation MSE during gradient descent")
print(f"{'':>10} |{'degree 1':^20}|{'degree 5':^20}|{'degree 12':^20}|")
print(f"{'iteration':>10} |" + f"{'train':>10}{'val':>10}|" * 3)
for it in [1, 10, 100, 1000, 10**4, 10**5, 10**6]:
    cells = ""
    for d in curves:
        row = curves[d][0][curves[d][0][:, 0] == it][0]
        cells += f"{row[1]:>10.5f}{row[2]:>10.5f}|"
    print(f"{it:>10} |" + cells)

print()
for d, (hist, eta) in curves.items():
    best = np.argmin(hist[:, 2])
    print(f"degree {d:>2}: step size {eta:.4f}, lowest val MSE {hist[best, 2]:.5f} "
          f"at iteration {int(hist[best, 0])}")
hist12 = curves[12][0]
print(f"degree 12: val MSE after 10^6 iterations / lowest val MSE = "
      f"{hist12[-1, 2] / hist12[:, 2].min():.0f}")

# The limit gradient descent is heading for: the exact least-squares solution.
print()
for d in curves:
    X, Xv = features(x, d), features(x_val, d)
    w = np.linalg.lstsq(X, y, rcond=None)[0]
    print(f"degree {d:>2} least squares (Program 1): "
          f"train {mse(X, w, y):.5f}, val {mse(Xv, w, y_val):.5f}")
