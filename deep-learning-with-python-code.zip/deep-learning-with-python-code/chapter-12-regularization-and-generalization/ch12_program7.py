# ch12_program7.py
# The bias-variance decomposition, measured. We know the truth f(x) = sin(x)
# and the noise level sigma = 0.2, so we can draw thousands of fresh training
# sets and see how the fitted curves behave on average (bias) and how much
# they swing from one training set to the next (variance).
#   Part A: the identity on a hand-sized example.
#   Part B: polynomial degree sweep (the U-curve of Program 1, explained).
#   Part C: an L2 penalty on the degree-12 polynomial (Program 2, explained).
#   Part D: what changes if the 15 input locations are redrawn every time.

import numpy as np

sigma = 0.2
f = np.sin

# ---- Part A: the identity, on four hypothetical training sets ---------------
x0 = 1.0
fits = np.array([0.60, 0.70, 0.80, 0.90])        # f_hat(x0) from four training sets
bias2 = (fits.mean() - f(x0)) ** 2
variance = fits.var()                            # mean squared deviation from the mean
rng_a = np.random.default_rng(3)
y_new = f(x0) + rng_a.normal(0, sigma, (1_000_000, len(fits)))   # fresh noisy targets
measured = np.mean((y_new - fits) ** 2)
print(f"Part A: f(x0) = sin(1) = {f(x0):.4f}, sigma^2 = {sigma ** 2:.2f}, "
      f"mean fit = {fits.mean():.4f}")
print(f"  bias^2 = {bias2:.5f}   variance = {variance:.5f}   noise = {sigma ** 2:.5f}")
print(f"  sum = {bias2 + variance + sigma ** 2:.5f}   "
      f"measured mean squared error = {measured:.5f}")

# ---- Parts B and C: fresh training sets, same 15 evenly spaced inputs ------
m, T = 15, 2000                                  # points per set, number of sets
x_train = np.linspace(-3, 3, m)
x_test = np.linspace(-3, 3, 121)
rng = np.random.default_rng(0)
Y = f(x_train)[:, None] + rng.normal(0, sigma, (m, T))          # column t = set t
Y_new = f(x_test)[:, None] + rng.normal(0, sigma, (len(x_test), T))

def design(xx, degree):
    return np.vstack([xx ** d for d in range(degree + 1)]).T

def decompose(degree, lam=0.0):
    X = design(x_train, degree)
    # ridge as least squares on [X; sqrt(lam)*I] (bias term unpenalised, as in Program 2)
    X_aug = np.vstack([X, np.sqrt(lam) * np.eye(degree + 1)[1:]])
    Y_aug = np.vstack([Y, np.zeros((degree, T))])
    W = np.linalg.lstsq(X_aug, Y_aug, rcond=None)[0]            # one fit per set
    P = design(x_test, degree) @ W                              # predictions, 121 x T
    bias2 = np.mean((P.mean(axis=1) - f(x_test)) ** 2)
    variance = np.mean(P.var(axis=1))
    measured = np.mean((Y_new - P) ** 2)                        # directly measured test MSE
    return bias2, variance, measured

def show(label, bias2, variance, measured):
    print(f"{label:>8}{bias2:>11.5f}{variance:>11.5f}{sigma ** 2:>11.5f}"
          f"{bias2 + variance + sigma ** 2:>11.5f}{measured:>11.5f}")

head = (f"{'':>8}{'bias^2':>11}{'variance':>11}"
        f"{'noise':>11}{'sum':>11}{'measured':>11}")
print(f"\nPart B: polynomial degree, {T} training sets of {m} evenly spaced points")
print(head.replace("      ", "degree", 1))
for degree in [1, 2, 3, 5, 7, 9, 12]:
    show(degree, *decompose(degree))

print("\nPart C: degree 12 with an L2 penalty lambda (Program 2's values)")
print(head.replace("      ", "lambda", 1))
for lam in [0, 1e-6, 1e-4, 0.01, 1, 100]:
    show(lam, *decompose(12, lam))

# ---- Part D: redraw the 15 input locations too (Program 1's situation) -----
print("\nPart D: x redrawn every time; test MSE of each fitted polynomial")
print(f"{'degree':>8}{'median':>12}{'mean':>12}{'share > 1':>12}")
rng_d = np.random.default_rng(1)
for degree in [3, 5, 12]:
    errs = []
    for _ in range(T):
        xt = np.sort(rng_d.uniform(-3, 3, m))
        yt = f(xt) + rng_d.normal(0, sigma, m)
        w = np.linalg.lstsq(design(xt, degree), yt, rcond=None)[0]
        y_star = f(x_test) + rng_d.normal(0, sigma, len(x_test))
        errs.append(np.mean((y_star - design(x_test, degree) @ w) ** 2))
    errs = np.array(errs)
    print(f"{degree:>8}{np.median(errs):>12.4g}{errs.mean():>12.4g}{np.mean(errs > 1):>12.3f}")
