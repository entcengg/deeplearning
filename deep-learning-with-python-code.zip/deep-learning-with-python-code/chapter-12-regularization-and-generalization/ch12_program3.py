# ch12_program3.py
# L1 versus L2 regularization: both shrink weights, but only L1 drives
# many of them to exactly (or very nearly) zero.

import numpy as np

rng = np.random.default_rng(0)
m = 15
x = np.sort(rng.uniform(-3, 3, m))
y = np.sin(x) + rng.normal(0, 0.2, m)

def poly_features_normalized(xx, degree):
    X = np.vstack([xx ** d for d in range(degree + 1)]).T
    scales = np.max(np.abs(X[:, 1:]), axis=0)
    Xn = X.copy(); Xn[:, 1:] /= scales
    return Xn

degree = 12
Xn = poly_features_normalized(x, degree)

def train_l2(lam, epochs=5000, eta=0.1):
    n = Xn.shape[1]; w = np.zeros(n)
    for _ in range(epochs):
        grad = (2 / len(y)) * Xn.T @ (Xn @ w - y)
        grad[1:] += 2 * lam * w[1:]
        w -= eta * grad
    return w

def train_l1(lam, epochs=5000, eta=0.1):
    n = Xn.shape[1]; w = np.zeros(n)
    for _ in range(epochs):
        grad = (2 / len(y)) * Xn.T @ (Xn @ w - y)
        grad[1:] += lam * np.sign(w[1:])       # subgradient of |w|
        w -= eta * grad
    return w

w_l2 = train_l2(lam=0.05)
w_l1 = train_l1(lam=0.05)

print("L2 weights:", np.round(w_l2, 4))
print("L1 weights:", np.round(w_l1, 4))
print(f"\nL2 coefficients with |w| < 0.01: {np.sum(np.abs(w_l2) < 0.01)} of {len(w_l2)}")
print(f"L1 coefficients with |w| < 0.01: {np.sum(np.abs(w_l1) < 0.01)} of {len(w_l1)}")
