#!/usr/bin/env python3
"""Run the book's programs and compare what each one prints with the
expected output stored in its folder's expected_output/.

Usage, from the top folder of the repository:

    python tools/check_outputs.py chapter-05-the-artificial-neuron
    python tools/check_outputs.py chapter-05-the-artificial-neuron/ch05_program2.py
    python tools/check_outputs.py chapter-05-the-artificial-neuron chapter-06-the-perceptron
    python tools/check_outputs.py                  # every chapter and appendix

and from inside a chapter folder:

    python ../tools/check_outputs.py .

Each program runs with the same Python that runs this script, from inside its
own folder, exactly as the chapter READMEs describe. Verdicts:

    MATCH      identical to the expected output
    CLOSE      the same text, with numbers that differ by less than 1% (other
               library versions or processors can change the last digits)
    DIFFERENT  anything else; use --diff to see the differing lines
    ERROR      the program stopped with an error (see its last lines)

A few programs cannot match exactly, by design (they print timings, installed
versions or unseeded random numbers); their verdict carries the reason.

For the authors: after changing a program, --update rewrites its expected
output from a fresh run instead of comparing.
"""
import argparse
import difflib
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INDEX = json.load(open(os.path.join(ROOT, "tools", "programs.json"), encoding="utf-8"))["programs"]
NUMBER = re.compile(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?")


def normalise(text):
    lines = [line.rstrip() for line in text.replace("\r\n", "\n").split("\n")]
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()
    return lines


def numbers_close(expected, actual, rel=0.01, abs_tol=1e-9):
    """True if the two outputs differ only in numbers, each within rel."""
    if len(expected) != len(actual):
        return False
    for a, b in zip(expected, actual):
        if NUMBER.sub("#", a) != NUMBER.sub("#", b):
            return False
        for x, y in zip(NUMBER.findall(a), NUMBER.findall(b)):
            x, y = float(x), float(y)
            if abs(x - y) > max(abs_tol, rel * max(abs(x), abs(y))):
                return False
    return True


def select(targets):
    """Programs named by the command-line targets (folders or files)."""
    if not targets:
        return list(INDEX)
    chosen = []
    for t in targets:
        path = os.path.abspath(t)
        rel = os.path.relpath(path, ROOT).replace(os.sep, "/")
        if rel == ".":
            return list(INDEX)
        hits = [p for p in INDEX if rel in (p["folder"], p["folder"] + "/" + p["file"])]
        if not hits:
            sys.exit(f"no program found for {t!r}: give a chapter folder or a program file")
        chosen += [p for p in hits if p not in chosen]
    return chosen


def run(p, timeout):
    folder = os.path.join(ROOT, p["folder"])
    start = time.time()
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    try:
        proc = subprocess.run([sys.executable, p["file"]], cwd=folder, capture_output=True,
                              text=True, encoding="utf-8", errors="replace", timeout=timeout,
                              env=env)
    except subprocess.TimeoutExpired:
        return None, "", f"stopped after {timeout} s", time.time() - start
    return proc.returncode, proc.stdout, proc.stderr, time.time() - start


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("targets", nargs="*", help="chapter folders or program files (default: all)")
    ap.add_argument("--diff", action="store_true", help="show the differing lines")
    ap.add_argument("--timeout", type=int, default=3600, help="seconds allowed per program")
    ap.add_argument("--update", action="store_true",
                    help="write each program's output to its expected_output file instead of comparing")
    args = ap.parse_args()

    programs = [p for p in select(args.targets) if p["file"].endswith(".py")]
    counts = {}
    print(f"Checking {len(programs)} program(s) with Python {sys.version.split()[0]}\n")
    for p in programs:
        expected_path = os.path.join(ROOT, p["folder"], "expected_output",
                                     os.path.splitext(p["file"])[0] + ".txt")
        expected = (normalise(open(expected_path, encoding="utf-8").read())
                    if os.path.exists(expected_path) else [])
        rc, out, err, secs = run(p, args.timeout)
        if p["file"] == "broken.py":           # this one is meant to fail
            out = re.sub(r'File "[^"]*broken\.py"', 'File "broken.py"', err)
            rc = 0 if "ModuleNotFoundError" in err else rc
        actual = normalise(out)
        if args.update and rc == 0:
            with open(expected_path, "w", encoding="utf-8", newline="\n") as fh:
                fh.write("\n".join(actual) + "\n")
            counts["UPDATED"] = counts.get("UPDATED", 0) + 1
            print(f"UPDATED    {p['folder']}/{p['file']}  [{secs:.0f} s]")
            continue
        if rc != 0:
            verdict = "ERROR"
        elif actual == expected:
            verdict = "MATCH"
        elif numbers_close(expected, actual):
            verdict = "CLOSE"
        else:
            verdict = "DIFFERENT"
        counts[verdict] = counts.get(verdict, 0) + 1
        why = f"  (expected: {p['varies']})" if p.get("varies") and verdict in ("CLOSE", "DIFFERENT") else ""
        print(f"{verdict:<10} {p['folder']}/{p['file']}  [{secs:.0f} s]{why}")
        if verdict == "ERROR":
            tail = (err or "").strip().splitlines()[-5:]
            print("           " + "\n           ".join(tail))
        elif verdict != "MATCH" and args.diff:
            for line in list(difflib.unified_diff(expected, actual, "expected", "yours",
                                                  lineterm="", n=0))[2:42]:
                print("           " + line)
    print("\n" + ", ".join(f"{v} {k}" for k, v in sorted(counts.items())))
    sys.exit(1 if counts.get("ERROR") else 0)


if __name__ == "__main__":
    main()
