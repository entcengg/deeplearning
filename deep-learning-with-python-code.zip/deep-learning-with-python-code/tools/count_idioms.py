#!/usr/bin/env python3
"""Count how many of the book's chapter programs use each Python, NumPy and
PyTorch idiom tabulated in Appendices A, B and C.

    python tools/count_idioms.py

Only the programs of Chapters 1-28 are counted (the files named
chNN_programM.py; not broken.py or the appendix files). Comments and string
literals are blanked out before searching, so an idiom that is only
mentioned, never used, does not count. Most rows count files; the
comprehension row and the loss table count occurrences.
"""
import ast
import glob
import io
import os
import re
import sys
import tokenize

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def code_only(src):
    """The source with every comment and string literal replaced by spaces."""
    rows = [list(line) for line in src.split("\n")]
    blank = {tokenize.COMMENT, tokenize.STRING}
    for name in ("FSTRING_START", "FSTRING_MIDDLE", "FSTRING_END"):
        if hasattr(tokenize, name):
            blank.add(getattr(tokenize, name))
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type not in blank:
            continue
        (r0, c0), (r1, c1) = tok.start, tok.end
        for r in range(r0 - 1, r1):
            a = c0 if r == r0 - 1 else 0
            b = c1 if r == r1 - 1 else len(rows[r])
            for c in range(a, b):
                rows[r][c] = " "
    return "\n".join("".join(row) for row in rows)


def text(pattern):
    """Files whose code (comments and strings removed) matches a regex."""
    rx = re.compile(pattern, re.M)
    return lambda code, tree: bool(rx.search(code))


def node(test):
    """Files containing a syntax-tree node that passes the test."""
    return lambda code, tree: any(test(n) for n in ast.walk(tree))


def mutable_default(n):
    return isinstance(n, (ast.FunctionDef, ast.Lambda)) and any(
        isinstance(d, (ast.List, ast.Dict, ast.Set)) for d in n.args.defaults + n.args.kw_defaults if d)


LOSSES = ["MSELoss", "CrossEntropyLoss", "BCELoss", "BCEWithLogitsLoss"]

TABLES = {
    "Appendix A (Python)": [
        ("with torch.no_grad():", text(r"with torch\.no_grad\(\):")),
        ("class ...(nn.Module)", text(r"class \w+\(nn\.Module\)")),
        ("any class definition", node(lambda n: isinstance(n, ast.ClassDef))),
        ("bare multi-value return a, b, ...", text(r"^\s*return \w+(, \w+)+\s*$")),
        ("enumerate(...)", text(r"\benumerate\(")),
        ("zip(...)", text(r"\bzip\(")),
        ("lambda", node(lambda n: isinstance(n, ast.Lambda))),
        ("try/except", node(lambda n: isinstance(n, ast.Try))),
        ("mutable default argument", node(mutable_default)),
    ],
    "Appendix B (NumPy)": [
        ("np.array(...)", text(r"np\.array\(")),
        ("@ (matrix multiply)", node(lambda n: isinstance(n, ast.BinOp) and isinstance(n.op, ast.MatMult))),
        ("np.zeros/ones/eye", text(r"np\.(zeros|ones|eye)\(")),
        (".reshape(...)", text(r"\.reshape\(")),
        ("concatenate/stack/vstack/hstack", text(r"np\.(concatenate|stack|vstack|hstack)\(")),
        ("np.random.seed(...)", text(r"np\.random\.seed\(")),
        ("np.random.default_rng(...)", text(r"np\.random\.default_rng\(")),
        (".T / np.transpose(...)", text(r"\.T\b|np\.transpose\(")),
        ("axis=... keyword", text(r"\baxis=")),
        ("np.linalg.*", text(r"np\.linalg\.")),
        ("np.dot(...)", text(r"np\.dot\(")),
        ("np.newaxis", text(r"np\.newaxis")),
        ("np.save/np.load (plain array)", text(r"np\.(save|load)\(")),
    ],
    "Appendix C (PyTorch)": [
        ("torch.manual_seed(...)", text(r"torch\.manual_seed\(")),
        (".backward()", text(r"\.backward\(\)")),
        ("optimizer.zero_grad()", text(r"\.zero_grad\(\)")),
        ("optim.Adam(...)", text(r"optim\.Adam\(")),
        ("nn.Linear(...)", text(r"nn\.Linear\(")),
        ("a loss from the loss table", text(r"nn\.(" + "|".join(LOSSES) + r")\(")),
        (".eval() / .train()", text(r"\.(eval|train)\(\)")),
        ("nn.Conv2d(...)", text(r"nn\.Conv2d\(")),
        ("nn.MaxPool2d(...)", text(r"nn\.MaxPool2d\(")),
        ("requires_grad=True / .requires_grad_()", text(r"requires_grad=True|\.requires_grad_\(")),
        ("nn.LSTM/GRU/RNN(...)", text(r"nn\.(LSTM|GRU|RNN)\(")),
        (".state_dict()", text(r"\.state_dict\(\)")),
        ("optim.SGD(...)", text(r"optim\.SGD\(")),
        ("nn.Dropout(...)", text(r"nn\.Dropout\(")),
        (".to(device) / torch.device(...)", text(r"\.to\(device\)|torch\.device\(")),
    ],
    "Appendix D (TensorFlow/Keras)": [
        ("imports keras or tensorflow", text(r"^\s*(import|from)\s+(keras|tensorflow)\b")),
    ],
}


def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else None
    if folder:
        files = sorted(glob.glob(os.path.join(folder, "ch*_program*.py")))
    else:
        files = sorted(glob.glob(os.path.join(ROOT, "chapter-*", "ch*_program*.py")))
    programs = []
    for f in files:
        src = open(f, encoding="utf-8").read()
        programs.append((os.path.basename(f), code_only(src), ast.parse(src)))
    print(f"{len(programs)} chapter program files\n")
    for title, rows in TABLES.items():
        print(title)
        for label, test in rows:
            hits = sum(1 for _, code, tree in programs if test(code, tree))
            print(f"  {label:<42} {hits:>4} files")
        if title.startswith("Appendix A"):
            comps = sum(isinstance(n, (ast.ListComp, ast.DictComp))
                        for _, _, tree in programs for n in ast.walk(tree))
            print(f"  {'list/dict comprehensions':<42} {comps:>4} occurrences")
        if title.startswith("Appendix C"):
            for loss in LOSSES:
                k = sum(len(re.findall(r"nn\." + loss + r"\(", code)) for _, code, _ in programs)
                print(f"  {'nn.' + loss + '()':<42} {k:>4} occurrences")
        print()


if __name__ == "__main__":
    main()
