#!/usr/bin/env python3
"""Build one Jupyter notebook per chapter and appendix from the program files.

Each program becomes two code cells: a %%writefile cell holding the program
(so a student can change it and re-run), and a cell that runs the file as a
separate Python process, exactly as `python chNN_programM.py` does in the
book. The expected output follows as text.

    python tools/make_notebooks.py           # rewrite every notebook
    python tools/make_notebooks.py --check   # report notebooks that are out of date

Run it after changing any program or expected output, so that the notebooks
always contain the same code as the .py files.
"""
import argparse
import hashlib
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = json.load(open(os.path.join(ROOT, "tools", "programs.json"), encoding="utf-8"))
BOOK, AUTHORS = DATA["book"], DATA["authors"]

EXTRA_SETUP = {   # first code cell of a notebook, for libraries Colab may not have
    "chapter-28-deploying-deep-learning-models": "%pip install -q onnx onnxruntime flask requests",
}
EXTRA_NOTE = {
    "chapter-13-building-networks-with-pytorch-and-keras":
        "Program 3 uses TensorFlow/Keras, which Colab already has. On your own computer, install it "
        "first with `python -m pip install -r requirements-tensorflow.txt` from the repository's top folder.",
    "appendix-d-tensorflow-keras-reference":
        "This appendix uses TensorFlow/Keras, which Colab already has. On your own computer, install it "
        "first with `python -m pip install -r requirements-tensorflow.txt` from the repository's top folder.",
    "chapter-28-deploying-deep-learning-models":
        "The first code cell installs the few libraries this chapter needs that Colab may lack; on your own "
        "computer `requirements.txt` already includes them.",
}


def lines(text):
    parts = text.split("\n")
    return [p + "\n" for p in parts[:-1]] + ([parts[-1]] if parts[-1] else [])


def cell_id(*key):
    return hashlib.sha1("/".join(key).encode()).hexdigest()[:12]


def markdown(key, text):
    return {"cell_type": "markdown", "id": cell_id(*key), "metadata": {}, "source": lines(text)}


def code(key, text):
    return {"cell_type": "code", "execution_count": None, "id": cell_id(*key), "metadata": {},
            "outputs": [], "source": lines(text)}


def runtime(seconds):
    if seconds is None:
        return ""
    if seconds < 1:
        return "under a second"
    if seconds < 60:
        return f"about {seconds:.0f} s"
    return f"about {max(1, round(seconds / 60))} min"


def notebook(folder_info):
    folder = folder_info["folder"]
    progs = [p for p in DATA["programs"] if p["folder"] == folder]
    label, title = folder_info["label"], folder_info["title"]
    cells = [markdown((folder, "title"), (
        f"# {label} · {title}\n\n"
        f"Every program from {label} of *{BOOK}* ({AUTHORS}).\n\n"
        "Each program takes two cells. The first writes the program to a file: change the code there to "
        "experiment, then run both cells again. The second runs the file as a fresh Python process, exactly "
        "as `python` runs it in the book, so every program starts from a clean state. The program's "
        "expected output, as printed in the book, follows it. (To explore a program's variables after it "
        "finishes, run it in a new cell with `%run` followed by the file name.)\n\n"
        "Run the cells from top to bottom. On Google Colab everything needed is already installed."
        + (f"\n\n{EXTRA_NOTE[folder]}" if folder in EXTRA_NOTE else "")))]
    if folder in EXTRA_SETUP:
        cells.append(code((folder, "setup"), EXTRA_SETUP[folder]))
    for p in progs:
        f = p["file"]
        stem = os.path.splitext(f)[0]
        src = open(os.path.join(ROOT, folder, f), encoding="utf-8").read().rstrip("\n")
        if p["kind"] == "appendix":
            heading = f"## `{f}`: {p['title']}"
            where = f"File `{f}`"
        elif f == "broken.py":
            heading = f"## Traceback example · {p['title']}"
            where = f"Book section {p['section']} ({p['section_title']}) · file `{f}`"
        else:
            heading = f"## Program {p['number']} · {p['title']}"
            where = f"Book section {p['section']} ({p['section_title']}) · file `{f}`"
        rt = runtime(p.get("seconds"))
        info = where + (f" · runs in {rt} on a 2-core CPU" if rt and rt != "under a second" else "")
        if p.get("varies"):
            info += f"\n\nIts output will not match the book exactly, because {p['varies']}."
        cells.append(markdown((folder, f, "head"), f"{heading}\n\n{info}"))
        if f.endswith(".sh"):
            cells.append(markdown((folder, f, "shell"), (
                "These are terminal commands, not Python. Type them one at a time in a terminal on your own "
                "computer; on Google Colab, skip them, because everything is already installed.\n\n"
                f"```bash\n{src}\n```")))
            continue
        cells.append(code((folder, f, "write"), f"%%writefile {f}\n{src}"))
        run = 'import sys\n!"{sys.executable}" -u ' + f
        if f == "broken.py":
            run = "# broken.py fails on purpose, to show a traceback\n" + run
        cells.append(code((folder, f, "run"), run))
        expected = open(os.path.join(ROOT, folder, "expected_output", stem + ".txt"),
                        encoding="utf-8").read().rstrip("\n")
        cells.append(markdown((folder, f, "expected"),
                              f"**Expected output** (as printed in the book):\n\n```text\n{expected}\n```"))
    return {
        "cells": cells,
        "metadata": {
            "colab": {"provenance": []},
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }


def notebook_path(folder_info):
    prefix = (f"ch{folder_info['number']:02d}" if folder_info["kind"] == "chapter"
              else f"app{folder_info['number']}")
    return os.path.join(ROOT, folder_info["folder"], f"{prefix}_notebook.ipynb")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--check", action="store_true", help="only report notebooks that are out of date")
    args = ap.parse_args()
    stale = 0
    for info in DATA["folders"]:
        text = json.dumps(notebook(info), indent=1, ensure_ascii=False) + "\n"
        path = notebook_path(info)
        current = open(path, encoding="utf-8").read() if os.path.exists(path) else None
        if args.check:
            if current != text:
                stale += 1
                print("out of date:", os.path.relpath(path, ROOT))
        elif current != text:
            with open(path, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(text)
            print("wrote", os.path.relpath(path, ROOT))
    if args.check:
        print("all notebooks up to date" if not stale else f"{stale} notebook(s) out of date")
        sys.exit(1 if stale else 0)


if __name__ == "__main__":
    main()
