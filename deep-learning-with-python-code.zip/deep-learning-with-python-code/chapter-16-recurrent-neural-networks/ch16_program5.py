# ch16_program5.py
# A practical, sensor-flavored illustration of the vanishing-gradient
# limitation: a simulated sensor stream carries exactly one spike event
# (sign +1 or -1) at a chosen position, buried in small noise everywhere
# else. The task -- classify the spike's sign after reading the whole
# stream -- is trivial in principle (ignore everything but the spike),
# but a plain RNN can only solve it if gradient can still reach back to
# wherever the spike occurred. Sweeping the spike's position relative to
# the end of a FIXED-length stream isolates "distance from the signal to
# the decision point" directly, the same quantity Program 3 varied by
# changing total sequence length.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

T = 25            # fixed stream length (readings per example)
NOISE_STD = 0.3
SPIKE_MAG = 2.0


def make_batch(event_pos, n_examples, seed):
    rng = np.random.RandomState(seed)
    seqs = rng.normal(0.0, NOISE_STD, size=(n_examples, T, 1)).astype(np.float32)
    signs = rng.choice([-1.0, 1.0], size=n_examples).astype(np.float32)
    seqs[:, event_pos, 0] = SPIKE_MAG * signs
    labels = (signs > 0).astype(np.float32)
    return torch.tensor(seqs), torch.tensor(labels)


class RecallRNN(nn.Module):
    """Identical structure to Chapter 16 Program 3's RecallRNN."""
    def __init__(self, hidden_size=16):
        super().__init__()
        self.rnn = nn.RNN(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, h_n = self.rnn(x)
        return self.head(h_n.squeeze(0)).squeeze(-1)


EVENT_POSITIONS = [24, 20, 18, 16, 10]   # 0-indexed: how early the spike occurs
print(f"fixed stream length T={T}; sweeping the spike's position within it")
print(f"{'event_pos':>10} {'lag (steps after spike)':>24} {'test_acc':>10}")

np.random.seed(0)
accs = []
for event_pos in EVENT_POSITIONS:
    lag = T - 1 - event_pos   # how many more readings arrive AFTER the spike
    torch.manual_seed(0)
    model = RecallRNN()
    opt = optim.SGD(model.parameters(), lr=0.5)
    loss_fn = nn.BCEWithLogitsLoss()

    X_train, y_train = make_batch(event_pos, 500, seed=0)
    X_test, y_test = make_batch(event_pos, 200, seed=1)

    for epoch in range(200):
        model.train()
        opt.zero_grad()
        loss = loss_fn(model(X_train), y_train)
        loss.backward()
        opt.step()

    model.eval()
    with torch.no_grad():
        preds = (torch.sigmoid(model(X_test)) > 0.5).float()
        acc = (preds == y_test).float().mean().item()
    accs.append(acc)
    print(f"{event_pos:>10} {lag:>24} {acc:>10.4f}")

