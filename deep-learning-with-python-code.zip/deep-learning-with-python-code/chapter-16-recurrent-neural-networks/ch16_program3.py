# ch16_program3.py
# Part A: measure how the loss gradient shrinks as it propagates
# backward through time in a 50-step RNN (the temporal analog of
# Chapter 15 Program 1's layer-by-layer measurement).
# Part B: a concrete consequence -- train a plain RNN to recall the
# FIRST element of a sequence, for several sequence lengths, and
# watch accuracy degrade as the sequence grows.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

torch.manual_seed(0)

# ---------------------------------------------------------------
# Part A: gradient norm at each timestep, walking backward from a
# loss computed only at the final hidden state.
# ---------------------------------------------------------------
T = 50
H = 20
cell = nn.RNNCell(input_size=1, hidden_size=H, nonlinearity="tanh")

torch.manual_seed(0)
xs = [torch.randn(1, 1) for _ in range(T)]
h = torch.zeros(1, H)
hs = [h]
for x in xs:
    h = cell(x, h)
    h.retain_grad()          # keep .grad on this non-leaf tensor
    hs.append(h)

target = torch.randn(1, H)
loss = ((hs[-1] - target) ** 2).mean()
loss.backward()

grad_norms = [hs[t].grad.norm().item() for t in range(1, T + 1)]
print(" timestep   ||dL/dh_t||")
for t in [1, 10, 20, 30, 40, 50]:
    print(f"{t:9d}   {grad_norms[t-1]:12.4e}")
print(f"\ntimestep 1 / timestep 50 ratio = {grad_norms[0] / grad_norms[-1]:.2e}")

# ---------------------------------------------------------------
# Part B: recall-the-first-input task, plain RNN, several lengths.
# ---------------------------------------------------------------
def make_batch(seq_len, n_examples):
    seqs = np.random.choice([-1.0, 1.0], size=(n_examples, seq_len, 1)).astype(np.float32)
    labels = (seqs[:, 0, 0] > 0).astype(np.float32)
    return torch.tensor(seqs), torch.tensor(labels)


class RecallRNN(nn.Module):
    def __init__(self, hidden_size=16):
        super().__init__()
        self.rnn = nn.RNN(input_size=1, hidden_size=hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        _, h_n = self.rnn(x)              # h_n: (1, batch, hidden)
        return self.head(h_n.squeeze(0)).squeeze(-1)


print("\nrecall-the-first-input task, plain RNN, plain SGD "
      "(Adam's adaptive step size can mask this effect, Chapter 11):")
print(" seq_len   test_acc")
np.random.seed(0)
for seq_len in [5, 10, 20, 40]:
    torch.manual_seed(0)
    model = RecallRNN()
    opt = optim.SGD(model.parameters(), lr=0.5)
    loss_fn = nn.BCEWithLogitsLoss()

    X_train, y_train = make_batch(seq_len, 500)
    X_test, y_test = make_batch(seq_len, 200)

    for epoch in range(200):
        model.train()
        opt.zero_grad()
        out = model(X_train)
        loss = loss_fn(out, y_train)
        loss.backward()
        opt.step()

    model.eval()
    with torch.no_grad():
        preds = (torch.sigmoid(model(X_test)) > 0.5).float()
        acc = (preds == y_test).float().mean().item()
    print(f"{seq_len:8d}   {acc:.4f}")
