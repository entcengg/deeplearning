# Chapter 16 · Recurrent Neural Networks

Code for Chapter 16 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 15](../chapter-15-cnn-architectures-and-transfer-learning/README.md) · [Chapter 17 →](../chapter-17-lstm-and-gru/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 16.2.1 Program 1: RNN Forward Pass, by Hand and by Framework | An RNN's forward pass, by hand and by framework | [`ch16_program1.py`](ch16_program1.py) | [ch16_program1.txt](expected_output/ch16_program1.txt) | 2 s |
| 2 | 16.4 Backpropagation Through Time | Backpropagation through time, by hand and by autograd | [`ch16_program2.py`](ch16_program2.py) | [ch16_program2.txt](expected_output/ch16_program2.txt) | 2 s |
| 3 | 16.5.1 Program 3: Vanishing Gradients Over Time, and Their Cost | Gradient magnitude vs. timestep in a 50-step RNN, and a long-range recall task's accuracy vs. sequence length | [`ch16_program3.py`](ch16_program3.py) | [ch16_program3.txt](expected_output/ch16_program3.txt) | 9 s |
| 4 | 16.6.1 Program 4: Clipping, by Hand and on an Exploding RNN | Gradient clipping checked by hand, then applied to an RNN with an inflated recurrent weight | [`ch16_program4.py`](ch16_program4.py) | [ch16_program4.txt](expected_output/ch16_program4.txt) | 3 s |
| 5 | 16.7.1 Program 5: Accuracy Versus Distance to the Decision | A sensor stream with one spike: plain-RNN accuracy as the spike moves away from the decision point | [`ch16_program5.py`](ch16_program5.py) | [ch16_program5.txt](expected_output/ch16_program5.txt) | 7 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-16-recurrent-neural-networks
python ch16_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch16_notebook.ipynb`](ch16_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, PyTorch.
