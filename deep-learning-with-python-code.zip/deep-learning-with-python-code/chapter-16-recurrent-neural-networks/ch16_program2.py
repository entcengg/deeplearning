# ch16_program2.py
# Backpropagation through time (BPTT), computed step by step with
# NumPy on the exact RNN from Program 1, and checked against
# PyTorch autograd.

import numpy as np
import torch
import torch.nn as nn

W_xh = np.array([[0.5, -0.3],
                  [0.1,  0.8]])
W_hh = np.array([[0.2,  0.4],
                  [-0.1, 0.3]])
b_h = np.array([0.1, -0.2])
W_hy = np.array([[0.6, -0.5]])
b_y = np.array([0.05])

xs = [np.array([1.0, 0.5]), np.array([-0.5, 1.0]), np.array([0.2, 0.2])]
target = 1.0

# ---------------------------------------------------------------
# Forward pass, keeping every hidden state (needed for BPTT).
# ---------------------------------------------------------------
h_prev = np.array([0.0, 0.0])
hs = [h_prev]
for x in xs:
    z = W_xh @ x + W_hh @ h_prev + b_h
    h_prev = np.tanh(z)
    hs.append(h_prev)
y = (W_hy @ hs[-1] + b_y)[0]
loss = 0.5 * (y - target) ** 2
print(f"forward: y = {y:.6f}, loss = {loss:.6f}")

# ---------------------------------------------------------------
# BPTT: walk backward through the 3 timesteps, accumulating
# gradients for the SHARED weights W_xh, W_hh, b_h.
# ---------------------------------------------------------------
dW_xh = np.zeros_like(W_xh)
dW_hh = np.zeros_like(W_hh)
db_h = np.zeros_like(b_h)

dy = y - target                      # dL/dy
dW_hy = np.outer([dy], hs[-1])
db_y = np.array([dy])
dh_next = W_hy.T.flatten() * dy      # dL/dh_3, entering from the output

for t in reversed(range(1, len(xs) + 1)):
    dz = dh_next * (1 - hs[t] ** 2)          # tanh'(z_t) = 1 - h_t^2
    dW_xh += np.outer(dz, xs[t - 1])
    dW_hh += np.outer(dz, hs[t - 1])
    db_h += dz
    dh_next = W_hh.T @ dz                     # gradient handed to timestep t-1

print("\nNumPy (manual BPTT) gradients:")
print("dW_xh =\n", dW_xh)
print("dW_hh =\n", dW_hh)
print("db_h  =", db_h)
print("dW_hy =", dW_hy)
print("db_y  =", db_y)

# ---------------------------------------------------------------
# Same computation with PyTorch autograd.
# ---------------------------------------------------------------
cell = nn.RNNCell(input_size=2, hidden_size=2, nonlinearity="tanh")
with torch.no_grad():
    cell.weight_ih.copy_(torch.tensor(W_xh, dtype=torch.float32))
    cell.weight_hh.copy_(torch.tensor(W_hh, dtype=torch.float32))
    cell.bias_ih.copy_(torch.tensor(b_h, dtype=torch.float32))
    cell.bias_hh.zero_()
W_hy_t = torch.tensor(W_hy, dtype=torch.float32, requires_grad=True)
b_y_t = torch.tensor(b_y, dtype=torch.float32, requires_grad=True)

h_t = torch.zeros(1, 2)
for x in xs:
    x_t = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
    h_t = cell(x_t, h_t)
y_t = (h_t @ W_hy_t.T + b_y_t).flatten()[0]
loss_t = 0.5 * (y_t - target) ** 2
loss_t.backward()

print("\nPyTorch autograd gradients:")
print("weight_ih.grad =\n", cell.weight_ih.grad.numpy())
print("weight_hh.grad =\n", cell.weight_hh.grad.numpy())
print("bias_ih.grad   =", cell.bias_ih.grad.numpy())
print("W_hy.grad      =", W_hy_t.grad.numpy())
print("b_y.grad       =", b_y_t.grad.numpy())
