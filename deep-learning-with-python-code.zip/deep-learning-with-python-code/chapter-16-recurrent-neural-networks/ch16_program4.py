# ch16_program4.py
# Gradient clipping: a practical response to exploding gradients.
# Part A: the clip-by-norm rule, checked by hand against PyTorch's
#         nn.utils.clip_grad_norm_ on a two-number gradient.
# Part B: a plain tanh RNN cell whose recurrent weight is scaled up 3x
#         (spectral radius above 1, the mirror image of Program 3's
#         vanishing case): the gradient norm grows with sequence length,
#         and clipping caps it without changing its direction.

import torch
import torch.nn as nn

# ---------------------------------------------------------------
# Part A: clip-by-norm, by hand:  if ||g|| > c, then g <- g * c / ||g||
# ---------------------------------------------------------------
g = torch.tensor([6.0, 8.0])
c = 5.0
norm = g.norm().item()
hand = g * (c / norm) if norm > c else g
print("Part A: clip g = (6, 8) to norm c = 5")
print(f"  ||g|| = {norm:.4f}  ->  hand-clipped g = {hand.tolist()}, "
      f"norm {hand.norm().item():.4f}")

param = torch.zeros(2, requires_grad=True)
param.grad = g.clone()
reported = nn.utils.clip_grad_norm_([param], max_norm=c)
print(f"  clip_grad_norm_: returns the pre-clip norm {reported.item():.4f};")
print(f"  grad after = [{param.grad[0].item():.7f}, {param.grad[1].item():.7f}]")


# ---------------------------------------------------------------
# Part B: an RNN whose gradient grows with sequence length.
# ---------------------------------------------------------------
def inflated_rnn_gradient(T, scale=3.0, H=20):
    """Gradients of a squared-error loss on h_T for a tanh RNNCell whose
    recurrent weight has been multiplied by `scale`. Same seed for every T."""
    torch.manual_seed(0)
    cell = nn.RNNCell(1, H, nonlinearity="tanh")
    with torch.no_grad():
        cell.weight_hh.mul_(scale)
    rho = torch.linalg.eigvals(cell.weight_hh.detach()).abs().max().item()
    h = torch.zeros(1, H)
    for x in [torch.randn(1, 1) for _ in range(T)]:
        h = cell(x, h)
    loss = ((h - torch.randn(1, H)) ** 2).mean()
    loss.backward()
    return cell, rho


print("\nPart B: tanh RNN cell, recurrent weight scaled 3x")
print(f"{'T (steps)':>10} {'gradient norm':>15}")
norms = {}
for T in [10, 20, 30, 40, 50]:
    cell, rho = inflated_rnn_gradient(T)
    # max_norm=inf never rescales: this call only MEASURES the global norm
    norms[T] = nn.utils.clip_grad_norm_(cell.parameters(), max_norm=float("inf")).item()
    print(f"{T:>10} {norms[T]:>15.4f}")
print(f"spectral radius of the scaled recurrent weight: {rho:.3f}")

T_big = max(norms, key=norms.get)
cell, _ = inflated_rnn_gradient(T_big)
raw = torch.cat([p.grad.flatten() for p in cell.parameters()]).clone()
nn.utils.clip_grad_norm_(cell.parameters(), max_norm=c)
clipped = torch.cat([p.grad.flatten() for p in cell.parameters()])
cos = torch.dot(raw, clipped) / (raw.norm() * clipped.norm())
print(f"\nclipping the largest one (T={T_big}) at c={c}:")
print(f"  norm before {raw.norm().item():.4f}, after {clipped.norm().item():.4f}, "
      f"scale factor {clipped.norm().item() / raw.norm().item():.4f}")
print(f"  cosine(raw gradient, clipped gradient) = {cos.item():.6f}")
