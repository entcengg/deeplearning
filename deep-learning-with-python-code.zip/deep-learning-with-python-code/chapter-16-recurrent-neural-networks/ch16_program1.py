# ch16_program1.py
# Forward pass through a simple RNN, computed step by step with NumPy
# and checked against PyTorch's nn.RNNCell.

import numpy as np
import torch
import torch.nn as nn

# A small, hand-followable RNN: 2 inputs, 2 hidden units, 3 timesteps.
W_xh = np.array([[0.5, -0.3],
                  [0.1,  0.8]])
W_hh = np.array([[0.2,  0.4],
                  [-0.1, 0.3]])
b_h = np.array([0.1, -0.2])
W_hy = np.array([[0.6, -0.5]])
b_y = np.array([0.05])

xs = [np.array([1.0, 0.5]), np.array([-0.5, 1.0]), np.array([0.2, 0.2])]
h = np.array([0.0, 0.0])   # h_0

print("NumPy, step by step:")
hs_numpy = [h]
for t, x in enumerate(xs, start=1):
    z = W_xh @ x + W_hh @ h + b_h
    h = np.tanh(z)
    y = W_hy @ h + b_y
    hs_numpy.append(h)
    print(f"  t={t}: z={z}, h={h}, y={y}")

# ---------------------------------------------------------------
# Same computation with PyTorch's nn.RNNCell, weights copied in.
# ---------------------------------------------------------------
cell = nn.RNNCell(input_size=2, hidden_size=2, nonlinearity="tanh")
with torch.no_grad():
    cell.weight_ih.copy_(torch.tensor(W_xh, dtype=torch.float32))
    cell.weight_hh.copy_(torch.tensor(W_hh, dtype=torch.float32))
    cell.bias_ih.copy_(torch.tensor(b_h, dtype=torch.float32))
    cell.bias_hh.zero_()   # keep all the bias in bias_ih, as in the NumPy version

h_t = torch.zeros(1, 2)
print("\nPyTorch nn.RNNCell, step by step:")
for t, x in enumerate(xs, start=1):
    x_t = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
    h_t = cell(x_t, h_t)
    print(f"  t={t}: h={h_t.detach().numpy().flatten()}")
