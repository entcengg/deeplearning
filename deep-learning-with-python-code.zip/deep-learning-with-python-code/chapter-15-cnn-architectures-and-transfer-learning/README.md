# Chapter 15 · CNN Architectures and Transfer Learning

Code for Chapter 15 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 14](../chapter-14-convolution-and-cnn-fundamentals/README.md) · [Chapter 16 →](../chapter-16-recurrent-neural-networks/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 15.3.1 Program 1: Gradient Flow, Plain vs. Residual | Measuring gradient flow in a 30-layer plain network versus a 30-layer residual network | [`ch15_program1.py`](ch15_program1.py) | [ch15_program1.txt](expected_output/ch15_program1.txt) | 2 s |
| 2 | 15.5.1 Program 2: Batch Normalization, by Hand and in Training | Batch normalization verified by hand, then compared with and without it on an 8-layer MLP | [`ch15_program2.py`](ch15_program2.py) | [ch15_program2.txt](expected_output/ch15_program2.txt) | 6 s |
| 3 | 15.6.2 Program 3: Transfer Learning with Scarce Data | Pretraining a small CNN, freezing its convolutional layers, and training only a new head on 30 scarce examples, compared to training the same architecture from scratch | [`ch15_program3.py`](ch15_program3.py) | [ch15_program3.txt](expected_output/ch15_program3.txt) | 6 s |
| 4 | 15.6.3 Program 4: Transfer Learning's Advantage Across Dataset Sizes | Transfer vs. scratch accuracy, swept across target training-set size | [`ch15_program4.py`](ch15_program4.py) | [ch15_program4.txt](expected_output/ch15_program4.txt) | 8 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-15-cnn-architectures-and-transfer-learning
python ch15_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch15_notebook.ipynb`](ch15_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn, PyTorch.

## Notes

- Program 4 saves its results as `ch15_scratch_vs_transfer_datasize.npz` in this folder.
