# ch15_program1.py
# Gradient flow in a very deep plain network vs. a very deep residual
# network, measured directly as the norm of each layer's weight
# gradient after one backward pass.

import torch
import torch.nn as nn

torch.manual_seed(0)

DEPTH = 30
WIDTH = 20


class PlainDeepNet(nn.Module):
    """DEPTH stacked Linear+sigmoid blocks, no shortcuts."""
    def __init__(self, depth=DEPTH, width=WIDTH):
        super().__init__()
        self.layers = nn.ModuleList(
            [nn.Linear(width, width) for _ in range(depth)]
        )
        self.act = nn.Sigmoid()

    def forward(self, x):
        for layer in self.layers:
            x = self.act(layer(x))
        return x


class ResidualDeepNet(nn.Module):
    """Same DEPTH stacked Linear+sigmoid blocks, each wrapped in an
    identity skip connection: y = F(x) + x (Equation 15.1)."""
    def __init__(self, depth=DEPTH, width=WIDTH):
        super().__init__()
        self.layers = nn.ModuleList(
            [nn.Linear(width, width) for _ in range(depth)]
        )
        self.act = nn.Sigmoid()

    def forward(self, x):
        for layer in self.layers:
            x = self.act(layer(x)) + x
        return x


# Build both networks from the SAME initial weights (same seed, same
# layer shapes in the same order) so the only difference is the
# presence of the skip connections.
torch.manual_seed(0)
plain = PlainDeepNet()

torch.manual_seed(0)
resnet = ResidualDeepNet()

# One fixed batch, shared by both networks.
torch.manual_seed(1)
x = torch.randn(8, WIDTH)
y = torch.randn(8, WIDTH)


def backward_grad_norms(model, x, y):
    model.zero_grad()
    out = model(x)
    loss = ((out - y) ** 2).mean()
    loss.backward()
    return [model.layers[i].weight.grad.norm().item() for i in range(DEPTH)]


plain_norms = backward_grad_norms(plain, x, y)
res_norms = backward_grad_norms(resnet, x, y)

print(" layer  plain grad norm   residual grad norm")
for i in [0, 5, 10, 15, 20, 25, 29]:
    print(f"{i:6d}   {plain_norms[i]:14.2e}   {res_norms[i]:14.2e}")

plain_ratio = plain.layers[0].weight.grad.norm() / plain.layers[29].weight.grad.norm()
res_ratio = resnet.layers[0].weight.grad.norm() / resnet.layers[29].weight.grad.norm()
print(f"\nplain network:    layer 0 / layer 29 ratio = {plain_ratio:.2e}")
print(f"residual network: layer 0 / layer 29 ratio = {res_ratio:.2e}")
