# ch15_program2.py
# Part A: verify the batch normalization formula (Equation 15.3) by
# hand against PyTorch's nn.BatchNorm1d.
# Part B: train an 8-layer MLP on the digits dataset with and without
# batch normalization between the hidden layers, and compare the
# resulting training-loss curves.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------
# Part A: batch normalization by hand, on a tiny toy batch.
# ---------------------------------------------------------------
x = np.array([2.0, 4.0, 4.0, 6.0])
eps = 1e-5

mean = x.mean()
var = ((x - mean) ** 2).mean()          # population variance, as BN uses
x_hat = (x - mean) / np.sqrt(var + eps)  # Equation 15.3, gamma=1, beta=0

print("Hand-computed batch normalization:")
print(f"  mean = {mean}")
print(f"  var  = {var}")
print(f"  x_hat = {x_hat}")

bn = nn.BatchNorm1d(1, eps=eps, momentum=1.0)
x_t = torch.tensor(x, dtype=torch.float32).view(-1, 1)
bn_out = bn(x_t).detach().numpy().flatten()
print(f"\nPyTorch nn.BatchNorm1d output: {bn_out}")

# ---------------------------------------------------------------
# Part B: an 8-layer MLP on digits, with vs. without batch norm.
# ---------------------------------------------------------------
digits = load_digits()
X = digits.data / 16.0
y = digits.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=0
)
X_train_t = torch.tensor(X_train, dtype=torch.float32)
y_train_t = torch.tensor(y_train, dtype=torch.long)
X_test_t = torch.tensor(X_test, dtype=torch.float32)
y_test_t = torch.tensor(y_test, dtype=torch.long)


class DeepMLP(nn.Module):
    """8 Linear layers (64->30x6->10); optionally BatchNorm1d after
    each hidden Linear, before the ReLU."""
    def __init__(self, use_bn=False, width=30, in_dim=64, out_dim=10, depth=8):
        super().__init__()
        self.use_bn = use_bn
        dims = [in_dim] + [width] * (depth - 1) + [out_dim]
        self.linears = nn.ModuleList(
            [nn.Linear(dims[i], dims[i + 1]) for i in range(depth)]
        )
        if use_bn:
            self.bns = nn.ModuleList(
                [nn.BatchNorm1d(width) for _ in range(depth - 1)]
            )
        self.act = nn.ReLU()

    def forward(self, x):
        for i in range(len(self.linears) - 1):
            x = self.linears[i](x)
            if self.use_bn:
                x = self.bns[i](x)
            x = self.act(x)
        return self.linears[-1](x)


def train(model, epochs=100, lr=0.01):
    opt = optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    history = {}
    for epoch in range(1, epochs + 1):
        model.train()
        opt.zero_grad()
        out = model(X_train_t)
        loss = loss_fn(out, y_train_t)
        loss.backward()
        opt.step()
        if epoch in (1, 20, 40, 60, 80, 100):
            history[epoch] = loss.item()
    model.eval()
    with torch.no_grad():
        test_acc = (model(X_test_t).argmax(1) == y_test_t).float().mean().item()
    return history, test_acc


torch.manual_seed(0)
model_plain = DeepMLP(use_bn=False)
torch.manual_seed(0)
model_bn = DeepMLP(use_bn=True)

hist_plain, acc_plain = train(model_plain)
hist_bn, acc_bn = train(model_bn)

print("\n8-layer MLP on digits, with vs. without batch normalization:")
print(" epoch   without BN loss   with BN loss")
for epoch in (1, 20, 40, 60, 80, 100):
    print(f"{epoch:6d}   {hist_plain[epoch]:15.4f}   {hist_bn[epoch]:12.4f}")

print(f"\nfinal test accuracy without BN: {acc_plain:.4f}")
print(f"final test accuracy with BN:    {acc_bn:.4f}")
