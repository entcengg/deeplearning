# ch15_program4.py
# Transfer learning's advantage across target dataset sizes: Program 3
# fixed the target set at 30 scarce examples and watched accuracy over
# epochs. This program instead fixes the epoch budget and sweeps the
# SIZE of the target training set, to show directly how the
# transfer-vs-scratch gap shrinks as more target data becomes available.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits

torch.manual_seed(0)
np.random.seed(0)

digits = load_digits()
X = digits.data.reshape(-1, 1, 8, 8) / 16.0
y = digits.target

# Same pretraining slice as Program 3 (1,400 examples). Of the 397
# remaining examples, hold out a FIXED 100 as the target test set, and
# draw increasing target TRAINING sizes from the remaining 297.
idx = np.random.permutation(len(X))
pretrain_idx = idx[:1400]
remaining_idx = idx[1400:]            # 397 examples
target_test_idx = remaining_idx[:100]       # fixed, never used for training
pool_idx = remaining_idx[100:]              # 297 examples to draw training sets from

X_pre = torch.tensor(X[pretrain_idx], dtype=torch.float32)
y_pre = torch.tensor(y[pretrain_idx], dtype=torch.long)
X_ttest = torch.tensor(X[target_test_idx], dtype=torch.float32)
y_ttest = torch.tensor(y[target_test_idx], dtype=torch.long)

print(f"pretrain examples: {len(X_pre)}, fixed target test examples: {len(X_ttest)}, "
      f"target-training pool: {len(pool_idx)}")


class FeatureCNN(nn.Module):
    """Identical to Chapter 15 Program 3's FeatureCNN."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.act = nn.ReLU()
        self.head = nn.Linear(16 * 2 * 2, 10)

    def features(self, x):
        x = self.pool(self.act(self.conv1(x)))
        x = self.pool(self.act(self.conv2(x)))
        return x.flatten(1)

    def forward(self, x):
        return self.head(self.features(x))


def test_accuracy(model, X_t, y_t):
    model.eval()
    with torch.no_grad():
        return (model(X_t).argmax(1) == y_t).float().mean().item()


loss_fn = nn.CrossEntropyLoss()

# ---------------------------------------------------------------
# Pretrain ONE backbone, exactly as Program 3 does, reused for every
# training-set size tested below.
# ---------------------------------------------------------------
torch.manual_seed(0)
pretrained = FeatureCNN()
opt = optim.Adam(pretrained.parameters(), lr=0.01)
for _ in range(30):
    pretrained.train()
    opt.zero_grad()
    loss_fn(pretrained(X_pre), y_pre).backward()
    opt.step()
pretrain_acc = test_accuracy(pretrained, X_pre, y_pre)
print(f"pretraining finished: train accuracy on the 1400-example set = {pretrain_acc:.4f}\n")

TRAIN_SIZES = [10, 20, 30, 50, 100, 200, 297]
EPOCHS = 100
transfer_accs, scratch_accs = [], []

print(f"{'train_size':>10} {'transfer_acc':>13} {'scratch_acc':>12} {'gap':>8}")
for size in TRAIN_SIZES:
    train_idx = pool_idx[:size]
    X_train = torch.tensor(X[train_idx], dtype=torch.float32)
    y_train = torch.tensor(y[train_idx], dtype=torch.long)

    # Transfer: frozen backbone, fresh head, trained on `size` examples.
    transfer_model = FeatureCNN()
    transfer_model.load_state_dict(pretrained.state_dict())
    for p in transfer_model.conv1.parameters():
        p.requires_grad = False
    for p in transfer_model.conv2.parameters():
        p.requires_grad = False
    torch.manual_seed(2)
    transfer_model.head = nn.Linear(16 * 2 * 2, 10)
    opt_t = optim.Adam(transfer_model.head.parameters(), lr=0.01)

    # Scratch: identical architecture, ALL weights trained from a fresh
    # random init, on the SAME `size` examples.
    torch.manual_seed(3)
    scratch_model = FeatureCNN()
    opt_s = optim.Adam(scratch_model.parameters(), lr=0.01)

    for epoch in range(EPOCHS):
        transfer_model.train()
        opt_t.zero_grad()
        loss_fn(transfer_model(X_train), y_train).backward()
        opt_t.step()

        scratch_model.train()
        opt_s.zero_grad()
        loss_fn(scratch_model(X_train), y_train).backward()
        opt_s.step()

    acc_t = test_accuracy(transfer_model, X_ttest, y_ttest)
    acc_s = test_accuracy(scratch_model, X_ttest, y_ttest)
    transfer_accs.append(acc_t)
    scratch_accs.append(acc_s)
    print(f"{size:>10} {acc_t:>13.4f} {acc_s:>12.4f} {acc_t - acc_s:>8.4f}")

np.savez("ch15_scratch_vs_transfer_datasize.npz",
         sizes=np.array(TRAIN_SIZES),
         transfer=np.array(transfer_accs), scratch=np.array(scratch_accs))
print("\nsaved sweep results to ch15_scratch_vs_transfer_datasize.npz")
