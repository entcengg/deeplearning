# ch15_program3.py
# Transfer learning, fully self-contained: a small CNN's convolutional
# feature extractor is pretrained on a large slice of the digits
# dataset, frozen, and given a fresh classification head trained on a
# tiny 30-example "scarce data" slice of the SAME 10 classes. Compared
# against an identical architecture trained from scratch on that same
# 30-example slice.

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.datasets import load_digits

torch.manual_seed(0)
np.random.seed(0)

digits = load_digits()
X = digits.data.reshape(-1, 1, 8, 8) / 16.0
y = digits.target

# Shuffle once, then slice: 1400 for pretraining, 30 for the scarce
# target task, and the remaining examples as a held-out target test set.
idx = np.random.permutation(len(X))
pretrain_idx = idx[:1400]
scarce_idx = idx[1400:1430]        # 30 examples
target_test_idx = idx[1430:]       # remaining ~367 examples

X_pre = torch.tensor(X[pretrain_idx], dtype=torch.float32)
y_pre = torch.tensor(y[pretrain_idx], dtype=torch.long)
X_scarce = torch.tensor(X[scarce_idx], dtype=torch.float32)
y_scarce = torch.tensor(y[scarce_idx], dtype=torch.long)
X_ttest = torch.tensor(X[target_test_idx], dtype=torch.float32)
y_ttest = torch.tensor(y[target_test_idx], dtype=torch.long)

print(f"pretrain examples: {len(X_pre)}, scarce target examples: "
      f"{len(X_scarce)}, target test examples: {len(X_ttest)}")


class FeatureCNN(nn.Module):
    """conv1 1->8ch (3x3, pad 1) -> pool -> conv2 8->16ch (3x3, pad 1)
    -> pool -> flatten (16*2*2=64) -> Linear head to 10 classes."""
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.act = nn.ReLU()
        self.head = nn.Linear(16 * 2 * 2, 10)

    def features(self, x):
        x = self.pool(self.act(self.conv1(x)))
        x = self.pool(self.act(self.conv2(x)))
        return x.flatten(1)

    def forward(self, x):
        return self.head(self.features(x))


def test_accuracy(model, X_t, y_t):
    model.eval()
    with torch.no_grad():
        preds = model(X_t).argmax(1)
        return (preds == y_t).float().mean().item()


# ---------------------------------------------------------------
# 1. Pretrain FeatureCNN on the 1400-example slice (all 10 classes).
# ---------------------------------------------------------------
torch.manual_seed(0)
pretrained = FeatureCNN()
opt = optim.Adam(pretrained.parameters(), lr=0.01)
loss_fn = nn.CrossEntropyLoss()
for epoch in range(30):
    pretrained.train()
    opt.zero_grad()
    loss = loss_fn(pretrained(X_pre), y_pre)
    loss.backward()
    opt.step()
pretrain_acc = test_accuracy(pretrained, X_pre, y_pre)
print(f"pretraining finished: train accuracy on the 1400-example set = {pretrain_acc:.4f}")

# ---------------------------------------------------------------
# 2. Transfer: freeze conv1/conv2, attach a FRESH head, train the
#    head only on the 30 scarce examples.
# ---------------------------------------------------------------
transfer_model = FeatureCNN()
transfer_model.load_state_dict(pretrained.state_dict())
for p in transfer_model.conv1.parameters():
    p.requires_grad = False
for p in transfer_model.conv2.parameters():
    p.requires_grad = False
torch.manual_seed(2)
transfer_model.head = nn.Linear(16 * 2 * 2, 10)   # fresh, untrained head

opt_t = optim.Adam(transfer_model.head.parameters(), lr=0.01)

# ---------------------------------------------------------------
# 3. Scratch baseline: identical architecture, ALL weights trained on
#    the same 30 scarce examples, from a fresh random initialization.
# ---------------------------------------------------------------
torch.manual_seed(3)
scratch_model = FeatureCNN()
opt_s = optim.Adam(scratch_model.parameters(), lr=0.01)

checkpoints = {5, 10, 20, 30, 50, 100}
transfer_curve = []
scratch_curve = []
print("\n  model     epoch  test_acc")
for epoch in range(1, 101):
    transfer_model.train()
    opt_t.zero_grad()
    loss_fn(transfer_model(X_scarce), y_scarce).backward()
    opt_t.step()

    scratch_model.train()
    opt_s.zero_grad()
    loss_fn(scratch_model(X_scarce), y_scarce).backward()
    opt_s.step()

    acc_t = test_accuracy(transfer_model, X_ttest, y_ttest)
    acc_s = test_accuracy(scratch_model, X_ttest, y_ttest)
    transfer_curve.append(acc_t)
    scratch_curve.append(acc_s)

    if epoch in checkpoints:
        print(f"  transfer  epoch {epoch:3d}: test_acc = {acc_t:.4f}")
        print(f"  scratch   epoch {epoch:3d}: test_acc = {acc_s:.4f}")
