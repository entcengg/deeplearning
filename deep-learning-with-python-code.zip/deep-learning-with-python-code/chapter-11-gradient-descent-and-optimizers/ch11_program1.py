# ch11_program1.py
# Batch, stochastic, and mini-batch gradient descent on the same
# synthetic dataset, comparing how noisy each one's progress looks.

import numpy as np

rng = np.random.default_rng(0)
m = 60
X = rng.uniform(0, 10, m)
Y = 3 * X + 2 + rng.normal(0, 1.5, m)     # true relationship: y = 3x + 2

def loss(w, b):
    return np.mean((Y - (w * X + b)) ** 2)

def grad_on(w, b, X_batch, Y_batch):
    y_hat = w * X_batch + b
    dw = 2 * np.mean(X_batch * (y_hat - Y_batch))
    db = 2 * np.mean(y_hat - Y_batch)
    return dw, db

eta = 0.01
epochs = 200

# --- Batch: the whole dataset, every step ---
w, b = 0.0, 0.0
for _ in range(epochs):
    dw, db = grad_on(w, b, X, Y)
    w -= eta * dw; b -= eta * db
print(f"batch      : w={w:.4f} b={b:.4f} loss={loss(w, b):.4f}")

# --- Stochastic: one random example per step ---
rng_s = np.random.default_rng(1)
w, b = 0.0, 0.0
for _ in range(epochs):
    for i in rng_s.permutation(m):
        dw, db = grad_on(w, b, X[i:i+1], Y[i:i+1])
        w -= eta * dw; b -= eta * db
print(f"stochastic : w={w:.4f} b={b:.4f} loss={loss(w, b):.4f}")

# --- Mini-batch: 10 examples per step ---
rng_m = np.random.default_rng(2)
w, b = 0.0, 0.0
batch_size = 10
for _ in range(epochs):
    idx = rng_m.permutation(m)
    for start in range(0, m, batch_size):
        batch = idx[start:start + batch_size]
        dw, db = grad_on(w, b, X[batch], Y[batch])
        w -= eta * dw; b -= eta * db
print(f"mini-batch : w={w:.4f} b={b:.4f} loss={loss(w, b):.4f}")
print("\n(true relationship: w=3, b=2 -- all three land close, but Figure 11.1")
print("shows how differently smooth their paths were getting there.)")
