# ch11_program4.py
# Learning-rate schedules: step decay, cosine decay, and linear warmup
# followed by cosine decay -- defined and compared, then a well-timed decay
# is actually applied to the RMSProp-on-the-ravine run that plateaued in
# Program 3.

import numpy as np

def step_decay(epoch, eta0, drop=0.5, step_size=100):
    return eta0 * (drop ** (epoch // step_size))

def cosine_decay(epoch, eta0, eta_min, T):
    return eta_min + 0.5 * (eta0 - eta_min) * (1 + np.cos(np.pi * epoch / T))

def warmup_cosine(epoch, eta0, eta_min, warmup_epochs, T):
    if epoch < warmup_epochs:
        return eta0 * epoch / warmup_epochs
    t = epoch - warmup_epochs
    return eta_min + 0.5 * (eta0 - eta_min) * (1 + np.cos(np.pi * t / (T - warmup_epochs)))

def hold_then_cosine_decay(epoch, eta0, eta_min, decay_start, T):
    """Common in practice: hold eta0 constant, decay only near the end."""
    if epoch < decay_start:
        return eta0
    t = epoch - decay_start
    return eta_min + 0.5 * (eta0 - eta_min) * (1 + np.cos(np.pi * t / (T - decay_start)))

print("Four schedules, sampled at the same checkpoints (eta0=0.1, T=500):")
checkpoints = [0, 50, 100, 200, 300, 400, 499]
print(f"{'epoch':>6} {'step_decay':>12} {'cosine_decay':>14} {'warmup_cosine':>15} {'hold_then_cos':>15}")
for e in checkpoints:
    sd = step_decay(e, eta0=0.1, drop=0.5, step_size=100)
    cd = cosine_decay(e, eta0=0.1, eta_min=0.0, T=500)
    wc = warmup_cosine(e, eta0=0.1, eta_min=0.0, warmup_epochs=20, T=500)
    ht = hold_then_cosine_decay(e, eta0=0.1, eta_min=0.001, decay_start=400, T=500)
    print(f"{e:>6} {sd:>12.5f} {cd:>14.5f} {wc:>15.5f} {ht:>15.5f}")

# --- Apply hold-then-decay to Chapter 11's RMSProp-on-the-ravine example ---
# (the exact same Celsius-to-Fahrenheit problem and RMSProp update rule as
# Program 3, which plateaued at loss=0.952504 with a FIXED eta=0.1.)
C = np.array([0.0, 10.0, 20.0, 30.0])
F = np.array([32.0, 50.0, 68.0, 86.0])

def grad(w, b):
    F_hat = w * C + b
    dw = 2 * np.mean(C * (F_hat - F))
    db = 2 * np.mean(F_hat - F)
    return dw, db

def loss(w, b):
    return np.mean((F - (w * C + b)) ** 2)

def run_rmsprop_scheduled(schedule, epochs, report_at, beta=0.9, eps=1e-8):
    w, b, sw, sb = 0.0, 0.0, 0.0, 0.0
    for epoch in range(1, epochs + 1):
        eta = schedule(epoch)
        dw, db = grad(w, b)
        sw = beta * sw + (1 - beta) * dw ** 2
        sb = beta * sb + (1 - beta) * db ** 2
        w -= eta * dw / (np.sqrt(sw) + eps)
        b -= eta * db / (np.sqrt(sb) + eps)
        if epoch in report_at:
            print(f"  epoch {epoch:>6} (eta={eta:.5f}): w={w:.4f} b={b:.4f} loss={loss(w,b):.6f}")

print("\nRMSProp + hold-then-cosine-decay (eta0=0.1 until epoch 400, then decays")
print("to 0.001 by epoch 500) on the same ravine:")
good_schedule = lambda e: hold_then_cosine_decay(e, eta0=0.1, eta_min=0.001, decay_start=400, T=500)
run_rmsprop_scheduled(good_schedule, epochs=500, report_at={1, 100, 300, 400, 420, 450, 480, 500})
print("\n(Program 3's FIXED eta=0.1 RMSProp plateaued at loss=0.952504 after 500 epochs.)")

print("\nFor contrast, decaying too EARLY instead (decay_start=100, same 500 epochs):")
early_schedule = lambda e: hold_then_cosine_decay(e, eta0=0.1, eta_min=0.001, decay_start=100, T=500)
run_rmsprop_scheduled(early_schedule, epochs=500, report_at={500})
print("(decaying before the optimizer has had time to approach the minimum")
print(" leaves it stranded, far worse than never decaying at all)")
