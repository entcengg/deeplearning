# ch11_program2.py
# Five steps of plain GD, momentum, RMSProp, and Adam on the same tiny
# problem, f(w) = (w-3)^2, so each update rule's mechanics can be
# checked by hand.

import numpy as np

def grad(w):
    return 2 * (w - 3)          # f(w) = (w-3)^2

eta = 0.1
steps = 5

print("Plain GD:")
w = 0.0
for t in range(1, steps + 1):
    g = grad(w)
    w = w - eta * g
    print(f"  t={t}: grad={g:.4f}  w={w:.4f}")

print("\nMomentum (beta=0.9):")
w, v = 0.0, 0.0
for t in range(1, steps + 1):
    g = grad(w)
    v = 0.9 * v + 0.1 * g
    w = w - eta * v
    print(f"  t={t}: grad={g:.4f}  v={v:.4f}  w={w:.4f}")

print("\nRMSProp (beta=0.9):")
w, s = 0.0, 0.0
eps = 1e-8
for t in range(1, steps + 1):
    g = grad(w)
    s = 0.9 * s + 0.1 * g ** 2
    w = w - eta * g / (np.sqrt(s) + eps)
    print(f"  t={t}: grad={g:.4f}  s={s:.4f}  w={w:.4f}")

print("\nAdam (beta1=0.9, beta2=0.999):")
w, m, v = 0.0, 0.0, 0.0
for t in range(1, steps + 1):
    g = grad(w)
    m = 0.9 * m + 0.1 * g
    v = 0.999 * v + 0.001 * g ** 2
    m_hat = m / (1 - 0.9 ** t)
    v_hat = v / (1 - 0.999 ** t)
    w = w - eta * m_hat / (np.sqrt(v_hat) + eps)
    print(f"  t={t}: grad={g:.4f}  m_hat={m_hat:.4f}  v_hat={v_hat:.6f}  w={w:.4f}")
