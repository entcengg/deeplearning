# ch11_program3.py
# Momentum, RMSProp, and Adam on the exact Celsius-to-Fahrenheit ravine
# from Chapters 4-5-10, where plain gradient descent needed 20000 epochs.

import numpy as np

C = np.array([0.0, 10.0, 20.0, 30.0])
F = np.array([32.0, 50.0, 68.0, 86.0])

def grad(w, b):
    F_hat = w * C + b
    dw = 2 * np.mean(C * (F_hat - F))
    db = 2 * np.mean(F_hat - F)
    return dw, db

def loss(w, b):
    return np.mean((F - (w * C + b)) ** 2)

def run_momentum(eta, beta, epochs, report_at):
    w, b, vw, vb = 0.0, 0.0, 0.0, 0.0
    for epoch in range(1, epochs + 1):
        dw, db = grad(w, b)
        vw = beta * vw + (1 - beta) * dw
        vb = beta * vb + (1 - beta) * db
        w -= eta * vw; b -= eta * vb
        if epoch in report_at:
            print(f"  epoch {epoch:>6}: w={w:.4f} b={b:.4f} loss={loss(w,b):.6f}")

def run_rmsprop(eta, beta, epochs, report_at, eps=1e-8):
    w, b, sw, sb = 0.0, 0.0, 0.0, 0.0
    for epoch in range(1, epochs + 1):
        dw, db = grad(w, b)
        sw = beta * sw + (1 - beta) * dw ** 2
        sb = beta * sb + (1 - beta) * db ** 2
        w -= eta * dw / (np.sqrt(sw) + eps)
        b -= eta * db / (np.sqrt(sb) + eps)
        if epoch in report_at:
            print(f"  epoch {epoch:>6}: w={w:.4f} b={b:.4f} loss={loss(w,b):.6f}")

def run_adam(eta, beta1, beta2, epochs, report_at, eps=1e-8):
    w, b, mw, mb, vw, vb = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    for epoch in range(1, epochs + 1):
        dw, db = grad(w, b)
        mw = beta1 * mw + (1 - beta1) * dw
        mb = beta1 * mb + (1 - beta1) * db
        vw = beta2 * vw + (1 - beta2) * dw ** 2
        vb = beta2 * vb + (1 - beta2) * db ** 2
        mw_hat = mw / (1 - beta1 ** epoch); mb_hat = mb / (1 - beta1 ** epoch)
        vw_hat = vw / (1 - beta2 ** epoch); vb_hat = vb / (1 - beta2 ** epoch)
        w -= eta * mw_hat / (np.sqrt(vw_hat) + eps)
        b -= eta * mb_hat / (np.sqrt(vb_hat) + eps)
        if epoch in report_at:
            print(f"  epoch {epoch:>6}: w={w:.4f} b={b:.4f} loss={loss(w,b):.6f}")

print("Momentum (eta=0.001, beta=0.9) -- plain GD needed 20000 epochs to reach loss~0:")
run_momentum(eta=0.001, beta=0.9, epochs=10000, report_at={1000, 2000, 4000, 6000, 10000})

print("\nRMSProp (eta=0.1, beta=0.9):")
run_rmsprop(eta=0.1, beta=0.9, epochs=500, report_at={1, 10, 100, 300, 500})

print("\nAdam (eta=0.1, beta1=0.9, beta2=0.999):")
run_adam(eta=0.1, beta1=0.9, beta2=0.999, epochs=1500, report_at={100, 500, 1000, 1500})
