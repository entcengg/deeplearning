# Chapter 11 · Gradient Descent and Optimizers

Code for Chapter 11 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 10](../chapter-10-backpropagation/README.md) · [Chapter 12 →](../chapter-12-regularization-and-generalization/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 11.1.1 Program 1: Three Kinds of Noise | Batch, stochastic, and mini-batch gradient descent on the same data | [`ch11_program1.py`](ch11_program1.py) | [ch11_program1.txt](expected_output/ch11_program1.txt) | < 1 s |
| 2 | 11.5 Program 2: The Update Rules, by Hand | Five steps of each optimizer on a single-parameter problem | [`ch11_program2.py`](ch11_program2.py) | [ch11_program2.txt](expected_output/ch11_program2.txt) | < 1 s |
| 3 | 11.6 The Ravine, Revisited | Momentum, RMSProp, and Adam on the ravine that stumped plain gradient descent | [`ch11_program3.py`](ch11_program3.py) | [ch11_program3.txt](expected_output/ch11_program3.txt) | < 1 s |
| 4 | 11.8 Learning Rate Scheduling | Three schedules, defined and applied to the exact ravine that plateaued in Program 3 | [`ch11_program4.py`](ch11_program4.py) | [ch11_program4.txt](expected_output/ch11_program4.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-11-gradient-descent-and-optimizers
python ch11_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch11_notebook.ipynb`](ch11_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.
