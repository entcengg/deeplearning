# Appendix B companion file: every snippet quoted in "NumPy Reference"
# lives here, in the order it appears in the appendix, so the whole
# file can be run top to bottom to reproduce every captured output.

import numpy as np

print("=== B.1 creating arrays ===")
a = np.array([1, 2, 3])
b = np.array([1.0, 2, 3])
z = np.zeros((2, 3))
o = np.ones(4)
r = np.arange(0, 10, 2)
lin = np.linspace(0, 1, 5)
print(a.dtype, b.dtype)
print(z)
print(o)
print(r)
print(lin)

print("=== B.2 shape, reshape, transpose ===")
M = np.arange(6).reshape(2, 3)
print(M)
print(M.shape, M.T.shape)
print(M.T)

print("=== B.3 indexing and slicing ===")
x = np.arange(10)
print(x[2:5])
print(x[::-1])
mask = x > 5
print(x[mask])

print("=== B.3 view vs copy ===")
x = np.arange(10)
view = x[2:5]
view[0] = 999
print(x)

x2 = np.arange(10)
copy = x2[x2 > 5]
copy[0] = -1
print(x2)

print("=== B.4 broadcasting ===")
X = np.arange(12).reshape(4, 3).astype(float)
bias = np.array([100.0, 200.0, 300.0])
print(X + bias)

print("=== B.5 reductions along an axis ===")
scores = np.array([[2.0, 1.0, 0.1],
                    [0.5, 2.5, 1.0]])
print(scores.sum())
print(scores.sum(axis=0))
print(scores.sum(axis=1))
row_max = scores.max(axis=1, keepdims=True)
print(row_max.shape)
weights = np.exp(scores - row_max)
weights = weights / weights.sum(axis=1, keepdims=True)
print(weights)
print(weights.sum(axis=1))

print("=== B.6 matrix and vector products ===")
W = np.array([[1.0, 0.0, 2.0],
              [-1.0, 3.0, 1.0]])
v = np.array([2.0, 1.0, 0.0])
print(W @ v)
try:
    W @ np.array([1.0, 2.0])
except ValueError as e:
    print("ValueError:", e)

print("=== B.7 linear algebra basics ===")
vn = np.array([3.0, -4.0])
print(np.linalg.norm(vn))

Xd = np.array([[1.0, 1.0], [1.0, 2.0], [1.0, 3.0]])
yd = np.array([2.0, 3.0, 5.0])
coeffs, *_ = np.linalg.lstsq(Xd, yd, rcond=None)
print(coeffs)

print("=== B.8 random numbers and reproducibility ===")
rng = np.random.default_rng(0)
print(rng.normal(size=3))
print(rng.integers(0, 10, size=3))

np.random.seed(0)
print(np.random.rand(3))

print("=== B.9 stacking and concatenating ===")
sa = np.array([1.0, 2.0])
sb = np.array([3.0, 4.0])
print(np.stack([sa, sb]))
print(np.stack([sa, sb], axis=1))
print(np.concatenate([sa, sb]))

print("=== B.10 saving and loading ===")
arr = np.array([[1.0, 2.0], [3.0, 4.0]])
np.savez("appB_demo.npz", weights=arr, note=np.array([1]))
loaded = np.load("appB_demo.npz")
print(sorted(loaded.files))
print(loaded["weights"])

print("=== B.11 mistake: integer array in-place true division ===")
counts = np.array([1, 2, 3])
print(counts.dtype)
try:
    counts /= 2
except TypeError as e:
    print("TypeError:", e)

print("=== B.11 mistake: view vs copy recap (already shown in B.3) ===")
print("see B.3 above -- slicing returns a view, boolean/fancy indexing returns a copy")
