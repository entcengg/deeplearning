# Appendix B · NumPy Reference

Companion file for Appendix B of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Appendix A](../appendix-a-python-refresher/README.md) · [Appendix C →](../appendix-c-pytorch-reference/README.md)

Every code listing in Appendix B comes from one file, [`appB_snippets.py`](appB_snippets.py), in the order the appendix prints them, and every output listing in the appendix comes from running it. Its complete output is in [`expected_output/appB_snippets.txt`](expected_output/appB_snippets.txt). Runtime: < 1 s on a 2-core CPU.

```bash
cd appendix-b-numpy-reference
python appB_snippets.py
```

The notebook [`appB_notebook.ipynb`](appB_notebook.ipynb) runs the same file in Jupyter or Google Colab.

## Listings in this file

| Listing | What it shows |
|:--|:--|
| Listing B.1 | Five ways to create an array |
| Listing B.3 | Shape, reshape, and transpose |
| Listing B.5 | Basic slicing and boolean masking |
| Listing B.7 | A slice is a view; a boolean-indexed result is a copy |
| Listing B.9 | A (4, 3) batch plus a (3,) bias vector |
| Listing B.11 | Reducing a matrix along each axis, and a real normalization pattern |
| Listing B.13 | Matrix-vector multiplication, and the shape-mismatch error — reusing Chapter 3, Program 2's exact numbers |
| Listing B.15 | Vector norm and an ordinary-least-squares fit |
| Listing B.17 | The modern Generator API and the legacy global-seed API |
| Listing B.19 | `stack` creates a new axis; `concatenate` does not |
| Listing B.21 | Saving several named arrays with `np.savez`, and loading them back |
| Listing B.23 | In-place true division on an integer array does not upcast — it raises |

## Libraries used

NumPy.

## Notes

- Running the file saves `appB_demo.npz` in this folder (Listing B.21).
