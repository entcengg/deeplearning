# Appendix D companion file: every snippet quoted in "TensorFlow/Keras
# Reference" lives here, in the order it appears in the appendix, so
# the whole file can be run top to bottom to reproduce every captured
# output. Run with stdout captured separately from stderr -- Keras
# prints CPU/oneDNN informational noise to stderr on import, exactly
# as Chapter 13's own Keras program (ch13_program3.py) does.

import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import numpy as np
import tensorflow as tf
import keras
from keras import layers

keras.utils.set_random_seed(0)

print("=== D.1 building a model: the Sequential API ===")
model = keras.Sequential([
    layers.Input(shape=(3,)),
    layers.Dense(4, activation="relu"),
    layers.Dense(1),
])
for layer in model.layers:
    print(layer.name, layer.output.shape, layer.count_params())
print("total params:", model.count_params())

print("=== D.2 the layer zoo: layers build lazily, on first call ===")
fresh = layers.Dense(4)
try:
    fresh.count_params()
except ValueError as e:
    print("ValueError:", e)

dense = layers.Dense(4)
out = dense(tf.zeros((1, 3)))
print(out.shape, dense.count_params())

conv = layers.Conv2D(8, 3)
out = conv(tf.zeros((1, 10, 10, 1)))
print(out.shape, conv.count_params())

lstm = layers.LSTM(8)
out = lstm(tf.zeros((1, 5, 4)))
print(out.shape, lstm.count_params())

print("=== D.3 compile, fit, evaluate, predict ===")
X = np.array([[0., 0., 1.], [1., 0., 0.], [0., 1., 0.], [1., 1., 1.]], dtype="float32")
y = np.array([0., 1., 1., 0.], dtype="float32")

model.compile(optimizer="adam", loss="mse", metrics=["mae"])
history = model.fit(X, y, epochs=5, verbose=0)
print([round(float(l), 4) for l in history.history["loss"]])
loss, mae = model.evaluate(X, y, verbose=0)
print(round(float(loss), 4), round(float(mae), 4))
preds = model.predict(X, verbose=0)
print(preds.shape)

print("=== D.4 callbacks: EarlyStopping ===")
keras.utils.set_random_seed(0)
model2 = keras.Sequential([layers.Input(shape=(3,)), layers.Dense(4, activation="relu"), layers.Dense(1)])
model2.compile(optimizer="adam", loss="mse")
callback = keras.callbacks.EarlyStopping(monitor="loss", patience=2, min_delta=0.005)
history2 = model2.fit(X, y, epochs=200, callbacks=[callback], verbose=0)
print("epochs actually run:", len(history2.history["loss"]), "of 200 requested")

print("=== D.5 saving and loading ===")
model.save("appD_demo_model.keras")
model3 = keras.models.load_model("appD_demo_model.keras")
print(np.allclose(model.predict(X, verbose=0), model3.predict(X, verbose=0)))

print("=== D.7 mistake 1: sparse vs one-hot crossentropy targets ===")
keras.utils.set_random_seed(0)
model_cls = keras.Sequential([layers.Input(shape=(3,)), layers.Dense(3, activation="softmax")])
model_cls.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
X_cls = np.array([[1., 0., 0.], [0., 1., 0.], [0., 0., 1.], [1., 0., 0.]], dtype="float32")
y_int = np.array([0, 1, 2, 0])  # integer labels, NOT one-hot -- the classic mismatch
try:
    h_wrong = model_cls.fit(X_cls, y_int, epochs=5, verbose=0)
    print("trained with no error; loss values:", [round(float(l), 4) for l in h_wrong.history["loss"]])
except ValueError as e:
    print("ValueError:", e)

keras.utils.set_random_seed(0)
model_cls2 = keras.Sequential([layers.Input(shape=(3,)), layers.Dense(3, activation="softmax")])
model_cls2.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
h_right = model_cls2.fit(X_cls, y_int, epochs=5, verbose=0)
print("with the matching loss; loss values:", [round(float(l), 4) for l in h_right.history["loss"]])

print("=== D.7 mistake 2: 'accuracy' on a regression model ===")
keras.utils.set_random_seed(0)
model_reg = keras.Sequential([layers.Input(shape=(3,)), layers.Dense(1)])
model_reg.compile(optimizer="adam", loss="mse", metrics=["accuracy"])
h_reg = model_reg.fit(X, y, epochs=5, verbose=0)
print("loss:", [round(float(v), 4) for v in h_reg.history["loss"]])
print("accuracy (meaningless here):", [round(float(v), 4) for v in h_reg.history["accuracy"]])
