# Appendix D · TensorFlow/Keras Reference

Companion file for Appendix D of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Appendix C](../appendix-c-pytorch-reference/README.md)

Every code listing in Appendix D comes from one file, [`appD_snippets.py`](appD_snippets.py), in the order the appendix prints them, and every output listing in the appendix comes from running it. Its complete output is in [`expected_output/appD_snippets.txt`](expected_output/appD_snippets.txt). Runtime: 9 s on a 2-core CPU.

```bash
cd appendix-d-tensorflow-keras-reference
python appD_snippets.py
```

The notebook [`appD_notebook.ipynb`](appD_notebook.ipynb) runs the same file in Jupyter or Google Colab.

## Listings in this file

| Listing | What it shows |
|:--|:--|
| Listing D.1 | A two-layer model, and a plain-text stand-in for `model.summary()` |
| Listing D.3 | A layer has no parameters until it has seen data once |
| Listing D.5 | Continuing with Listing D.1's model: compile, fit, evaluate, predict |
| Listing D.7 | Stopping once the loss stops improving by a meaningful margin |
| Listing D.9 | Saving and reloading a full model, architecture included |
| Listing D.11 | Integer labels against `categorical_crossentropy` fail loudly; `sparse_categorical_crossentropy` is the fix |
| Listing D.13 | ``Accuracy'' compiles and runs on a regression model — and reports a number that means nothing |

## Libraries used

NumPy, TensorFlow/Keras.

## Notes

- Needs TensorFlow: from the top folder run `python -m pip install -r requirements-tensorflow.txt`. Running the file saves `appD_demo_model.keras` in this folder (Listing D.9).
