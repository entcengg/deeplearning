# ch18_program3.py
# The payoff: a "find the marked value" retrieval task. Every sequence
# has exactly one randomly placed marker; the model must output the
# value sitting at that marked position -- a position that is DIFFERENT
# every example and unknown until the marker is seen. Part A compares a
# minimal attention-based retriever against a plain RNN (Chapter 16)
# across sequence lengths. Part B looks directly at the attention
# weights themselves: do they really point at the right position?

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


def make_batch(seq_len, n, rng):
    values = rng.standard_normal((n, seq_len)).astype(np.float32)
    positions = rng.integers(0, seq_len, size=n)
    markers = np.zeros((n, seq_len), dtype=np.float32)
    markers[np.arange(n), positions] = 1.0
    targets = values[np.arange(n), positions]
    X = np.stack([values, markers], axis=-1)          # (n, seq_len, 2)
    return torch.tensor(X), torch.tensor(targets), positions


class AttentionRetriever(nn.Module):
    """One learned query attends over learned per-position keys/values."""

    def __init__(self, d_model=16):
        super().__init__()
        self.key_proj = nn.Linear(2, d_model)
        self.val_proj = nn.Linear(2, d_model)
        self.query = nn.Parameter(torch.randn(d_model))
        self.head = nn.Linear(d_model, 1)
        self.d_model = d_model

    def forward(self, x):
        K = self.key_proj(x)                          # (batch, T, d_model)
        V = self.val_proj(x)
        scores = (K @ self.query) / self.d_model ** 0.5
        weights = torch.softmax(scores, dim=1)         # (batch, T)
        context = (weights.unsqueeze(-1) * V).sum(dim=1)
        return self.head(context).squeeze(-1), weights


class RNNRetriever(nn.Module):
    """Chapter 16's plain RNN, given the identical task."""

    def __init__(self, hidden=16):
        super().__init__()
        self.rnn = nn.RNN(input_size=2, hidden_size=hidden, batch_first=True)
        self.head = nn.Linear(hidden, 1)

    def forward(self, x):
        _, h_n = self.rnn(x)
        return self.head(h_n.squeeze(0)).squeeze(-1)


def train_and_test(model_fn, seq_len, train_rng, test_rng, epochs=300):
    torch.manual_seed(0)
    model = model_fn()
    opt = optim.Adam(model.parameters(), lr=0.01)
    X_train, y_train, _ = make_batch(seq_len, 1000, train_rng)
    X_test, y_test, _ = make_batch(seq_len, 200, test_rng)
    for _ in range(epochs):
        opt.zero_grad()
        out = model(X_train)
        pred = out[0] if isinstance(out, tuple) else out
        loss = ((pred - y_train) ** 2).mean()
        loss.backward()
        opt.step()
    with torch.no_grad():
        out = model(X_test)
        pred = out[0] if isinstance(out, tuple) else out
        test_mse = ((pred - y_test) ** 2).mean().item()
    return test_mse, y_test.var().item()


# ---------------------------------------------------------------
# Part A: test MSE vs sequence length, attention vs plain RNN.
# ---------------------------------------------------------------
print("Part A: test MSE recovering the value at a RANDOM marked position")
print(f"{'seq_len':>8}{'attention_mse':>16}{'rnn_mse':>12}{'target_var':>13}")
np.random.seed(0)
for seq_len in [10, 20, 50, 100]:
    train_rng = np.random.default_rng(seq_len)
    test_rng = np.random.default_rng(seq_len + 1000)
    att_mse, target_var = train_and_test(AttentionRetriever, seq_len, train_rng, test_rng)
    train_rng = np.random.default_rng(seq_len)
    test_rng = np.random.default_rng(seq_len + 1000)
    rnn_mse, _ = train_and_test(RNNRetriever, seq_len, train_rng, test_rng)
    print(f"{seq_len:8d}{att_mse:16.4f}{rnn_mse:12.4f}{target_var:13.4f}")

# ---------------------------------------------------------------
# Part B: do the attention weights actually point at the marker?
# Retrain one attention model at seq_len=50 and inspect 5 fresh
# test examples' full weight distributions.
# ---------------------------------------------------------------
print("\nPart B: attention weights on 5 fresh test examples, seq_len=50")
torch.manual_seed(0)
model = AttentionRetriever()
opt = optim.Adam(model.parameters(), lr=0.01)
train_rng = np.random.default_rng(50)
X_train, y_train, _ = make_batch(50, 1000, train_rng)
for _ in range(300):
    opt.zero_grad()
    pred, _ = model(X_train)
    loss = ((pred - y_train) ** 2).mean()
    loss.backward()
    opt.step()

inspect_rng = np.random.default_rng(123)
X_inspect, y_inspect, true_positions = make_batch(50, 5, inspect_rng)
with torch.no_grad():
    pred, weights = model(X_inspect)

header = (f"{'example':>8}{'true_pos':>10}{'argmax_pos':>12}"
          f"{'weight_there':>14}{'pred':>10}{'target':>10}")
print(header)
for i in range(5):
    top = weights[i].argmax().item()
    print(f"{i:8d}{true_positions[i]:10d}{top:12d}{weights[i, top].item():14.4f}"
          f"{pred[i].item():10.4f}{y_inspect[i].item():10.4f}")

np.savez("ch18_attention_weights.npz",
         weights=weights.numpy(), true_positions=true_positions)
