# Chapter 18 · Attention Mechanisms

Code for Chapter 18 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 17](../chapter-17-lstm-and-gru/README.md) · [Chapter 19 →](../chapter-19-transformers/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 18.2.1 Program 1: Scaled Dot-Product Attention, by Hand and by Framework | Scaled dot-product attention, by hand and by framework | [`ch18_program1.py`](ch18_program1.py) | [ch18_program1.txt](expected_output/ch18_program1.txt) | 2 s |
| 2 | 18.3.1 Program 2: Self-Attention, by Hand and by Framework | Self-attention over a 3-token sequence, by hand and by framework | [`ch18_program2.py`](ch18_program2.py) | [ch18_program2.txt](expected_output/ch18_program2.txt) | 2 s |
| 4 | 18.3.2 Program 4: A Self-Attention Heatmap for a Real Sentence | A self-attention heatmap for a real sentence, from actual computed weights | [`ch18_program4.py`](ch18_program4.py) | [ch18_program4.txt](expected_output/ch18_program4.txt) | < 1 s |
| 3 | 18.4.1 Program 3: Long-Range Retrieval, Attention vs. Plain RNN | Long-range retrieval: attention vs. plain RNN, plus a direct look at the learned attention weights | [`ch18_program3.py`](ch18_program3.py) | [ch18_program3.txt](expected_output/ch18_program3.txt) | 29 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-18-attention-mechanisms
python ch18_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch18_notebook.ipynb`](ch18_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, PyTorch.

## Notes

- The programs are listed in the order the book prints them: Program 4 (Section 18.3.2) comes before Program 3 (Section 18.4.1).
- Program 3 saves the learned attention weights as `ch18_attention_weights.npz` in this folder.
