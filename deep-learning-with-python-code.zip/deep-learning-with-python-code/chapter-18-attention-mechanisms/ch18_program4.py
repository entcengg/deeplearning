# ch18_program4.py
# An attention-weight heatmap for a real short sentence, computed from
# ACTUAL self-attention over hand-designed token embeddings -- extending
# Program 1's "Q, K, V given directly" framing and Program 2's
# self-attention equation from abstract tokens x1,x2,x3 to real words.
# The sentence contains a classic coreference case: "it" can only
# sensibly refer to "dog". That fact is built directly into the
# embeddings via one shared "referent" feature that ONLY "dog" and "it"
# carry -- everything else about the computation is exactly
# Equation 18.6 (scaled dot-product self-attention), run for real.

import numpy as np

sentence = ["the", "dog", "barked", "because", "it", "was", "scared"]
T = len(sentence)

# Each of the 6 "ordinary" words gets its own one-hot identity feature
# (magnitude a). "dog" and the pronoun "it" additionally share one
# "referent" feature (magnitude b) that no other word has -- a stand-in
# for the semantic fact that "it" refers to "dog" in this sentence.
# "it" itself carries NO identity feature of its own, only the referent
# feature, since a pronoun's whole content here is what it refers to.
# d_model = 6 identity dims + 1 referent dim = 7.
a, b = 2.0, 3.0
d_model = 7
identity_dim = {"the": 0, "dog": 1, "barked": 2, "because": 3, "was": 4, "scared": 5}

E = np.zeros((T, d_model))
for word, dim in identity_dim.items():
    E[sentence.index(word), dim] = a
E[sentence.index("dog"), 6] = b
E[sentence.index("it"), 6] = b

# Self-attention, exactly Equation 18.6: Q = K = V = E directly.
d_k = d_model
scores = (E @ E.T) / np.sqrt(d_k)
weights = np.exp(scores - scores.max(axis=1, keepdims=True))
weights = weights / weights.sum(axis=1, keepdims=True)

print(f"Scaled self-attention weights (divided by sqrt(d_k)={np.sqrt(d_k):.4f}):")
header = "            " + "".join(f"{w:>10s}" for w in sentence)
print(header)
for word, row in zip(sentence, weights):
    print(f"  {word:10s}" + "".join(f"{v:10.4f}" for v in row))
