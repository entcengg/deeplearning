# ch18_program1.py
# Scaled dot-product attention, computed by hand with NumPy (one query,
# three key/value pairs) and checked against the same computation done
# with raw PyTorch tensor operations (matmul + softmax).

import numpy as np
import torch
import torch.nn.functional as F

q = np.array([1.0, 0.0])
K = np.array([[1.0, 0.0],
              [0.0, 1.0],
              [1.0, 1.0]])
V = np.array([[1.0, 2.0],
              [3.0, 4.0],
              [4.0, 7.0]])
d_k = q.shape[0]

print("NumPy, step by step:")
scores = K @ q                      # one score per key
print(f"  raw scores       = {scores}")
scaled = scores / np.sqrt(d_k)
print(f"  scaled scores    = {scaled}  (divided by sqrt(d_k)={np.sqrt(d_k):.4f})")

exp_scaled = np.exp(scaled - scaled.max())   # max-subtraction, Chapter 7's overflow trick
weights = exp_scaled / exp_scaled.sum()
print(f"  attention weights = {weights}  (sum = {weights.sum():.4f})")

context = weights @ V
print(f"  context vector    = {context}")

# ---------------------------------------------------------------
# Same computation with raw PyTorch ops, no black-box attention call.
# ---------------------------------------------------------------
q_t = torch.tensor(q, dtype=torch.float32)
K_t = torch.tensor(K, dtype=torch.float32)
V_t = torch.tensor(V, dtype=torch.float32)

scores_t = K_t @ q_t
scaled_t = scores_t / torch.sqrt(torch.tensor(float(d_k)))
weights_t = F.softmax(scaled_t, dim=0)
context_t = weights_t @ V_t

print("\nPyTorch, raw tensor ops:")
print(f"  attention weights = {weights_t.numpy()}")
print(f"  context vector    = {context_t.numpy()}")
