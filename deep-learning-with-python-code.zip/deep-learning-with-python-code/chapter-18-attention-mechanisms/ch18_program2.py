# ch18_program2.py
# Self-attention: a full sequence attends to itself. Queries, keys, and
# values are all learned linear projections of the SAME input sequence
# X, computed with NumPy and checked against raw PyTorch tensor ops.

import numpy as np
import torch
import torch.nn.functional as F

# A 3-token sequence, embedding dimension 3 (e.g. 3 toy word vectors).
X = np.array([[1.0, 0.0, 1.0],
              [0.0, 1.0, 1.0],
              [1.0, 1.0, 0.0]])

# Learned projection matrices (embedding dim 3 -> key/query/value dim 2).
W_Q = np.array([[1.0, 0.0],
                [0.0, 1.0],
                [1.0, 1.0]])
W_K = np.array([[0.0, 1.0],
                [1.0, 0.0],
                [1.0, 1.0]])
W_V = np.array([[1.0, 1.0],
                [0.0, 1.0],
                [1.0, 0.0]])
d_k = W_Q.shape[1]

print("NumPy, step by step:")
Q = X @ W_Q
K = X @ W_K
V = X @ W_V
print(f"  Q =\n{Q}")
print(f"  K =\n{K}")
print(f"  V =\n{V}")

scores = (Q @ K.T) / np.sqrt(d_k)
print(f"  scaled scores (3x3, row i = token i attending to every token) =\n{scores}")

weights = np.exp(scores - scores.max(axis=1, keepdims=True))
weights = weights / weights.sum(axis=1, keepdims=True)
print(f"  attention weights (each row sums to 1) =\n{weights}")

output = weights @ V
print(f"  self-attention output =\n{output}")

# ---------------------------------------------------------------
# Same computation with raw PyTorch tensor ops.
# ---------------------------------------------------------------
X_t = torch.tensor(X, dtype=torch.float32)
W_Q_t = torch.tensor(W_Q, dtype=torch.float32)
W_K_t = torch.tensor(W_K, dtype=torch.float32)
W_V_t = torch.tensor(W_V, dtype=torch.float32)

Q_t = X_t @ W_Q_t
K_t = X_t @ W_K_t
V_t = X_t @ W_V_t
scores_t = (Q_t @ K_t.T) / torch.sqrt(torch.tensor(float(d_k)))
weights_t = F.softmax(scores_t, dim=1)
output_t = weights_t @ V_t

print("\nPyTorch, raw tensor ops:")
print(f"  attention weights =\n{weights_t.numpy()}")
print(f"  self-attention output =\n{output_t.numpy()}")
