# Chapter 6 · The Perceptron

Code for Chapter 6 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 5](../chapter-05-the-artificial-neuron/README.md) · [Chapter 7 →](../chapter-07-activation-functions/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 6.3 Program 1: Training a Perceptron on AND | The perceptron learning rule, trained on AND | [`ch06_program1.py`](ch06_program1.py) | [ch06_program1.txt](expected_output/ch06_program1.txt) | < 1 s |
| 2 | 6.6 Program 2: The Perceptron Cannot Learn XOR | The same perceptron algorithm, run on XOR | [`ch06_program2.py`](ch06_program2.py) | [ch06_program2.txt](expected_output/ch06_program2.txt) | < 1 s |
| 3 | 6.9 From One Perceptron to Many: Solving XOR by Stacking | Solving XOR by stacking three hand-designed perceptrons – no training, pure forward pass | [`ch06_program3.py`](ch06_program3.py) | [ch06_program3.txt](expected_output/ch06_program3.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-06-the-perceptron
python ch06_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch06_notebook.ipynb`](ch06_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.
