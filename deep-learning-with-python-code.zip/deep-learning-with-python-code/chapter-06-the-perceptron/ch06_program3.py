# ch06_program3.py
# Solving XOR by stacking perceptrons: two hand-designed hidden perceptrons
# (OR and NAND) feed a third (AND). No training here -- the weights are
# chosen by hand, purely to demonstrate representational capacity.

import numpy as np

def step(z):
    return 1 if z > 0 else 0

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_xor = np.array([0, 1, 1, 0])

# Hidden neuron 1: OR
w_or, b_or = np.array([1.0, 1.0]), -0.5
# Hidden neuron 2: NAND
w_nand, b_nand = np.array([-1.0, -1.0]), 1.5
# Output neuron: AND of (OR, NAND)
w_out, b_out = np.array([1.0, 1.0]), -1.5

print(f"{'x1':>3} {'x2':>3} {'h1=OR':>6} {'h2=NAND':>8} {'out':>5} {'true XOR':>9}")
all_correct = True
for xi, yi in zip(X, y_xor):
    h1 = step(w_or @ xi + b_or)
    h2 = step(w_nand @ xi + b_nand)
    out = step(w_out @ np.array([h1, h2]) + b_out)
    ok = (out == yi)
    all_correct &= ok
    print(f"{xi[0]:>3} {xi[1]:>3} {h1:>6} {h2:>8} {out:>5} {yi:>9}   {'OK' if ok else 'WRONG'}")

print(f"\nAll four predictions correct: {all_correct}")
