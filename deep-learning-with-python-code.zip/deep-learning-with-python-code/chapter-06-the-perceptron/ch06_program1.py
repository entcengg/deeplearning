# ch06_program1.py
# The perceptron learning rule, trained on the AND gate.

import numpy as np

def step(z):
    return 1 if z > 0 else 0

def train_perceptron(X, y, epochs, eta=1.0):
    m, n = X.shape
    w = np.zeros(n)
    b = 0.0
    for epoch in range(1, epochs + 1):
        errors = 0
        for xi, yi in zip(X, y):
            z = w @ xi + b
            y_hat = step(z)
            error = yi - y_hat          # 0 if correct, else +-1
            if error != 0:
                w = w + eta * error * xi
                b = b + eta * error
                errors += 1
        print(f"epoch {epoch:>2}: misclassified={errors}  w={w}  b={b:.0f}")
        if errors == 0:
            print("converged -- no misclassifications this epoch.")
            break
    return w, b

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([0, 0, 0, 1])          # AND

print("Training a perceptron on AND:")
w, b = train_perceptron(X, y, epochs=20)

print(f"\nfinal decision rule: predict 1 if {w[0]:.0f}*x1 + {w[1]:.0f}*x2 + ({b:.0f}) > 0")
print("checking all four inputs:")
for xi, yi in zip(X, y):
    z = w @ xi + b
    print(f"  x=({xi[0]},{xi[1]})  z={z:.0f}  prediction={step(z)}  true={yi}")
