# ch06_program2.py
# The SAME perceptron algorithm, unmodified, run on XOR -- which is not
# linearly separable. It never converges; it cycles forever.

import numpy as np

def step(z):
    return 1 if z > 0 else 0

def train_perceptron(X, y, epochs, eta=1.0):
    m, n = X.shape
    w = np.zeros(n)
    b = 0.0
    for epoch in range(1, epochs + 1):
        errors = 0
        for xi, yi in zip(X, y):
            z = w @ xi + b
            y_hat = step(z)
            error = yi - y_hat
            if error != 0:
                w = w + eta * error * xi
                b = b + eta * error
                errors += 1
        print(f"epoch {epoch:>2}: misclassified={errors}  w={w}  b={b:.0f}")
    return w, b

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([0, 1, 1, 0])          # XOR

print("Training a perceptron on XOR (same code, same hyperparameters):")
w, b = train_perceptron(X, y, epochs=8)
print("\n...this pattern of weights repeats forever. It never reaches zero errors.")
