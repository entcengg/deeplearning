# ch02_program4.py
# Random numbers, with and without a seed.

import numpy as np

print("Two runs WITHOUT a seed (different every time):")
print("run 1:", np.random.rand(3).round(4))
print("run 2:", np.random.rand(3).round(4))

print("\nTwo runs WITH the seed 42 (identical every time):")
np.random.seed(42)
print("run 1:", np.random.rand(3).round(4))
np.random.seed(42)
print("run 2:", np.random.rand(3).round(4))
