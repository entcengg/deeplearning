# Create a virtual environment named dlbook (one-time step)
python3 -m venv dlbook

# Activate it -- Linux / macOS:
source dlbook/bin/activate
# Activate it -- Windows (Command Prompt):
# dlbook\Scripts\activate

# Install the libraries used from Chapter 1 to Chapter 12
python -m pip install numpy pandas matplotlib scikit-learn

# The deep learning frameworks, used from Chapter 13 onward
# (safe to defer until then; see the framework's website for
# the exact command matching your operating system and GPU):
python -m pip install torch
python -m pip install tensorflow
