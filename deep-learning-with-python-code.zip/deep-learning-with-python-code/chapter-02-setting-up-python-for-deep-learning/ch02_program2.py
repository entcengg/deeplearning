# ch02_program2.py
# Check that Python and the scientific stack are installed and report versions.

import sys
print("Python     :", sys.version.split()[0])

import numpy
print("NumPy      :", numpy.__version__)

import pandas
print("pandas     :", pandas.__version__)

import matplotlib
print("Matplotlib :", matplotlib.__version__)

import sklearn
print("scikit-learn:", sklearn.__version__)

# The deep learning frameworks are optional until Chapter 13,
# so their absence is reported politely instead of crashing.
for name in ["torch", "tensorflow"]:
    try:
        module = __import__(name)
        print(f"{name:<11}:", module.__version__)
    except ImportError:
        print(f"{name:<11}: not installed yet (needed from Chapter 13)")
