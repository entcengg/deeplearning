# Chapter 2 · Setting Up Python for Deep Learning

Code for Chapter 2 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 1](../chapter-01-what-is-deep-learning/README.md) · [Chapter 3 →](../chapter-03-vectors-matrices-and-tensors/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 2.2 Installing Python and Creating an Environment | Creating an environment and installing the scientific stack (terminal commands) | [`ch02_program1_install.sh`](ch02_program1_install.sh) | — | — |
| 2 | 2.4 Checking the Installation | Checking the installed versions | [`ch02_program2.py`](ch02_program2.py) | [ch02_program2.txt](expected_output/ch02_program2.txt) | 7 s |
| 3 | 2.5 A First Job for Each Library | One small job for each core library | [`ch02_program3.py`](ch02_program3.py) | [ch02_program3.txt](expected_output/ch02_program3.txt) | < 1 s |
| Traceback example | 2.6 Reading a Traceback | A one-line program with a typo, used to practice reading a traceback | [`broken.py`](broken.py) | [broken.txt](expected_output/broken.txt) | < 1 s |
| 4 | 2.7 Randomness and Reproducibility | Random numbers, with and without a seed | [`ch02_program4.py`](ch02_program4.py) | [ch02_program4.txt](expected_output/ch02_program4.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-02-setting-up-python-for-deep-learning
python ch02_program2.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch02_notebook.ipynb`](ch02_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, pandas, Matplotlib and scikit-learn; Program 2 also reports PyTorch and TensorFlow if they are installed.

## Notes

- `ch02_program1_install.sh` is a list of terminal commands, not a Python program: type them one at a time in a terminal (the Windows activation command is in its comments). The top-level README shows the same setup using this repository's `requirements.txt`. On Google Colab, skip it: everything is already installed.
- Program 2 prints the versions installed on *your* computer, so its output will differ from the book's, which was captured before PyTorch and TensorFlow were installed.
- Program 3 saves its plot as `first_plot.png` in this folder.
- `broken.py` fails on purpose (`import torhc` is a typo for `torch`), so that you can practice reading a traceback. Your traceback shows the full path to the file where the book shows just `broken.py`.
- Program 4's first two runs are deliberately unseeded, so their numbers change every time you run it; the two seeded runs always print the values shown in the book.
