# ch02_program3.py
# One small job for each core library: NumPy computes, pandas organises,
# Matplotlib draws. The numbers describe a loss valley like Chapter 1's.

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")           # draw to a file, not to a window
import matplotlib.pyplot as plt

# --- NumPy: arithmetic on whole arrays at once ---
w_values = np.array([1.0, 2.0, 3.0, 4.0, 5.0])   # five candidate weights
loss = (w_values - 3.0) ** 2    # squares every element in one line
print("w    :", w_values)
print("loss :", loss)

# --- pandas: the same numbers, organised as a labelled table ---
table = pd.DataFrame({"w": w_values, "loss": loss})
print("\n", table, sep="")

# --- Matplotlib: the whole valley, drawn ---
w = np.linspace(0.0, 6.0, 200)
plt.figure(figsize=(6.5, 4.2))
plt.plot(w, (w - 3.0) ** 2, linewidth=2.2)
plt.scatter([3.0], [0.0], zorder=5, marker="o")
plt.annotate("lowest loss at w = 3", (3.0, 0.0),
             textcoords="offset points", xytext=(10, 12))
plt.xlabel("weight w")
plt.ylabel("loss")
plt.title("A loss valley: the picture behind gradient descent")
plt.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("first_plot.png", dpi=200)
print("\nSaved first_plot.png")
