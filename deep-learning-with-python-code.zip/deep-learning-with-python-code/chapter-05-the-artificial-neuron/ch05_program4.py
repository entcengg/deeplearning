# ch05_program4.py
# Training the SAME train_neuron function, unmodified, on a small REAL
# dataset: predicting diabetes progression from body-mass index (BMI).

import numpy as np
from sklearn.datasets import load_diabetes

def train_neuron(X, y, epochs, learning_rate, report_at):
    """Batch gradient descent for a linear neuron a = X @ w + b.
    X has shape (m, n): m examples, n features. Returns the trained
    w (shape (n,)), b (scalar), and the loss history."""
    m, n = X.shape
    w = np.zeros(n)
    b = 0.0
    losses = []
    for epoch in range(1, epochs + 1):
        y_hat = X @ w + b
        loss = np.mean((y - y_hat) ** 2)
        grad_w = (2 / m) * (X.T @ (y_hat - y))
        grad_b = 2 * np.mean(y_hat - y)
        w -= learning_rate * grad_w
        b -= learning_rate * grad_b
        losses.append(loss)
        if epoch in report_at:
            print(f"epoch {epoch:>6}: w={np.round(w, 3)}  b={b:>9.4f}  loss={loss:.4f}")
    return w, b, losses

# A real dataset: 442 patients, 10 baseline measurements, and a target
# that measures disease progression one year later (higher = worse).
data = load_diabetes()
print("dataset: sklearn's diabetes dataset")
print("full data shape:", data.data.shape, " target shape:", data.target.shape)

bmi = data.data[:, data.feature_names.index("bmi")].reshape(-1, 1)   # one feature, shape (442, 1)
y = data.target
print("feature used: bmi, shape", bmi.shape)

checkpoints = {1, 10, 100, 500, 1000, 2000}
w, b, losses = train_neuron(bmi, y, epochs=2000, learning_rate=0.8,
                             report_at=checkpoints)

print(f"\nfinal weight w = {w[0]:.4f}")
print(f"final bias   b = {b:.4f}")
print(f"final loss     = {losses[-1]:.4f}")

# Honest baseline: predicting the mean progression for every patient.
baseline_loss = np.mean((y - y.mean()) ** 2)
print(f"\nbaseline loss (always predict the mean) = {baseline_loss:.4f}")
print(f"trained loss is {100*(1 - losses[-1]/baseline_loss):.1f}% lower than the baseline"
      f" -- but nowhere near zero, unlike every synthetic dataset so far.")
