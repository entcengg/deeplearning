# Chapter 5 · The Artificial Neuron

Code for Chapter 5 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 4](../chapter-04-derivatives-gradients-and-the-chain-rule/README.md) · [Chapter 6 →](../chapter-06-the-perceptron/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 5.2 Program 1: The Forward Pass, by Hand and in Code | The forward pass of a single neuron, with any number of inputs, plus a preview of how the activation changes the output | [`ch05_program1.py`](ch05_program1.py) | [ch05_program1.txt](expected_output/ch05_program1.txt) | < 1 s |
| 2 | 5.4 Training a Neuron with One Input | Training a one-input neuron with the general vector form, to convergence | [`ch05_program2.py`](ch05_program2.py) | [ch05_program2.txt](expected_output/ch05_program2.txt) | < 1 s |
| 3 | 5.5 Training a Neuron with Several Inputs | The identical training function, applied unmodified to a neuron with two inputs | [`ch05_program3.py`](ch05_program3.py) | [ch05_program3.txt](expected_output/ch05_program3.txt) | < 1 s |
| 4 | 5.8 Program 4: A Real Dataset | The unmodified training function, now on a real, noisy, 442-patient dataset | [`ch05_program4.py`](ch05_program4.py) | [ch05_program4.txt](expected_output/ch05_program4.txt) | 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-05-the-artificial-neuron
python ch05_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch05_notebook.ipynb`](ch05_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy, scikit-learn.
