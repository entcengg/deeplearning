# ch05_program2.py
# Training a neuron with ONE input: revisiting Chapter 1's Celsius-to-
# Fahrenheit model, now written with the general vector form w.x + b.

import numpy as np

def train_neuron(X, y, epochs, learning_rate, report_at):
    """Batch gradient descent for a linear neuron a = X @ w + b.
    X has shape (m, n): m examples, n features. Returns the trained
    w (shape (n,)), b (scalar), and the loss history."""
    m, n = X.shape
    w = np.zeros(n)
    b = 0.0
    losses = []
    for epoch in range(1, epochs + 1):
        y_hat = X @ w + b                      # forward pass, whole batch
        loss = np.mean((y - y_hat) ** 2)
        grad_w = (2 / m) * (X.T @ (y_hat - y))  # Eq. 4.12, generalized to a vector
        grad_b = 2 * np.mean(y_hat - y)         # Eq. 4.13, unchanged
        w -= learning_rate * grad_w
        b -= learning_rate * grad_b
        losses.append(loss)
        if epoch in report_at:
            print(f"epoch {epoch:>6}: w={np.round(w, 5)}  b={b:>9.5f}  loss={loss:.6f}")
    return w, b, losses

# Chapter 1's data, reshaped into the (m, n) convention of Chapter 3:
# one column, because there is exactly one feature, Celsius.
C = np.array([0.0, 10.0, 20.0, 30.0]).reshape(-1, 1)   # shape (4, 1)
F = np.array([32.0, 50.0, 68.0, 86.0])

checkpoints = {1, 10, 100, 1000, 5000, 10000, 20000}
w, b, losses = train_neuron(C, F, epochs=20000, learning_rate=0.001,
                             report_at=checkpoints)

print(f"\nfinal weight w = {w[0]:.5f}  (target 1.8)")
print(f"final bias   b = {b:.5f}  (target 32)")
print(f"final loss     = {losses[-1]:.8f}")
