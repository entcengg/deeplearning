# ch05_program1.py
# The forward pass of a single artificial neuron, with any number of
# inputs, and a preview of how the activation function shapes the output.

import numpy as np

def neuron_forward(x, w, b, activation):
    """One neuron: weighted sum of inputs, plus bias, through an activation."""
    z = w @ x + b          # the dot product from Chapter 3, plus a bias
    return activation(z), z

def identity(z):
    return z

def step(z):
    return 1.0 if z > 0 else 0.0

# Three inputs -- the neuron does not care whether there are 1 or 1,000.
x = np.array([2.0, 5.0, -1.0])
w = np.array([0.5, -0.2, 0.1])
b = 0.3

a_identity, z = neuron_forward(x, w, b, identity)
a_step, _ = neuron_forward(x, w, b, step)

print("inputs  x:", x)
print("weights w:", w)
print("bias    b:", b)
print(f"\nz = w . x + b = {z:.4f}")
print(f"with identity activation, a = {a_identity:.4f}  (a regression-style output)")
print(f"with step activation,     a = {a_step:.1f}  (a yes/no decision)")
