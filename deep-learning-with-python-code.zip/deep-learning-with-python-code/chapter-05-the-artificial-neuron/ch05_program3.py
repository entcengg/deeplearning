# ch05_program3.py
# The SAME training approach as Program 2, unmodified, now used on a
# neuron with TWO inputs. This is the payoff of the vector form w.x + b.

import numpy as np

def train_neuron(X, y, epochs, learning_rate, report_at):
    """Batch gradient descent for a linear neuron a = X @ w + b.
    X has shape (m, n): m examples, n features. Returns the trained
    w (shape (n,)), b (scalar), and the loss history."""
    m, n = X.shape
    w = np.zeros(n)
    b = 0.0
    losses = []
    for epoch in range(1, epochs + 1):
        y_hat = X @ w + b
        loss = np.mean((y - y_hat) ** 2)
        grad_w = (2 / m) * (X.T @ (y_hat - y))
        grad_b = 2 * np.mean(y_hat - y)
        w -= learning_rate * grad_w
        b -= learning_rate * grad_b
        losses.append(loss)
        if epoch in report_at:
            print(f"epoch {epoch:>6}: w={np.round(w, 5)}  b={b:>9.5f}  loss={loss:.6f}")
    return w, b, losses

# A small dataset with two features. True relationship: y = 2*x1 - x2 + 5
# (unknown to the training loop -- it must be recovered from data alone).
x1 = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])
x2 = np.array([3.0, 1.0, 4.0, 2.0, 5.0, 3.0])
y  = 2 * x1 - x2 + 5

X = np.stack([x1, x2], axis=1)     # shape (6, 2): the Chapter 3 convention
print("X shape:", X.shape, " y shape:", y.shape)
print("y:", y)

checkpoints = {1, 10, 100, 1000, 3000, 6000}
w, b, losses = train_neuron(X, y, epochs=6000, learning_rate=0.01,
                             report_at=checkpoints)

print(f"\nfinal weights w = {np.round(w, 5)}  (target [2, -1])")
print(f"final bias    b = {b:.5f}  (target 5)")
print(f"final loss      = {losses[-1]:.8f}")

# A fresh forward pass on a point NOT in the training data.
x_new = np.array([3.0, 4.0])
print(f"\nprediction for x=(3,4): {x_new @ w + b:.4f}  (true value: {2*3-4+5})")
