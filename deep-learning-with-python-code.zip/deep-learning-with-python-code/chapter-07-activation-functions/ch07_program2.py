# ch07_program2.py
# The activation functions: formulas, derivatives, and numerical checks
# using the central-difference technique from Chapter 4.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

def tanh_prime(z):
    return 1 - np.tanh(z) ** 2

def relu(z):
    return np.maximum(0, z)

def relu_prime(z):
    return 1.0 if z > 0 else 0.0

def central_diff(f, z, h=1e-4):
    return (f(z + h) - f(z - h)) / (2 * h)

print("Sigmoid: sigma(z) and sigma'(z) = sigma(z)(1-sigma(z))")
for z in [0.0, 2.0, -2.0, 5.0, -5.0]:
    s = sigmoid(z)
    analytical = sigmoid_prime(z)
    numeric = central_diff(sigmoid, z)
    print(f"  z={z:>5}: sigma={s:.6f}  sigma'(analytical)={analytical:.6f}  numeric={numeric:.6f}")

print("\nTanh: tanh(z) and tanh'(z) = 1 - tanh(z)^2")
for z in [0.0, 1.0, -1.0, 3.0]:
    t = np.tanh(z)
    analytical = tanh_prime(z)
    numeric = central_diff(np.tanh, z)
    print(f"  z={z:>5}: tanh={t:.6f}  tanh'(analytical)={analytical:.6f}  numeric={numeric:.6f}")

print("\nReLU: relu(z) and relu'(z), the step function of Chapter 6")
for z in [-3.0, -0.5, 0.5, 3.0]:
    r = relu(z)
    rp = relu_prime(z)
    print(f"  z={z:>5}: relu={r:.4f}   relu'={rp:.1f}")

print("\nRelation check: tanh(z) = 2*sigmoid(2z) - 1")
z0 = 1.0
print(f"  tanh({z0}) = {np.tanh(z0):.6f}   2*sigmoid(2*{z0})-1 = {2*sigmoid(2*z0)-1:.6f}")
