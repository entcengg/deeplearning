# ch07_program4.py
# GELU and SiLU (Swish): two smooth activations used throughout modern
# architectures (GELU in transformers such as BERT and GPT; SiLU/Swish in
# EfficientNet and others) in place of plain ReLU. Exact formulas, a fast
# tanh-based approximation for GELU, and numerical derivative checks using
# the same central-difference technique as Program 2.

import numpy as np
from math import erf

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

_erf_vec = np.vectorize(erf)

def gelu_exact(z):
    # GELU(z) = z * Phi(z), where Phi is the standard normal CDF,
    # Phi(z) = 0.5*(1 + erf(z/sqrt(2))).  Hendrycks & Gimpel (2016).
    z = np.asarray(z, dtype=float)
    return z * 0.5 * (1 + _erf_vec(z / np.sqrt(2)))

def gelu_tanh_approx(z):
    # The fast approximation used in practice (avoids computing erf):
    return 0.5 * z * (1 + np.tanh(np.sqrt(2 / np.pi) * (z + 0.044715 * z ** 3)))

def silu(z):
    # SiLU, also called Swish-1: z * sigmoid(z).
    # Elfwing, Uchibe & Doya (2017); Ramachandran, Zoph & Le (2017).
    return z * sigmoid(z)

def silu_prime(z):
    # Product rule on z*sigma(z): sigma(z) + z*sigma(z)*(1-sigma(z)).
    s = sigmoid(z)
    return s + z * s * (1 - s)

def central_diff(f, z, h=1e-4):
    return (f(z + h) - f(z - h)) / (2 * h)

print("GELU: exact (normal CDF) vs. the fast tanh-based approximation")
for z in [-3.0, -1.0, 0.0, 1.0, 3.0]:
    exact = float(gelu_exact(z))
    approx = float(gelu_tanh_approx(z))
    print(f"  z={z:>5}: GELU_exact={exact:.6f}  GELU_tanh_approx={approx:.6f}  "
          f"abs diff={abs(exact - approx):.2e}")

print("\nSiLU: value and derivative, analytical vs. central-difference check")
for z in [-3.0, -1.0, 0.0, 1.0, 3.0]:
    val = silu(z)
    analytical = silu_prime(z)
    numeric = central_diff(silu, z)
    print(f"  z={z:>5}: SiLU={val:.6f}  SiLU'(analytical)={analytical:.6f}  "
          f"numeric={numeric:.6f}")

print("\nUnlike ReLU, GELU and SiLU are NOT monotonic -- both dip slightly")
print("below zero for small negative z before flattening out:")
zs = np.linspace(-5, 0, 200001)
gelu_vals = gelu_exact(zs)
silu_vals = silu(zs)
g_min_idx = int(np.argmin(gelu_vals))
s_min_idx = int(np.argmin(silu_vals))
print(f"  GELU's minimum on [-5,0]: {gelu_vals[g_min_idx]:.6f} at z={zs[g_min_idx]:.4f}")
print(f"  SiLU's minimum on [-5,0]: {silu_vals[s_min_idx]:.6f} at z={zs[s_min_idx]:.4f}")

print("\nFor large |z|, GELU and SiLU both approach ReLU's behavior:")
for z in [-10.0, 10.0]:
    print(f"  z={z:>5}: GELU={float(gelu_exact(z)):.6f}  SiLU={silu(z):.6f}  "
          f"ReLU={max(0.0, z):.6f}")
