# Chapter 7 · Activation Functions

Code for Chapter 7 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 6](../chapter-06-the-perceptron/README.md) · [Chapter 8 →](../chapter-08-loss-functions/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 7.1.1 Program 1: Watching the Collapse Happen | Two linear layers collapse to one | [`ch07_program1.py`](ch07_program1.py) | [ch07_program1.txt](expected_output/ch07_program1.txt) | < 1 s |
| 2 | 7.3 Program 2: Activations and Their Derivatives | Sigmoid, tanh, and ReLU: formulas, derivatives, and numerical checks | [`ch07_program2.py`](ch07_program2.py) | [ch07_program2.txt](expected_output/ch07_program2.txt) | < 1 s |
| 3 | 7.4 The Vanishing Gradient Problem | Multiplying five saturated sigmoid slopes via the chain rule | [`ch07_program3.py`](ch07_program3.py) | [ch07_program3.txt](expected_output/ch07_program3.txt) | < 1 s |
| 4 | 7.7.1 Program 4: GELU, SiLU, and Their Non-Monotonic Dip | GELU and SiLU: exact formulas, the tanh approximation, and derivative checks | [`ch07_program4.py`](ch07_program4.py) | [ch07_program4.txt](expected_output/ch07_program4.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-07-activation-functions
python ch07_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch07_notebook.ipynb`](ch07_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.

## Notes

- The book prints Program 3 in 2 parts, with explanation in between; `ch07_program3.py` is the whole program.
