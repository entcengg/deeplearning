# ch07_program1.py
# Stacking linear layers with NO activation between them collapses to a
# single linear layer -- the algebraic reason activations are necessary.

import numpy as np

W1 = np.array([[1.0, 2.0], [0.0, 1.0], [-1.0, 1.0]])   # shape (3, 2)
b1 = np.array([0.5, -1.0, 2.0])                        # shape (3,)
W2 = np.array([[2.0, 0.0, 1.0], [1.0, -1.0, 0.0]])     # shape (2, 3)
b2 = np.array([1.0, 0.0])                              # shape (2,)

x = np.array([1.0, 3.0])

# Two-step computation: layer 1, then layer 2, no activation in between.
h = W1 @ x + b1
y_two_step = W2 @ h + b2
print("two-step result:", y_two_step)

# Combine the two layers algebraically into ONE linear layer.
W_combined = W2 @ W1
b_combined = W2 @ b1 + b2
y_combined = W_combined @ x + b_combined
print("combined result:", y_combined)

print("\nW_combined:\n", W_combined, sep="")
print("b_combined:", b_combined)
print("\nSame answer either way -- two 'layers' with no activation between")
print("them were secretly just one layer all along.")
