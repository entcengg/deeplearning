# ch07_program3.py
# The vanishing gradient: multiplying several saturated local slopes,
# via the chain rule, shrinks fast. Then: softmax, and why naive softmax
# code overflows on large inputs.

import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_prime(z):
    s = sigmoid(z)
    return s * (1 - s)

# Five "layers," each pretending its pre-activation landed deep in the
# saturated part of the sigmoid (a common situation in deep networks).
zs = [3.0, -4.0, 5.0, -3.0, 4.0]
slopes = [sigmoid_prime(z) for z in zs]
print("per-layer local slopes:", [round(float(s), 5) for s in slopes])

product = 1.0
for i, s in enumerate(slopes, start=1):
    product *= s
    print(f"  after layer {i}: cumulative product = {product:.2e}")

print(f"\nA gradient signal is multiplied by ALL FIVE of these on its way")
print(f"back through the network (Chapter 10's backpropagation). Final")
print(f"factor: {product:.2e} -- the original gradient is essentially erased.")

# --- Softmax ---
def softmax(z):
    z = z - np.max(z)          # the stability trick
    e = np.exp(z)
    return e / np.sum(e)

logits = np.array([2.0, 1.0, 0.1])
probs = softmax(logits)
print(f"\nSoftmax of {logits} = {np.round(probs, 4)}  (sums to {probs.sum():.4f})")

# --- Why the stability trick is not optional ---
big_logits = np.array([1000.0, 1001.0, 1002.0])
with np.errstate(over="raise"):
    try:
        naive = np.exp(big_logits)
        naive = naive / naive.sum()
    except FloatingPointError as err:
        print(f"\nNaive softmax on {big_logits}: OverflowError ({err})")

print("Stable softmax on the same input:", np.round(softmax(big_logits), 4))
