# Appendix A companion file: every snippet quoted in "Python Refresher"
# lives here, in the order it appears in the appendix, so the whole
# file can be run top to bottom to reproduce every captured output.

import numpy as np
import torch
import torch.nn as nn

print("=== A.2 types ===")
x = 3            # int
y = 3.0          # float
name = "epoch"   # str
done = False     # bool
nothing = None    # NoneType
print(type(x), type(y), type(name), type(done), type(nothing))
print(7 / 2)
print(7 // 2)
print(7 % 2)
print(2 ** 10)
print(0 < x < 10)
print(x is None, x == 3)

print("=== A.3 control flow ===")
losses = [0.90, 0.60, 0.62, 0.61, 0.30]
best = float("inf")
patience, bad_epochs = 2, 0
for epoch, loss in enumerate(losses, start=1):
    if loss < best:
        best, bad_epochs = loss, 0
    else:
        bad_epochs += 1
    if bad_epochs >= patience:
        print(f"stopping after epoch {epoch}: no improvement for {patience} epochs")
        break
else:
    print("completed all epochs without early stopping")

print("=== A.4 functions: multi-value return ===")
def load_split(n_train=8, n_test=2, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n_train + n_test, 4))
    y = (X.sum(axis=1) > 0).astype(int)
    return X[:n_train], y[:n_train], X[n_train:], y[n_train:]

X_train, y_train, X_test, y_test = load_split()
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

print("=== A.4 functions: *args and **kwargs ===")
def summarize(*values, **labels):
    print("values:", values)
    print("labels:", labels)

summarize(0.9667, 0.9689, model="DigitClassifier", chapter=28)

print("=== A.4 functions: mutable default argument (the bug) ===")
def add_result_buggy(value, history=[]):
    history.append(value)
    return history

print(add_result_buggy(1))
print(add_result_buggy(2))

print("=== A.4 functions: mutable default argument (the fix) ===")
def add_result_fixed(value, history=None):
    if history is None:
        history = []
    history.append(value)
    return history

print(add_result_fixed(1))
print(add_result_fixed(2))

print("=== A.5 containers ===")
report = {"n_flagged": 0, "n_features": 64, "mean_ks_statistic": 0.0242}
print(report["n_flagged"], report.get("missing_key", "not present"))
for key, value in report.items():
    print(f"{key}: {value}")

sizes_kb = [8.5, 15.4, 6.6]
sizes_kb[0] = 9.0
print(sizes_kb)

point = (37.7749, -122.4194)
try:
    point[0] = 0.0
except TypeError as e:
    print("TypeError:", e)

seen_classes = {2, 3, 2, 7, 3}
print(seen_classes)

print("=== A.6 comprehensions ===")
probs = [0.0021, 0.9098, 0.0901, 0.0003]
rounded = [round(p, 4) for p in probs]
big = [p for p in probs if p > 0.01]
squared_by_class = {i: round(p ** 2, 6) for i, p in enumerate(probs)}
print(rounded)
print(big)
print(squared_by_class)

print("=== A.7 f-strings ===")
acc, kb, ratio = 0.9667, 22.7, 3.11
print(f"accuracy: {acc:.4f}")
print(f"size: {kb:.1f} KB")
print(f"ratio: {ratio:.2f}x")
print(f"padded: [{42:5d}] [{42:<5d}] [{3.14159:.2e}]")
print(f"with commas: {1234567:,}")

print("=== A.8 classes: the nn.Module pattern ===")
class TinyNet(nn.Module):
    def __init__(self, n_in, n_out):
        super().__init__()
        self.linear = nn.Linear(n_in, n_out)

    def forward(self, x):
        return self.linear(x)

torch.manual_seed(0)
net = TinyNet(4, 2)
print(net)
print(sum(p.numel() for p in net.parameters()))

print("=== A.9 exceptions ===")
def safe_divide(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return float("nan")

print(safe_divide(10, 2), safe_divide(10, 0))

print("=== A.10 context managers ===")
xt = torch.tensor([2.0], requires_grad=True)
with torch.no_grad():
    yt = xt * 3
print(yt.requires_grad)

print("=== A.11 iteration helpers: enumerate and zip ===")
X = [0.1, 0.4, -0.2]
y = [1, 1, 0]
for i, (xi, yi) in enumerate(zip(X, y), start=1):
    print(f"example {i}: x={xi}, y={yi}")

print("=== A.12 mistake: mutating a list while iterating over it ===")
nums = [1, 2, 3, 4, 5, 6]
for n in nums:
    if n % 2 == 0:
        nums.remove(n)
print(nums)

print("=== A.12 mistake: float equality ===")
total = 0.1 + 0.1 + 0.1
print(total == 0.3, total)
print(abs(total - 0.3) < 1e-9)

print("=== A.12 mistake: forgetting super().__init__() ===")
class BrokenNet(nn.Module):
    def __init__(self, n_in, n_out):
        # super().__init__() -- forgotten on purpose, to show the result
        self.linear = nn.Linear(n_in, n_out)

try:
    broken = BrokenNet(4, 2)
except AttributeError as e:
    print("AttributeError:", e)

print("=== A.12 mistake: shadowing a builtin name ===")
list = [1, 2, 3]
print(list)
try:
    more = list(range(3))
except TypeError as e:
    print("TypeError:", e)
