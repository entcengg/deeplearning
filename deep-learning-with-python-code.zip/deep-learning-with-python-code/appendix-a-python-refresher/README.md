# Appendix A · Python Refresher

Companion file for Appendix A of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 28](../chapter-28-deploying-deep-learning-models/README.md) · [Appendix B →](../appendix-b-numpy-reference/README.md)

Every code listing in Appendix A comes from one file, [`appA_snippets.py`](appA_snippets.py), in the order the appendix prints them, and every output listing in the appendix comes from running it. Its complete output is in [`expected_output/appA_snippets.txt`](expected_output/appA_snippets.txt). Runtime: 2 s on a 2-core CPU.

```bash
cd appendix-a-python-refresher
python appA_snippets.py
```

The notebook [`appA_notebook.ipynb`](appA_notebook.ipynb) runs the same file in Jupyter or Google Colab.

## Listings in this file

| Listing | What it shows |
|:--|:--|
| Listing A.1 | Basic types and operators |
| Listing A.3 | A minimal early-stopping loop, using `for`/`else` |
| Listing A.5 | A data-loading function returning four values, unpacked by position |
| Listing A.7 | Variable positional and keyword arguments |
| Listing A.9 | A mutable default argument, and what actually happens |
| Listing A.11 | The fix: default to `None`, create the list inside the function |
| Listing A.13 | Lists, tuples, dictionaries, and sets side by side |
| Listing A.15 | List and dictionary comprehensions |
| Listing A.17 | f-strings and format specs |
| Listing A.19 | A minimal `nn.Module` subclass |
| Listing A.21 | Catching a specific exception type |
| Listing A.23 | `torch.no_grad()` as a context manager |
| Listing A.25 | `enumerate` and `zip` together |
| Listing A.27 | Removing items from a list while iterating over it skips some of them |
| Listing A.29 | Exact equality on floats fails where it looks like it should not |
| Listing A.31 | An `nn.Module` subclass that never calls its parent constructor |
| Listing A.33 | Reassigning a built-in name shadows the built-in itself |

## Libraries used

Python itself, plus NumPy and PyTorch for the examples taken from the book's programs.
