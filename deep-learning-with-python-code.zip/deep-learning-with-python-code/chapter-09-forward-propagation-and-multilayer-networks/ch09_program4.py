# ch09_program4.py
# Width versus depth: with the SAME number of ReLU neurons, how many
# "pieces" (linear regions) can a 1-D function have?

import numpy as np

def tent(x):
    return 2 * np.maximum(0, x) - 4 * np.maximum(0, x - 0.5)

def deep_narrow(x, depth):
    """`depth` layers of 2 ReLU neurons each, composing `tent` on itself."""
    y = x.copy()
    for _ in range(depth):
        y = tent(y)
    return y

def count_linear_pieces(xs, ys):
    """One more than the number of times the sampled slope changes sign."""
    diffs = np.diff(ys)
    signs = np.sign(diffs)
    signs = signs[signs != 0]
    sign_changes = np.sum(signs[1:] != signs[:-1])
    return int(sign_changes) + 1

def shallow_wide(x, n_neurons, rng):
    """ONE hidden layer, n_neurons random ReLU units, breakpoints forced
    inside [0,1] so the comparison is not won by an accident of scale."""
    breakpoints = rng.uniform(0.0, 1.0, n_neurons)
    signs = rng.choice([-1.0, 1.0], n_neurons)
    weights_out = rng.normal(0, 1, n_neurons)
    y = np.zeros_like(x)
    for bp, s, v in zip(breakpoints, signs, weights_out):
        y += v * np.maximum(0, s * (x - bp))
    return y

xs = np.linspace(0.0, 1.0, 400001)
rng = np.random.default_rng(0)
for depth in range(1, 7):
    n_neurons = 2 * depth
    deep_pieces = count_linear_pieces(xs, deep_narrow(xs, depth))
    shallow_pieces = count_linear_pieces(xs, shallow_wide(xs, n_neurons, rng))
    print(f"neurons={n_neurons:>2}  deep(depth={depth}): {deep_pieces:>3} pieces "
          f"(2^depth={2**depth})   shallow(width={n_neurons}): {shallow_pieces} pieces "
          f"(max possible {n_neurons+1})")
