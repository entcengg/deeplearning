# ch09_program1.py
# General forward propagation through a multilayer network: input ->
# hidden layer (ReLU) -> output layer (softmax).

import numpy as np

def relu(z):
    return np.maximum(0, z)

def softmax(z):
    z = z - np.max(z)
    e = np.exp(z)
    return e / np.sum(e)

def forward_pass(x, layers):
    """layers is a list of (W, b, activation) tuples. Returns the final
    output and a list of every layer's (z, a) for inspection."""
    a = x
    trace = []
    for W, b, activation in layers:
        z = W @ a + b
        a = activation(z)
        trace.append((z, a))
    return a, trace

x = np.array([1.0, -2.0, 0.5])          # 3 input features

W1 = np.array([[0.2, -0.1, 0.4],
               [0.5, 0.3, -0.2],
               [-0.3, 0.8, 0.1],
               [0.1, 0.1, 0.1]])        # shape (4, 3): 4 hidden neurons
b1 = np.array([0.1, -0.2, 0.05, 0.0])

W2 = np.array([[0.3, -0.2, 0.5, 0.1],
               [-0.1, 0.4, 0.2, -0.3]]) # shape (2, 4): 2 output neurons
b2 = np.array([0.0, 0.1])

layers = [(W1, b1, relu), (W2, b2, softmax)]
output, trace = forward_pass(x, layers)

for i, (z, a) in enumerate(trace, start=1):
    print(f"layer {i}: z = {np.round(z, 4)}")
    print(f"layer {i}: a = {np.round(a, 4)}")

print(f"\nfinal output (class probabilities): {np.round(output, 4)}")
print(f"sums to: {output.sum():.4f}")
