# ch09_program3.py
# A more realistic nonlinear example than XOR: classifying points as
# "inside" or "outside" a diamond-shaped region, |x1|+|x2| <= 1, using a
# hand-designed network with FOUR hidden step units instead of XOR's two --
# each hidden unit tests one of the four half-planes whose intersection is
# exactly the diamond, and the output ANDs all four together.

import numpy as np

def step(z):
    return np.where(z > 0, 1.0, 0.0)

# Hidden layer: four half-plane membership tests.
#   h1: x1 + x2 <= 1   (z1 = 1 - x1 - x2)
#   h2: x1 - x2 <= 1   (z2 = 1 - x1 + x2)
#   h3: -x1 + x2 <= 1  (z3 = 1 + x1 - x2)
#   h4: -x1 - x2 <= 1  (z4 = 1 + x1 + x2)
# Together, h1..h4 all equal to 1 is exactly |x1| + |x2| <= 1.
W1 = np.array([[-1.0, -1.0],
               [-1.0, 1.0],
               [1.0, -1.0],
               [1.0, 1.0]])
b1 = np.array([1.0, 1.0, 1.0, 1.0])

# Output layer: AND of all four hidden units (generalizing Chapter 9's
# 2-input AND, bias -1.5, to a 4-input AND: bias -(4 - 0.5) = -3.5).
W2 = np.array([[1.0, 1.0, 1.0, 1.0]])
b2 = np.array([-3.5])

def diamond_network(x):
    h = step(W1 @ x + b1)
    out = step(W2 @ h + b2)
    return h, out

test_points = np.array([
    [0.0, 0.0], [0.5, 0.2], [-0.3, -0.4], [0.4, -0.4],   # inside the diamond
    [1.0, 1.0], [-1.0, 1.0], [0.9, 0.9], [2.0, 0.0], [0.0, -2.0],  # outside
])
true_inside = (np.abs(test_points[:, 0]) + np.abs(test_points[:, 1]) <= 1.0).astype(float)

print(" x1    x2  | h1 h2 h3 h4 | network | |x1|+|x2|<=1 (ground truth)")
all_match = True
for xi, truth in zip(test_points, true_inside):
    h, out = diamond_network(xi)
    match = (out[0] == truth)
    all_match = all_match and match
    print(f"{xi[0]:>5.1f} {xi[1]:>5.1f} |  {h[0]:.0f}  {h[1]:.0f}  {h[2]:.0f}  {h[3]:.0f}  |"
          f"   {out[0]:.0f}     |      {truth:.0f}          {'OK' if match else 'MISMATCH'}")

print(f"\nAll {len(test_points)} test points match ground truth: {all_match}")

# A finer sanity check: evaluate on a dense grid and compare to the exact
# geometric rule everywhere, not just at the nine hand-picked points above.
rng = np.random.default_rng(0)
grid = rng.uniform(-2.5, 2.5, size=(20000, 2))
truth_grid = (np.abs(grid[:, 0]) + np.abs(grid[:, 1]) <= 1.0).astype(float)
preds_grid = np.array([diamond_network(p)[1][0] for p in grid])
agreement = np.mean(preds_grid == truth_grid)
print(f"Agreement with the exact diamond rule over 20,000 random grid points: {agreement:.4%}")
