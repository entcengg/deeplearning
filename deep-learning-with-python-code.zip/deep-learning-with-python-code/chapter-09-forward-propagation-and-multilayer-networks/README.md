# Chapter 9 · Forward Propagation and Multilayer Networks

Code for Chapter 9 of *Deep Learning with Python: A Practical and Mathematical Introduction* by Nitin Rakesh, Viraj Gulhane and Shreyas Hole.

[All chapters](../README.md) · [← Chapter 8](../chapter-08-loss-functions/README.md) · [Chapter 10 →](../chapter-10-backpropagation/README.md)

## Programs

| Program | Book section | What it does | Code | Expected output | Runtime |
|:-:|:--|:--|:--|:--|--:|
| 1 | 9.2 Program 1: A General Forward Pass | Forward propagation through an arbitrary stack of layers | [`ch09_program1.py`](ch09_program1.py) | [ch09_program1.txt](expected_output/ch09_program1.txt) | < 1 s |
| 2 | 9.3.1 Program 2: Verifying the XOR Network | The hand-designed two-layer XOR network | [`ch09_program2.py`](ch09_program2.py) | [ch09_program2.txt](expected_output/ch09_program2.txt) | < 1 s |
| 3 | 9.3.3 Beyond XOR: A Bounded Nonlinear Region | Four hidden units and an AND output, classifying points inside a diamond | [`ch09_program3.py`](ch09_program3.py) | [ch09_program3.txt](expected_output/ch09_program3.txt) | < 1 s |
| 4 | 9.5 Width Versus Depth: How Capacity Scales | Counting linear pieces: composing a tent function (depth) versus one wide ReLU layer (width), same neuron budget | [`ch09_program4.py`](ch09_program4.py) | [ch09_program4.txt](expected_output/ch09_program4.txt) | < 1 s |

Each file in [`expected_output/`](expected_output/) is the complete output of its program, exactly as printed in the book. Runtimes were measured on a 2-core CPU without a GPU; yours may be faster or slower.

## How to run

From the top folder of the repository:

```bash
cd chapter-09-forward-propagation-and-multilayer-networks
python ch09_program1.py
```

Run the programs from inside this folder, as above, so that any file a program saves lands here. To run every program in the chapter and compare each with its expected output:

```bash
python ../tools/check_outputs.py .
```

To use Jupyter or Google Colab instead, open [`ch09_notebook.ipynb`](ch09_notebook.ipynb): it contains every program of the chapter, each followed by its expected output (see the top-level README for how to open it in Colab).

## Libraries used

NumPy.
