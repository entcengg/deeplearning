# ch09_program2.py
# A hand-designed two-layer network that solves XOR -- something Chapter
# 6 proved a single perceptron can never do.

import numpy as np

def step(z):
    return np.where(z > 0, 1.0, 0.0)

# Hidden layer: neuron A behaves like OR, neuron B behaves like NAND.
W1 = np.array([[1.0, 1.0],       # neuron A: OR
               [-1.0, -1.0]])    # neuron B: NAND
b1 = np.array([-0.5, 1.5])

# Output layer: AND of the two hidden neurons.
W2 = np.array([[1.0, 1.0]])
b2 = np.array([-1.5])

def xor_network(x):
    z1 = W1 @ x + b1
    a1 = step(z1)
    z2 = W2 @ a1 + b2
    a2 = step(z2)
    return a1, a2

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
y_xor = np.array([0, 1, 1, 0])

print("x1  x2 | h_A(OR)  h_B(NAND) | output | true XOR")
for xi, yi in zip(X, y_xor):
    a1, a2 = xor_network(xi)
    print(f" {xi[0]:.0f}   {xi[1]:.0f} |   {a1[0]:.0f}         {a1[1]:.0f}     |   {a2[0]:.0f}    |    {yi}")

print("\nEvery row matches -- two layers of the SAME kind of unit that")
print("failed alone in Chapter 6 solve XOR together.")
